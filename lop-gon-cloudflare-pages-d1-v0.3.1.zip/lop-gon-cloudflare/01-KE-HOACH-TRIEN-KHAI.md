# 01 — Kế hoạch triển khai Lớp Gọn

## 1. Mục tiêu

Triển khai một PWA quản lý trung tâm với mức phí dự kiến 399.000–499.000 đồng/năm, ưu tiên:

- Trung tâm có 100–500 học sinh.
- Không giới hạn số lớp.
- 1–5 email quản lý.
- Không cần nhân viên kỹ thuật tại trung tâm.
- Chi phí hạ tầng ban đầu gần 0 đồng.
- Không tích hợp ngân hàng, SMS hoặc Zalo API trong gói rẻ.

## 2. Kiến trúc chốt

```text
Cloudflare Pages
├── React/Vite PWA
├── URL pages.dev
└── Pages Functions /api/*

Cloudflare D1 Free
├── 1 CONTROL_DB
└── 9 TENANT_DB
```

`CONTROL_DB` lưu:

- Trung tâm.
- Email đăng nhập.
- Mật khẩu đã băm.
- Vai trò.
- Phiên đăng nhập.
- Giới hạn gói.

Mỗi `TENANT_DB` lưu riêng dữ liệu của một trung tâm:

- Học sinh và lớp.
- Điểm danh.
- Hóa đơn học phí.
- Khoản thu và phân bổ.
- Số dư.
- Ca thu ngân.
- Sao kê.
- Cổng phụ huynh.
- Audit log.

## 3. Các giai đoạn

### Giai đoạn A — Local

1. Cài Node.js 22.
2. Chạy `npm install`.
3. Chạy `npm run db:migrate:local`.
4. Chạy `npm run check`.
5. Chạy `npm run dev`.
6. Khởi tạo tài khoản tại `/bootstrap`.
7. Kiểm thử bằng dữ liệu giả, tuyệt đối chưa nhập dữ liệu thật.

Điều kiện qua giai đoạn:

- Build thành công.
- Test thành công.
- Tạo được học sinh, lớp và buổi học.
- Thu tiền và hoàn tiền cập nhật đúng công nợ.
- Trung tâm thứ hai không thấy dữ liệu trung tâm thứ nhất.

### Giai đoạn B — Cloudflare Pages thử nghiệm

1. Chạy `npm run cf:login`.
2. Chạy `npm run cf:db:create`.
3. Kiểm tra `wrangler.jsonc` không còn chuỗi `REPLACE_...`.
4. Chạy `npm run db:migrate:remote`.
5. Chạy `npm run cf:deploy`.
6. Mở `/api/health`.
7. Khởi tạo trung tâm đầu tiên.
8. Test đầy đủ trên URL `pages.dev`.

Điều kiện qua giai đoạn:

- Health trả `ok: true`.
- Đăng nhập/đăng xuất hoạt động.
- PWA cài được trên Android và iPhone.
- Import Excel chạy với file nhỏ và file gần 500 học sinh.
- Thu tiền mặt yêu cầu mở ca.
- Backup thành công.

### Giai đoạn C — Pilot một trung tâm

Thời gian pilot đề xuất: 2–4 tuần.

Phạm vi:

- Một trung tâm.
- Tối đa 100–200 học sinh trước.
- 1–3 tài khoản quản lý.
- Dùng song song với Excel/sổ cũ.
- Chưa bỏ hệ thống cũ.

Kiểm thử mỗi ngày:

- Số học sinh.
- Điểm danh.
- Tổng phải thu.
- Tổng đã thu.
- Tiền mặt theo ca.
- Chuyển khoản.
- Khoản hoàn.
- Công nợ cuối ngày.

Điều kiện mở rộng:

- Không phát sinh chênh lệch không giải thích được.
- Backup và restore thử thành công.
- Nhân viên thao tác được mà không cần hỗ trợ thường xuyên.
- Không có lỗi phân quyền nghiêm trọng.

### Giai đoạn D — 3 trung tâm

- Giữ nguyên giới hạn tối đa 500 học sinh/trung tâm.
- Theo dõi dung lượng từng D1.
- Chuẩn hóa file nhập sao kê của các ngân hàng thường dùng.
- Viết hướng dẫn một trang cho thu ngân và kế toán.
- Thiết lập lịch backup định kỳ bằng máy quản trị hoặc GitHub Actions có secret riêng.

### Giai đoạn E — Tối đa 9 trung tâm Free

- Mỗi trung tâm dùng một tenant slot.
- Không tái sử dụng slot đã từng cấp khi chưa xóa sạch và xác minh backup.
- Cảnh báo khi database đạt 60%, 75% và 90% dung lượng.
- Không nhận trung tâm thứ 10 trên kiến trúc Free.

Khi cần trung tâm thứ 10:

- Nâng Cloudflare Workers Paid/D1 phù hợp; hoặc
- Tạo một cụm triển khai thứ hai với tài khoản Cloudflare riêng và quy trình vận hành tách biệt.

Không nên âm thầm nhét nhiều trung tâm vào một tenant DB chỉ để tiếp tục miễn phí.

## 4. Kế hoạch giá

### Gói Cơ bản — 399.000 đồng/năm

- Tối đa 300 học sinh đang hoạt động.
- Tối đa 3 email.
- Không giới hạn lớp.
- Học sinh, lớp, điểm danh.
- Học phí, công nợ, biên nhận.
- Import/export.

### Gói Đầy đủ — 499.000 đồng/năm

- Tối đa 500 học sinh đang hoạt động.
- Tối đa 5 email.
- Không giới hạn lớp.
- Ca thu ngân.
- Hoàn tiền và số dư.
- Sao kê và đối soát.
- Cổng phụ huynh.
- Báo cáo nâng cao.

Không bao gồm:

- Nhập dữ liệu hộ.
- SMS/Zalo API.
- Kết nối ngân hàng tự động.
- Tùy chỉnh riêng miễn phí.
- Hỗ trợ 24/7.
- Lưu ảnh/PDF không giới hạn.

## 5. Definition of Done cho production nhỏ

Chỉ được mở thu tiền thật khi:

- `npm run check` thành công.
- Migration remote thành công.
- Test tách dữ liệu giữa hai trung tâm thành công.
- Backup và restore thành công.
- Đã đổi mật khẩu bootstrap mạnh.
- Đã xác nhận quyền owner/admin/accountant/cashier/teacher.
- Đã thử thu, hoàn một phần, đóng thừa và cấn số dư.
- Đã đối chiếu một ngày giao dịch với ngân hàng và tiền mặt thực tế.
- Có người chịu trách nhiệm xử lý sự cố.
