# 02 — Đã làm được gì trong v0.3.0

## Nền tảng

- Chuyển hoàn toàn khỏi Next.js/Supabase.
- React + Vite tạo frontend tĩnh cho Cloudflare Pages.
- Pages Functions cung cấp API cùng nguồn tại `/api/*`.
- Cloudflare D1 lưu toàn bộ dữ liệu.
- PWA manifest, service worker, offline page và icons.
- Responsive cho điện thoại và desktop.

## Kiến trúc nhiều trung tâm

- Một control database.
- Chín tenant database.
- Một trung tâm được gán một tenant slot riêng.
- Tối đa chín trung tâm trong cấu hình Free hiện tại.
- Mỗi trung tâm mặc định tối đa 500 học sinh và 5 email.
- Không giới hạn số lớp bằng business rule.
- Tenant slot đã cấp không tự tái sử dụng khi trung tâm bị tạm khóa.

## Đăng nhập và bảo mật cơ bản

- Email và mật khẩu.
- PBKDF2-SHA256 với salt riêng và 210.000 vòng.
- Session token ngẫu nhiên.
- Database chỉ lưu hash của session token.
- Cookie HttpOnly, SameSite=Lax và Secure trên HTTPS.
- Chặn request cross-site theo Origin và Sec-Fetch-Site.
- Giới hạn đăng nhập sai theo email + IP.
- Tự xóa session hết hạn khi đăng nhập.
- Phân quyền server-side theo vai trò.
- Menu giao diện ẩn chức năng không có quyền.

## Quản lý trung tâm và nhân viên

- Bootstrap hệ thống.
- Tạo trung tâm mới từ trang quản trị nền tảng.
- Tự chọn tenant slot còn trống.
- Cấp tài khoản chủ trung tâm.
- Tạo tài khoản nhân viên.
- Vai trò owner, admin, accountant, cashier, teacher.
- Đổi vai trò.
- Tạm khóa/kích hoạt tài khoản.
- Đặt lại mật khẩu tạm.
- Bảo vệ tài khoản owner.

## Học sinh

- Danh sách, tìm kiếm và phân trang.
- Tạo, cập nhật và đổi trạng thái.
- Mã học sinh duy nhất trong trung tâm.
- Giới hạn số học sinh đang hoạt động theo gói.
- Import XLSX/CSV phía trình duyệt, tự chia lô tối đa 40 dòng/API.
- Chống mã trùng trong file và database.
- Hồ sơ tổng hợp lớp, hóa đơn, giao dịch, số dư và kết quả kiểm tra.
- Link phụ huynh có token băm và thời hạn.

## Lớp và buổi học

- Tạo và cập nhật lớp.
- Ghi danh học sinh.
- Mức học phí lớp và override theo học sinh.
- Tạo buổi học.
- Trạng thái scheduled/in progress/completed/cancelled.
- Danh sách lớp và sĩ số.

## Điểm danh

- Mặc định có mặt.
- Có mặt, vắng phép, vắng không phép, đi muộn, học bù, online.
- Lưu theo lô tối đa 40 học sinh/API.
- Upsert chống trùng một học sinh/một buổi.
- Không cho hoàn tất nếu chưa lưu đủ học sinh đang ghi danh.
- Audit khi hoàn tất buổi học.

## Học phí

- Tạo hóa đơn riêng.
- Tạo hàng loạt tối đa 20 học sinh/API.
- Giao diện tự chia lô cho lớp lớn.
- Hóa đơn có invoice item.
- Chống phát hành trùng học sinh/lớp/kỳ.
- Trạng thái nháp, đã phát hành, đóng một phần, đã đóng, quá hạn và hủy.
- Không cho hủy hóa đơn đã có thanh toán.

## Thu tiền

- Tiền mặt, chuyển khoản và phương thức khác.
- Một khoản thu phân bổ tối đa 15 hóa đơn.
- Một hóa đơn được thanh toán nhiều lần.
- Kiểm tra không phân bổ vượt số tiền nhận hoặc vượt công nợ.
- Tiền đóng thừa vào số dư học sinh.
- Dùng số dư để cấn trừ hóa đơn.
- D1 batch cho các thao tác nhiều câu lệnh.
- Lưu tên người thu ngay trong tenant database.
- Biên nhận điện tử bằng link bảo mật.

## Hoàn tiền

- Hoàn một phần hoặc toàn bộ.
- Hoàn từ phần số dư chưa sử dụng trước.
- Sau đó hoàn theo payment allocation.
- Tự giảm paid amount và mở lại công nợ.
- Hoàn tiền mặt yêu cầu ca hiện tại đang mở.
- Lưu adjustment và audit log.
- Không xóa cứng payment.

## Ca thu ngân

- Mở ca và nhập tiền đầu ca.
- Chỉ một ca mở/submitted trên mỗi người.
- Thu tiền mặt gắn vào ca.
- Tính tiền phải có.
- Nhập tiền thực đếm.
- Tính chênh lệch.
- Gửi duyệt, duyệt hoặc từ chối.
- Lưu tên thu ngân và người duyệt trong tenant DB.

## Phụ huynh

- Link không cần tài khoản.
- Xem học sinh, công nợ, thanh toán, số dư, điểm danh và điểm kiểm tra.
- Báo đã chuyển khoản.
- Thông báo phụ huynh không tự gạch nợ.
- Kế toán xác nhận hoặc từ chối.
- Chống gửi thông báo giống nhau trong thời gian ngắn.
- Honeypot chống bot cơ bản.

## Sao kê ngân hàng

- Import XLSX/XLS/CSV tại trình duyệt.
- Nhận dạng một số tên cột phổ biến tiếng Việt và tiếng Anh.
- Chỉ lấy dòng tiền vào lớn hơn 0.
- Tối đa 300 dòng/file trên giao diện.
- Tự chia 15 giao dịch/API để giữ mức query thấp.
- Fingerprint chống nhập trùng.
- Đề xuất hóa đơn khi nội dung có mã hóa đơn hoặc mã học sinh.
- Kế toán phải bấm xác nhận.
- Phần vượt công nợ chuyển vào số dư.
- Có thể đánh dấu giao dịch không liên quan.

## Báo cáo và xuất dữ liệu

- Dashboard phải thu, đã thu, còn nợ và thu hôm nay.
- Số học sinh, lớp và tài khoản đang dùng.
- Báo cáo theo phương thức.
- Tuổi nợ.
- Tổng số dư học sinh.
- Export học sinh CSV.
- Export công nợ CSV.
- Export giao dịch CSV.

## Phân quyền trên giao diện

- Giáo viên chỉ thấy học sinh, lớp, điểm danh và kết quả kiểm tra.
- Giáo viên không nhận dữ liệu tài chính từ API hồ sơ học sinh/dashboard.
- Thu ngân không thấy nút hoàn tiền hoặc xuất báo cáo tài chính.
- Chỉ owner/admin được thêm học sinh và lớp.
- Chỉ owner/admin/accountant được phát hành học phí.
- Route giao diện nhạy cảm có kiểm tra vai trò; API vẫn là lớp bảo vệ chính.

## Công cụ triển khai

- Script tạo 10 D1 database.
- Tự đọc D1 ID và cập nhật `wrangler.jsonc`.
- Script migration local/remote cho cả 10 database.
- Script backup cả 10 database.
- GitHub Actions kiểm tra type, test và build.
- Unit test mật khẩu/token và validation tiền/email.

## Chưa hoàn thiện hoặc chưa xác nhận

- Chưa deploy vào tài khoản Cloudflare thật trong môi trường đóng gói.
- Chưa chạy migration trên D1 remote thật.
- Package registry của môi trường đóng gói trả HTTP 503 nên chưa có `package-lock.json` và chưa chạy build dependency thật.
- Chưa kiểm thử tải thực tế với chín trung tâm đồng thời.
- Chưa có 2FA, passkey hoặc email tự phục hồi mật khẩu.
- Chưa có multi-branch.
- Chưa có Zalo/SMS và tự động kết nối ngân hàng.
- Chưa có PDF server-side; biên nhận dùng trang web/in của trình duyệt.
- Import sao kê dùng heuristic chung, có thể cần adapter riêng theo mẫu từng ngân hàng.
- Chưa được kiểm toán bảo mật độc lập.
- Chưa phải phần mềm kế toán hoặc hóa đơn điện tử theo quy định thuế.
