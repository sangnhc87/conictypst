# Hướng dẫn đẩy Lớp Gọn lên web — dành cho người không rành kỹ thuật

## Bạn cần chuẩn bị

- Một máy tính có Internet ổn định.
- Tài khoản Cloudflare miễn phí.
- File ZIP source code Lớp Gọn đã giải nén.
- Gemini CLI hoặc công cụ Gemini có thể đọc toàn bộ thư mục và chạy terminal.
- Khoảng thời gian đủ để hoàn thành đăng nhập, tạo database, migration và kiểm tra; không nên làm vội khi đang thu học phí thật.

## Những việc bạn phải tự làm

Gemini có thể chạy phần lớn câu lệnh, nhưng bạn phải tự thực hiện hai việc nhạy cảm:

1. Khi Wrangler mở trình duyệt, tự đăng nhập Cloudflare và cấp quyền.
2. Sau deploy, tự mở `/bootstrap` và nhập email/mật khẩu quản trị đầu tiên.

Không gửi mật khẩu Cloudflare hoặc mật khẩu quản trị trung tâm vào chat.

## Cách giao việc cho Gemini

1. Giải nén ZIP.
2. Mở đúng thư mục có `package.json`, `wrangler.jsonc`, `src/`, `server/` và `functions/`.
3. Cho Gemini quyền đọc repository và chạy terminal.
4. Mở file `GEMINI-DEPLOY-PROMPT.md`.
5. Sao chép từ dòng `# PROMPT BẮT ĐẦU` đến `# PROMPT KẾT THÚC` và gửi nguyên văn cho Gemini.
6. Không rút ngắn prompt vì các đoạn cấm xóa database và cấm tự bật gói trả phí rất quan trọng.

## Quy trình bạn sẽ thấy

### Bước 1: Kiểm tra máy

Gemini kiểm tra Node.js 22, npm và source code.

### Bước 2: Cài và kiểm tra

Gemini chạy:

```bash
npm install
npm run check
```

Chỉ được tiếp tục khi TypeScript, test và build đều thành công.

### Bước 3: Đăng nhập Cloudflare

Gemini chạy:

```bash
npm run cf:login
```

Trình duyệt sẽ mở. Bạn đăng nhập đúng tài khoản Cloudflare.

### Bước 4: Tạo D1

Gemini kiểm tra tài khoản rồi chạy:

```bash
npm run cf:db:create
```

Hệ thống dự kiến sử dụng:

- Một database điều khiển.
- Chín database trung tâm.

Không được xóa database có sẵn để lấy chỗ. Khi tài khoản không đủ quota, dừng lại và lựa chọn tài khoản khác hoặc thay đổi kế hoạch một cách có kiểm soát.

### Bước 5: Tạo bảng dữ liệu

Gemini chạy:

```bash
npm run db:migrate:remote
```

Bước này tạo cấu trúc tài khoản, học sinh, lớp, điểm danh, học phí, giao dịch và báo cáo trong D1.

### Bước 6: Đẩy website

Gemini chạy:

```bash
npm run cf:deploy
```

Kết quả sẽ có địa chỉ tương tự:

```text
https://lop-gon.pages.dev
```

### Bước 7: Kiểm tra hệ thống

Gemini phải kiểm tra:

```text
/api/health
/manifest.webmanifest
/bootstrap
```

Bạn tự vào:

```text
https://<tên-project>.pages.dev/bootstrap
```

rồi tạo tài khoản quản trị đầu tiên.

### Bước 8: Thử nghiệp vụ

Tạo một học sinh thử, một lớp thử, một buổi điểm danh và một hóa đơn thử. Không dùng dữ liệu thật cho đến khi luồng thử thành công.

### Bước 9: Backup

Gemini chạy:

```bash
npm run backup
```

Lưu thư mục backup riêng tư. Không đưa backup lên GitHub công khai.

## Dấu hiệu triển khai thành công

Chỉ coi là thành công khi đủ các điều kiện:

- `npm run check` thành công.
- Có URL `pages.dev` mở được.
- `/api/health` trả `ok: true` và `database: true`.
- Bạn tạo được tài khoản bootstrap.
- Đăng xuất và đăng nhập lại được.
- Tạo được học sinh, lớp và dữ liệu thử.
- Có bản backup đầu tiên.
- Gemini tạo `DEPLOYMENT-RESULT.md` ghi kết quả thật.

## Những điều không cho Gemini làm

- Không xóa D1 database.
- Không xóa Pages project.
- Không bật gói trả phí.
- Không chuyển sang Supabase/Vercel/Firebase.
- Không tự đặt mật khẩu quản trị.
- Không bỏ qua test hoặc lỗi build.
- Không sửa trực tiếp migration đã chạy.
- Không nói “đã xong” khi chưa kiểm tra website thật.

## Sau này cập nhật phiên bản mới

Trước mỗi lần cập nhật:

```bash
npm run backup
npm run check
```

Sau đó Gemini phải:

1. Đọc `CHANGELOG.md`.
2. So sánh migration mới.
3. Không chạy lại `cf:db:create` nếu database đã tồn tại đúng.
4. Chạy `npm run db:migrate:remote` nếu có migration mới.
5. Chạy `npm run cf:deploy`.
6. Kiểm tra `/api/health` và các luồng quan trọng.
7. Ghi kết quả vào `DEPLOYMENT-RESULT.md`.

Prompt cập nhật ngắn có thể dùng:

```text
Hãy cập nhật deployment Lớp Gọn hiện có từ repository này. Trước tiên đọc README.md, CHANGELOG.md, DEPLOYMENT-CHECKLIST.md, OPERATIONS-RUNBOOK.md và DEPLOYMENT-RESULT.md. Không tạo lại hoặc xóa D1 database, không đổi kiến trúc, không bật dịch vụ trả phí. Hãy backup trước, chạy npm install và npm run check, xem migration mới, áp dụng migration remote theo đúng thứ tự, deploy Cloudflare Pages, kiểm tra /api/health và các luồng đăng nhập/học phí, rồi cập nhật DEPLOYMENT-RESULT.md bằng kết quả thật. Chỉ yêu cầu tôi thao tác khi cần xác nhận đăng nhập Cloudflare.
```

## Ba thông tin phải lưu lại

Sau khi triển khai, lưu ở nơi an toàn:

- URL `pages.dev`.
- Email quản trị đầu tiên.
- Vị trí lưu backup gần nhất.

Mật khẩu nên lưu trong password manager, không lưu vào file Markdown trong repository.
