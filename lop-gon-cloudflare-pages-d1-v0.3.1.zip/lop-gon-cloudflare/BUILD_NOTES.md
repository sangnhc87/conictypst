# Build Notes — v0.3.0

Ngày đóng gói: 27/07/2026.

## Đã kiểm tra trong môi trường đóng gói

- Node.js có sẵn: v22.16.0.
- Worker/server TypeScript chạy qua `tsc` strict với D1/Pages type stub cục bộ.
- Frontend TS/TSX chạy qua strict check với React/Router/XLSX type stub cục bộ.
- `migrations/control/0001_control.sql` chạy qua SQLite parser.
- `migrations/tenant/0001_tenant.sql` chạy qua SQLite parser.
- `migrations/tenant/0002_bank_reconciliation.sql` chạy qua SQLite parser.
- Script Node `create-databases`, `migrate-all`, `backup-all` qua `node --check`.
- Không còn tham chiếu `env.DB` của kiến trúc cũ.
- Các join `users/workspaces` chỉ nằm trong CONTROL_DB handler.
- Insert payment và cash shift đã có trường tên người thao tác denormalized.
- Quyền giao diện được đối chiếu với quyền API: giáo viên không thấy tài chính, thu ngân không thấy hoàn tiền/xuất tài chính.
- `scripts/sql-smoke-test.py` chạy thành công.
- JSON, PWA icons, tài liệu bắt buộc và secret/conflict scan đều đạt.

## Chưa chạy được trong môi trường đóng gói

`npm install`/`npm view` đã được thử nhưng package registry của môi trường đóng gói trả HTTP 503. Vì vậy chưa thể chạy thực tế:

```bash
npm run typecheck
npm run test
npm run build
npx wrangler pages dev dist
```

Gói ZIP không có `node_modules` và không có `package-lock.json`.

## Việc người triển khai bắt buộc làm

```bash
npm install
npm run check
```

Nếu các lệnh không thành công, không deploy.

Sau khi install thành công, nên commit `package-lock.json` để các lần build sau có dependency cố định.
