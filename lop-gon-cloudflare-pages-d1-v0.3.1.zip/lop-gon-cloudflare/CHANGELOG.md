# Changelog

## 0.3.1 — 2026-07-27

### Tài liệu triển khai

- Thêm `GEMINI-DEPLOY-PROMPT.md` để giao Gemini triển khai theo quy trình khóa chặt.
- Thêm `03-HUONG-DAN-DAY-WEB-VA-GIAO-GEMINI.md` cho người không rành kỹ thuật.
- Thêm `DEPLOYMENT-RESULT-TEMPLATE.md` để ghi kết quả triển khai thật.
- Bổ sung quy tắc không xóa D1, không tự bật dịch vụ trả phí và không báo thành công khi chưa kiểm tra production.
- Cập nhật version hiển thị tại health endpoint lên 0.3.1.

## 0.3.0 — 2026-07-27

### Thay đổi kiến trúc

- Thay Next.js/Supabase bằng React/Vite + Cloudflare Pages Functions + D1.
- Bỏ toàn bộ dependency Supabase.
- Bỏ external auth; dùng custom D1 auth.
- Tách CONTROL_DB và chín tenant DB.

### Thêm

- Tạo trung tâm và cấp tenant slot.
- Giới hạn 1–5 email, tối đa 500 học sinh.
- Script tạo database, migration và backup.
- Import sao kê và đối soát có xác nhận.
- Header bảo mật và chặn cross-site mutation.
- CI và unit tests cơ bản.
- Phân quyền giao diện đồng bộ với quyền API.
- Cho phép mọi tài khoản tự đổi mật khẩu và thu hồi phiên cũ.
- File mẫu học sinh/sao kê và báo cáo kiểm tra đóng gói.

### Giữ lại nghiệp vụ

- Học sinh, lớp, điểm danh.
- Học phí hàng loạt.
- Thu một phần/nhiều hóa đơn.
- Số dư và cấn trừ.
- Hoàn tiền.
- Ca thu ngân.
- Cổng phụ huynh.
- Biên nhận và báo cáo.

### Hạn chế

- Chưa build với dependency thật trong môi trường đóng gói do package registry của môi trường trả HTTP 503.
- Tối đa chín trung tâm trên cụm Free.
