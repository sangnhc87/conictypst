# Kiến trúc Cloudflare Free

## Sơ đồ

```text
Người dùng
   │ HTTPS
   ▼
Cloudflare Pages
   ├── Static React/Vite
   ├── PWA assets
   └── /api/* → Pages Functions
                    │
                    ├── CONTROL_DB
                    │      ├── workspaces
                    │      ├── users
                    │      ├── memberships
                    │      └── sessions
                    │
                    └── TENANT_1 ... TENANT_9
                           ├── students/classes
                           ├── attendance
                           ├── invoices/payments
                           ├── cash shifts
                           ├── bank transactions
                           └── audit logs
```

## Vì sao tách database

Một D1 database Free có giới hạn dung lượng riêng. Dùng một database chung cho nhiều trung tâm khiến toàn hệ thống cùng tranh một giới hạn. Tách một database cho mỗi trung tâm giúp:

- Cô lập dữ liệu vật lý tốt hơn.
- Dễ export/restore một trung tâm.
- Dễ theo dõi dung lượng.
- Tận dụng tổng số database của gói Free.

Đổi lại:

- Cấu hình có 10 bindings.
- Free chỉ phục vụ tối đa 9 trung tâm trên một cụm.
- Quản trị nền tảng phải quản lý backup nhiều file.

## Luồng xác thực

1. Browser gửi email/mật khẩu tới `/api/auth/login`.
2. CONTROL_DB tìm user.
3. Worker xác minh PBKDF2.
4. Worker tạo random session token.
5. CONTROL_DB lưu SHA-256 của token.
6. Browser nhận cookie HttpOnly.
7. Mỗi request xác định workspace và tenant slot từ CONTROL_DB.
8. Nghiệp vụ chỉ truy vấn database tenant tương ứng.

## Luồng thu tiền

1. Kiểm tra role.
2. Kiểm tra học sinh và hóa đơn trong tenant DB.
3. Kiểm tra tổng allocation.
4. Nếu tiền mặt, kiểm tra ca đang mở.
5. Dùng D1 batch để tạo payment, allocation, cập nhật invoice và số dư.
6. Ghi audit log.

## Giữ trong giới hạn Free

- Import học sinh: 40 dòng/API.
- Điểm danh: 40 dòng/API.
- Phát hành học phí: 20 hóa đơn/API.
- Thu tiền: tối đa 15 allocation/API.
- Import sao kê: 15 dòng/API.
- Giao diện tự chia file thành nhiều request.
- Query có workspace filter và index.
- Không tải toàn bộ dữ liệu khi danh sách lớn.
- Không lưu file sau import.
- Không lưu ảnh/PDF.

## Hạn chế kiến trúc

- Tối đa 9 trung tâm trong một cụm Free.
- Không có staging remote riêng khi đã dùng hết 10 D1 database; local là môi trường thử chính.
- Public parent/receipt token phải tìm lần lượt qua tối đa 9 tenant DB.
- Quản trị đa cụm chưa được xây.
- Không phù hợp ngay cho chuỗi trung tâm lớn hoặc hàng chục chi nhánh.
