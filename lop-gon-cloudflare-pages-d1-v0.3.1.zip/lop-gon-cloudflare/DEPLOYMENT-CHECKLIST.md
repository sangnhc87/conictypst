# Deployment Checklist

## A. Trước khi bắt đầu

- [ ] Node.js 22 đã cài.
- [ ] Tài khoản Cloudflare đã xác minh.
- [ ] Máy triển khai không chứa malware.
- [ ] Repository nằm trong thư mục riêng tư.
- [ ] Đã đọc `SECURITY.md`.
- [ ] Đã xác định người giữ tài khoản quản trị nền tảng.

## B. Kiểm tra source

```bash
npm install
npm run typecheck
npm run test
npm run build
```

- [ ] Tất cả lệnh thành công.
- [ ] Không bỏ qua lỗi TypeScript.
- [ ] Không deploy khi test thất bại.
- [ ] Kiểm tra `npm audit` và đánh giá cảnh báo.
- [ ] Commit/tag bản source đã deploy.

## C. Cloudflare

```bash
npm run cf:login
npm run cf:db:create
```

- [ ] Có đúng 10 database `lop-gon-*`.
- [ ] `wrangler.jsonc` không còn `REPLACE_CONTROL_DATABASE_ID`.
- [ ] `wrangler.jsonc` không còn `REPLACE_TENANT_*`.
- [ ] Database được tạo ở vị trí APAC.
- [ ] Không chia sẻ file cấu hình chứa thông tin tài khoản khác.

## D. Migration

```bash
npm run db:migrate:remote
```

- [ ] Control migration thành công.
- [ ] Tenant migration thành công trên TENANT_1 đến TENANT_9.
- [ ] Không sửa migration đã chạy; tạo migration mới khi nâng cấp.

## E. Deploy Pages

```bash
npm run cf:deploy
```

- [ ] Có URL `https://<project>.pages.dev`.
- [ ] `/api/health` trả `ok: true`.
- [ ] HTTPS hoạt động.
- [ ] Header CSP có hiệu lực.
- [ ] Route SPA mở lại được sau refresh.
- [ ] Manifest và service worker tải được.

## F. Bootstrap

- [ ] Mở `/bootstrap` chỉ khi database chưa có user.
- [ ] Tạo mật khẩu dài, duy nhất.
- [ ] Lưu mật khẩu trong password manager.
- [ ] Không dùng email/mật khẩu demo.
- [ ] Đăng xuất và đăng nhập lại thành công.
- [ ] `/bootstrap` không thể khởi tạo lần thứ hai.

## G. Kiểm thử phân quyền

Tạo tối thiểu:

- [ ] Owner.
- [ ] Accountant.
- [ ] Cashier.
- [ ] Teacher.

Xác minh:

- [ ] Teacher không thấy báo cáo tài chính.
- [ ] Teacher không thu/hoàn tiền.
- [ ] Cashier không quản lý nhân viên.
- [ ] Accountant không sửa thiết lập owner.
- [ ] Owner quản lý được thành viên.
- [ ] API trả 403 khi gọi chức năng không có quyền.

## H. Kiểm thử tách trung tâm

- [ ] Tạo trung tâm thứ hai từ `/platform`.
- [ ] Thêm dữ liệu khác nhau ở hai trung tâm.
- [ ] User trung tâm A không đọc được student ID của B.
- [ ] User trung tâm A không đọc được invoice/payment của B.
- [ ] Link phụ huynh A không mở dữ liệu B.
- [ ] Mỗi trung tâm có tenant slot khác nhau.

## I. Kiểm thử học phí

- [ ] Tạo học phí một học sinh.
- [ ] Tạo hàng loạt một lớp.
- [ ] Thử tạo trùng cùng kỳ và thấy bị chặn.
- [ ] Thu đủ.
- [ ] Thu một phần.
- [ ] Thu một khoản cho nhiều hóa đơn.
- [ ] Đóng thừa tạo số dư.
- [ ] Cấn số dư kỳ sau.
- [ ] Hoàn một phần.
- [ ] Hoàn toàn bộ.
- [ ] Công nợ sau hoàn chính xác.
- [ ] Không có nút xóa payment.

## J. Kiểm thử ca tiền mặt

- [ ] Không mở ca thì không thu tiền mặt được.
- [ ] Mở ca với tiền đầu ca.
- [ ] Thu nhiều khoản tiền mặt.
- [ ] Hoàn tiền mặt trong ca hiện tại.
- [ ] Chốt ca.
- [ ] Kiểm tra expected/count/difference.
- [ ] Người có quyền duyệt ca.

## K. Import

Có thể bắt đầu bằng `examples/hoc-sinh-mau.csv` và `examples/sao-ke-mau.csv`.

- [ ] Import 10 học sinh.
- [ ] Import file có mã trùng và thấy lỗi.
- [ ] Import gần 500 học sinh trên môi trường thử.
- [ ] Import sao kê XLSX.
- [ ] Import lại cùng file và thấy dòng trùng bị bỏ qua.
- [ ] Xác nhận giao dịch có đề xuất.
- [ ] Giao dịch không rõ không tự gạch nợ.

## L. Backup và phục hồi

```bash
npm run backup
```

- [ ] Có 10 file SQL.
- [ ] File backup có dung lượng hợp lý.
- [ ] Backup được mã hóa/lưu nơi riêng tư.
- [ ] Thử restore vào database thử nghiệm.
- [ ] Ghi ngày restore gần nhất.

## M. Trước khi pilot

- [ ] Có thỏa thuận sử dụng và chính sách dữ liệu.
- [ ] Có kênh báo lỗi.
- [ ] Có người trực xử lý tài chính sai lệch.
- [ ] Trung tâm vẫn giữ Excel/sổ đối chiếu trong pilot.
- [ ] Chưa quảng cáo SLA hoặc “không bao giờ mất dữ liệu”.

## N. Khi giao Gemini triển khai

- [ ] Đã gửi nguyên văn `GEMINI-DEPLOY-PROMPT.md`.
- [ ] Gemini đã đọc tài liệu bắt buộc trước khi chạy lệnh.
- [ ] Không cho phép Gemini xóa D1/Pages project có sẵn.
- [ ] Không cho phép tự bật dịch vụ trả phí.
- [ ] Người dùng tự đăng nhập Cloudflare trong trình duyệt.
- [ ] Người dùng tự nhập mật khẩu tại `/bootstrap`.
- [ ] Gemini đã tạo `DEPLOYMENT-RESULT.md` từ template.
- [ ] Kết quả trong báo cáo khớp log và URL production thật.
