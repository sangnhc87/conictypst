# Giới hạn và giá đề xuất

## Gói Cơ bản — 399.000 đồng/năm

- 300 học sinh đang hoạt động.
- 3 email.
- Không giới hạn lớp.
- Một chi nhánh.
- Học sinh, lớp, điểm danh.
- Học phí, thu tiền, công nợ.
- Biên nhận và báo cáo cơ bản.

## Gói Đầy đủ — 499.000 đồng/năm

- 500 học sinh đang hoạt động.
- 5 email.
- Không giới hạn lớp.
- Một chi nhánh.
- Ca thu ngân.
- Hoàn tiền và số dư.
- Import sao kê.
- Cổng phụ huynh.
- Báo cáo tài chính.

## Phí dịch vụ riêng

- Nhập dữ liệu hộ: 200.000–500.000 đồng/lần.
- Đào tạo riêng: 200.000 đồng/buổi.
- Chỉnh dữ liệu do khách nhập sai: báo giá.
- Tùy chỉnh tính năng: báo giá.

## Không bao gồm

- SMS.
- Zalo API.
- Kết nối ngân hàng tự động.
- Hóa đơn điện tử thuế.
- Nhiều chi nhánh.
- Hỗ trợ 24/7.
- Lưu file/ảnh không giới hạn.
