# Master prompt giao Gemini triển khai Lớp Gọn lên Cloudflare

## Cách sử dụng

1. Giải nén toàn bộ repository.
2. Mở thư mục repository bằng Gemini CLI hoặc công cụ Gemini có quyền đọc file và chạy terminal.
3. Dán nguyên văn prompt trong phần **PROMPT BẮT ĐẦU** bên dưới.
4. Chỉ tự thao tác khi Gemini yêu cầu mở trình duyệt đăng nhập Cloudflare hoặc nhập thông tin tài khoản quản trị đầu tiên tại `/bootstrap`.
5. Không gửi mật khẩu quản trị cho Gemini trong chat. Hãy tự nhập trực tiếp trên trang web sau khi deploy.

---

# PROMPT BẮT ĐẦU

Bạn là kỹ sư triển khai chịu trách nhiệm đưa repository **Lớp Gọn Cloudflare** này lên Cloudflare Pages bằng tài khoản Cloudflare của tôi.

Mục tiêu là triển khai đúng kiến trúc đã có trong repository:

- React + Vite tạo frontend tĩnh.
- Cloudflare Pages phục vụ website/PWA.
- Pages Functions xử lý API trong thư mục `functions/`.
- Một D1 `CONTROL_DB` quản lý tài khoản và trung tâm.
- Chín D1 `TENANT_1` đến `TENANT_9` lưu dữ liệu riêng cho tối đa chín trung tâm.
- Mỗi trung tâm tối đa 500 học sinh đang hoạt động và 1–5 tài khoản quản lý.
- URL ban đầu dùng tên miền miễn phí `*.pages.dev`.

## Quy tắc bắt buộc

1. Đọc trước các file sau:
   - `README.md`
   - `CLOUDFLARE-FREE-ARCHITECTURE.md`
   - `DEPLOYMENT-CHECKLIST.md`
   - `OPERATIONS-RUNBOOK.md`
   - `SECURITY.md`
   - `BUILD_NOTES.md`
   - `package.json`
   - `wrangler.jsonc`
   - `scripts/create-databases.mjs`
   - `scripts/migrate-all.mjs`

2. Không đổi framework, không chuyển sang Supabase, Vercel, Firebase, VPS hoặc một kiến trúc khác.

3. Không tạo tài nguyên trả phí. Nếu Cloudflare yêu cầu nâng cấp hoặc thanh toán, dừng lại và báo rõ cho tôi. Không bấm xác nhận mua gói.

4. Không xóa, đổi tên hoặc ghi đè bất kỳ D1 database, Pages project hay tài nguyên Cloudflare có sẵn nào mà không được tôi đồng ý rõ ràng.

5. Không chạy lệnh phá hủy như xóa database, xóa project, xóa dữ liệu production hoặc reset migration.

6. Không in mật khẩu, cookie phiên, token đăng nhập hoặc thông tin nhạy cảm vào báo cáo/chat.

7. Không tự đặt mật khẩu bootstrap. Sau khi deploy, chỉ đưa URL `/bootstrap` để tôi tự nhập thông tin quản trị.

8. Không sửa migration đã áp dụng trên remote. Khi cần sửa database sau này, phải tạo migration mới.

9. Không tuyên bố triển khai thành công nếu chưa kiểm tra URL thật, `/api/health`, đăng nhập và ít nhất một luồng dữ liệu thử.

10. Khi gặp lỗi, đọc log, xác định nguyên nhân và sửa tối thiểu. Không viết lại toàn bộ dự án chỉ để né lỗi cấu hình.

11. Chỉ hỏi tôi khi thật sự cần một thao tác con người, chủ yếu là:
    - Xác nhận đăng nhập Cloudflare trong trình duyệt.
    - Chọn đúng tài khoản Cloudflare nếu có nhiều tài khoản.
    - Tự nhập tài khoản quản trị tại `/bootstrap`.
    - Quyết định khi tài khoản không còn đủ quota D1 Free.

12. Trước khi dùng một câu lệnh Cloudflare có vẻ đã thay đổi, kiểm tra tài liệu chính thức mới nhất của Cloudflare. Không dựa vào blog không chính thức.

## Giai đoạn 1 — Audit repository, chưa deploy

Thực hiện:

```bash
node --version
npm --version
```

Yêu cầu Node.js 22. Nếu sai phiên bản, báo rõ cách đổi sang Node.js 22 rồi tiếp tục khi môi trường đã đúng.

Đọc `package.json` và xác nhận các script quan trọng:

```text
npm run check
npm run cf:login
npm run cf:db:create
npm run db:migrate:remote
npm run cf:deploy
npm run backup
```

Kiểm tra Git status nếu repository có Git. Không xóa thay đổi của người dùng.

Sau audit, báo ngắn:

- Stack đã nhận diện.
- Số migration control/tenant.
- D1 bindings trong `wrangler.jsonc`.
- Có còn UUID giả hay đã có ID D1 thật.
- Rủi ro hoặc xung đột phát hiện được.

Sau đó tiếp tục, không chờ xác nhận nếu không có xung đột nghiêm trọng.

## Giai đoạn 2 — Cài dependency và kiểm tra source

Chạy:

```bash
npm install
npm run check
```

`npm run check` phải hoàn thành đủ:

- TypeScript.
- Unit tests.
- Vite production build.

Xác nhận thư mục `dist/` được tạo. Với dự án React/Vite này, build command đúng là `npm run build` và output đúng là `dist`.

Nếu `npm install` hoặc build lỗi:

1. Đọc lỗi đầy đủ.
2. Kiểm tra Node.js 22.
3. Không tự nâng hàng loạt dependency.
4. Chỉ sửa đúng nguyên nhân.
5. Chạy lại `npm run check`.
6. Ghi rõ file đã sửa và lý do.

Không deploy khi `npm run check` còn lỗi.

## Giai đoạn 3 — Đăng nhập và kiểm tra Cloudflare

Chạy:

```bash
npm run cf:login
```

Khi Wrangler mở trình duyệt, yêu cầu tôi hoàn tất đăng nhập. Sau đó chạy:

```bash
npx wrangler whoami
npx wrangler d1 list
```

Trước khi tạo database:

- Xác nhận đang ở đúng tài khoản Cloudflare.
- Liệt kê các D1 database có tên bắt đầu bằng `lop-gon-`.
- Không xóa database có sẵn.
- Kiểm tra tài khoản có đủ chỗ cho tổng cộng 10 D1 database của dự án.

Nếu tài khoản đã có các database `lop-gon-control` hoặc `lop-gon-tenant-*`, phải xác minh đây có phải tài nguyên của chính dự án này hay không. Không được giả định chỉ dựa vào tên.

Nếu tài khoản không đủ quota Free:

- Dừng trước bước tạo database.
- Không xóa tài nguyên khác.
- Báo số database đang có, số còn thiếu và các lựa chọn an toàn.

## Giai đoạn 4 — Tạo và bind D1

Khi đã an toàn, chạy:

```bash
npm run cf:db:create
```

Script phải:

- Tạo `lop-gon-control`.
- Tạo `lop-gon-tenant-1` đến `lop-gon-tenant-9` nếu chưa tồn tại.
- Chọn location APAC.
- Cập nhật `database_id` thật vào `wrangler.jsonc`.

Sau đó kiểm tra:

```bash
npx wrangler d1 list
```

Đọc lại `wrangler.jsonc` và xác nhận:

- Có đúng `CONTROL_DB`.
- Có `TENANT_1` đến `TENANT_9`.
- Không còn UUID placeholder `00000000-...`.
- Mỗi binding trỏ đúng database name.
- `migrations_dir` của control là `migrations/control`.
- `migrations_dir` của tenant là `migrations/tenant`.

Không công khai toàn bộ file cấu hình trong chat nếu không cần thiết.

## Giai đoạn 5 — Migration remote

Chạy:

```bash
npm run db:migrate:remote
```

Phải áp dụng migration cho:

- `CONTROL_DB`.
- `TENANT_1` đến `TENANT_9`.

Nếu một migration thất bại:

- Không tiếp tục deploy.
- Không sửa trực tiếp database production bằng lệnh tùy tiện.
- Xác định database/binding và migration bị lỗi.
- Sửa migration chỉ khi migration đó chưa từng áp dụng thành công ở remote.
- Nếu migration đã áp dụng trước đây, tạo migration mới.
- Chạy lại kiểm tra local và remote thích hợp.

Sau migration, kiểm tra tối thiểu bằng các truy vấn chỉ đọc hoặc danh sách migration. Không chèn dữ liệu bootstrap bằng terminal.

## Giai đoạn 6 — Deploy Cloudflare Pages

Chạy lại:

```bash
npm run check
npm run cf:deploy
```

Dự án Pages mặc định:

```text
lop-gon
```

Không đổi sang một project name khác trừ khi tên đã thuộc một dự án không liên quan. Nếu xung đột, báo cho tôi trước khi chọn tên mới.

Sau deploy, ghi lại URL production dạng:

```text
https://<project>.pages.dev
```

Nếu Cloudflare yêu cầu cấu hình thủ công, bảo đảm:

- Build command: `npm run build`.
- Build output: `dist`.
- Pages Functions trong `functions/` được deploy cùng dự án.
- D1 bindings lấy từ `wrangler.jsonc`.
- Không tạo Worker/API riêng không cần thiết.

## Giai đoạn 7 — Kiểm tra deployment thật

Kiểm tra các URL:

```text
https://<project>.pages.dev/
https://<project>.pages.dev/api/health
https://<project>.pages.dev/manifest.webmanifest
https://<project>.pages.dev/bootstrap
```

`/api/health` phải trả kết quả có:

```json
{
  "ok": true,
  "database": true
}
```

Kiểm tra thêm:

- Website tải được qua HTTPS.
- Refresh một route SPA không bị 404.
- CSS và JavaScript tải thành công.
- Manifest tải được.
- Service worker không gây vòng lặp cache.
- API và frontend cùng origin.
- Không có lỗi nghiêm trọng trong console/network.

Sau đó yêu cầu tôi tự mở `/bootstrap` và nhập:

- Tên trung tâm.
- Họ tên quản trị.
- Email quản trị.
- Mật khẩu mạnh ít nhất 8 ký tự.

Không yêu cầu tôi gửi mật khẩu vào chat.

Sau khi tôi báo đã bootstrap, kiểm tra:

- `/bootstrap` không còn cho tạo hệ thống lần hai.
- Đăng xuất và đăng nhập lại được.
- Dashboard mở được.
- `/api/health` vẫn tốt.

## Giai đoạn 8 — Smoke test nghiệp vụ

Tạo dữ liệu thử tối thiểu, nhưng không dùng dữ liệu cá nhân thật:

1. Một học sinh thử.
2. Một lớp thử.
3. Ghi danh học sinh vào lớp.
4. Một buổi học và điểm danh.
5. Một hóa đơn học phí thử.
6. Một giao dịch thu thử phù hợp với quy trình.
7. Kiểm tra công nợ và biên nhận.

Không test tiền mặt nếu chưa mở ca thu ngân.

Nếu dữ liệu thử không cần giữ, xóa/điều chỉnh bằng đúng chức năng ứng dụng; không xóa trực tiếp bảng tài chính.

## Giai đoạn 9 — Backup đầu tiên

Chạy:

```bash
npm run backup
```

Xác nhận:

- Có backup control database.
- Có backup chín tenant database.
- File không rỗng.
- Thư mục backup không bị commit lên Git.

Không tải backup lên nơi công khai. Nhắc tôi lưu bản backup ở nơi riêng tư và có mã hóa.

## Giai đoạn 10 — Báo cáo kết quả

Tạo file mới trong repository:

```text
DEPLOYMENT-RESULT.md
```

Nội dung gồm:

```markdown
# Deployment Result

## Thời điểm triển khai

## Tài khoản Cloudflare
Chỉ ghi account name/ID không nhạy cảm; không ghi token.

## Pages project
- Project name:
- Production URL:

## D1
- CONTROL_DB:
- TENANT_1 đến TENANT_9:
- Migration status:

## Kiểm tra source
- npm install:
- typecheck:
- tests:
- build:

## Kiểm tra production
- /api/health:
- bootstrap:
- login:
- SPA routes:
- PWA manifest:

## Backup đầu tiên
- Thư mục:
- Kết quả:

## Các thay đổi đã thực hiện

## Vấn đề còn lại

## Bước vận hành tiếp theo
```

Trong câu trả lời cuối cùng, trình bày ngắn gọn:

- URL website.
- Các lệnh đã chạy và kết quả thật.
- Database/migration đã sẵn sàng hay chưa.
- Bootstrap và đăng nhập đã kiểm tra hay chưa.
- Backup đã tạo hay chưa.
- File nào đã sửa.
- Rủi ro còn lại.

Không dùng từ “hoàn tất” khi bất kỳ bước bắt buộc nào chưa đạt.

# PROMPT KẾT THÚC
