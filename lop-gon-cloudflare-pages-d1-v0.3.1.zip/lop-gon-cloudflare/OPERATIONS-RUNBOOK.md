# Operations Runbook

## 1. Kiểm tra hằng ngày

1. Mở `/api/health`.
2. Kiểm tra đăng nhập.
3. Kiểm tra giao dịch lỗi được trung tâm báo.
4. Kiểm tra ca chưa chốt.
5. Kiểm tra thông báo chuyển khoản chưa xử lý.
6. Không chỉnh trực tiếp database khi chưa có backup.

## 2. Backup định kỳ

Chạy trên máy quản trị đã đăng nhập Wrangler:

```bash
npm run backup
```

Kết quả:

```text
backups/YYYY-MM-DDTHH-MM-SS/
├── lop-gon-control.sql
├── lop-gon-tenant-1.sql
└── ... lop-gon-tenant-9.sql
```

Khuyến nghị:

- Backup mỗi ngày khi bắt đầu có tiền thật.
- Giữ bản hằng ngày 14 ngày.
- Giữ bản hằng tuần 8 tuần.
- Giữ bản hằng tháng 12 tháng.
- Mã hóa file backup trước khi đưa lên Drive.
- Không gửi backup qua Zalo/email không mã hóa.

## 3. Restore

Không restore đè ngay lên production.

Quy trình:

1. Dừng thao tác tài chính của trung tâm liên quan.
2. Xuất backup hiện tại.
3. Xác định database tenant slot.
4. Tạo database thử hoặc dùng môi trường local.
5. Restore file SQL vào môi trường thử.
6. Kiểm tra số học sinh, hóa đơn, payment và công nợ.
7. Chỉ restore production khi đã có phê duyệt.

Ví dụ local:

```bash
npx wrangler d1 execute TENANT_1 --local --file=backups/<folder>/lop-gon-tenant-1.sql --yes
```

Với remote, cần bảo đảm database mục tiêu sạch hoặc dùng quy trình Time Travel của D1. Không chạy file full export lên database đang có dữ liệu nếu chưa đánh giá xung đột khóa.

## 4. Sai lệch công nợ

Không sửa trực tiếp `paid_amount`.

Kiểm tra:

1. Payment gốc.
2. Payment allocations.
3. Refund/adjustment.
4. Credit ledger.
5. Invoice total/paid.
6. Audit log.

Cách xử lý đúng:

- Hoàn tiền.
- Hủy hóa đơn chưa thanh toán.
- Cấn số dư.
- Ghi nhận giao dịch mới có tham chiếu.

Cách xử lý sai:

- Xóa payment.
- UPDATE số tiền trực tiếp bằng D1 console.
- Xóa audit log.

## 5. Nhân viên quên mật khẩu

- Owner/admin mở trang Nhân viên.
- Đặt mật khẩu tạm mạnh.
- Gửi mật khẩu qua kênh riêng.
- Yêu cầu đăng nhập và đổi quy trình nội bộ.

Phiên bản này chưa có email tự phục hồi mật khẩu.

## 6. Nghi ngờ lộ mật khẩu

1. Tạm khóa user.
2. Xóa session của user trong CONTROL_DB.
3. Đặt lại mật khẩu.
4. Kiểm tra platform audit và tenant audit.
5. Kiểm tra giao dịch tài chính trong khoảng nghi ngờ.
6. Ghi biên bản sự cố.

SQL tham khảo, chỉ chạy khi đã xác định đúng user:

```sql
DELETE FROM sessions WHERE user_id = '<USER_ID>';
```

## 7. Trung tâm đạt 500 học sinh

- Chuyển học sinh đã nghỉ sang `inactive` nếu đúng nghiệp vụ.
- Không xóa lịch sử học sinh chỉ để giảm số lượng.
- Nâng gói/giới hạn chỉ sau khi kiểm tra dung lượng database.
- Không tăng trên 500 bằng sửa database mà chưa kiểm thử tải.

## 8. D1 gần đầy

Ngưỡng xử lý nội bộ:

- 60%: theo dõi hàng tuần.
- 75%: dừng tính năng lưu dữ liệu không thiết yếu.
- 90%: dừng nhận thêm dữ liệu lớn và lập kế hoạch nâng gói/archive.

Không lưu:

- PDF biên nhận.
- File Excel sau import.
- Ảnh giao dịch.
- Ảnh học sinh dung lượng lớn.

## 9. Hết 9 tenant slot

Không tạo trung tâm thứ 10 trên cụm hiện tại.

Lựa chọn:

1. Nâng Cloudflare phù hợp.
2. Triển khai cụm Lớp Gọn thứ hai.
3. Tái kiến trúc nhiều workspace/database trên gói trả phí.

Không tái sử dụng database của trung tâm đã ngừng nếu chưa:

- Backup đầy đủ.
- Có yêu cầu xóa dữ liệu hợp lệ.
- Xác minh database sạch.
- Ghi audit quyết định.

## 10. Deploy lỗi

1. Không chạy migration rollback ngẫu nhiên.
2. Xem log Pages Functions.
3. Kiểm tra `/api/health`.
4. Rollback deployment Pages về bản trước nếu frontend/API lỗi.
5. Nếu migration đã chạy, đánh giá schema trước khi rollback code.
6. Luôn tạo migration tiến về phía trước để sửa schema.

## 11. Sự cố nghiêm trọng

Sự cố nghiêm trọng gồm:

- Trung tâm thấy dữ liệu của trung tâm khác.
- Sai lệch hàng loạt công nợ.
- Mất payment.
- Không thể phục hồi database.
- Lộ backup hoặc mật khẩu quản trị.

Hành động:

1. Tạm dừng hệ thống hoặc chức năng liên quan.
2. Giữ log và backup.
3. Không xóa dấu vết.
4. Xác định phạm vi trung tâm bị ảnh hưởng.
5. Phục hồi trên môi trường thử.
6. Thông báo minh bạch cho bên bị ảnh hưởng theo nghĩa vụ áp dụng.
