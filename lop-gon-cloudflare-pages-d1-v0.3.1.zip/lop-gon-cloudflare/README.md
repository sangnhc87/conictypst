# Lớp Gọn Cloudflare — v0.3.1

PWA quản lý trung tâm giáo dục nhỏ và vừa, tối ưu để khởi động với chi phí hạ tầng gần 0 đồng:

- Cloudflare Pages: giao diện React/Vite và PWA.
- Cloudflare Pages Functions: API cùng tên miền.
- Cloudflare D1: tài khoản, lớp học, học phí, giao dịch và báo cáo.
- Không phụ thuộc Supabase, Vercel, server VPS hay dịch vụ ngân hàng.

## Quy mô thiết kế

Mỗi trung tâm:

- Tối đa 500 học sinh đang hoạt động.
- Tối đa 5 email quản lý.
- Không giới hạn số lớp trong phần mềm.
- Một chi nhánh trong phiên bản giá thấp.

Kiến trúc Free dùng 10 D1 database:

- `lop-gon-control`: tài khoản, phiên đăng nhập và danh sách trung tâm.
- `lop-gon-tenant-1` đến `lop-gon-tenant-9`: dữ liệu nghiệp vụ tách riêng cho tối đa 9 trung tâm.

Mỗi database tenant chỉ chứa một trung tâm, giảm nguy cơ lẫn dữ liệu và tận dụng giới hạn dung lượng của D1 Free tốt hơn một database dùng chung.

## Chức năng chính

- Khởi tạo hệ thống và tài khoản quản trị nền tảng.
- Tạo tối đa 9 trung tâm trên kiến trúc Free.
- Cấp 1–5 email với vai trò chủ, quản lý, kế toán, thu ngân hoặc giáo viên.
- Quản lý học sinh, lớp và ghi danh.
- Import học sinh từ XLSX/CSV theo từng lô.
- Tạo buổi học và điểm danh trên điện thoại.
- Phát hành học phí một học sinh hoặc hàng loạt theo lớp.
- Thu đủ, thu một phần và phân bổ một khoản tiền vào nhiều hóa đơn.
- Tiền đóng thừa trở thành số dư học sinh.
- Dùng số dư để cấn trừ kỳ sau.
- Thu tiền mặt bắt buộc có ca thu ngân đang mở.
- Chốt, duyệt hoặc từ chối ca thu ngân.
- Hoàn tiền một phần hoặc toàn bộ, có lý do và audit log.
- Biên nhận điện tử bằng liên kết bảo mật.
- Cổng phụ huynh chỉ đọc và chức năng “Tôi đã chuyển khoản”.
- Import sao kê XLSX/CSV, chống trùng và đề xuất ghép theo mã hóa đơn/mã học sinh.
- Báo cáo học phí, công nợ, tiền mặt, chuyển khoản và số dư.
- Export học sinh, công nợ và giao dịch ra CSV.
- PWA có thể cài lên màn hình điện thoại.

## Yêu cầu máy triển khai

- Node.js 22.
- npm.
- Tài khoản Cloudflare.
- Wrangler đăng nhập vào tài khoản Cloudflare.

## Chạy local

```bash
npm install
npm run db:migrate:local
npm run build
npx wrangler pages dev dist
```

Mở địa chỉ Wrangler hiển thị, sau đó vào `/bootstrap` để tạo trung tâm đầu tiên.

Có thể dùng:

```bash
npm run dev
```

Lệnh này tự chạy migration local, build và mở Pages local.

## Triển khai lên pages.dev

```bash
npm install
npm run cf:login
npm run cf:db:create
npm run db:migrate:remote
npm run check
npm run cf:deploy
```

`wrangler.jsonc` ban đầu dùng UUID giả hợp lệ để chạy local. Lệnh tạo database sẽ thay toàn bộ UUID giả bằng ID D1 thật. Tài khoản Cloudflare cần còn đủ 10 database trên gói Free; nếu đã dùng D1 cho dự án khác, hãy dùng tài khoản/cụm khác hoặc giảm số tenant.

`npm run cf:db:create` sẽ:

1. Đọc danh sách D1 hiện có.
2. Tạo các database còn thiếu tại khu vực APAC.
3. Đọc ID của từng database.
4. Tự cập nhật `wrangler.jsonc`.

Sau khi deploy, mở URL `*.pages.dev` và vào `/bootstrap`.

Tài khoản bootstrap đầu tiên đồng thời là:

- Chủ trung tâm đầu tiên.
- Quản trị nền tảng để tạo các trung tâm tiếp theo.

## Kiểm tra trước deploy

```bash
npm run typecheck
npm run test
npm run build
```

Hoặc:

```bash
npm run check
```

## Backup

```bash
npm run backup
```

Backup SQL của cả 10 database sẽ nằm trong thư mục `backups/<thời-gian>/`.

Không đưa thư mục backup lên Git công khai.

## Cấu trúc quan trọng

```text
functions/api/[[path]].ts     Pages Function tiếp nhận API
server/                       Auth, router và nghiệp vụ phía server
src/                          Giao diện React
migrations/control/           Schema tài khoản và trung tâm
migrations/tenant/            Schema nghiệp vụ từng trung tâm
scripts/                      Tạo DB, migration và backup
public/                       PWA manifest, service worker và icons
```

## Trạng thái phát hành

Phiên bản này hướng tới **staging/pilot có kiểm soát**, chưa nên tuyên bố đạt chuẩn kế toán hoặc bảo mật doanh nghiệp lớn.

Môi trường đóng gói đã kiểm tra:

- TypeScript phía Worker bằng trình kiểm tra strict và type stub D1.
- Cú pháp TypeScript/TSX giao diện.
- Hai nhóm migration bằng SQLite parser.
- Cú pháp các script Node.
- Quét tham chiếu database cũ và bảng chéo tenant.

Môi trường đóng gói không tải xong dependency từ npm nên chưa chạy được build thực tế với `node_modules`. Người triển khai phải chạy `npm install` và `npm run check` trước khi deploy.

Để giao Gemini triển khai:

- `03-HUONG-DAN-DAY-WEB-VA-GIAO-GEMINI.md`
- `GEMINI-DEPLOY-PROMPT.md`
- `DEPLOYMENT-RESULT-TEMPLATE.md`

Đọc tiếp:

- `01-KE-HOACH-TRIEN-KHAI.md`
- `02-DA-LAM-DUOC-GI.md`
- `DEPLOYMENT-CHECKLIST.md`
- `OPERATIONS-RUNBOOK.md`
- `CLOUDFLARE-FREE-ARCHITECTURE.md`
- `SECURITY.md`
- `BUILD_NOTES.md`
- `VERIFICATION-REPORT.md`

File mẫu:

- `examples/hoc-sinh-mau.csv`
- `examples/sao-ke-mau.csv`
