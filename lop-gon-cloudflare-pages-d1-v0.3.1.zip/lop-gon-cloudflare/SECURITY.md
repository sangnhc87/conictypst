# Security Notes

## Đã triển khai

- Password PBKDF2-SHA256, salt ngẫu nhiên, 210.000 vòng.
- So sánh hash theo cách giảm rò rỉ timing.
- Session token ngẫu nhiên 256-bit mặc định.
- Chỉ lưu hash session token.
- Cookie HttpOnly, SameSite=Lax, Secure trên HTTPS.
- Login throttling 10 lần/15 phút theo email và IP hash.
- Origin/Sec-Fetch-Site check cho request thay đổi dữ liệu.
- CSP, X-Frame-Options, nosniff và Permissions-Policy.
- Prepared statements cho SQL.
- Giới hạn độ dài input và request 1,5 MB.
- Role permission kiểm tra tại API.
- Tenant database chọn từ workspace trong session, không nhận tenant slot từ client.
- Public link lưu token hash và có thời hạn/thu hồi.
- Không lưu ảnh chứng từ hoặc file Excel.
- Không xóa cứng giao dịch tài chính qua API.
- Audit log cho thao tác quan trọng.

## Cần làm trước khi mở rộng

- Security review độc lập.
- 2FA hoặc passkey cho owner/platform admin.
- Email reset password có token ngắn hạn.
- Session management UI và nút đăng xuất mọi thiết bị.
- Cảnh báo đăng nhập bất thường.
- Rate limiting phân tán mạnh hơn cho public link.
- Chính sách mật khẩu mạnh và kiểm tra mật khẩu rò rỉ.
- Automated dependency scanning.
- Test IDOR và phân quyền tự động trên D1 thật.
- Quy trình xóa/xuất dữ liệu theo yêu cầu hợp lệ.

## Lưu ý custom authentication

Phiên bản này tự quản lý email/mật khẩu trong D1 để không phụ thuộc dịch vụ khác. Đây là lựa chọn tối ưu chi phí nhưng khiến người vận hành chịu trách nhiệm cao hơn về:

- Bảo vệ tài khoản Cloudflare.
- Bảo vệ source và backup.
- Cập nhật thư viện.
- Xử lý reset mật khẩu.
- Điều tra sự cố.

Không dùng phiên bản này cho dữ liệu nhạy cảm quy mô lớn trước khi có kiểm thử bảo mật chuyên nghiệp.

## Secret

Không đặt secret trong:

- Source code.
- `wrangler.jsonc` vars công khai.
- GitHub repository.
- Tin nhắn hỗ trợ.

Hiện hệ thống không cần API secret bên ngoài. Tài khoản Cloudflare và token CI phải được bảo vệ bằng secret manager của nền tảng.
