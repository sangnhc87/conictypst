import type { Env } from "../../server/types";
import { handleApi } from "../../server/router";

export const onRequest: PagesFunction<Env> = async (context) => {
  return handleApi(context.request, context.env);
};
