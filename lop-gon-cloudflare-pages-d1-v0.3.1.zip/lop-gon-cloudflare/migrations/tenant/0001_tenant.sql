PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS students (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  code TEXT NOT NULL,
  full_name TEXT NOT NULL,
  birth_date TEXT,
  phone TEXT,
  parent_name TEXT,
  parent_phone TEXT,
  school TEXT,
  grade TEXT,
  address TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','reserved','inactive')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(workspace_id, code)
);

CREATE TABLE IF NOT EXISTS classes (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  subject TEXT,
  grade TEXT,
  teacher_name TEXT,
  schedule_text TEXT,
  fee_amount INTEGER NOT NULL DEFAULT 0 CHECK (fee_amount >= 0),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','completed','inactive')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(workspace_id, code)
);

CREATE TABLE IF NOT EXISTS enrollments (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  class_id TEXT NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','reserved','ended')),
  start_date TEXT NOT NULL DEFAULT (date('now')),
  end_date TEXT,
  fee_override INTEGER CHECK (fee_override IS NULL OR fee_override >= 0),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(class_id, student_id)
);

CREATE TABLE IF NOT EXISTS lesson_sessions (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  class_id TEXT NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  session_date TEXT NOT NULL,
  start_time TEXT NOT NULL DEFAULT '18:00',
  end_time TEXT,
  status TEXT NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled','in_progress','completed','cancelled','makeup')),
  topic TEXT,
  created_by TEXT NOT NULL,
  confirmed_by TEXT,
  confirmed_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(class_id, session_date, start_time)
);

CREATE TABLE IF NOT EXISTS attendance_records (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  session_id TEXT NOT NULL REFERENCES lesson_sessions(id) ON DELETE CASCADE,
  student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('present','excused','absent','late','makeup','online')),
  note TEXT,
  recorded_by TEXT NOT NULL,
  recorded_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(session_id, student_id)
);

CREATE TABLE IF NOT EXISTS invoices (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  student_id TEXT NOT NULL REFERENCES students(id),
  class_id TEXT REFERENCES classes(id),
  number TEXT NOT NULL,
  period_key TEXT NOT NULL,
  issue_date TEXT NOT NULL DEFAULT (date('now')),
  due_date TEXT,
  status TEXT NOT NULL DEFAULT 'issued' CHECK (status IN ('draft','issued','partially_paid','paid','overdue','void')),
  total_amount INTEGER NOT NULL CHECK (total_amount >= 0),
  paid_amount INTEGER NOT NULL DEFAULT 0 CHECK (paid_amount >= 0 AND paid_amount <= total_amount),
  notes TEXT,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(workspace_id, number),
  UNIQUE(workspace_id, student_id, class_id, period_key)
);

CREATE TABLE IF NOT EXISTS invoice_items (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit_amount INTEGER NOT NULL,
  total_amount INTEGER NOT NULL,
  item_type TEXT NOT NULL DEFAULT 'fee' CHECK (item_type IN ('fee','discount','adjustment')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS cash_shifts (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  user_name TEXT NOT NULL,
  opened_at TEXT NOT NULL DEFAULT (datetime('now')),
  opening_cash INTEGER NOT NULL DEFAULT 0 CHECK (opening_cash >= 0),
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','submitted','approved','rejected')),
  submitted_at TEXT,
  counted_cash INTEGER CHECK (counted_cash IS NULL OR counted_cash >= 0),
  expected_cash INTEGER CHECK (expected_cash IS NULL OR expected_cash >= 0),
  difference INTEGER,
  approved_by TEXT,
  approved_by_name TEXT,
  approved_at TEXT,
  note TEXT
);

CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  student_id TEXT NOT NULL REFERENCES students(id),
  receipt_number TEXT NOT NULL,
  amount INTEGER NOT NULL CHECK (amount > 0),
  method TEXT NOT NULL CHECK (method IN ('cash','bank_transfer','other','credit')),
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('pending','confirmed','partially_refunded','refunded','reversed','void')),
  source_key TEXT,
  reference TEXT,
  note TEXT,
  received_at TEXT NOT NULL DEFAULT (datetime('now')),
  received_by TEXT NOT NULL,
  received_by_name TEXT NOT NULL,
  cash_shift_id TEXT REFERENCES cash_shifts(id),
  refunded_amount INTEGER NOT NULL DEFAULT 0 CHECK (refunded_amount >= 0 AND refunded_amount <= amount),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(workspace_id, receipt_number)
);

CREATE TABLE IF NOT EXISTS payment_allocations (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  payment_id TEXT NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
  invoice_id TEXT NOT NULL REFERENCES invoices(id),
  amount INTEGER NOT NULL CHECK (amount > 0),
  refunded_amount INTEGER NOT NULL DEFAULT 0 CHECK (refunded_amount >= 0 AND refunded_amount <= amount),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(payment_id, invoice_id)
);

CREATE TABLE IF NOT EXISTS student_credits (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  balance_amount INTEGER NOT NULL DEFAULT 0 CHECK (balance_amount >= 0),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(workspace_id, student_id)
);

CREATE TABLE IF NOT EXISTS credit_ledger (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  student_id TEXT NOT NULL REFERENCES students(id),
  payment_id TEXT REFERENCES payments(id),
  invoice_id TEXT REFERENCES invoices(id),
  entry_type TEXT NOT NULL CHECK (entry_type IN ('deposit','apply','refund','adjustment')),
  amount INTEGER NOT NULL,
  balance_after INTEGER NOT NULL CHECK (balance_after >= 0),
  note TEXT,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS payment_adjustments (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  payment_id TEXT NOT NULL REFERENCES payments(id),
  adjustment_type TEXT NOT NULL CHECK (adjustment_type IN ('refund','reversal','void')),
  amount INTEGER NOT NULL CHECK (amount > 0),
  reason TEXT NOT NULL,
  cash_shift_id TEXT REFERENCES cash_shifts(id),
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS parent_links (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  revoked_at TEXT,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS receipt_links (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  payment_id TEXT NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  revoked_at TEXT,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS parent_transfer_notices (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  student_id TEXT NOT NULL REFERENCES students(id),
  invoice_id TEXT REFERENCES invoices(id),
  amount INTEGER NOT NULL CHECK (amount > 0),
  sender_name TEXT,
  transferred_at TEXT,
  source_key TEXT,
  reference TEXT,
  note TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','rejected')),
  reviewed_by TEXT,
  reviewed_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS exam_results (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  test_name TEXT NOT NULL,
  subject TEXT,
  score REAL NOT NULL,
  max_score REAL NOT NULL DEFAULT 10,
  taken_at TEXT NOT NULL DEFAULT (date('now')),
  note TEXT,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  actor_user_id TEXT,
  actor_name TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT,
  details_json TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_students_workspace_status ON students(workspace_id, status, full_name);
CREATE INDEX IF NOT EXISTS idx_students_workspace_phone ON students(workspace_id, parent_phone);
CREATE INDEX IF NOT EXISTS idx_classes_workspace_status ON classes(workspace_id, status);
CREATE INDEX IF NOT EXISTS idx_enrollments_class_status ON enrollments(workspace_id, class_id, status);
CREATE INDEX IF NOT EXISTS idx_enrollments_student_status ON enrollments(workspace_id, student_id, status);
CREATE INDEX IF NOT EXISTS idx_lesson_sessions_date ON lesson_sessions(workspace_id, session_date, status);
CREATE INDEX IF NOT EXISTS idx_attendance_session ON attendance_records(workspace_id, session_id);
CREATE INDEX IF NOT EXISTS idx_invoices_student_status ON invoices(workspace_id, student_id, status, due_date);
CREATE INDEX IF NOT EXISTS idx_invoices_period ON invoices(workspace_id, period_key, status);
CREATE INDEX IF NOT EXISTS idx_payments_received ON payments(workspace_id, received_at, status);
CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_source_key ON payments(workspace_id,source_key) WHERE source_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_allocations_invoice ON payment_allocations(workspace_id, invoice_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_one_active_shift_per_user ON cash_shifts(workspace_id, user_id) WHERE status IN ('open','submitted');
CREATE INDEX IF NOT EXISTS idx_cash_shifts_workspace ON cash_shifts(workspace_id, status, opened_at);
CREATE INDEX IF NOT EXISTS idx_parent_links_token ON parent_links(token_hash, expires_at, revoked_at);
CREATE INDEX IF NOT EXISTS idx_receipt_links_token ON receipt_links(token_hash, expires_at, revoked_at);
CREATE INDEX IF NOT EXISTS idx_transfer_notices_status ON parent_transfer_notices(workspace_id, status, created_at);
CREATE INDEX IF NOT EXISTS idx_exam_results_student ON exam_results(workspace_id, student_id, taken_at);
CREATE INDEX IF NOT EXISTS idx_audit_workspace_created ON audit_logs(workspace_id, created_at);

-- Ràng buộc tài chính ở tầng database để không phụ thuộc hoàn toàn vào UI/API.
CREATE UNIQUE INDEX IF NOT EXISTS idx_invoice_unique_period_normalized
  ON invoices(workspace_id,student_id,COALESCE(class_id,''),period_key);

CREATE TRIGGER IF NOT EXISTS trg_payment_allocation_validate
BEFORE INSERT ON payment_allocations
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM payments p JOIN invoices i
      ON p.workspace_id=i.workspace_id AND p.student_id=i.student_id
    WHERE p.id=NEW.payment_id AND i.id=NEW.invoice_id
      AND p.workspace_id=NEW.workspace_id
  ) THEN RAISE(ABORT,'PAYMENT_INVOICE_MISMATCH') END;

  SELECT CASE WHEN NEW.amount + COALESCE((
    SELECT SUM(amount) FROM payment_allocations WHERE payment_id=NEW.payment_id
  ),0) > (SELECT amount FROM payments WHERE id=NEW.payment_id)
  THEN RAISE(ABORT,'PAYMENT_OVER_ALLOCATION') END;

  SELECT CASE WHEN NEW.amount > (
    SELECT total_amount-paid_amount FROM invoices WHERE id=NEW.invoice_id
  ) THEN RAISE(ABORT,'INVOICE_OVERPAYMENT') END;
END;
