PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS bank_transactions (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  occurred_at TEXT NOT NULL,
  amount INTEGER NOT NULL CHECK (amount > 0),
  description TEXT,
  reference TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','matched','ignored')),
  suggested_invoice_id TEXT REFERENCES invoices(id),
  suggested_student_id TEXT REFERENCES students(id),
  matched_payment_id TEXT REFERENCES payments(id),
  imported_by TEXT NOT NULL,
  reviewed_by TEXT,
  reviewed_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(workspace_id, fingerprint)
);

CREATE INDEX IF NOT EXISTS idx_bank_transactions_status
  ON bank_transactions(workspace_id,status,occurred_at);
