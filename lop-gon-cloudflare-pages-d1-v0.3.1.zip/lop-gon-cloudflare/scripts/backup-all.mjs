import { spawnSync } from "node:child_process";
import { mkdirSync } from "node:fs";
import { join } from "node:path";

const stamp = new Date().toISOString().replaceAll(':','-').replaceAll('.','-');
const dir = join('backups',stamp);
mkdirSync(dir,{recursive:true});
const names = ['lop-gon-control', ...Array.from({length:9},(_,i)=>`lop-gon-tenant-${i+1}`)];
const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';
for (const name of names) {
  console.log(`Xuất ${name}…`);
  const result = spawnSync(npx,['wrangler','d1','export',name,'--remote','--output',join(dir,`${name}.sql`),'--skip-confirmation'],{stdio:'inherit'});
  if ((result.status ?? 1) !== 0) process.exit(result.status ?? 1);
}
console.log(`Backup hoàn tất tại ${dir}`);
