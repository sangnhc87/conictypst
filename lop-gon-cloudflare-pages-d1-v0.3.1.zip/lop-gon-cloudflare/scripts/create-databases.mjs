import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";

const configPath = new URL('../wrangler.jsonc', import.meta.url);
const names = ['lop-gon-control', ...Array.from({length:9},(_,i)=>`lop-gon-tenant-${i+1}`)];
const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';

function run(args, capture=false) {
  const result = spawnSync(npx, ['wrangler', ...args], {encoding:capture?'utf8':undefined, stdio:capture?'pipe':'inherit'});
  if ((result.status ?? 1) !== 0) {
    if (capture) console.error(result.stderr || result.stdout);
    process.exit(result.status ?? 1);
  }
  return capture ? String(result.stdout || '') : '';
}

console.log('Đang đọc danh sách D1 hiện có…');
let output = run(['d1','list','--json'], true);
let start = output.indexOf('['), end = output.lastIndexOf(']');
if (start < 0 || end < start) throw new Error('Không đọc được JSON từ wrangler d1 list.');
let list = JSON.parse(output.slice(start,end+1));
const existing = new Set(list.map((item)=>item.name || item.database_name));
for (const name of names) {
  if (existing.has(name)) { console.log(`Đã có ${name}, bỏ qua.`); continue; }
  console.log(`Tạo ${name} tại khu vực APAC…`);
  run(['d1','create',name,'--location','apac']);
}

output = run(['d1','list','--json'], true);
start = output.indexOf('['); end = output.lastIndexOf(']');
list = JSON.parse(output.slice(start,end+1));
const idByName = new Map(list.map((item)=>[item.name || item.database_name, item.uuid || item.id || item.database_id]));
const config = JSON.parse(readFileSync(configPath,'utf8'));
for (const binding of config.d1_databases) {
  const id = idByName.get(binding.database_name);
  if (!id) throw new Error(`Không tìm thấy database ${binding.database_name} sau khi tạo.`);
  binding.database_id = id;
}
writeFileSync(configPath, JSON.stringify(config,null,2)+'\n');
console.log('\nĐã tạo/đồng bộ 10 database và cập nhật wrangler.jsonc.');
console.log('Bước tiếp theo: npm run db:migrate:remote');
