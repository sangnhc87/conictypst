import { spawnSync } from "node:child_process";

const mode = process.argv[2];
if (!['local','remote'].includes(mode)) {
  console.error('Cách dùng: node scripts/migrate-all.mjs local|remote');
  process.exit(1);
}
const bindings = ['CONTROL_DB', ...Array.from({length:9},(_,i)=>`TENANT_${i+1}`)];
for (const binding of bindings) {
  console.log(`\n== Áp dụng migration cho ${binding} (${mode}) ==`);
  const result = spawnSync(process.platform === 'win32' ? 'npx.cmd' : 'npx', ['wrangler','d1','migrations','apply',binding,`--${mode}`], {stdio:'inherit'});
  if ((result.status ?? 1) !== 0) process.exit(result.status ?? 1);
}
console.log('\nĐã áp dụng migration cho toàn bộ database.');
