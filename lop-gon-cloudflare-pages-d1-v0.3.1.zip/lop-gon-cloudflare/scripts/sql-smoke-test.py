from pathlib import Path
import sqlite3

root = Path(__file__).resolve().parents[1]

control = sqlite3.connect(':memory:')
control.executescript((root/'migrations/control/0001_control.sql').read_text())
control.execute("INSERT INTO workspaces(id,name,code,tenant_slot) VALUES ('w1','Demo','TT-DEMO',1)")
control.execute("INSERT INTO users(id,email,password_hash,full_name) VALUES ('u1','owner@example.com','hash','Owner')")
control.execute("INSERT INTO workspace_members(id,workspace_id,user_id,role) VALUES ('m1','w1','u1','owner')")
assert control.execute("SELECT COUNT(*) FROM workspace_members").fetchone()[0] == 1
control.close()

tenant = sqlite3.connect(':memory:')
tenant.execute('PRAGMA foreign_keys=ON')
for migration in sorted((root/'migrations/tenant').glob('*.sql')):
    tenant.executescript(migration.read_text())
tenant.execute("INSERT INTO students(id,workspace_id,code,full_name) VALUES ('s1','w1','HS001','Nguyễn An')")
tenant.execute("INSERT INTO classes(id,workspace_id,code,name,fee_amount) VALUES ('c1','w1','T10','Toán 10',500000)")
tenant.execute("INSERT INTO enrollments(id,workspace_id,class_id,student_id) VALUES ('e1','w1','c1','s1')")
tenant.execute("INSERT INTO invoices(id,workspace_id,student_id,class_id,number,period_key,total_amount,created_by) VALUES ('i1','w1','s1','c1','HD001','2026-08',500000,'u1')")
tenant.execute("INSERT INTO invoice_items(id,workspace_id,invoice_id,description,unit_amount,total_amount) VALUES ('it1','w1','i1','Học phí',500000,500000)")
tenant.execute("INSERT INTO cash_shifts(id,workspace_id,user_id,user_name,opening_cash) VALUES ('sh1','w1','u1','Owner',0)")
tenant.execute("INSERT INTO payments(id,workspace_id,student_id,receipt_number,amount,method,received_by,received_by_name,cash_shift_id) VALUES ('p1','w1','s1','PT001',500000,'cash','u1','Owner','sh1')")
tenant.execute("INSERT INTO payment_allocations(id,workspace_id,payment_id,invoice_id,amount) VALUES ('a1','w1','p1','i1',500000)")
tenant.execute("UPDATE invoices SET paid_amount=500000,status='paid' WHERE id='i1'")
tenant.execute("INSERT INTO bank_transactions(id,workspace_id,fingerprint,occurred_at,amount,description,imported_by) VALUES ('b1','w1','fp1','2026-07-27',500000,'HD001','u1')")
assert tenant.execute("SELECT paid_amount FROM invoices WHERE id='i1'").fetchone()[0] == 500000
try:
    tenant.execute("INSERT INTO payment_allocations(id,workspace_id,payment_id,invoice_id,amount) VALUES ('a2','w1','p1','i1',1)")
    raise AssertionError('Trigger over-allocation did not fire')
except sqlite3.IntegrityError:
    pass
print('SQL smoke test: OK')
