import type { AuthContext, Env, Role } from "./types";
import { ApiError, getClientIp } from "./http";
import { randomToken, sha256 } from "./crypto";
import { id } from "./ids";

const COOKIE_NAME = "lg_session";

function parseCookies(request: Request): Record<string, string> {
  const raw = request.headers.get("cookie") || "";
  return Object.fromEntries(
    raw.split(";").map((part) => part.trim()).filter(Boolean).map((part) => {
      const index = part.indexOf("=");
      return [decodeURIComponent(part.slice(0, index)), decodeURIComponent(part.slice(index + 1))];
    })
  );
}

function days(env: Env): number {
  const value = Number(env.SESSION_DAYS || "30");
  return Number.isFinite(value) && value >= 1 && value <= 90 ? value : 30;
}

export async function createSession(request: Request, env: Env, userId: string): Promise<{ cookie: string }> {
  const token = randomToken(32);
  const tokenHash = await sha256(token);
  const sessionId = id("ses");
  const sessionDays = days(env);
  const expiresAt = new Date(Date.now() + sessionDays * 86_400_000).toISOString();
  const ipHash = await sha256(getClientIp(request));
  await env.CONTROL_DB.prepare(
    `INSERT INTO sessions (id,user_id,token_hash,expires_at,user_agent,ip_hash) VALUES (?,?,?,?,?,?)`
  ).bind(sessionId, userId, tokenHash, expiresAt, request.headers.get("user-agent"), ipHash).run();
  const secure = new URL(request.url).protocol === "https:" ? "; Secure" : "";
  return {
    cookie: `${COOKIE_NAME}=${encodeURIComponent(token)}; HttpOnly${secure}; SameSite=Lax; Path=/; Max-Age=${sessionDays * 86400}`,
  };
}

export function clearSessionCookie(request: Request): string {
  const secure = new URL(request.url).protocol === "https:" ? "; Secure" : "";
  return `${COOKIE_NAME}=; HttpOnly${secure}; SameSite=Lax; Path=/; Max-Age=0`;
}

export async function destroySession(request: Request, env: Env): Promise<void> {
  const token = parseCookies(request)[COOKIE_NAME];
  if (!token) return;
  const tokenHash = await sha256(token);
  await env.CONTROL_DB.prepare(`DELETE FROM sessions WHERE token_hash = ?`).bind(tokenHash).run();
}

export async function optionalAuth(request: Request, env: Env): Promise<(AuthContext & { isPlatformAdmin: boolean }) | null> {
  const token = parseCookies(request)[COOKIE_NAME];
  if (!token) return null;
  const tokenHash = await sha256(token);
  const row = await env.CONTROL_DB.prepare(`
    SELECT u.id AS user_id, u.email, u.full_name, u.is_platform_admin, s.last_seen_at,
           wm.workspace_id, wm.role, w.name AS workspace_name, w.tenant_slot, w.max_users, w.max_students
    FROM sessions s
    JOIN users u ON u.id = s.user_id
    JOIN workspace_members wm ON wm.user_id = u.id AND wm.status = 'active'
    JOIN workspaces w ON w.id = wm.workspace_id AND w.status = 'active'
    WHERE s.token_hash = ? AND s.expires_at > datetime('now') AND u.status = 'active'
    ORDER BY CASE wm.role WHEN 'owner' THEN 1 ELSE 2 END
    LIMIT 1
  `).bind(tokenHash).first<{
    user_id: string; email: string; full_name: string; is_platform_admin: number; last_seen_at: string;
    workspace_id: string; role: Role; workspace_name: string; tenant_slot: number; max_users: number; max_students: number;
  }>();
  if (!row) return null;
  if (new Date(row.last_seen_at).getTime() < Date.now() - 15 * 60_000) {
    await env.CONTROL_DB.prepare(`UPDATE sessions SET last_seen_at = datetime('now') WHERE token_hash = ?`).bind(tokenHash).run();
  }
  return {
    userId: row.user_id,
    email: row.email,
    fullName: row.full_name,
    workspaceId: row.workspace_id,
    workspaceName: row.workspace_name,
    tenantSlot: row.tenant_slot,
    role: row.role,
    maxUsers: row.max_users,
    maxStudents: row.max_students,
    isPlatformAdmin: row.is_platform_admin === 1,
  };
}

export async function requireAuth(request: Request, env: Env): Promise<AuthContext & { isPlatformAdmin: boolean }> {
  const auth = await optionalAuth(request, env);
  if (!auth) throw new ApiError(401, "Phiên đăng nhập đã hết hạn.", "UNAUTHORIZED");
  return auth;
}

export async function requirePlatformAdmin(request: Request, env: Env): Promise<AuthContext & { isPlatformAdmin: true }> {
  const auth = await requireAuth(request, env);
  if (!auth.isPlatformAdmin) throw new ApiError(403, "Chỉ tài khoản quản trị hệ thống được thực hiện thao tác này.", "FORBIDDEN");
  return auth as AuthContext & { isPlatformAdmin: true };
}
