import type { AuthContext, Env } from "./types";
import { id } from "./ids";
import { tenantDb } from "./tenant";

export async function audit(env:Env,auth:AuthContext,action:string,entityType:string,entityId:string|null,details:unknown=null):Promise<void>{
  const db=tenantDb(env,auth.tenantSlot);
  await db.prepare(`INSERT INTO audit_logs (id,workspace_id,actor_user_id,actor_name,action,entity_type,entity_id,details_json) VALUES (?,?,?,?,?,?,?,?)`)
    .bind(id("aud"),auth.workspaceId,auth.userId,auth.fullName,action,entityType,entityId,details?JSON.stringify(details):null).run();
}
export async function countActiveStudents(env:Env,auth:AuthContext):Promise<number>{const row=await tenantDb(env,auth.tenantSlot).prepare(`SELECT COUNT(*) AS total FROM students WHERE workspace_id=? AND status='active'`).bind(auth.workspaceId).first<{total:number}>();return Number(row?.total||0)}
export async function countActiveMembers(env:Env,workspaceId:string):Promise<number>{const row=await env.CONTROL_DB.prepare(`SELECT COUNT(*) AS total FROM workspace_members WHERE workspace_id=? AND status='active'`).bind(workspaceId).first<{total:number}>();return Number(row?.total||0)}
export async function nextSequence(_env:Env,_workspaceId:string,prefix:string,_table:"invoices"|"payments"):Promise<string>{const date=new Date().toISOString().slice(0,10).replaceAll("-","");const suffix=crypto.randomUUID().slice(0,8).toUpperCase();return `${prefix}${date}-${suffix}`}
