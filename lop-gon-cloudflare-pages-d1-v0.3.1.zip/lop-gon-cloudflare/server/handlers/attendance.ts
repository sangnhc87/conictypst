import type { Env } from "../types";
import { requireAuth } from "../auth";
import { requirePermission } from "../permissions";
import { ApiError, created, ok, readJson } from "../http";
import { audit } from "../db";
import { id } from "../ids";
import { optionalString, requiredString } from "../validation";
import { tenantDb } from "../tenant";

const statuses=["present","excused","absent","late","makeup","online"] as const;

export async function attendanceRoutes(request:Request,env:Env,path:string,method:string,url:URL):Promise<Response|null>{
  if(path==="/attendance/sessions"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"classes.read");
    const date=url.searchParams.get("date")||new Date().toISOString().slice(0,10);
    const result=await db.prepare(`
      SELECT ls.id,ls.session_date,ls.start_time,ls.end_time,ls.status,ls.topic,c.id AS class_id,c.name AS class_name,c.code AS class_code,
             (SELECT COUNT(*) FROM attendance_records ar WHERE ar.session_id=ls.id) AS recorded_count,
             (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=ls.class_id AND e.status='active') AS student_count
      FROM lesson_sessions ls JOIN classes c ON c.id=ls.class_id
      WHERE ls.workspace_id=? AND ls.session_date=? ORDER BY ls.start_time,c.name
    `).bind(auth.workspaceId,date).all();
    return ok({sessions:result.results,date});
  }
  if(path==="/attendance/sessions"&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"attendance.write");
    const body=await readJson<Record<string,unknown>>(request);
    const classId=requiredString(body.classId,"Lớp",80); const sessionDate=requiredString(body.sessionDate,"Ngày học",10);
    const startTime=optionalString(body.startTime,5)||"18:00"; const sessionId=id("sesn");
    const klass=await db.prepare(`SELECT id FROM classes WHERE id=? AND workspace_id=? AND status='active'`).bind(classId,auth.workspaceId).first();
    if(!klass) throw new ApiError(404,"Không tìm thấy lớp đang hoạt động.","NOT_FOUND");
    try{
      await db.prepare(`INSERT INTO lesson_sessions (id,workspace_id,class_id,session_date,start_time,end_time,topic,created_by) VALUES (?,?,?,?,?,?,?,?)`)
        .bind(sessionId,auth.workspaceId,classId,sessionDate,startTime,optionalString(body.endTime,5),optionalString(body.topic,300),auth.userId).run();
    }catch(error){if(String(error).includes("UNIQUE")) throw new ApiError(409,"Buổi học này đã tồn tại.","DUPLICATE_SESSION");throw error;}
    await audit(env,auth,"attendance.session_created","lesson_session",sessionId,{classId,sessionDate});
    return created({id:sessionId});
  }
  const match=path.match(/^\/attendance\/sessions\/([^/]+)$/);
  if(match&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"classes.read");
    const session=await db.prepare(`SELECT ls.*,c.name AS class_name,c.code AS class_code FROM lesson_sessions ls JOIN classes c ON c.id=ls.class_id WHERE ls.id=? AND ls.workspace_id=?`).bind(match[1],auth.workspaceId).first();
    if(!session) throw new ApiError(404,"Không tìm thấy buổi học.","NOT_FOUND");
    const students=await db.prepare(`
      SELECT s.id,s.code,s.full_name,s.grade,COALESCE(ar.status,'present') AS attendance_status,ar.note
      FROM enrollments e JOIN students s ON s.id=e.student_id
      LEFT JOIN attendance_records ar ON ar.session_id=? AND ar.student_id=s.id
      WHERE e.workspace_id=? AND e.class_id=? AND e.status='active' AND s.status!='inactive'
      ORDER BY s.full_name
    `).bind(match[1],auth.workspaceId,(session as {class_id:string}).class_id).all();
    return ok({session,students:students.results});
  }
  const recordsMatch=path.match(/^\/attendance\/sessions\/([^/]+)\/records$/);
  if(recordsMatch&&method==="PUT"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"attendance.write");
    const body=await readJson<{records?:Array<{studentId?:unknown;status?:unknown;note?:unknown}>}>(request);
    if(!Array.isArray(body.records)||!body.records.length||body.records.length>40) throw new ApiError(400,"Mỗi lần lưu từ 1 đến 40 học sinh.","BATCH_LIMIT");
    const session=await db.prepare(`SELECT id,class_id,status FROM lesson_sessions WHERE id=? AND workspace_id=?`).bind(recordsMatch[1],auth.workspaceId).first<{id:string;class_id:string;status:string}>();
    if(!session) throw new ApiError(404,"Không tìm thấy buổi học.","NOT_FOUND");
    if(session.status==="cancelled") throw new ApiError(409,"Buổi học đã hủy.","SESSION_CANCELLED");
    const clean=body.records.map((record)=>{
      const studentId=requiredString(record.studentId,"Học sinh",80);
      const status=typeof record.status==="string"&&statuses.includes(record.status as typeof statuses[number])?record.status:null;
      if(!status) throw new ApiError(400,"Trạng thái điểm danh không hợp lệ.","VALIDATION_ERROR");
      return {studentId,status,note:optionalString(record.note,300)};
    });
    const statements=clean.map(r=>db.prepare(`
      INSERT INTO attendance_records (id,workspace_id,session_id,student_id,status,note,recorded_by)
      SELECT ?,?,?,?,?,?,? WHERE EXISTS (
        SELECT 1 FROM enrollments WHERE workspace_id=? AND class_id=? AND student_id=? AND status='active'
      )
      ON CONFLICT(session_id,student_id) DO UPDATE SET status=excluded.status,note=excluded.note,recorded_by=excluded.recorded_by,updated_at=datetime('now')
    `).bind(id("att"),auth.workspaceId,recordsMatch[1],r.studentId,r.status,r.note,auth.userId,auth.workspaceId,session.class_id,r.studentId));
    await db.batch(statements);
    return ok({saved:clean.length});
  }
  const completeMatch=path.match(/^\/attendance\/sessions\/([^/]+)\/complete$/);
  if(completeMatch&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"attendance.write");
    const row=await db.prepare(`
      SELECT ls.id,
       (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=ls.class_id AND e.status='active') AS expected,
       (SELECT COUNT(*) FROM attendance_records ar WHERE ar.session_id=ls.id) AS actual
      FROM lesson_sessions ls WHERE ls.id=? AND ls.workspace_id=?
    `).bind(completeMatch[1],auth.workspaceId).first<{id:string;expected:number;actual:number}>();
    if(!row) throw new ApiError(404,"Không tìm thấy buổi học.","NOT_FOUND");
    if(Number(row.actual)<Number(row.expected)) throw new ApiError(409,`Còn ${Number(row.expected)-Number(row.actual)} học sinh chưa được lưu điểm danh.`,"INCOMPLETE_ATTENDANCE");
    await db.prepare(`UPDATE lesson_sessions SET status='completed',confirmed_by=?,confirmed_at=datetime('now') WHERE id=? AND workspace_id=?`).bind(auth.userId,completeMatch[1],auth.workspaceId).run();
    await audit(env,auth,"attendance.completed","lesson_session",completeMatch[1],{count:row.actual}); return ok({ok:true});
  }
  return null;
}
