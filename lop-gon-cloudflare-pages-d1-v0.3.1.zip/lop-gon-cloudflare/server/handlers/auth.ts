import type { Env } from "../types";
import { ApiError, created, getClientIp, ok, readJson } from "../http";
import { hashPassword, sha256, verifyPassword } from "../crypto";
import { id } from "../ids";
import { createSession, clearSessionCookie, destroySession, optionalAuth, requireAuth } from "../auth";
import { requiredString, validEmail, validPassword } from "../validation";

export async function authRoutes(request: Request, env: Env, path: string, method: string): Promise<Response | null> {
  if (path === "/auth/status" && method === "GET") {
    const row = await env.CONTROL_DB.prepare(`SELECT COUNT(*) AS total FROM users`).first<{ total: number }>();
    return ok({ needsBootstrap: Number(row?.total || 0) === 0 });
  }

  if (path === "/auth/bootstrap" && method === "POST") {
    const existing = await env.CONTROL_DB.prepare(`SELECT COUNT(*) AS total FROM users`).first<{ total: number }>();
    if (Number(existing?.total || 0) > 0) throw new ApiError(409, "Hệ thống đã được khởi tạo.", "ALREADY_BOOTSTRAPPED");
    const body = await readJson<Record<string, unknown>>(request);
    const workspaceName = requiredString(body.workspaceName, "Tên trung tâm", 120);
    const fullName = requiredString(body.fullName, "Họ tên", 120);
    const email = validEmail(body.email);
    const password = validPassword(body.password);
    const userId = id("usr");
    const workspaceId = id("wsp");
    const memberId = id("mem");
    const passwordHash = await hashPassword(password);
    const code = `TT-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    await env.CONTROL_DB.batch([
      env.CONTROL_DB.prepare(`INSERT INTO workspaces (id,name,code,tenant_slot,max_users,max_students) VALUES (?,?,?,?,?,?)`)
        .bind(workspaceId, workspaceName, code, 1, 5, 500),
      env.CONTROL_DB.prepare(`INSERT INTO users (id,email,password_hash,full_name,is_platform_admin) VALUES (?,?,?,?,1)`)
        .bind(userId, email, passwordHash, fullName),
      env.CONTROL_DB.prepare(`INSERT INTO workspace_members (id,workspace_id,user_id,role) VALUES (?,?,?,'owner')`)
        .bind(memberId, workspaceId, userId),
      env.CONTROL_DB.prepare(`INSERT INTO platform_audit_logs (id,actor_user_id,action,workspace_id,details_json) VALUES (?,?,?,?,?)`)
        .bind(id("paud"), userId, "system.bootstrap", workspaceId, JSON.stringify({ email, tenantSlot: 1 })),
    ]);
    const session = await createSession(request, env, userId);
    const response = created({ ok: true, workspaceId, userId, email, workspaceName });
    response.headers.set("set-cookie", session.cookie);
    return response;
  }

  if (path === "/auth/login" && method === "POST") {
    const body = await readJson<Record<string, unknown>>(request);
    const email = validEmail(body.email);
    const password = requiredString(body.password, "Mật khẩu", 128);
    const attemptKey = await sha256(`${email}|${getClientIp(request)}`);
    const attempt = await env.CONTROL_DB.prepare(`SELECT attempts,window_started FROM auth_attempts WHERE key_hash=?`).bind(attemptKey).first<{attempts:number;window_started:string}>();
    if (attempt && new Date(attempt.window_started).getTime() > Date.now()-15*60_000 && Number(attempt.attempts) >= 10) {
      throw new ApiError(429, "Đăng nhập sai quá nhiều lần. Vui lòng thử lại sau 15 phút.", "TOO_MANY_ATTEMPTS");
    }
    const user = await env.CONTROL_DB.prepare(`SELECT id,password_hash,status FROM users WHERE email = ? COLLATE NOCASE`)
      .bind(email).first<{ id: string; password_hash: string; status: string }>();
    if (!user || user.status !== "active" || !(await verifyPassword(password, user.password_hash))) {
      await env.CONTROL_DB.prepare(`INSERT INTO auth_attempts (key_hash,attempts,window_started) VALUES (?,1,datetime('now')) ON CONFLICT(key_hash) DO UPDATE SET attempts=CASE WHEN window_started<datetime('now','-15 minutes') THEN 1 ELSE attempts+1 END,window_started=CASE WHEN window_started<datetime('now','-15 minutes') THEN datetime('now') ELSE window_started END`).bind(attemptKey).run();
      throw new ApiError(401, "Email hoặc mật khẩu không đúng.", "INVALID_CREDENTIALS");
    }
    const membership = await env.CONTROL_DB.prepare(`SELECT id FROM workspace_members WHERE user_id = ? AND status = 'active' LIMIT 1`)
      .bind(user.id).first();
    if (!membership) throw new ApiError(403, "Tài khoản chưa được cấp quyền vào trung tâm.", "NO_WORKSPACE");
    await env.CONTROL_DB.batch([
      env.CONTROL_DB.prepare(`UPDATE users SET last_login_at = datetime('now') WHERE id = ?`).bind(user.id),
      env.CONTROL_DB.prepare(`DELETE FROM auth_attempts WHERE key_hash=?`).bind(attemptKey),
      env.CONTROL_DB.prepare(`DELETE FROM sessions WHERE expires_at<=datetime('now')`),
    ]);
    const session = await createSession(request, env, user.id);
    const response = ok({ ok: true });
    response.headers.set("set-cookie", session.cookie);
    return response;
  }

  if (path === "/auth/change-password" && method === "POST") {
    const auth = await requireAuth(request, env);
    const body = await readJson<Record<string, unknown>>(request);
    const currentPassword = requiredString(body.currentPassword, "Mật khẩu hiện tại", 128);
    const newPassword = validPassword(body.newPassword);
    if (currentPassword === newPassword) throw new ApiError(400, "Mật khẩu mới phải khác mật khẩu hiện tại.", "PASSWORD_UNCHANGED");
    const user = await env.CONTROL_DB.prepare(`SELECT password_hash FROM users WHERE id=? AND status='active'`).bind(auth.userId).first<{password_hash:string}>();
    if (!user || !(await verifyPassword(currentPassword, user.password_hash))) throw new ApiError(401, "Mật khẩu hiện tại không đúng.", "INVALID_CURRENT_PASSWORD");
    const passwordHash = await hashPassword(newPassword);
    await env.CONTROL_DB.batch([
      env.CONTROL_DB.prepare(`UPDATE users SET password_hash=?,updated_at=datetime('now') WHERE id=?`).bind(passwordHash,auth.userId),
      env.CONTROL_DB.prepare(`DELETE FROM sessions WHERE user_id=?`).bind(auth.userId),
      env.CONTROL_DB.prepare(`INSERT INTO platform_audit_logs (id,actor_user_id,action,workspace_id) VALUES (?,?,?,?)`).bind(id("paud"),auth.userId,"auth.password_changed",auth.workspaceId),
    ]);
    const session = await createSession(request,env,auth.userId);
    const response=ok({ok:true}); response.headers.set("set-cookie",session.cookie); return response;
  }

  if (path === "/auth/logout" && method === "POST") {
    await destroySession(request, env);
    const response = ok({ ok: true });
    response.headers.set("set-cookie", clearSessionCookie(request));
    return response;
  }

  if (path === "/auth/me" && method === "GET") {
    const auth = await optionalAuth(request, env);
    if (!auth) throw new ApiError(401, "Chưa đăng nhập.", "UNAUTHORIZED");
    return ok({ user: auth });
  }

  return null;
}
