import type { Env } from "../types";
import { requireAuth } from "../auth";
import { requirePermission } from "../permissions";
import { ApiError, created, ok, readJson } from "../http";
import { audit, nextSequence } from "../db";
import { id } from "../ids";
import { sha256 } from "../crypto";
import { integerMoney, optionalString, requiredString } from "../validation";
import { tenantDb } from "../tenant";

interface ImportRow { occurredAt?:unknown; amount?:unknown; description?:unknown; reference?:unknown }

export async function bankRoutes(request:Request,env:Env,path:string,method:string):Promise<Response|null>{
  if(path==="/bank-transactions"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.collect");
    const result=await db.prepare(`
      SELECT bt.id,bt.occurred_at,bt.amount,bt.description,bt.reference,bt.status,
             bt.suggested_invoice_id,bt.suggested_student_id,
             i.number AS invoice_number,i.period_key,i.total_amount-i.paid_amount AS invoice_outstanding,
             s.code AS student_code,s.full_name
      FROM bank_transactions bt
      LEFT JOIN invoices i ON i.id=bt.suggested_invoice_id
      LEFT JOIN students s ON s.id=COALESCE(bt.suggested_student_id,i.student_id)
      WHERE bt.workspace_id=? ORDER BY CASE bt.status WHEN 'pending' THEN 1 ELSE 2 END,bt.occurred_at DESC LIMIT 200
    `).bind(auth.workspaceId).all();
    return ok({transactions:result.results});
  }

  if(path==="/bank-transactions/import"&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.collect");
    const body=await readJson<{rows?:ImportRow[]}>(request);
    if(!Array.isArray(body.rows)||!body.rows.length||body.rows.length>15) throw new ApiError(400,"Mỗi đợt nhập sao kê từ 1 đến 15 giao dịch.","BATCH_LIMIT");
    const rows=[] as Array<{id:string;occurredAt:string;amount:number;description:string|null;reference:string|null;fingerprint:string;invoiceId:string|null;studentId:string|null}>;
    for(const raw of body.rows){
      const occurredAt=requiredString(raw.occurredAt,"Thời gian giao dịch",40);
      const amount=integerMoney(raw.amount,"Số tiền vào");
      const description=optionalString(raw.description,500); const reference=optionalString(raw.reference,120);
      const fingerprint=await sha256(`${occurredAt}|${amount}|${reference||""}|${description||""}`);
      const suggestion=await db.prepare(`
        SELECT i.id AS invoice_id,i.student_id
        FROM invoices i JOIN students s ON s.id=i.student_id
        WHERE i.workspace_id=? AND i.status IN ('issued','partially_paid','overdue') AND i.total_amount>i.paid_amount
          AND (? LIKE '%'||i.number||'%' OR ? LIKE '%'||s.code||'%')
        ORDER BY CASE WHEN i.total_amount-i.paid_amount=? THEN 0 ELSE 1 END,i.due_date LIMIT 1
      `).bind(auth.workspaceId,description||"",description||"",amount).first<{invoice_id:string;student_id:string}>();
      rows.push({id:id("btx"),occurredAt,amount,description,reference,fingerprint,invoiceId:suggestion?.invoice_id||null,studentId:suggestion?.student_id||null});
    }
    const statements=rows.map(row=>db.prepare(`INSERT OR IGNORE INTO bank_transactions (id,workspace_id,fingerprint,occurred_at,amount,description,reference,suggested_invoice_id,suggested_student_id,imported_by) VALUES (?,?,?,?,?,?,?,?,?,?)`)
      .bind(row.id,auth.workspaceId,row.fingerprint,row.occurredAt,row.amount,row.description,row.reference,row.invoiceId,row.studentId,auth.userId));
    const results=await db.batch(statements); const imported=results.reduce((sum,result)=>sum+Number(result.meta.changes||0),0);
    await audit(env,auth,"bank_statement.imported","bank_transaction",null,{submitted:rows.length,imported});
    return created({submitted:rows.length,imported,duplicates:rows.length-imported});
  }

  const confirm=path.match(/^\/bank-transactions\/([^/]+)\/confirm$/);
  if(confirm&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.collect");
    const body=await readJson<Record<string,unknown>>(request);
    const transaction=await db.prepare(`SELECT * FROM bank_transactions WHERE id=? AND workspace_id=? AND status='pending'`).bind(confirm[1],auth.workspaceId).first<{id:string;amount:number;reference:string|null;description:string|null;occurred_at:string;suggested_invoice_id:string|null;suggested_student_id:string|null}>();
    if(!transaction) throw new ApiError(409,"Giao dịch không tồn tại hoặc đã được xử lý.","ALREADY_REVIEWED");
    const invoiceId=optionalString(body.invoiceId,80)||transaction.suggested_invoice_id;
    let studentId=optionalString(body.studentId,80)||transaction.suggested_student_id; let allocation=0;
    if(invoiceId){
      const invoice=await db.prepare(`SELECT student_id,total_amount-paid_amount AS outstanding FROM invoices WHERE id=? AND workspace_id=? AND status IN ('issued','partially_paid','overdue')`).bind(invoiceId,auth.workspaceId).first<{student_id:string;outstanding:number}>();
      if(!invoice) throw new ApiError(409,"Hóa đơn đề xuất không còn công nợ.","INVALID_INVOICE");
      studentId=invoice.student_id; allocation=Math.min(transaction.amount,Number(invoice.outstanding));
    }
    if(!studentId) throw new ApiError(400,"Cần chọn học sinh trước khi xác nhận giao dịch.","STUDENT_REQUIRED");
    const student=await db.prepare(`SELECT id FROM students WHERE id=? AND workspace_id=?`).bind(studentId,auth.workspaceId).first();
    if(!student) throw new ApiError(404,"Không tìm thấy học sinh.","NOT_FOUND");
    const paymentId=id("pay"), receiptNumber=await nextSequence(env,auth.workspaceId,"PT","payments"), credit=transaction.amount-allocation;
    const statements:D1PreparedStatement[]=[
      db.prepare(`INSERT INTO payments (id,workspace_id,student_id,receipt_number,amount,method,source_key,reference,note,received_at,received_by,received_by_name) VALUES (?,?,?,?,?,'bank_transfer',?,?,?,?,?,?)`)
        .bind(paymentId,auth.workspaceId,studentId,receiptNumber,transaction.amount,`bank:${transaction.id}`,transaction.reference,"Đối soát từ sao kê",transaction.occurred_at,auth.userId,auth.fullName),
      db.prepare(`UPDATE bank_transactions SET status='matched',matched_payment_id=?,reviewed_by=?,reviewed_at=datetime('now') WHERE id=? AND workspace_id=? AND status='pending'`).bind(paymentId,auth.userId,transaction.id,auth.workspaceId),
    ];
    if(allocation>0&&invoiceId){
      statements.push(db.prepare(`INSERT INTO payment_allocations (id,workspace_id,payment_id,invoice_id,amount) VALUES (?,?,?,?,?)`).bind(id("pal"),auth.workspaceId,paymentId,invoiceId,allocation));
      statements.push(db.prepare(`UPDATE invoices SET paid_amount=paid_amount+?,status=CASE WHEN paid_amount+?=total_amount THEN 'paid' ELSE 'partially_paid' END,updated_at=datetime('now') WHERE id=? AND workspace_id=?`).bind(allocation,allocation,invoiceId,auth.workspaceId));
    }
    if(credit>0){
      statements.push(db.prepare(`INSERT INTO student_credits (id,workspace_id,student_id,balance_amount) VALUES (?,?,?,?) ON CONFLICT(workspace_id,student_id) DO UPDATE SET balance_amount=balance_amount+excluded.balance_amount,updated_at=datetime('now')`).bind(id("crd"),auth.workspaceId,studentId,credit));
      statements.push(db.prepare(`INSERT INTO credit_ledger (id,workspace_id,student_id,payment_id,entry_type,amount,balance_after,note,created_by) SELECT ?,?,?,?,?,?,balance_amount,?,? FROM student_credits WHERE workspace_id=? AND student_id=?`).bind(id("clg"),auth.workspaceId,studentId,paymentId,"deposit",credit,"Phần chuyển khoản chưa phân bổ",auth.userId,auth.workspaceId,studentId));
    }
    try{await db.batch(statements);}catch(error){if(String(error).includes("UNIQUE"))throw new ApiError(409,"Giao dịch sao kê đã được xác nhận trước đó.","ALREADY_REVIEWED");throw error;} await audit(env,auth,"bank_transaction.matched","payment",paymentId,{bankTransactionId:transaction.id,allocation,credit});
    return created({paymentId,receiptNumber,allocation,credit});
  }

  const ignore=path.match(/^\/bank-transactions\/([^/]+)\/ignore$/);
  if(ignore&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.collect");
    const result=await db.prepare(`UPDATE bank_transactions SET status='ignored',reviewed_by=?,reviewed_at=datetime('now') WHERE id=? AND workspace_id=? AND status='pending'`).bind(auth.userId,ignore[1],auth.workspaceId).run();
    if(!result.meta.changes) throw new ApiError(409,"Giao dịch không tồn tại hoặc đã xử lý.","ALREADY_REVIEWED");
    await audit(env,auth,"bank_transaction.ignored","bank_transaction",ignore[1]); return ok({ok:true});
  }
  return null;
}
