import type { Env } from "../types";
import { requireAuth } from "../auth";
import { requirePermission } from "../permissions";
import { ApiError, created, ok, readJson } from "../http";
import { audit, nextSequence } from "../db";
import { id } from "../ids";
import { integerMoney, optionalString, requiredString } from "../validation";
import { tenantDb } from "../tenant";

export async function billingRoutes(request:Request,env:Env,path:string,method:string,url:URL):Promise<Response|null>{
  if(path==="/billing/invoices"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"billing.read");
    const status=url.searchParams.get("status")||"open";
    const q=(url.searchParams.get("q")||"").trim(); const like=`%${q}%`;
    const page=Math.max(Number(url.searchParams.get("page")||1),1); const limit=Math.min(Math.max(Number(url.searchParams.get("limit")||50),1),100); const offset=(page-1)*limit;
    const where=`i.workspace_id=? AND (?='all' OR (?='open' AND i.status IN ('issued','partially_paid','overdue')) OR i.status=?) AND (?='' OR s.full_name LIKE ? OR s.code LIKE ? OR i.number LIKE ?)`;
    const [data,count]=await Promise.all([
      db.prepare(`SELECT i.id,i.number,i.period_key,i.issue_date,i.due_date,i.status,i.total_amount,i.paid_amount,i.total_amount-i.paid_amount AS outstanding,s.id AS student_id,s.code AS student_code,s.full_name,c.name AS class_name FROM invoices i JOIN students s ON s.id=i.student_id LEFT JOIN classes c ON c.id=i.class_id WHERE ${where} ORDER BY i.issue_date DESC,i.created_at DESC LIMIT ? OFFSET ?`)
        .bind(auth.workspaceId,status,status,status,q,like,like,like,limit,offset).all(),
      db.prepare(`SELECT COUNT(*) AS total FROM invoices i JOIN students s ON s.id=i.student_id WHERE ${where}`).bind(auth.workspaceId,status,status,status,q,like,like,like).first<{total:number}>(),
    ]);
    return ok({invoices:data.results,total:Number(count?.total||0),page,limit});
  }

  if(path==="/billing/invoices"&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"billing.write");
    const body=await readJson<Record<string,unknown>>(request);
    const studentId=requiredString(body.studentId,"Học sinh",80); const classId=optionalString(body.classId,80); const periodKey=requiredString(body.periodKey,"Kỳ học phí",20);
    const amount=integerMoney(body.amount,"Số tiền"); const description=optionalString(body.description,200)||`Học phí kỳ ${periodKey}`;
    const student=await db.prepare(`SELECT id FROM students WHERE id=? AND workspace_id=? AND status!='inactive'`).bind(studentId,auth.workspaceId).first();
    if(!student) throw new ApiError(404,"Không tìm thấy học sinh.","NOT_FOUND");
    const invoiceId=id("inv"); const number=await nextSequence(env,auth.workspaceId,"HD", "invoices");
    try{
      await db.batch([
        db.prepare(`INSERT INTO invoices (id,workspace_id,student_id,class_id,number,period_key,issue_date,due_date,total_amount,notes,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?)`)
          .bind(invoiceId,auth.workspaceId,studentId,classId,number,periodKey,optionalString(body.issueDate,10)||new Date().toISOString().slice(0,10),optionalString(body.dueDate,10),amount,optionalString(body.notes,500),auth.userId),
        db.prepare(`INSERT INTO invoice_items (id,workspace_id,invoice_id,description,quantity,unit_amount,total_amount,item_type) VALUES (?,?,?,?,1,?,?,'fee')`)
          .bind(id("itm"),auth.workspaceId,invoiceId,description,amount,amount),
      ]);
    }catch(error){if(String(error).includes("UNIQUE")) throw new ApiError(409,"Học phí của học sinh trong kỳ này đã được phát hành.","DUPLICATE_INVOICE");throw error;}
    await audit(env,auth,"invoice.created","invoice",invoiceId,{studentId,amount,periodKey}); return created({invoice:{id:invoiceId,number,amount,periodKey}});
  }

  if(path==="/billing/candidates"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"billing.write");
    const classId=requiredString(url.searchParams.get("classId"),"Lớp",80); const periodKey=requiredString(url.searchParams.get("periodKey"),"Kỳ học phí",20);
    const result=await db.prepare(`
      SELECT s.id AS student_id,s.code,s.full_name,COALESCE(e.fee_override,c.fee_amount) AS suggested_amount
      FROM enrollments e JOIN students s ON s.id=e.student_id JOIN classes c ON c.id=e.class_id
      LEFT JOIN invoices i ON i.workspace_id=e.workspace_id AND i.student_id=s.id AND i.class_id=c.id AND i.period_key=?
      WHERE e.workspace_id=? AND e.class_id=? AND e.status='active' AND s.status='active' AND i.id IS NULL
      ORDER BY s.full_name
    `).bind(periodKey,auth.workspaceId,classId).all();
    return ok({candidates:result.results});
  }

  if(path==="/billing/invoices/bulk"&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"billing.write");
    const body=await readJson<{classId?:unknown;periodKey?:unknown;dueDate?:unknown;rows?:Array<{studentId?:unknown;amount?:unknown}>}>(request);
    const classId=requiredString(body.classId,"Lớp",80); const periodKey=requiredString(body.periodKey,"Kỳ học phí",20);
    if(!Array.isArray(body.rows)||!body.rows.length||body.rows.length>20) throw new ApiError(400,"Mỗi đợt phát hành từ 1 đến 20 hóa đơn.","BATCH_LIMIT");
    const dueDate=optionalString(body.dueDate,10); const issueDate=new Date().toISOString().slice(0,10);
    const existingCount=await db.prepare(`SELECT COUNT(*) AS total FROM invoices WHERE workspace_id=? AND number LIKE ?`).bind(auth.workspaceId,`HD${issueDate.replaceAll("-","")}-%`).first<{total:number}>();
    let sequence=Number(existingCount?.total||0)+1; const createdInvoices:Array<{id:string;studentId:string;number:string;amount:number}>=[]; const statements:D1PreparedStatement[]=[];
    for(const row of body.rows){
      const studentId=requiredString(row.studentId,"Học sinh",80); const amount=integerMoney(row.amount,"Học phí"); const invoiceId=id("inv");
      const number=`HD${issueDate.replaceAll("-","")}-${String(sequence++).padStart(4,"0")}`;
      createdInvoices.push({id:invoiceId,studentId,number,amount});
      statements.push(db.prepare(`INSERT INTO invoices (id,workspace_id,student_id,class_id,number,period_key,issue_date,due_date,total_amount,created_by) SELECT ?,?,?,?,?,?,?,?,?,? WHERE EXISTS (SELECT 1 FROM enrollments WHERE workspace_id=? AND class_id=? AND student_id=? AND status='active')`)
        .bind(invoiceId,auth.workspaceId,studentId,classId,number,periodKey,issueDate,dueDate,amount,auth.userId,auth.workspaceId,classId,studentId));
      statements.push(db.prepare(`INSERT INTO invoice_items (id,workspace_id,invoice_id,description,quantity,unit_amount,total_amount,item_type) VALUES (?,?,?,?,1,?,?,'fee')`)
        .bind(id("itm"),auth.workspaceId,invoiceId,`Học phí kỳ ${periodKey}`,amount,amount));
    }
    try{await db.batch(statements);}catch(error){if(String(error).includes("UNIQUE")) throw new ApiError(409,"Có học sinh đã được phát hành học phí trong kỳ này. Hãy tải lại danh sách.","DUPLICATE_INVOICE");throw error;}
    await audit(env,auth,"invoice.bulk_created","invoice",null,{classId,periodKey,count:createdInvoices.length}); return created({invoices:createdInvoices});
  }

  const voidMatch=path.match(/^\/billing\/invoices\/([^/]+)\/void$/);
  if(voidMatch&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"billing.write");
    const body=await readJson<Record<string,unknown>>(request); const reason=requiredString(body.reason,"Lý do",500);
    const invoice=await db.prepare(`SELECT paid_amount,status FROM invoices WHERE id=? AND workspace_id=?`).bind(voidMatch[1],auth.workspaceId).first<{paid_amount:number;status:string}>();
    if(!invoice) throw new ApiError(404,"Không tìm thấy hóa đơn.","NOT_FOUND");
    if(invoice.paid_amount>0) throw new ApiError(409,"Hóa đơn đã có thanh toán; cần hoàn hoặc phân bổ lại trước khi hủy.","INVOICE_HAS_PAYMENT");
    await db.prepare(`UPDATE invoices SET status='void',notes=COALESCE(notes,'')||?,updated_at=datetime('now') WHERE id=? AND workspace_id=?`).bind(`\nHủy: ${reason}`,voidMatch[1],auth.workspaceId).run();
    await audit(env,auth,"invoice.voided","invoice",voidMatch[1],{reason}); return ok({ok:true});
  }

  return null;
}
