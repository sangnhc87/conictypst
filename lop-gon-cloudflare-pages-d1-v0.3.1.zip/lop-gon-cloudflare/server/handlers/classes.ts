import type { Env } from "../types";
import { requireAuth } from "../auth";
import { requirePermission } from "../permissions";
import { ApiError, created, ok, readJson } from "../http";
import { audit } from "../db";
import { id } from "../ids";
import { integerMoney, optionalString, requiredString } from "../validation";
import { tenantDb } from "../tenant";

function classPayload(body:Record<string,unknown>){
  return {
    code:requiredString(body.code,"Mã lớp",30).toUpperCase(),
    name:requiredString(body.name,"Tên lớp",120),
    subject:optionalString(body.subject,80),
    grade:optionalString(body.grade,30),
    teacherName:optionalString(body.teacherName,120),
    scheduleText:optionalString(body.scheduleText,200),
    feeAmount:integerMoney(body.feeAmount??0,"Học phí",true),
  };
}

export async function classRoutes(request:Request,env:Env,path:string,method:string,url:URL):Promise<Response|null>{
  if(path==="/classes"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"classes.read");
    const status=url.searchParams.get("status")||"active";
    const result=await db.prepare(`
      SELECT c.id,c.code,c.name,c.subject,c.grade,c.teacher_name,c.schedule_text,c.fee_amount,c.status,c.created_at,
             COUNT(CASE WHEN e.status='active' THEN 1 END) AS student_count
      FROM classes c LEFT JOIN enrollments e ON e.class_id=c.id AND e.workspace_id=c.workspace_id
      WHERE c.workspace_id=? AND (?='all' OR c.status=?)
      GROUP BY c.id ORDER BY c.name
    `).bind(auth.workspaceId,status,status).all();
    return ok({classes:result.results});
  }
  if(path==="/classes"&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"classes.write");
    const body=await readJson<Record<string,unknown>>(request); const data=classPayload(body); const classId=id("cls");
    try{
      await db.prepare(`INSERT INTO classes (id,workspace_id,code,name,subject,grade,teacher_name,schedule_text,fee_amount) VALUES (?,?,?,?,?,?,?,?,?)`)
        .bind(classId,auth.workspaceId,data.code,data.name,data.subject,data.grade,data.teacherName,data.scheduleText,data.feeAmount).run();
    }catch(error){ if(String(error).includes("UNIQUE")) throw new ApiError(409,"Mã lớp đã tồn tại.","DUPLICATE_CODE"); throw error; }
    await audit(env,auth,"class.created","class",classId,{code:data.code});
    return created({class:{id:classId,...data,status:"active"}});
  }
  const match=path.match(/^\/classes\/([^/]+)$/);
  if(match&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"classes.read");
    const klass=await db.prepare(`SELECT * FROM classes WHERE id=? AND workspace_id=?`).bind(match[1],auth.workspaceId).first();
    if(!klass) throw new ApiError(404,"Không tìm thấy lớp.","NOT_FOUND");
    const [students,sessions]=await Promise.all([
      db.prepare(`SELECT e.id AS enrollment_id,e.status,e.start_date,s.id,s.code,s.full_name,s.grade,s.parent_phone FROM enrollments e JOIN students s ON s.id=e.student_id WHERE e.workspace_id=? AND e.class_id=? ORDER BY s.full_name`).bind(auth.workspaceId,match[1]).all(),
      db.prepare(`SELECT id,session_date,start_time,end_time,status,topic,confirmed_at FROM lesson_sessions WHERE workspace_id=? AND class_id=? ORDER BY session_date DESC,start_time DESC LIMIT 30`).bind(auth.workspaceId,match[1]).all(),
    ]);
    return ok({class:klass,students:students.results,sessions:sessions.results});
  }
  if(match&&method==="PATCH"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"classes.write");
    const body=await readJson<Record<string,unknown>>(request); const data=classPayload(body);
    const status=typeof body.status==="string"&&["active","completed","inactive"].includes(body.status)?body.status:"active";
    const result=await db.prepare(`UPDATE classes SET code=?,name=?,subject=?,grade=?,teacher_name=?,schedule_text=?,fee_amount=?,status=?,updated_at=datetime('now') WHERE id=? AND workspace_id=?`)
      .bind(data.code,data.name,data.subject,data.grade,data.teacherName,data.scheduleText,data.feeAmount,status,match[1],auth.workspaceId).run();
    if(!result.meta.changes) throw new ApiError(404,"Không tìm thấy lớp.","NOT_FOUND");
    await audit(env,auth,"class.updated","class",match[1],{status}); return ok({ok:true});
  }
  const enrollMatch=path.match(/^\/classes\/([^/]+)\/enrollments$/);
  if(enrollMatch&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"classes.write");
    const body=await readJson<Record<string,unknown>>(request); const studentId=requiredString(body.studentId,"Học sinh",80);
    const [klass,student]=await Promise.all([
      db.prepare(`SELECT id FROM classes WHERE id=? AND workspace_id=?`).bind(enrollMatch[1],auth.workspaceId).first(),
      db.prepare(`SELECT id FROM students WHERE id=? AND workspace_id=? AND status!='inactive'`).bind(studentId,auth.workspaceId).first(),
    ]);
    if(!klass||!student) throw new ApiError(404,"Không tìm thấy lớp hoặc học sinh.","NOT_FOUND");
    await db.prepare(`INSERT INTO enrollments (id,workspace_id,class_id,student_id,status,start_date) VALUES (?,?,?,?, 'active',?) ON CONFLICT(class_id,student_id) DO UPDATE SET status='active',end_date=NULL`)
      .bind(id("enr"),auth.workspaceId,enrollMatch[1],studentId,optionalString(body.startDate,10)||new Date().toISOString().slice(0,10)).run();
    await audit(env,auth,"enrollment.created","class",enrollMatch[1],{studentId}); return created({ok:true});
  }
  const removeMatch=path.match(/^\/classes\/([^/]+)\/enrollments\/([^/]+)$/);
  if(removeMatch&&method==="DELETE"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"classes.write");
    await db.prepare(`UPDATE enrollments SET status='ended',end_date=date('now') WHERE workspace_id=? AND class_id=? AND student_id=?`).bind(auth.workspaceId,removeMatch[1],removeMatch[2]).run();
    await audit(env,auth,"enrollment.ended","class",removeMatch[1],{studentId:removeMatch[2]}); return ok({ok:true});
  }
  return null;
}
