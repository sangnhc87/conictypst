import type { Env } from "../types";
import { requireAuth } from "../auth";
import { requirePermission } from "../permissions";
import { ApiError, created, ok, readJson } from "../http";
import { audit, nextSequence } from "../db";
import { id } from "../ids";
import { optionalString, requiredString } from "../validation";
import { tenantDb } from "../tenant";

export async function noticeRoutes(request:Request,env:Env,path:string,method:string):Promise<Response|null>{
  if(path==="/transfer-notices"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.collect");
    const result=await db.prepare(`SELECT n.*,s.code AS student_code,s.full_name,i.number AS invoice_number,i.total_amount-i.paid_amount AS invoice_outstanding FROM parent_transfer_notices n JOIN students s ON s.id=n.student_id LEFT JOIN invoices i ON i.id=n.invoice_id WHERE n.workspace_id=? ORDER BY CASE n.status WHEN 'pending' THEN 1 ELSE 2 END,n.created_at DESC LIMIT 200`).bind(auth.workspaceId).all();
    return ok({notices:result.results});
  }
  const reject=path.match(/^\/transfer-notices\/([^/]+)\/reject$/);
  if(reject&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.collect"); const body=await readJson<Record<string,unknown>>(request); const reason=requiredString(body.reason,"Lý do",500);
    const result=await db.prepare(`UPDATE parent_transfer_notices SET status='rejected',reviewed_by=?,reviewed_at=datetime('now'),note=COALESCE(note,'')||? WHERE id=? AND workspace_id=? AND status='pending'`).bind(auth.userId,`\nTừ chối: ${reason}`,reject[1],auth.workspaceId).run();
    if(!result.meta.changes)throw new ApiError(409,"Thông báo đã được xử lý.","ALREADY_REVIEWED"); await audit(env,auth,"transfer_notice.rejected","transfer_notice",reject[1],{reason});return ok({ok:true});
  }
  const confirm=path.match(/^\/transfer-notices\/([^/]+)\/confirm$/);
  if(confirm&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.collect");
    const notice=await db.prepare(`SELECT * FROM parent_transfer_notices WHERE id=? AND workspace_id=? AND status='pending'`).bind(confirm[1],auth.workspaceId).first<{id:string;student_id:string;invoice_id:string|null;amount:number;reference:string|null}>();
    if(!notice)throw new ApiError(409,"Thông báo không tồn tại hoặc đã được xử lý.","ALREADY_REVIEWED");
    let allocation=0; if(notice.invoice_id){const invoice=await db.prepare(`SELECT total_amount-paid_amount AS outstanding FROM invoices WHERE id=? AND workspace_id=? AND student_id=?`).bind(notice.invoice_id,auth.workspaceId,notice.student_id).first<{outstanding:number}>();allocation=Math.min(Number(invoice?.outstanding||0),notice.amount);}
    const paymentId=id("pay"),receiptNumber=await nextSequence(env,auth.workspaceId,"PT","payments"),credit=notice.amount-allocation; const statements:D1PreparedStatement[]=[
      db.prepare(`INSERT INTO payments (id,workspace_id,student_id,receipt_number,amount,method,source_key,reference,note,received_by,received_by_name) VALUES (?,?,?,?,?,'bank_transfer',?,?,'Phụ huynh báo chuyển khoản',?,?)`).bind(paymentId,auth.workspaceId,notice.student_id,receiptNumber,notice.amount,`notice:${notice.id}`,notice.reference,auth.userId,auth.fullName),
      db.prepare(`UPDATE parent_transfer_notices SET status='confirmed',reviewed_by=?,reviewed_at=datetime('now') WHERE id=? AND workspace_id=?`).bind(auth.userId,notice.id,auth.workspaceId),
    ];
    if(allocation>0&&notice.invoice_id){statements.push(db.prepare(`INSERT INTO payment_allocations (id,workspace_id,payment_id,invoice_id,amount) VALUES (?,?,?,?,?)`).bind(id("pal"),auth.workspaceId,paymentId,notice.invoice_id,allocation));statements.push(db.prepare(`UPDATE invoices SET paid_amount=paid_amount+?,status=CASE WHEN paid_amount+?=total_amount THEN 'paid' ELSE 'partially_paid' END,updated_at=datetime('now') WHERE id=? AND workspace_id=?`).bind(allocation,allocation,notice.invoice_id,auth.workspaceId));}
    if(credit>0){statements.push(db.prepare(`INSERT INTO student_credits (id,workspace_id,student_id,balance_amount) VALUES (?,?,?,?) ON CONFLICT(workspace_id,student_id) DO UPDATE SET balance_amount=balance_amount+excluded.balance_amount,updated_at=datetime('now')`).bind(id("crd"),auth.workspaceId,notice.student_id,credit));statements.push(db.prepare(`INSERT INTO credit_ledger (id,workspace_id,student_id,payment_id,entry_type,amount,balance_after,note,created_by) SELECT ?,?,?,?,?,?,balance_amount,?,? FROM student_credits WHERE workspace_id=? AND student_id=?`).bind(id("clg"),auth.workspaceId,notice.student_id,paymentId,"deposit",credit,"Phần chuyển khoản chưa phân bổ",auth.userId,auth.workspaceId,notice.student_id));}
    try{await db.batch(statements);}catch(error){if(String(error).includes("UNIQUE"))throw new ApiError(409,"Thông báo đã được xác nhận trước đó.","ALREADY_REVIEWED");throw error;}await audit(env,auth,"transfer_notice.confirmed","payment",paymentId,{noticeId:notice.id,amount:notice.amount,allocation,credit});return created({paymentId,receiptNumber,allocation,credit});
  }
  return null;
}
