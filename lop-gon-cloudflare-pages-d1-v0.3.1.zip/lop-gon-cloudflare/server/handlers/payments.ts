import type { Env } from "../types";
import { requireAuth } from "../auth";
import { requirePermission } from "../permissions";
import { ApiError, created, ok, readJson } from "../http";
import { audit, nextSequence } from "../db";
import { id } from "../ids";
import { integerMoney, optionalString, requiredString } from "../validation";
import { randomToken, sha256 } from "../crypto";
import { tenantDb } from "../tenant";

interface AllocationInput { invoiceId?: unknown; amount?: unknown }

async function openShift(db:D1Database,workspaceId:string,userId:string){
  return db.prepare(`SELECT id FROM cash_shifts WHERE workspace_id=? AND user_id=? AND status='open' ORDER BY opened_at DESC LIMIT 1`).bind(workspaceId,userId).first<{id:string}>();
}

export async function paymentRoutes(request:Request,env:Env,path:string,method:string,url:URL):Promise<Response|null>{
  if(path==="/payments"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"billing.read");
    const q=(url.searchParams.get("q")||"").trim(), like=`%${q}%`; const methodFilter=url.searchParams.get("method")||"all";
    const result=await db.prepare(`
      SELECT p.id,p.receipt_number,p.amount,p.method,p.status,p.reference,p.received_at,p.refunded_amount,s.id AS student_id,s.code AS student_code,s.full_name,
             COALESCE(SUM(pa.amount-pa.refunded_amount),0) AS allocated_amount
      FROM payments p JOIN students s ON s.id=p.student_id LEFT JOIN payment_allocations pa ON pa.payment_id=p.id
      WHERE p.workspace_id=? AND (?='all' OR p.method=?) AND (?='' OR s.full_name LIKE ? OR s.code LIKE ? OR p.receipt_number LIKE ? OR p.reference LIKE ?)
      GROUP BY p.id ORDER BY p.received_at DESC LIMIT 200
    `).bind(auth.workspaceId,methodFilter,methodFilter,q,like,like,like,like).all();
    return ok({payments:result.results});
  }

  if(path==="/payments"&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.collect");
    const body=await readJson<{studentId?:unknown;amount?:unknown;method?:unknown;reference?:unknown;note?:unknown;receivedAt?:unknown;allocations?:AllocationInput[]}>(request);
    const studentId=requiredString(body.studentId,"Học sinh",80); const amount=integerMoney(body.amount,"Số tiền");
    const paymentMethod=typeof body.method==="string"&&["cash","bank_transfer","other"].includes(body.method)?body.method:null;
    if(!paymentMethod) throw new ApiError(400,"Phương thức thanh toán không hợp lệ.","VALIDATION_ERROR");
    if(!Array.isArray(body.allocations)||body.allocations.length>15) throw new ApiError(400,"Mỗi lần thu được phân bổ tối đa 15 hóa đơn.","BATCH_LIMIT");
    const student=await db.prepare(`SELECT id FROM students WHERE id=? AND workspace_id=?`).bind(studentId,auth.workspaceId).first();
    if(!student) throw new ApiError(404,"Không tìm thấy học sinh.","NOT_FOUND");
    const clean=body.allocations.map(a=>({invoiceId:requiredString(a.invoiceId,"Hóa đơn",80),amount:integerMoney(a.amount,"Số tiền phân bổ")}));
    const duplicateIds=new Set(clean.map(a=>a.invoiceId)); if(duplicateIds.size!==clean.length) throw new ApiError(400,"Hóa đơn bị chọn trùng.","DUPLICATE_ALLOCATION");
    const allocatedTotal=clean.reduce((sum,a)=>sum+a.amount,0); if(allocatedTotal>amount) throw new ApiError(400,"Tổng phân bổ vượt số tiền nhận.","OVER_ALLOCATION");
    if(clean.length){
      const placeholders=clean.map(()=>"?").join(",");
      const invoices=await db.prepare(`SELECT id,total_amount-paid_amount AS outstanding FROM invoices WHERE workspace_id=? AND student_id=? AND id IN (${placeholders}) AND status IN ('issued','partially_paid','overdue')`)
        .bind(auth.workspaceId,studentId,...clean.map(a=>a.invoiceId)).all<{id:string;outstanding:number}>();
      const outstanding=new Map(invoices.results.map(i=>[i.id,Number(i.outstanding)]));
      for(const allocation of clean){if(!outstanding.has(allocation.invoiceId)) throw new ApiError(409,"Có hóa đơn không còn hợp lệ để thu.","INVALID_INVOICE"); if(allocation.amount>(outstanding.get(allocation.invoiceId)||0)) throw new ApiError(409,"Số tiền phân bổ vượt công nợ hóa đơn.","OVERPAY_INVOICE");}
    }
    let shiftId:string|null=null;
    if(paymentMethod==="cash"){
      const shift=await openShift(db,auth.workspaceId,auth.userId); if(!shift) throw new ApiError(409,"Cần mở ca thu ngân trước khi thu tiền mặt.","NO_OPEN_SHIFT"); shiftId=shift.id;
    }
    const paymentId=id("pay"); const receiptNumber=await nextSequence(env,auth.workspaceId,"PT","payments"); const credit=amount-allocatedTotal;
    const statements:D1PreparedStatement[]=[db.prepare(`INSERT INTO payments (id,workspace_id,student_id,receipt_number,amount,method,reference,note,received_at,received_by,received_by_name,cash_shift_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
      .bind(paymentId,auth.workspaceId,studentId,receiptNumber,amount,paymentMethod,optionalString(body.reference,100),optionalString(body.note,500),optionalString(body.receivedAt,30)||new Date().toISOString(),auth.userId,auth.fullName,shiftId)];
    for(const a of clean){
      statements.push(db.prepare(`INSERT INTO payment_allocations (id,workspace_id,payment_id,invoice_id,amount) VALUES (?,?,?,?,?)`).bind(id("pal"),auth.workspaceId,paymentId,a.invoiceId,a.amount));
      statements.push(db.prepare(`UPDATE invoices SET paid_amount=paid_amount+?,status=CASE WHEN paid_amount+?=total_amount THEN 'paid' ELSE 'partially_paid' END,updated_at=datetime('now') WHERE id=? AND workspace_id=?`).bind(a.amount,a.amount,a.invoiceId,auth.workspaceId));
    }
    if(credit>0){
      const creditId=id("crd");
      statements.push(db.prepare(`INSERT INTO student_credits (id,workspace_id,student_id,balance_amount) VALUES (?,?,?,?) ON CONFLICT(workspace_id,student_id) DO UPDATE SET balance_amount=balance_amount+excluded.balance_amount,updated_at=datetime('now')`).bind(creditId,auth.workspaceId,studentId,credit));
      statements.push(db.prepare(`INSERT INTO credit_ledger (id,workspace_id,student_id,payment_id,entry_type,amount,balance_after,note,created_by) SELECT ?,?,?,?,?,?,balance_amount,?,? FROM student_credits WHERE workspace_id=? AND student_id=?`)
        .bind(id("clg"),auth.workspaceId,studentId,paymentId,"deposit",credit,"Tiền đóng thừa/đóng trước",auth.userId,auth.workspaceId,studentId));
    }
    await db.batch(statements); await audit(env,auth,"payment.confirmed","payment",paymentId,{amount,paymentMethod,allocatedTotal,credit});
    return created({payment:{id:paymentId,receiptNumber,amount,method:paymentMethod,credit}});
  }

  if(path==="/payments/apply-credit"&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.collect");
    const body=await readJson<{studentId?:unknown;allocations?:AllocationInput[]}>(request); const studentId=requiredString(body.studentId,"Học sinh",80);
    if(!Array.isArray(body.allocations)||!body.allocations.length||body.allocations.length>15) throw new ApiError(400,"Chọn từ 1 đến 15 hóa đơn.","BATCH_LIMIT");
    const clean=body.allocations.map(a=>({invoiceId:requiredString(a.invoiceId,"Hóa đơn",80),amount:integerMoney(a.amount,"Số tiền")})); const total=clean.reduce((s,a)=>s+a.amount,0);
    const credit=await db.prepare(`SELECT balance_amount FROM student_credits WHERE workspace_id=? AND student_id=?`).bind(auth.workspaceId,studentId).first<{balance_amount:number}>();
    if(Number(credit?.balance_amount||0)<total) throw new ApiError(409,"Số dư học sinh không đủ.","INSUFFICIENT_CREDIT");
    const placeholders=clean.map(()=>"?").join(","); const invoices=await db.prepare(`SELECT id,total_amount-paid_amount AS outstanding FROM invoices WHERE workspace_id=? AND student_id=? AND id IN (${placeholders})`).bind(auth.workspaceId,studentId,...clean.map(a=>a.invoiceId)).all<{id:string;outstanding:number}>();
    const outstanding=new Map(invoices.results.map(i=>[i.id,Number(i.outstanding)])); for(const a of clean){if(a.amount>(outstanding.get(a.invoiceId)||0)) throw new ApiError(409,"Phân bổ số dư vượt công nợ.","OVERPAY_INVOICE");}
    const paymentId=id("pay"); const receiptNumber=await nextSequence(env,auth.workspaceId,"SD","payments"); const statements:D1PreparedStatement[]=[
      db.prepare(`INSERT INTO payments (id,workspace_id,student_id,receipt_number,amount,method,note,received_by,received_by_name) VALUES (?,?,?,?,?,'credit','Cấn trừ số dư học sinh',?,?)`).bind(paymentId,auth.workspaceId,studentId,receiptNumber,total,auth.userId,auth.fullName),
      db.prepare(`UPDATE student_credits SET balance_amount=balance_amount-?,updated_at=datetime('now') WHERE workspace_id=? AND student_id=? AND balance_amount>=?`).bind(total,auth.workspaceId,studentId,total),
    ];
    for(const a of clean){statements.push(db.prepare(`INSERT INTO payment_allocations (id,workspace_id,payment_id,invoice_id,amount) VALUES (?,?,?,?,?)`).bind(id("pal"),auth.workspaceId,paymentId,a.invoiceId,a.amount));statements.push(db.prepare(`UPDATE invoices SET paid_amount=paid_amount+?,status=CASE WHEN paid_amount+?=total_amount THEN 'paid' ELSE 'partially_paid' END,updated_at=datetime('now') WHERE id=? AND workspace_id=?`).bind(a.amount,a.amount,a.invoiceId,auth.workspaceId));}
    statements.push(db.prepare(`INSERT INTO credit_ledger (id,workspace_id,student_id,payment_id,entry_type,amount,balance_after,note,created_by) SELECT ?,?,?,?,?,?,balance_amount,?,? FROM student_credits WHERE workspace_id=? AND student_id=?`).bind(id("clg"),auth.workspaceId,studentId,paymentId,"apply",-total,"Cấn trừ hóa đơn",auth.userId,auth.workspaceId,studentId));
    await db.batch(statements); await audit(env,auth,"credit.applied","payment",paymentId,{total}); return created({payment:{id:paymentId,receiptNumber,total}});
  }

  const refundMatch=path.match(/^\/payments\/([^/]+)\/refund$/);
  if(refundMatch&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.refund");
    const body=await readJson<Record<string,unknown>>(request); const refundAmount=integerMoney(body.amount,"Số tiền hoàn"); const reason=requiredString(body.reason,"Lý do hoàn",500);
    const payment=await db.prepare(`SELECT * FROM payments WHERE id=? AND workspace_id=? AND status IN ('confirmed','partially_refunded')`).bind(refundMatch[1],auth.workspaceId).first<{id:string;student_id:string;amount:number;refunded_amount:number;method:string}>();
    if(!payment) throw new ApiError(404,"Không tìm thấy khoản thu có thể hoàn.","NOT_FOUND");
    if(refundAmount>payment.amount-payment.refunded_amount) throw new ApiError(409,"Số tiền hoàn vượt phần còn lại của khoản thu.","OVER_REFUND");
    const allocations=await db.prepare(`SELECT id,invoice_id,amount,refunded_amount FROM payment_allocations WHERE workspace_id=? AND payment_id=? ORDER BY created_at DESC`).bind(auth.workspaceId,payment.id).all<{id:string;invoice_id:string;amount:number;refunded_amount:number}>();
    const originalAllocated=allocations.results.reduce((s,a)=>s+Number(a.amount),0); const originalCredit=payment.amount-originalAllocated;
    const existingCredit=await db.prepare(`SELECT balance_amount FROM student_credits WHERE workspace_id=? AND student_id=?`).bind(auth.workspaceId,payment.student_id).first<{balance_amount:number}>();
    const previousRefund=payment.refunded_amount; const maxCreditRefund=Math.max(0,originalCredit-Math.min(previousRefund,originalCredit));
    let remaining=refundAmount; const creditRefund=Math.min(remaining,maxCreditRefund,Number(existingCredit?.balance_amount||0)); remaining-=creditRefund;
    const changes:Array<{allocationId:string;invoiceId:string;amount:number}>=[];
    for(const a of allocations.results){if(remaining<=0)break; const available=Number(a.amount)-Number(a.refunded_amount); const take=Math.min(remaining,available); if(take>0){changes.push({allocationId:a.id,invoiceId:a.invoice_id,amount:take});remaining-=take;}}
    if(remaining>0) throw new ApiError(409,"Một phần tiền đã được cấn sang giao dịch khác; không đủ số dư để hoàn khoản này.","REFUND_NOT_AVAILABLE");
    let refundShiftId:string|null=null; if(payment.method==="cash"){const shift=await openShift(db,auth.workspaceId,auth.userId);if(!shift)throw new ApiError(409,"Cần mở ca hiện tại để ghi nhận tiền mặt hoàn ra.","NO_OPEN_SHIFT");refundShiftId=shift.id;}
    const statements:D1PreparedStatement[]=[];
    if(creditRefund>0){statements.push(db.prepare(`UPDATE student_credits SET balance_amount=balance_amount-?,updated_at=datetime('now') WHERE workspace_id=? AND student_id=? AND balance_amount>=?`).bind(creditRefund,auth.workspaceId,payment.student_id,creditRefund));statements.push(db.prepare(`INSERT INTO credit_ledger (id,workspace_id,student_id,payment_id,entry_type,amount,balance_after,note,created_by) SELECT ?,?,?,?,?,?,balance_amount,?,? FROM student_credits WHERE workspace_id=? AND student_id=?`).bind(id("clg"),auth.workspaceId,payment.student_id,payment.id,"refund",-creditRefund,reason,auth.userId,auth.workspaceId,payment.student_id));}
    for(const change of changes){statements.push(db.prepare(`UPDATE payment_allocations SET refunded_amount=refunded_amount+? WHERE id=? AND workspace_id=?`).bind(change.amount,change.allocationId,auth.workspaceId));statements.push(db.prepare(`UPDATE invoices SET paid_amount=paid_amount-?,status=CASE WHEN paid_amount-?=0 THEN 'issued' ELSE 'partially_paid' END,updated_at=datetime('now') WHERE id=? AND workspace_id=?`).bind(change.amount,change.amount,change.invoiceId,auth.workspaceId));}
    statements.push(db.prepare(`UPDATE payments SET refunded_amount=refunded_amount+?,status=CASE WHEN refunded_amount+?=amount THEN 'refunded' ELSE 'partially_refunded' END,updated_at=datetime('now') WHERE id=? AND workspace_id=?`).bind(refundAmount,refundAmount,payment.id,auth.workspaceId));
    statements.push(db.prepare(`INSERT INTO payment_adjustments (id,workspace_id,payment_id,adjustment_type,amount,reason,cash_shift_id,created_by) VALUES (?,?,?,'refund',?,?,?,?)`).bind(id("adj"),auth.workspaceId,payment.id,refundAmount,reason,refundShiftId,auth.userId));
    await db.batch(statements); await audit(env,auth,"payment.refunded","payment",payment.id,{refundAmount,reason,creditRefund}); return ok({ok:true,refundAmount});
  }

  const receiptMatch=path.match(/^\/payments\/([^/]+)\/receipt-link$/);
  if(receiptMatch&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"billing.read");
    const payment=await db.prepare(`SELECT id FROM payments WHERE id=? AND workspace_id=?`).bind(receiptMatch[1],auth.workspaceId).first(); if(!payment)throw new ApiError(404,"Không tìm thấy phiếu thu.","NOT_FOUND");
    const token=randomToken(24), tokenHash=await sha256(token), expiresAt=new Date(Date.now()+365*86400000).toISOString();
    await db.batch([db.prepare(`UPDATE receipt_links SET revoked_at=datetime('now') WHERE workspace_id=? AND payment_id=? AND revoked_at IS NULL`).bind(auth.workspaceId,receiptMatch[1]),db.prepare(`INSERT INTO receipt_links (id,workspace_id,payment_id,token_hash,expires_at,created_by) VALUES (?,?,?,?,?,?)`).bind(id("rlk"),auth.workspaceId,receiptMatch[1],tokenHash,expiresAt,auth.userId)]);
    return created({token,expiresAt});
  }
  return null;
}
