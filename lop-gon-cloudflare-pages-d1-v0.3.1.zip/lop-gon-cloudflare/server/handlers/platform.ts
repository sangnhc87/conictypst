import type { Env, Role } from "../types";
import { requirePlatformAdmin, requireAuth } from "../auth";
import { ApiError, created, ok, readJson } from "../http";
import { hashPassword } from "../crypto";
import { id } from "../ids";
import { countActiveMembers, audit } from "../db";
import { enumValue, integerMoney, requiredString, validEmail, validPassword } from "../validation";
import { requirePermission } from "../permissions";
import { tenantDb } from "../tenant";

const roles = ["owner","admin","accountant","cashier","teacher"] as const;

export async function platformRoutes(request: Request, env: Env, path: string, method: string): Promise<Response | null> {
  if (path === "/workspace" && method === "GET") {
    const auth = await requireAuth(request, env);
    const db = tenantDb(env,auth.tenantSlot);
    const workspace = await env.CONTROL_DB.prepare(`SELECT id,name,code,status,max_users,max_students,timezone,currency,receipt_prefix,tenant_slot,created_at FROM workspaces WHERE id=?`).bind(auth.workspaceId).first();
    const businessUsage = await db.prepare(`SELECT COUNT(*) AS students FROM students WHERE workspace_id=? AND status='active'`).bind(auth.workspaceId).first<{students:number}>();
    const memberUsage = await env.CONTROL_DB.prepare(`SELECT COUNT(*) AS users FROM workspace_members WHERE workspace_id=? AND status='active'`).bind(auth.workspaceId).first<{users:number}>();
    return ok({ workspace, usage:{students:Number(businessUsage?.students||0),users:Number(memberUsage?.users||0)} });
  }

  if (path === "/workspace" && method === "PATCH") {
    const auth = await requireAuth(request, env);
    requirePermission(auth.role, "workspace.manage");
    const body = await readJson<Record<string, unknown>>(request);
    const name = requiredString(body.name, "Tên trung tâm", 120);
    const receiptPrefix = requiredString(body.receiptPrefix || "PT", "Tiền tố phiếu thu", 8).toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (!receiptPrefix) throw new ApiError(400, "Tiền tố phiếu thu không hợp lệ.", "VALIDATION_ERROR");
    await env.CONTROL_DB.prepare(`UPDATE workspaces SET name=?,receipt_prefix=?,updated_at=datetime('now') WHERE id=?`).bind(name,receiptPrefix,auth.workspaceId).run();
    await audit(env,auth,"workspace.updated","workspace",auth.workspaceId,{name,receiptPrefix});
    return ok({ok:true});
  }

  if (path === "/platform/workspaces" && method === "GET") {
    await requirePlatformAdmin(request, env);
    const result = await env.CONTROL_DB.prepare(`
      SELECT w.id,w.name,w.code,w.tenant_slot,w.status,w.max_users,w.max_students,w.created_at,
             (SELECT COUNT(*) FROM workspace_members m WHERE m.workspace_id=w.id AND m.status='active') AS user_count
      FROM workspaces w ORDER BY w.created_at DESC
    `).all<Record<string,unknown>>();
    const workspaces=[] as Record<string,unknown>[];
    for(const workspace of result.results){
      const slot=Number(workspace.tenant_slot); const db=tenantDb(env,slot);
      const count=await db.prepare(`SELECT COUNT(*) AS total FROM students WHERE workspace_id=? AND status='active'`).bind(String(workspace.id)).first<{total:number}>();
      workspaces.push({...workspace,student_count:Number(count?.total||0)});
    }
    return ok({ workspaces });
  }

  if (path === "/platform/workspaces" && method === "POST") {
    const admin = await requirePlatformAdmin(request, env);
    const body = await readJson<Record<string, unknown>>(request);
    const name = requiredString(body.name, "Tên trung tâm", 120);
    const ownerName = requiredString(body.ownerName, "Tên chủ trung tâm", 120);
    const ownerEmail = validEmail(body.ownerEmail);
    const tempPassword = validPassword(body.tempPassword);
    const maxUsers = Math.min(Math.max(integerMoney(body.maxUsers ?? 5, "Số tài khoản"), 1), 5);
    const maxStudents = Math.min(Math.max(integerMoney(body.maxStudents ?? 500, "Số học sinh"), 1), 500);
    const duplicate = await env.CONTROL_DB.prepare(`SELECT id FROM users WHERE email = ? COLLATE NOCASE`).bind(ownerEmail).first();
    if (duplicate) throw new ApiError(409, "Email chủ trung tâm đã tồn tại.", "EMAIL_EXISTS");
    const slots=await env.CONTROL_DB.prepare(`SELECT tenant_slot FROM workspaces`).all<{tenant_slot:number}>();
    const used=new Set(slots.results.map(r=>Number(r.tenant_slot))); let tenantSlot=0; for(let i=1;i<=9;i++){if(!used.has(i)){tenantSlot=i;break;}}
    if(!tenantSlot) throw new ApiError(409,"Gói Cloudflare Free đã dùng đủ 9 database trung tâm. Cần nâng Workers Paid hoặc ngừng tạo thêm.","FREE_TENANT_LIMIT");
    const workspaceId = id("wsp"); const userId = id("usr"); const code = `TT-${crypto.randomUUID().slice(0, 8).toUpperCase()}`; const passwordHash = await hashPassword(tempPassword);
    await env.CONTROL_DB.batch([
      env.CONTROL_DB.prepare(`INSERT INTO workspaces (id,name,code,tenant_slot,max_users,max_students) VALUES (?,?,?,?,?,?)`).bind(workspaceId, name, code, tenantSlot, maxUsers, maxStudents),
      env.CONTROL_DB.prepare(`INSERT INTO users (id,email,password_hash,full_name) VALUES (?,?,?,?)`).bind(userId, ownerEmail, passwordHash, ownerName),
      env.CONTROL_DB.prepare(`INSERT INTO workspace_members (id,workspace_id,user_id,role) VALUES (?,?,?,'owner')`).bind(id("mem"), workspaceId, userId),
      env.CONTROL_DB.prepare(`INSERT INTO platform_audit_logs (id,actor_user_id,action,workspace_id,details_json) VALUES (?,?,?,?,?)`).bind(id("paud"),admin.userId,"platform.workspace_created",workspaceId,JSON.stringify({name,ownerEmail,tenantSlot,maxUsers,maxStudents})),
    ]);
    return created({ workspace: { id: workspaceId, name, code, tenantSlot, maxUsers, maxStudents }, owner: { email: ownerEmail, tempPassword } });
  }

  if (path === "/members" && method === "GET") {
    const auth = await requireAuth(request, env); requirePermission(auth.role, "members.manage");
    const result = await env.CONTROL_DB.prepare(`SELECT u.id,u.email,u.full_name,u.status,wm.role,wm.status AS membership_status,wm.created_at,u.last_login_at FROM workspace_members wm JOIN users u ON u.id=wm.user_id WHERE wm.workspace_id=? ORDER BY CASE wm.role WHEN 'owner' THEN 1 WHEN 'admin' THEN 2 ELSE 3 END,u.full_name`).bind(auth.workspaceId).all();
    return ok({ members: result.results, limit: auth.maxUsers });
  }

  if (path === "/members" && method === "POST") {
    const auth = await requireAuth(request, env); requirePermission(auth.role, "members.manage");
    const current = await countActiveMembers(env, auth.workspaceId); if (current >= auth.maxUsers) throw new ApiError(409, `Trung tâm đã dùng đủ ${auth.maxUsers} tài khoản.`, "USER_LIMIT");
    const body = await readJson<Record<string, unknown>>(request); const email = validEmail(body.email); const fullName = requiredString(body.fullName, "Họ tên", 120); const password = validPassword(body.tempPassword); const role = enumValue(body.role, roles.filter((r) => r !== "owner"), "Vai trò") as Exclude<Role,"owner">;
    const duplicate = await env.CONTROL_DB.prepare(`SELECT id FROM users WHERE email = ? COLLATE NOCASE`).bind(email).first(); if (duplicate) throw new ApiError(409, "Email đã được sử dụng.", "EMAIL_EXISTS");
    const userId = id("usr"); const passwordHash = await hashPassword(password);
    await env.CONTROL_DB.batch([
      env.CONTROL_DB.prepare(`INSERT INTO users (id,email,password_hash,full_name) VALUES (?,?,?,?)`).bind(userId,email,passwordHash,fullName),
      env.CONTROL_DB.prepare(`INSERT INTO workspace_members (id,workspace_id,user_id,role) VALUES (?,?,?,?)`).bind(id("mem"),auth.workspaceId,userId,role),
    ]);
    await audit(env,auth,"member.created","user",userId,{email,role});
    return created({ member: { id:userId,email,fullName,role }, tempPassword: password });
  }

  const memberMatch = path.match(/^\/members\/([^/]+)$/);
  if (memberMatch && method === "PATCH") {
    const auth = await requireAuth(request, env); requirePermission(auth.role, "members.manage"); const userId = memberMatch[1]; const body = await readJson<Record<string, unknown>>(request);
    const target = await env.CONTROL_DB.prepare(`SELECT wm.role,wm.status,u.email FROM workspace_members wm JOIN users u ON u.id=wm.user_id WHERE wm.workspace_id=? AND wm.user_id=?`).bind(auth.workspaceId,userId).first<{role:Role;status:string;email:string}>();
    if (!target) throw new ApiError(404,"Không tìm thấy tài khoản.","NOT_FOUND"); if (target.role === "owner") throw new ApiError(403,"Không thể khóa hoặc đổi vai trò chủ trung tâm.","OWNER_PROTECTED"); if(target.role==="admin"&&auth.role!=="owner")throw new ApiError(403,"Chỉ chủ trung tâm được quản lý tài khoản quản lý khác.","ADMIN_PROTECTED");
    const newRole = body.role ? enumValue(body.role, roles.filter((r)=>r!=="owner"), "Vai trò") : target.role; const newStatus = body.status ? enumValue(body.status,["active","suspended"] as const,"Trạng thái") : target.status;
    await env.CONTROL_DB.batch([env.CONTROL_DB.prepare(`UPDATE workspace_members SET role=?,status=? WHERE workspace_id=? AND user_id=?`).bind(newRole,newStatus,auth.workspaceId,userId),env.CONTROL_DB.prepare(`UPDATE users SET status=?,updated_at=datetime('now') WHERE id=?`).bind(newStatus,userId)]);
    await audit(env,auth,"member.updated","user",userId,{role:newRole,status:newStatus}); return ok({ ok:true });
  }

  const resetMatch = path.match(/^\/members\/([^/]+)\/reset-password$/);
  if (resetMatch && method === "POST") {
    const auth = await requireAuth(request, env); requirePermission(auth.role,"members.manage"); const body = await readJson<Record<string,unknown>>(request); const password = validPassword(body.tempPassword);
    const target = await env.CONTROL_DB.prepare(`SELECT wm.role FROM workspace_members wm WHERE wm.workspace_id=? AND wm.user_id=?`).bind(auth.workspaceId,resetMatch[1]).first<{role:Role}>(); if (!target) throw new ApiError(404,"Không tìm thấy tài khoản.","NOT_FOUND"); if (target.role === "owner" && auth.role !== "owner") throw new ApiError(403,"Không đủ quyền đổi mật khẩu chủ trung tâm.","FORBIDDEN");
    await env.CONTROL_DB.batch([env.CONTROL_DB.prepare(`UPDATE users SET password_hash=?,updated_at=datetime('now') WHERE id=?`).bind(await hashPassword(password),resetMatch[1]),env.CONTROL_DB.prepare(`DELETE FROM sessions WHERE user_id=?`).bind(resetMatch[1])]);
    await audit(env,auth,"member.password_reset","user",resetMatch[1]); return ok({ ok:true,tempPassword:password });
  }

  return null;
}
