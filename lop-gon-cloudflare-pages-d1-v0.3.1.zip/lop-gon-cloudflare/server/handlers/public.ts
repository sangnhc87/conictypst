import type { Env } from "../types";
import { ApiError, created, ok, readJson } from "../http";
import { sha256 } from "../crypto";
import { id } from "../ids";
import { integerMoney, optionalString } from "../validation";
import { allTenantDbs } from "../tenant";

async function findToken<T>(env:Env,table:"parent_links"|"receipt_links",hash:string):Promise<{db:D1Database;slot:number;row:T}|null>{
  for(const item of allTenantDbs(env)){
    const row=await item.db.prepare(`SELECT * FROM ${table} WHERE token_hash=? AND revoked_at IS NULL AND expires_at>datetime('now')`).bind(hash).first<T>();
    if(row)return {...item,row};
  }
  return null;
}

export async function publicRoutes(request:Request,env:Env,path:string,method:string):Promise<Response|null>{
  const parentMatch=path.match(/^\/public\/parent\/([^/]+)$/);
  if(parentMatch&&method==="GET"){
    const found=await findToken<{workspace_id:string;student_id:string}>(env,"parent_links",await sha256(parentMatch[1]));
    if(!found)throw new ApiError(404,"Liên kết phụ huynh không hợp lệ hoặc đã hết hạn.","INVALID_LINK"); const {db,row:link}=found;
    const workspace=await env.CONTROL_DB.prepare(`SELECT name FROM workspaces WHERE id=? AND tenant_slot=? AND status='active'`).bind(link.workspace_id,found.slot).first<{name:string}>(); if(!workspace)throw new ApiError(404,"Trung tâm không còn hoạt động.","WORKSPACE_INACTIVE");
    const [student,invoices,payments,credit,attendance,results]=await Promise.all([
      db.prepare(`SELECT id,code,full_name,grade,school FROM students WHERE id=? AND workspace_id=?`).bind(link.student_id,link.workspace_id).first(),
      db.prepare(`SELECT id,number,period_key,due_date,status,total_amount,paid_amount,total_amount-paid_amount AS outstanding FROM invoices WHERE workspace_id=? AND student_id=? AND status!='void' ORDER BY issue_date DESC LIMIT 36`).bind(link.workspace_id,link.student_id).all(),
      db.prepare(`SELECT receipt_number,amount,method,status,received_at,refunded_amount FROM payments WHERE workspace_id=? AND student_id=? ORDER BY received_at DESC LIMIT 36`).bind(link.workspace_id,link.student_id).all(),
      db.prepare(`SELECT balance_amount FROM student_credits WHERE workspace_id=? AND student_id=?`).bind(link.workspace_id,link.student_id).first<{balance_amount:number}>(),
      db.prepare(`SELECT ar.status,COUNT(*) AS count FROM attendance_records ar WHERE ar.workspace_id=? AND ar.student_id=? GROUP BY ar.status`).bind(link.workspace_id,link.student_id).all(),
      db.prepare(`SELECT test_name,subject,score,max_score,taken_at FROM exam_results WHERE workspace_id=? AND student_id=? ORDER BY taken_at DESC LIMIT 20`).bind(link.workspace_id,link.student_id).all(),
    ]);
    return ok({workspaceName:workspace.name,student,invoices:invoices.results,payments:payments.results,credit:Number(credit?.balance_amount||0),attendance:attendance.results,examResults:results.results});
  }
  const noticeMatch=path.match(/^\/public\/parent\/([^/]+)\/transfer-notices$/);
  if(noticeMatch&&method==="POST"){
    const found=await findToken<{workspace_id:string;student_id:string}>(env,"parent_links",await sha256(noticeMatch[1]));
    if(!found)throw new ApiError(404,"Liên kết không hợp lệ hoặc đã hết hạn.","INVALID_LINK"); const {db,row:link}=found;
    const body=await readJson<Record<string,unknown>>(request); if(body.website)return created({ok:true}); const amount=integerMoney(body.amount,"Số tiền"); const invoiceId=optionalString(body.invoiceId,80);
    if(invoiceId){const invoice=await db.prepare(`SELECT id FROM invoices WHERE id=? AND workspace_id=? AND student_id=?`).bind(invoiceId,link.workspace_id,link.student_id).first();if(!invoice)throw new ApiError(404,"Không tìm thấy hóa đơn.","NOT_FOUND");}
    const recent=await db.prepare(`SELECT id FROM parent_transfer_notices WHERE workspace_id=? AND student_id=? AND amount=? AND created_at>datetime('now','-10 minutes') AND status='pending'`).bind(link.workspace_id,link.student_id,amount).first();if(recent)throw new ApiError(409,"Thông báo tương tự vừa được gửi. Trung tâm sẽ kiểm tra.","DUPLICATE_NOTICE");
    const noticeId=id("ntc");await db.prepare(`INSERT INTO parent_transfer_notices (id,workspace_id,student_id,invoice_id,amount,sender_name,transferred_at,reference,note) VALUES (?,?,?,?,?,?,?,?,?)`).bind(noticeId,link.workspace_id,link.student_id,invoiceId,amount,optionalString(body.senderName,120),optionalString(body.transferredAt,30),optionalString(body.reference,100),optionalString(body.note,500)).run();
    return created({id:noticeId,message:"Đã gửi thông báo. Trung tâm sẽ xác nhận sau khi kiểm tra tài khoản ngân hàng."});
  }
  const receiptMatch=path.match(/^\/public\/receipt\/([^/]+)$/);
  if(receiptMatch&&method==="GET"){
    const found=await findToken<{workspace_id:string;payment_id:string}>(env,"receipt_links",await sha256(receiptMatch[1]));
    if(!found)throw new ApiError(404,"Biên nhận không tồn tại hoặc liên kết đã hết hạn.","INVALID_LINK");const{db,row:link}=found;
    const workspace=await env.CONTROL_DB.prepare(`SELECT name FROM workspaces WHERE id=? AND tenant_slot=?`).bind(link.workspace_id,found.slot).first<{name:string}>();
    const payment=await db.prepare(`SELECT p.receipt_number,p.amount,p.method,p.status,p.reference,p.received_at,p.refunded_amount,p.received_by_name,s.code AS student_code,s.full_name FROM payments p JOIN students s ON s.id=p.student_id WHERE p.id=? AND p.workspace_id=?`).bind(link.payment_id,link.workspace_id).first<Record<string,unknown>>();
    if(!payment)throw new ApiError(404,"Không tìm thấy khoản thu.","NOT_FOUND");
    const allocations=await db.prepare(`SELECT pa.amount,pa.refunded_amount,i.number,i.period_key FROM payment_allocations pa JOIN invoices i ON i.id=pa.invoice_id WHERE pa.payment_id=? AND pa.workspace_id=?`).bind(link.payment_id,link.workspace_id).all();
    return ok({payment:{...payment,workspace_name:workspace?.name||"Trung tâm",received_by_name:payment.received_by_name},allocations:allocations.results});
  }
  return null;
}
