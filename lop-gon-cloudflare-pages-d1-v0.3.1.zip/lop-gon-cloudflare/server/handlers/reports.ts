import type { Env } from "../types";
import { requireAuth } from "../auth";
import { hasPermission, requirePermission } from "../permissions";
import { ok } from "../http";
import { tenantDb } from "../tenant";

function csvEscape(value:unknown):string{const text=String(value??"");return /[",\n]/.test(text)?`"${text.replaceAll('"','""')}"`:text;}
function csvResponse(name:string,headers:string[],rows:unknown[][]):Response{const bom="\uFEFF";const body=bom+[headers,...rows].map(row=>row.map(csvEscape).join(",")).join("\n");return new Response(body,{headers:{"content-type":"text/csv; charset=utf-8","content-disposition":`attachment; filename="${name}"`,"cache-control":"no-store"}});}

export async function reportRoutes(request:Request,env:Env,path:string,method:string):Promise<Response|null>{
  if(path==="/dashboard"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot);
    const canViewFinance=hasPermission(auth.role,"reports.finance"); const canCollect=hasPermission(auth.role,"payments.collect");
    const [businessCounts,userCount]=await Promise.all([
      db.prepare(`SELECT (SELECT COUNT(*) FROM students WHERE workspace_id=? AND status='active') AS students,(SELECT COUNT(*) FROM classes WHERE workspace_id=? AND status='active') AS classes`).bind(auth.workspaceId,auth.workspaceId).first(),
      env.CONTROL_DB.prepare(`SELECT COUNT(*) AS total FROM workspace_members WHERE workspace_id=? AND status='active'`).bind(auth.workspaceId).first<{total:number}>(),
    ]);
    let finance={total_billed:0,total_paid:0,total_debt:0}; let today={cash:0,bank:0,total:0}; let pendingTransferNotices=0;
    if(canViewFinance){
      const [financeRow,todayRow]=await Promise.all([
        db.prepare(`SELECT COALESCE(SUM(total_amount),0) AS total_billed,COALESCE(SUM(paid_amount),0) AS total_paid,COALESCE(SUM(total_amount-paid_amount),0) AS total_debt FROM invoices WHERE workspace_id=? AND status!='void'`).bind(auth.workspaceId).first<typeof finance>(),
        db.prepare(`SELECT COALESCE(SUM(CASE WHEN method='cash' THEN amount-refunded_amount ELSE 0 END),0) AS cash,COALESCE(SUM(CASE WHEN method='bank_transfer' THEN amount-refunded_amount ELSE 0 END),0) AS bank,COALESCE(SUM(amount-refunded_amount),0) AS total FROM payments WHERE workspace_id=? AND date(received_at)=date('now') AND status NOT IN ('reversed','void')`).bind(auth.workspaceId).first<typeof today>(),
      ]); finance=financeRow||finance;today=todayRow||today;
    }
    if(canCollect){const row=await db.prepare(`SELECT COUNT(*) AS total FROM parent_transfer_notices WHERE workspace_id=? AND status='pending'`).bind(auth.workspaceId).first<{total:number}>();pendingTransferNotices=Number(row?.total||0);}
    const counts={...(businessCounts as Record<string,unknown>|null),users:Number(userCount?.total||0)};
    return ok({finance,counts,today,pendingTransferNotices,capabilities:{canViewFinance,canCollect,canAttendance:hasPermission(auth.role,"attendance.write"),canBillingWrite:hasPermission(auth.role,"billing.write"),canManageShifts:hasPermission(auth.role,"shifts.manage")},workspace:{name:auth.workspaceName,maxUsers:auth.maxUsers,maxStudents:auth.maxStudents,role:auth.role}});
  }
  if(path==="/reports/finance"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"reports.finance");
    const [summary,methods,aging,monthly,credits]=await Promise.all([
      db.prepare(`SELECT COALESCE(SUM(total_amount),0) AS billed,COALESCE(SUM(paid_amount),0) AS paid,COALESCE(SUM(total_amount-paid_amount),0) AS debt,COUNT(*) AS invoice_count FROM invoices WHERE workspace_id=? AND status!='void'`).bind(auth.workspaceId).first(),
      db.prepare(`SELECT method,COUNT(*) AS count,COALESCE(SUM(amount-refunded_amount),0) AS net_amount FROM payments WHERE workspace_id=? AND status NOT IN ('reversed','void') GROUP BY method ORDER BY net_amount DESC`).bind(auth.workspaceId).all(),
      db.prepare(`SELECT CASE WHEN due_date IS NULL OR due_date>=date('now') THEN 'Chưa đến hạn' WHEN julianday('now')-julianday(due_date)<=7 THEN 'Quá hạn 1–7 ngày' WHEN julianday('now')-julianday(due_date)<=30 THEN 'Quá hạn 8–30 ngày' ELSE 'Quá hạn trên 30 ngày' END AS bucket,COALESCE(SUM(total_amount-paid_amount),0) AS amount,COUNT(*) AS count FROM invoices WHERE workspace_id=? AND status IN ('issued','partially_paid','overdue') GROUP BY bucket`).bind(auth.workspaceId).all(),
      db.prepare(`SELECT substr(issue_date,1,7) AS month,COALESCE(SUM(total_amount),0) AS billed,COALESCE(SUM(paid_amount),0) AS paid FROM invoices WHERE workspace_id=? AND status!='void' GROUP BY month ORDER BY month DESC LIMIT 12`).bind(auth.workspaceId).all(),
      db.prepare(`SELECT COALESCE(SUM(balance_amount),0) AS total,COUNT(*) AS student_count FROM student_credits WHERE workspace_id=? AND balance_amount>0`).bind(auth.workspaceId).first(),
    ]);
    return ok({summary,methods:methods.results,aging:aging.results,monthly:monthly.results,credits});
  }
  if(path==="/exports/students.csv"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"students.read"); const result=await db.prepare(`SELECT code,full_name,birth_date,phone,parent_name,parent_phone,school,grade,status FROM students WHERE workspace_id=? ORDER BY full_name`).bind(auth.workspaceId).all<Record<string,unknown>>();
    return csvResponse("hoc-sinh.csv",["Mã","Họ tên","Ngày sinh","Điện thoại","Phụ huynh","SĐT phụ huynh","Trường","Khối","Trạng thái"],result.results.map(r=>[r.code,r.full_name,r.birth_date,r.phone,r.parent_name,r.parent_phone,r.school,r.grade,r.status]));
  }
  if(path==="/exports/debt.csv"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"reports.finance"); const result=await db.prepare(`SELECT s.code,s.full_name,i.number,i.period_key,i.due_date,i.total_amount,i.paid_amount,i.total_amount-i.paid_amount AS debt FROM invoices i JOIN students s ON s.id=i.student_id WHERE i.workspace_id=? AND i.status IN ('issued','partially_paid','overdue') ORDER BY s.full_name,i.due_date`).bind(auth.workspaceId).all<Record<string,unknown>>();
    return csvResponse("cong-no.csv",["Mã HS","Họ tên","Hóa đơn","Kỳ","Hạn đóng","Phải thu","Đã thu","Còn nợ"],result.results.map(r=>[r.code,r.full_name,r.number,r.period_key,r.due_date,r.total_amount,r.paid_amount,r.debt]));
  }
  if(path==="/exports/payments.csv"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"reports.finance"); const result=await db.prepare(`SELECT p.receipt_number,s.code,s.full_name,p.amount,p.refunded_amount,p.method,p.reference,p.received_at,p.received_by_name FROM payments p JOIN students s ON s.id=p.student_id WHERE p.workspace_id=? ORDER BY p.received_at DESC`).bind(auth.workspaceId).all<Record<string,unknown>>();
    return csvResponse("giao-dich.csv",["Phiếu thu","Mã HS","Họ tên","Số tiền","Đã hoàn","Phương thức","Tham chiếu","Thời gian","Người thu"],result.results.map(r=>[r.receipt_number,r.code,r.full_name,r.amount,r.refunded_amount,r.method,r.reference,r.received_at,r.received_by_name]));
  }
  return null;
}
