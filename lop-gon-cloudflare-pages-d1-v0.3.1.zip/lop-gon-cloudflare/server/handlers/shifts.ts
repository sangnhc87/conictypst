import type { Env } from "../types";
import { requireAuth } from "../auth";
import { requirePermission } from "../permissions";
import { ApiError, created, ok, readJson } from "../http";
import { audit } from "../db";
import { id } from "../ids";
import { integerMoney, optionalString } from "../validation";
import { tenantDb } from "../tenant";

async function shiftExpected(db:D1Database,workspaceId:string,shiftId:string,openingCash:number){
  const income=await db.prepare(`SELECT COALESCE(SUM(amount),0) AS total FROM payments WHERE workspace_id=? AND cash_shift_id=? AND method='cash' AND status IN ('confirmed','partially_refunded','refunded')`).bind(workspaceId,shiftId).first<{total:number}>();
  const refunds=await db.prepare(`SELECT COALESCE(SUM(amount),0) AS total FROM payment_adjustments WHERE workspace_id=? AND cash_shift_id=? AND adjustment_type='refund'`).bind(workspaceId,shiftId).first<{total:number}>();
  return openingCash+Number(income?.total||0)-Number(refunds?.total||0);
}

export async function shiftRoutes(request:Request,env:Env,path:string,method:string):Promise<Response|null>{
  if(path==="/cash-shifts"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"shifts.manage");
    const result=await db.prepare(`SELECT cs.*,cs.user_name AS cashier_name,cs.approved_by_name AS approver_name FROM cash_shifts cs WHERE cs.workspace_id=? ORDER BY cs.opened_at DESC LIMIT 100`).bind(auth.workspaceId).all();
    return ok({shifts:result.results});
  }
  if(path==="/cash-shifts/current"&&method==="GET"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"shifts.manage");
    const shift=await db.prepare(`SELECT * FROM cash_shifts WHERE workspace_id=? AND user_id=? AND status IN ('open','submitted') ORDER BY opened_at DESC LIMIT 1`).bind(auth.workspaceId,auth.userId).first<{id:string;opening_cash:number;status:string}>();
    if(!shift)return ok({shift:null});
    const expected=await shiftExpected(db,auth.workspaceId,shift.id,Number(shift.opening_cash)); return ok({shift:{...shift,live_expected_cash:expected}});
  }
  if(path==="/cash-shifts/open"&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"shifts.manage");
    const body=await readJson<Record<string,unknown>>(request); const openingCash=integerMoney(body.openingCash??0,"Tiền đầu ca",true);
    const active=await db.prepare(`SELECT id FROM cash_shifts WHERE workspace_id=? AND user_id=? AND status IN ('open','submitted')`).bind(auth.workspaceId,auth.userId).first();
    if(active)throw new ApiError(409,"Bạn đang có một ca chưa hoàn tất.","ACTIVE_SHIFT_EXISTS");
    const shiftId=id("shf"); await db.prepare(`INSERT INTO cash_shifts (id,workspace_id,user_id,user_name,opening_cash,note) VALUES (?,?,?,?,?,?)`).bind(shiftId,auth.workspaceId,auth.userId,auth.fullName,openingCash,optionalString(body.note,500)).run();
    await audit(env,auth,"cash_shift.opened","cash_shift",shiftId,{openingCash}); return created({id:shiftId});
  }
  const submitMatch=path.match(/^\/cash-shifts\/([^/]+)\/submit$/);
  if(submitMatch&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"shifts.manage"); const body=await readJson<Record<string,unknown>>(request); const countedCash=integerMoney(body.countedCash,"Tiền thực đếm",true);
    const shift=await db.prepare(`SELECT id,opening_cash,status,user_id FROM cash_shifts WHERE id=? AND workspace_id=?`).bind(submitMatch[1],auth.workspaceId).first<{id:string;opening_cash:number;status:string;user_id:string}>();
    if(!shift)throw new ApiError(404,"Không tìm thấy ca.","NOT_FOUND"); if(shift.user_id!==auth.userId&&!["owner","admin"].includes(auth.role))throw new ApiError(403,"Không thể chốt ca của người khác.","FORBIDDEN"); if(shift.status!=="open")throw new ApiError(409,"Ca không ở trạng thái đang mở.","INVALID_SHIFT_STATUS");
    const expected=await shiftExpected(db,auth.workspaceId,shift.id,Number(shift.opening_cash)); const difference=countedCash-expected;
    await db.prepare(`UPDATE cash_shifts SET status='submitted',submitted_at=datetime('now'),counted_cash=?,expected_cash=?,difference=?,note=COALESCE(?,note) WHERE id=? AND workspace_id=?`).bind(countedCash,expected,difference,optionalString(body.note,500),shift.id,auth.workspaceId).run();
    await audit(env,auth,"cash_shift.submitted","cash_shift",shift.id,{countedCash,expected,difference}); return ok({expected,countedCash,difference});
  }
  const approveMatch=path.match(/^\/cash-shifts\/([^/]+)\/approve$/);
  if(approveMatch&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.refund");
    const result=await db.prepare(`UPDATE cash_shifts SET status='approved',approved_by=?,approved_by_name=?,approved_at=datetime('now') WHERE id=? AND workspace_id=? AND status='submitted'`).bind(auth.userId,auth.fullName,approveMatch[1],auth.workspaceId).run();
    if(!result.meta.changes)throw new ApiError(409,"Ca không tồn tại hoặc chưa được gửi duyệt.","INVALID_SHIFT_STATUS"); await audit(env,auth,"cash_shift.approved","cash_shift",approveMatch[1]); return ok({ok:true});
  }
  const rejectMatch=path.match(/^\/cash-shifts\/([^/]+)\/reject$/);
  if(rejectMatch&&method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"payments.refund"); const body=await readJson<Record<string,unknown>>(request);
    const reason=optionalString(body.reason,500)||"Yêu cầu kiểm tra lại"; const result=await db.prepare(`UPDATE cash_shifts SET status='rejected',note=COALESCE(note,'')||? WHERE id=? AND workspace_id=? AND status='submitted'`).bind(`\nTừ chối: ${reason}`,rejectMatch[1],auth.workspaceId).run();
    if(!result.meta.changes)throw new ApiError(409,"Ca không tồn tại hoặc chưa được gửi duyệt.","INVALID_SHIFT_STATUS"); await audit(env,auth,"cash_shift.rejected","cash_shift",rejectMatch[1],{reason}); return ok({ok:true});
  }
  return null;
}
