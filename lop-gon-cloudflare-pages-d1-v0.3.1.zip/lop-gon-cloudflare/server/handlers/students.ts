import type { Env } from "../types";
import { requireAuth } from "../auth";
import { hasPermission, requirePermission } from "../permissions";
import { ApiError, created, ok, readJson } from "../http";
import { audit, countActiveStudents } from "../db";
import { id } from "../ids";
import { optionalString, requiredString } from "../validation";
import { randomToken, sha256 } from "../crypto";
import { tenantDb } from "../tenant";

function studentPayload(body: Record<string, unknown>) {
  return {
    code: requiredString(body.code, "Mã học sinh", 30).toUpperCase(),
    fullName: requiredString(body.fullName, "Họ tên học sinh", 120),
    birthDate: optionalString(body.birthDate, 10),
    phone: optionalString(body.phone, 30),
    parentName: optionalString(body.parentName, 120),
    parentPhone: optionalString(body.parentPhone, 30),
    school: optionalString(body.school, 120),
    grade: optionalString(body.grade, 30),
    address: optionalString(body.address, 300),
    notes: optionalString(body.notes, 1000),
  };
}

export async function studentRoutes(request: Request, env: Env, path: string, method: string, url: URL): Promise<Response | null> {
  if (path === "/students" && method === "GET") {
    const auth = await requireAuth(request, env); const db=tenantDb(env,auth.tenantSlot);
    requirePermission(auth.role, "students.read");
    const q = (url.searchParams.get("q") || "").trim();
    const status = url.searchParams.get("status") || "active";
    const page = Math.max(Number(url.searchParams.get("page") || 1), 1);
    const limit = Math.min(Math.max(Number(url.searchParams.get("limit") || 50), 1), 100);
    const offset = (page - 1) * limit;
    const like = `%${q}%`;
    const where = `workspace_id=? AND (?='all' OR status=?) AND (?='' OR full_name LIKE ? OR code LIKE ? OR parent_phone LIKE ?)`;
    const [data, count] = await Promise.all([
      db.prepare(`SELECT id,code,full_name,birth_date,phone,parent_name,parent_phone,school,grade,status,created_at FROM students WHERE ${where} ORDER BY full_name LIMIT ? OFFSET ?`)
        .bind(auth.workspaceId,status,status,q,like,like,like,limit,offset).all(),
      db.prepare(`SELECT COUNT(*) AS total FROM students WHERE ${where}`).bind(auth.workspaceId,status,status,q,like,like,like).first<{total:number}>(),
    ]);
    return ok({ students:data.results,total:Number(count?.total||0),page,limit,maxStudents:auth.maxStudents });
  }

  if (path === "/students" && method === "POST") {
    const auth = await requireAuth(request, env); const db=tenantDb(env,auth.tenantSlot);
    requirePermission(auth.role, "students.write");
    const current = await countActiveStudents(env, auth);
    if (current >= auth.maxStudents) throw new ApiError(409,`Trung tâm đã dùng đủ ${auth.maxStudents} học sinh đang hoạt động.`,"STUDENT_LIMIT");
    const body = await readJson<Record<string,unknown>>(request);
    const data = studentPayload(body);
    const studentId = id("stu");
    try {
      await db.prepare(`INSERT INTO students (id,workspace_id,code,full_name,birth_date,phone,parent_name,parent_phone,school,grade,address,notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
        .bind(studentId,auth.workspaceId,data.code,data.fullName,data.birthDate,data.phone,data.parentName,data.parentPhone,data.school,data.grade,data.address,data.notes).run();
    } catch (error) {
      if (String(error).includes("UNIQUE")) throw new ApiError(409,"Mã học sinh đã tồn tại.","DUPLICATE_CODE");
      throw error;
    }
    await audit(env,auth,"student.created","student",studentId,{code:data.code});
    return created({ student:{id:studentId,...data,status:"active"} });
  }

  if (path === "/students/import" && method === "POST") {
    const auth = await requireAuth(request, env); const db=tenantDb(env,auth.tenantSlot);
    requirePermission(auth.role,"students.write");
    const body = await readJson<{rows?:Record<string,unknown>[]}>(request);
    if (!Array.isArray(body.rows) || body.rows.length === 0) throw new ApiError(400,"Không có dữ liệu để nhập.","EMPTY_IMPORT");
    if (body.rows.length > 40) throw new ApiError(400,"Mỗi lần API chỉ nhập tối đa 40 học sinh; giao diện sẽ tự chia file lớn thành nhiều đợt.","IMPORT_TOO_LARGE");
    const current = await countActiveStudents(env,auth);
    if (current + body.rows.length > auth.maxStudents) throw new ApiError(409,`Nhập dữ liệu sẽ vượt giới hạn ${auth.maxStudents} học sinh.`,"STUDENT_LIMIT");
    const seen = new Set<string>();
    const rows = body.rows.map((row,index)=>{
      const data=studentPayload(row);
      if(seen.has(data.code)) throw new ApiError(400,`Mã ${data.code} bị trùng trong file ở dòng ${index+2}.`,"DUPLICATE_IMPORT");
      seen.add(data.code);
      return {id:id("stu"),...data};
    });
    const existing = await db.prepare(`SELECT code FROM students WHERE workspace_id=? AND code IN (${rows.map(()=>"?").join(",")})`)
      .bind(auth.workspaceId,...rows.map(r=>r.code)).all<{code:string}>();
    if(existing.results.length) throw new ApiError(409,`Các mã đã tồn tại: ${existing.results.map(r=>r.code).join(", ")}`,"DUPLICATE_CODE");
    const statements=rows.map(r=>db.prepare(`INSERT INTO students (id,workspace_id,code,full_name,birth_date,phone,parent_name,parent_phone,school,grade,address,notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
      .bind(r.id,auth.workspaceId,r.code,r.fullName,r.birthDate,r.phone,r.parentName,r.parentPhone,r.school,r.grade,r.address,r.notes));
    await db.batch(statements);
    await audit(env,auth,"student.bulk_imported","student",null,{count:rows.length});
    return created({imported:rows.length});
  }

  const match = path.match(/^\/students\/([^/]+)$/);
  if (match && method === "GET") {
    const auth = await requireAuth(request, env); const db=tenantDb(env,auth.tenantSlot);
    requirePermission(auth.role,"students.read");
    const student = await db.prepare(`SELECT * FROM students WHERE id=? AND workspace_id=?`).bind(match[1],auth.workspaceId).first();
    if(!student) throw new ApiError(404,"Không tìm thấy học sinh.","NOT_FOUND");
    const canViewFinance=hasPermission(auth.role,"billing.read");
    const [enrollments,results]=await Promise.all([
      db.prepare(`SELECT e.id,e.status,e.start_date,c.id AS class_id,c.name,c.code,c.subject FROM enrollments e JOIN classes c ON c.id=e.class_id WHERE e.workspace_id=? AND e.student_id=? ORDER BY e.created_at DESC`).bind(auth.workspaceId,match[1]).all(),
      db.prepare(`SELECT id,test_name,subject,score,max_score,taken_at,note FROM exam_results WHERE workspace_id=? AND student_id=? ORDER BY taken_at DESC LIMIT 30`).bind(auth.workspaceId,match[1]).all(),
    ]);
    let invoices:Record<string,unknown>[]=[]; let payments:Record<string,unknown>[]=[]; let credit=0;
    if(canViewFinance){
      const [invoiceResult,paymentResult,creditResult]=await Promise.all([
        db.prepare(`SELECT id,number,period_key,due_date,status,total_amount,paid_amount,total_amount-paid_amount AS outstanding FROM invoices WHERE workspace_id=? AND student_id=? ORDER BY issue_date DESC LIMIT 50`).bind(auth.workspaceId,match[1]).all<Record<string,unknown>>(),
        db.prepare(`SELECT id,receipt_number,amount,method,status,received_at,refunded_amount FROM payments WHERE workspace_id=? AND student_id=? ORDER BY received_at DESC LIMIT 50`).bind(auth.workspaceId,match[1]).all<Record<string,unknown>>(),
        db.prepare(`SELECT balance_amount FROM student_credits WHERE workspace_id=? AND student_id=?`).bind(auth.workspaceId,match[1]).first<{balance_amount:number}>(),
      ]);
      invoices=invoiceResult.results;payments=paymentResult.results;credit=Number(creditResult?.balance_amount||0);
    }
    return ok({student,enrollments:enrollments.results,invoices,payments,credit,examResults:results.results,permissions:{canViewFinance,canManageStudent:hasPermission(auth.role,"students.write"),canWriteTests:hasPermission(auth.role,"tests.write")}});
  }

  if (match && method === "PATCH") {
    const auth = await requireAuth(request, env); const db=tenantDb(env,auth.tenantSlot);
    requirePermission(auth.role,"students.write");
    const body=await readJson<Record<string,unknown>>(request);
    const existing=await db.prepare(`SELECT id,status FROM students WHERE id=? AND workspace_id=?`).bind(match[1],auth.workspaceId).first<{id:string;status:string}>();
    if(!existing) throw new ApiError(404,"Không tìm thấy học sinh.","NOT_FOUND");
    const data=studentPayload(body);
    const status = typeof body.status === "string" && ["active","reserved","inactive"].includes(body.status) ? body.status : existing.status;
    if(existing.status!=="active" && status==="active" && await countActiveStudents(env,auth)>=auth.maxStudents) throw new ApiError(409,"Đã đạt giới hạn học sinh đang hoạt động.","STUDENT_LIMIT");
    await db.prepare(`UPDATE students SET code=?,full_name=?,birth_date=?,phone=?,parent_name=?,parent_phone=?,school=?,grade=?,address=?,notes=?,status=?,updated_at=datetime('now') WHERE id=? AND workspace_id=?`)
      .bind(data.code,data.fullName,data.birthDate,data.phone,data.parentName,data.parentPhone,data.school,data.grade,data.address,data.notes,status,match[1],auth.workspaceId).run();
    await audit(env,auth,"student.updated","student",match[1],{status});
    return ok({ok:true});
  }

  const parentLinkMatch=path.match(/^\/students\/([^/]+)\/parent-link$/);
  if(parentLinkMatch && method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot);
    requirePermission(auth.role,"students.write");
    const student=await db.prepare(`SELECT id FROM students WHERE id=? AND workspace_id=?`).bind(parentLinkMatch[1],auth.workspaceId).first();
    if(!student) throw new ApiError(404,"Không tìm thấy học sinh.","NOT_FOUND");
    const token=randomToken(24); const hash=await sha256(token);
    const expiresAt=new Date(Date.now()+180*86400000).toISOString();
    await db.batch([
      db.prepare(`UPDATE parent_links SET revoked_at=datetime('now') WHERE workspace_id=? AND student_id=? AND revoked_at IS NULL`).bind(auth.workspaceId,parentLinkMatch[1]),
      db.prepare(`INSERT INTO parent_links (id,workspace_id,student_id,token_hash,expires_at,created_by) VALUES (?,?,?,?,?,?)`).bind(id("plk"),auth.workspaceId,parentLinkMatch[1],hash,expiresAt,auth.userId),
    ]);
    await audit(env,auth,"parent_link.created","student",parentLinkMatch[1]);
    return created({token,expiresAt});
  }

  const resultMatch=path.match(/^\/students\/([^/]+)\/exam-results$/);
  if(resultMatch && method==="POST"){
    const auth=await requireAuth(request,env); const db=tenantDb(env,auth.tenantSlot); requirePermission(auth.role,"tests.write");
    const body=await readJson<Record<string,unknown>>(request);
    const testName=requiredString(body.testName,"Tên bài kiểm tra",160);
    const score=Number(body.score), maxScore=Number(body.maxScore??10);
    if(!Number.isFinite(score)||!Number.isFinite(maxScore)||maxScore<=0||score<0||score>maxScore) throw new ApiError(400,"Điểm kiểm tra không hợp lệ.","VALIDATION_ERROR");
    const resultId=id("res");
    await db.prepare(`INSERT INTO exam_results (id,workspace_id,student_id,test_name,subject,score,max_score,taken_at,note,created_by) VALUES (?,?,?,?,?,?,?,?,?,?)`)
      .bind(resultId,auth.workspaceId,resultMatch[1],testName,optionalString(body.subject,80),score,maxScore,optionalString(body.takenAt,10)||new Date().toISOString().slice(0,10),optionalString(body.note,500),auth.userId).run();
    return created({id:resultId});
  }

  return null;
}
