import type { ApiErrorBody } from "./types";

export class ApiError extends Error {
  status: number;
  code?: string;
  details?: unknown;

  constructor(status: number, message: string, code?: string, details?: unknown) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export function json(data: unknown, init: ResponseInit = {}): Response {
  const headers = new Headers(init.headers);
  headers.set("content-type", "application/json; charset=utf-8");
  headers.set("cache-control", "no-store");
  headers.set("x-content-type-options", "nosniff");
  headers.set("referrer-policy", "same-origin");
  return new Response(JSON.stringify(data), { ...init, headers });
}

export function ok(data: unknown = { ok: true }): Response {
  return json(data, { status: 200 });
}

export function created(data: unknown): Response {
  return json(data, { status: 201 });
}

export function noContent(): Response {
  return new Response(null, { status: 204 });
}

export function errorResponse(error: unknown): Response {
  if (error instanceof ApiError) {
    const body: ApiErrorBody = { error: error.message, code: error.code, details: error.details };
    return json(body, { status: error.status });
  }
  console.error("Unhandled API error", error);
  return json({ error: "Đã xảy ra lỗi hệ thống. Vui lòng thử lại." }, { status: 500 });
}

export async function readJson<T>(request: Request): Promise<T> {
  const contentType = request.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    throw new ApiError(415, "Yêu cầu phải gửi dữ liệu JSON.", "UNSUPPORTED_MEDIA_TYPE");
  }
  try {
    return (await request.json()) as T;
  } catch {
    throw new ApiError(400, "Dữ liệu JSON không hợp lệ.", "INVALID_JSON");
  }
}

export function getClientIp(request: Request): string {
  return request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for") || "unknown";
}
