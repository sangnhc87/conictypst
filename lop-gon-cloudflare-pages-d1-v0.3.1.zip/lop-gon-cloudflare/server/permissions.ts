import type { Role } from "./types";
import { ApiError } from "./http";

export type Permission =
  | "workspace.manage"
  | "members.manage"
  | "students.read"
  | "students.write"
  | "classes.read"
  | "classes.write"
  | "attendance.write"
  | "billing.read"
  | "billing.write"
  | "payments.collect"
  | "payments.refund"
  | "shifts.manage"
  | "reports.finance"
  | "tests.write";

const permissions: Record<Role, ReadonlySet<Permission>> = {
  owner: new Set([
    "workspace.manage","members.manage","students.read","students.write","classes.read","classes.write",
    "attendance.write","billing.read","billing.write","payments.collect","payments.refund","shifts.manage",
    "reports.finance","tests.write"
  ]),
  admin: new Set([
    "members.manage","students.read","students.write","classes.read","classes.write","attendance.write",
    "billing.read","billing.write","payments.collect","payments.refund","shifts.manage","reports.finance","tests.write"
  ]),
  accountant: new Set([
    "students.read","classes.read","billing.read","billing.write","payments.collect","payments.refund",
    "shifts.manage","reports.finance"
  ]),
  cashier: new Set(["students.read","classes.read","billing.read","payments.collect","shifts.manage"]),
  teacher: new Set(["students.read","classes.read","attendance.write","tests.write"]),
};

export function hasPermission(role: Role, permission: Permission): boolean {
  return permissions[role].has(permission);
}

export function requirePermission(role: Role, permission: Permission): void {
  if (!hasPermission(role, permission)) {
    throw new ApiError(403, "Tài khoản không có quyền thực hiện thao tác này.", "FORBIDDEN");
  }
}
