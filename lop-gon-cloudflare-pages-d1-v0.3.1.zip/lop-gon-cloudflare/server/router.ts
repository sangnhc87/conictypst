import type { Env } from "./types";
import { ApiError, errorResponse, json, ok } from "./http";
import { authRoutes } from "./handlers/auth";
import { platformRoutes } from "./handlers/platform";
import { studentRoutes } from "./handlers/students";
import { classRoutes } from "./handlers/classes";
import { attendanceRoutes } from "./handlers/attendance";
import { billingRoutes } from "./handlers/billing";
import { paymentRoutes } from "./handlers/payments";
import { shiftRoutes } from "./handlers/shifts";
import { reportRoutes } from "./handlers/reports";
import { publicRoutes } from "./handlers/public";
import { noticeRoutes } from "./handlers/notices";
import { bankRoutes } from "./handlers/bank";

function withSecurityHeaders(response: Response): Response {
  response.headers.set("x-frame-options", "DENY");
  response.headers.set("x-content-type-options", "nosniff");
  response.headers.set("referrer-policy", "strict-origin-when-cross-origin");
  response.headers.set("permissions-policy", "camera=(), microphone=(), geolocation=()");
  return response;
}

export async function handleApi(request: Request, env: Env): Promise<Response> {
  try {
    const url = new URL(request.url);
    const path = url.pathname.replace(/^\/api/, "") || "/";
    const method = request.method.toUpperCase();
    const contentLength = Number(request.headers.get("content-length") || 0);
    if (contentLength > 1_500_000) throw new ApiError(413, "Dữ liệu gửi lên vượt giới hạn 1,5 MB.", "PAYLOAD_TOO_LARGE");
    if (["POST", "PATCH", "PUT", "DELETE"].includes(method)) {
      const secFetchSite = request.headers.get("sec-fetch-site");
      if (secFetchSite === "cross-site") throw new ApiError(403, "Yêu cầu khác nguồn đã bị chặn.", "CROSS_SITE_BLOCKED");
      const origin = request.headers.get("origin");
      if (origin && origin !== url.origin) throw new ApiError(403, "Nguồn gửi yêu cầu không hợp lệ.", "ORIGIN_MISMATCH");
    }
    if (method === "OPTIONS") return withSecurityHeaders(new Response(null, { status: 204 }));
    if (path === "/health" && method === "GET") {
      const control = await env.CONTROL_DB.prepare("SELECT 1 AS ok").first();
      const tenant = await env.TENANT_1.prepare("SELECT 1 AS ok").first();
      return withSecurityHeaders(ok({ ok: true, database: Boolean(control)&&Boolean(tenant), time: new Date().toISOString(), version: "0.3.1" }));
    }

    const handlers = [
      () => publicRoutes(request, env, path, method),
      () => authRoutes(request, env, path, method),
      () => platformRoutes(request, env, path, method),
      () => studentRoutes(request, env, path, method, url),
      () => classRoutes(request, env, path, method, url),
      () => attendanceRoutes(request, env, path, method, url),
      () => billingRoutes(request, env, path, method, url),
      () => paymentRoutes(request, env, path, method, url),
      () => shiftRoutes(request, env, path, method),
      () => bankRoutes(request, env, path, method),
      () => noticeRoutes(request, env, path, method),
      () => reportRoutes(request, env, path, method),
    ];
    for (const run of handlers) {
      const response = await run();
      if (response) return withSecurityHeaders(response);
    }
    return withSecurityHeaders(json({ error: "Không tìm thấy API." }, { status: 404 }));
  } catch (error) {
    return withSecurityHeaders(errorResponse(error));
  }
}
