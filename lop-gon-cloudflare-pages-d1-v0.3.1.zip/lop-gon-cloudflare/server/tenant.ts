import type { Env } from "./types";
import { ApiError } from "./http";

export function tenantDb(env: Env, slot: number): D1Database {
  const db = ({
    1: env.TENANT_1, 2: env.TENANT_2, 3: env.TENANT_3,
    4: env.TENANT_4, 5: env.TENANT_5, 6: env.TENANT_6,
    7: env.TENANT_7, 8: env.TENANT_8, 9: env.TENANT_9,
  } as Record<number, D1Database | undefined>)[slot];
  if (!db) throw new ApiError(503, "Database của trung tâm chưa được cấu hình.", "TENANT_DB_UNAVAILABLE");
  return db;
}

export function allTenantDbs(env: Env): Array<{ slot:number; db:D1Database }> {
  return Array.from({length:9},(_,index)=>({slot:index+1,db:tenantDb(env,index+1)}));
}
