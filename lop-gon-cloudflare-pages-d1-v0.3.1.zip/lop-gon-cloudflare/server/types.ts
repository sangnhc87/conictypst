export interface Env {
  CONTROL_DB: D1Database;
  TENANT_1: D1Database;
  TENANT_2: D1Database;
  TENANT_3: D1Database;
  TENANT_4: D1Database;
  TENANT_5: D1Database;
  TENANT_6: D1Database;
  TENANT_7: D1Database;
  TENANT_8: D1Database;
  TENANT_9: D1Database;
  APP_NAME?: string;
  SESSION_DAYS?: string;
}

export type Role = "owner" | "admin" | "accountant" | "cashier" | "teacher";

export interface AuthContext {
  userId: string;
  email: string;
  fullName: string;
  workspaceId: string;
  workspaceName: string;
  tenantSlot: number;
  role: Role;
  maxUsers: number;
  maxStudents: number;
}

export interface ApiErrorBody { error: string; code?: string; details?: unknown }
