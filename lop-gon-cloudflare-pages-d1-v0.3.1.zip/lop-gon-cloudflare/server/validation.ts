import { ApiError } from "./http";

export function requiredString(value: unknown, field: string, max = 200): string {
  if (typeof value !== "string" || !value.trim()) throw new ApiError(400, `${field} là bắt buộc.`, "VALIDATION_ERROR");
  const normalized = value.trim();
  if (normalized.length > max) throw new ApiError(400, `${field} quá dài.`, "VALIDATION_ERROR");
  return normalized;
}

export function optionalString(value: unknown, max = 500): string | null {
  if (value === undefined || value === null || value === "") return null;
  if (typeof value !== "string") throw new ApiError(400, "Dữ liệu văn bản không hợp lệ.", "VALIDATION_ERROR");
  const normalized = value.trim();
  if (normalized.length > max) throw new ApiError(400, "Dữ liệu văn bản quá dài.", "VALIDATION_ERROR");
  return normalized || null;
}

export function integerMoney(value: unknown, field = "Số tiền", allowZero = false): number {
  const number = typeof value === "string" ? Number(value) : value;
  if (typeof number !== "number" || !Number.isSafeInteger(number)) {
    throw new ApiError(400, `${field} phải là số nguyên theo đơn vị đồng.`, "VALIDATION_ERROR");
  }
  if (allowZero ? number < 0 : number <= 0) {
    throw new ApiError(400, `${field} không hợp lệ.`, "VALIDATION_ERROR");
  }
  return number;
}

export function validEmail(value: unknown): string {
  const email = requiredString(value, "Email", 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new ApiError(400, "Email không hợp lệ.", "VALIDATION_ERROR");
  return email;
}

export function validPassword(value: unknown): string {
  const password = requiredString(value, "Mật khẩu", 128);
  if (password.length < 8) throw new ApiError(400, "Mật khẩu cần ít nhất 8 ký tự.", "VALIDATION_ERROR");
  return password;
}

export function enumValue<T extends string>(value: unknown, allowed: readonly T[], field: string): T {
  if (typeof value !== "string" || !allowed.includes(value as T)) {
    throw new ApiError(400, `${field} không hợp lệ.`, "VALIDATION_ERROR");
  }
  return value as T;
}
