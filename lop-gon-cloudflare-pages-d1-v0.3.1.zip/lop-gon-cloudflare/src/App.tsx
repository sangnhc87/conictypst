import { Navigate,Route,Routes } from "react-router-dom";
import { AppLayout } from "./components/AppLayout";
import { Spinner } from "./components/ui";
import { useAuth } from "./lib/auth";
import { LoginPage } from "./pages/LoginPage";
import { BootstrapPage } from "./pages/BootstrapPage";
import { DashboardPage } from "./pages/DashboardPage";
import { StudentsPage } from "./pages/StudentsPage";
import { StudentDetailPage } from "./pages/StudentDetailPage";
import { ClassesPage } from "./pages/ClassesPage";
import { ClassDetailPage } from "./pages/ClassDetailPage";
import { AttendancePage } from "./pages/AttendancePage";
import { AttendanceDetailPage } from "./pages/AttendanceDetailPage";
import { BillingPage } from "./pages/BillingPage";
import { PaymentsPage } from "./pages/PaymentsPage";
import { CashShiftsPage } from "./pages/CashShiftsPage";
import { ReportsPage } from "./pages/ReportsPage";
import { TeamPage } from "./pages/TeamPage";
import { SettingsPage } from "./pages/SettingsPage";
import { PlatformPage } from "./pages/PlatformPage";
import { ParentPage } from "./pages/ParentPage";
import { ReceiptPage } from "./pages/ReceiptPage";
import type { Role } from "./types";

function RoleRoute({roles,children}:{roles:readonly Role[];children:any}){const{user}=useAuth();return user&&roles.includes(user.role)?children:<Navigate to="/dashboard" replace/>}

function PlatformRoute({children}:{children:any}){const{user}=useAuth();return user?.isPlatformAdmin?children:<Navigate to="/dashboard" replace/>}

function Protected(){const{user,loading,needsBootstrap}=useAuth();if(loading)return <div className="center-screen"><Spinner/></div>;if(needsBootstrap)return <Navigate to="/bootstrap" replace/>;if(!user)return <Navigate to="/login" replace/>;return <AppLayout/>}
export default function App(){return <Routes><Route path="/parent/:token" element={<ParentPage/>}/><Route path="/receipt/:token" element={<ReceiptPage/>}/><Route path="/bootstrap" element={<BootstrapPage/>}/><Route path="/login" element={<LoginPage/>}/><Route element={<Protected/>}><Route path="/dashboard" element={<DashboardPage/>}/><Route path="/students" element={<StudentsPage/>}/><Route path="/students/:id" element={<StudentDetailPage/>}/><Route path="/classes" element={<ClassesPage/>}/><Route path="/classes/:id" element={<ClassDetailPage/>}/><Route path="/attendance" element={<RoleRoute roles={["owner","admin","teacher"]}><AttendancePage/></RoleRoute>}/><Route path="/attendance/:id" element={<RoleRoute roles={["owner","admin","teacher"]}><AttendanceDetailPage/></RoleRoute>}/><Route path="/billing" element={<RoleRoute roles={["owner","admin","accountant","cashier"]}><BillingPage/></RoleRoute>}/><Route path="/payments" element={<RoleRoute roles={["owner","admin","accountant","cashier"]}><PaymentsPage/></RoleRoute>}/><Route path="/cash-shifts" element={<RoleRoute roles={["owner","admin","accountant","cashier"]}><CashShiftsPage/></RoleRoute>}/><Route path="/reports" element={<RoleRoute roles={["owner","admin","accountant"]}><ReportsPage/></RoleRoute>}/><Route path="/team" element={<RoleRoute roles={["owner","admin"]}><TeamPage/></RoleRoute>}/><Route path="/settings" element={<RoleRoute roles={["owner","admin","accountant","cashier","teacher"]}><SettingsPage/></RoleRoute>}/><Route path="/platform" element={<PlatformRoute><PlatformPage/></PlatformRoute>}/></Route><Route path="/" element={<Navigate to="/dashboard" replace/>}/><Route path="*" element={<Navigate to="/dashboard" replace/>}/></Routes>}
