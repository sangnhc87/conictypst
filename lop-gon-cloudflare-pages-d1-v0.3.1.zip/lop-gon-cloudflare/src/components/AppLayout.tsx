import { NavLink,Outlet,useNavigate } from "react-router-dom";
import { BookOpen,CalendarCheck,ChartNoAxesCombined,GraduationCap,Landmark,LayoutDashboard,LogOut,Menu,ReceiptText,Settings,Users,WalletCards,X } from "lucide-react";
import { useState } from "react";
import { useAuth } from "../lib/auth";
import { Button } from "./ui";
import type { Role } from "../types";

const nav: ReadonlyArray<readonly [string,string,typeof LayoutDashboard,readonly Role[]]> = [
  ["/dashboard","Hôm nay",LayoutDashboard,["owner","admin","accountant","cashier","teacher"]],
  ["/students","Học sinh",GraduationCap,["owner","admin","accountant","cashier","teacher"]],
  ["/classes","Lớp học",BookOpen,["owner","admin","accountant","cashier","teacher"]],
  ["/attendance","Điểm danh",CalendarCheck,["owner","admin","teacher"]],
  ["/billing","Học phí",ReceiptText,["owner","admin","accountant","cashier"]],
  ["/payments","Thu tiền",WalletCards,["owner","admin","accountant","cashier"]],
  ["/cash-shifts","Ca thu ngân",Landmark,["owner","admin","accountant","cashier"]],
  ["/reports","Báo cáo",ChartNoAxesCombined,["owner","admin","accountant"]],
  ["/team","Nhân viên",Users,["owner","admin"]],
  ["/settings","Tài khoản",Settings,["owner","admin","accountant","cashier","teacher"]],
 ];

export function AppLayout(){const{user,logout}=useAuth();const navigate=useNavigate();const[open,setOpen]=useState(false);if(!user)return null;
  const signOut=async()=>{await logout();navigate("/login");};
  return <div className="app-shell">
    <aside className={`sidebar ${open?"sidebar-open":""}`}>
      <div className="brand"><div className="brand-mark">LG</div><div><strong>Lớp Gọn</strong><small>{user.workspaceName}</small></div><button className="icon-button close-sidebar" onClick={()=>setOpen(false)}><X/></button></div>
      <nav>{nav.filter(([, , ,roles])=>roles.includes(user.role)).map(([to,label,Icon])=><NavLink key={to} to={to} onClick={()=>setOpen(false)} className={({isActive}:{isActive:boolean})=>isActive?"active":""}><Icon size={19}/><span>{label}</span></NavLink>)}{user.isPlatformAdmin&&<NavLink to="/platform" onClick={()=>setOpen(false)}><Settings size={19}/><span>Quản trị hệ thống</span></NavLink>}</nav>
      <div className="sidebar-user"><strong>{user.fullName}</strong><small>{user.email} · {user.role}</small><Button variant="ghost" onClick={signOut}><LogOut size={17}/> Đăng xuất</Button></div>
    </aside>
    {open&&<button className="sidebar-backdrop" onClick={()=>setOpen(false)} aria-label="Đóng menu"/>}
    <main className="main"><div className="mobile-top"><button className="icon-button" onClick={()=>setOpen(true)}><Menu/></button><strong>Lớp Gọn</strong><span/></div><Outlet/></main>
  </div>;
}
