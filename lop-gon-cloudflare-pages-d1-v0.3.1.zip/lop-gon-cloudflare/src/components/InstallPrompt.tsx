import { useEffect,useState } from "react";
import { Button } from "./ui";
interface BeforeInstallPromptEvent extends Event{prompt:()=>Promise<void>;userChoice:Promise<{outcome:"accepted"|"dismissed"}>}
export function InstallPrompt(){const[event,setEvent]=useState<BeforeInstallPromptEvent|null>(null);useEffect(()=>{const handler=(e:Event)=>{e.preventDefault();setEvent(e as BeforeInstallPromptEvent)};window.addEventListener("beforeinstallprompt",handler);return()=>window.removeEventListener("beforeinstallprompt",handler)},[]);if(!event)return null;return <Button variant="secondary" onClick={async()=>{await event.prompt();await event.userChoice;setEvent(null)}}>Cài ứng dụng</Button>}
