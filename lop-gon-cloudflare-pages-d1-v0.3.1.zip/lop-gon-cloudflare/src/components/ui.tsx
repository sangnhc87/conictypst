import type { ButtonHTMLAttributes,InputHTMLAttributes,ReactNode,SelectHTMLAttributes,TextareaHTMLAttributes } from "react";

export function Button({className="",variant="primary",...props}:ButtonHTMLAttributes<HTMLButtonElement>&{variant?:"primary"|"secondary"|"danger"|"ghost"}){return <button className={`btn btn-${variant} ${className}`} {...props}/>;}
export function Input(props:InputHTMLAttributes<HTMLInputElement>){return <input className="input" {...props}/>;}
export function Select(props:SelectHTMLAttributes<HTMLSelectElement>){return <select className="input" {...props}/>;}
export function Textarea(props:TextareaHTMLAttributes<HTMLTextAreaElement>){return <textarea className="input textarea" {...props}/>;}
export function Card({children,className=""}:{children:ReactNode;className?:string}){return <section className={`card ${className}`}>{children}</section>;}
export function Field({label,children,hint}:{label:string;children:ReactNode;hint?:string}){return <label className="field"><span>{label}</span>{children}{hint&&<small>{hint}</small>}</label>;}
export function Badge({children,tone="neutral"}:{children:ReactNode;tone?:"neutral"|"success"|"warning"|"danger"|"info"}){return <span className={`badge badge-${tone}`}>{children}</span>;}
export function Empty({title,description}:{title:string;description?:string}){return <div className="empty"><strong>{title}</strong>{description&&<p>{description}</p>}</div>;}
export function Spinner(){return <div className="spinner" aria-label="Đang tải"/>;}
export function PageHeader({title,description,actions}:{title:string;description?:string;actions?:ReactNode}){return <header className="page-header"><div><h1>{title}</h1>{description&&<p>{description}</p>}</div>{actions&&<div className="page-actions">{actions}</div>}</header>;}
