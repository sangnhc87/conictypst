export class ApiClientError extends Error {
  status: number;
  code?: string;
  details?: unknown;
  constructor(status:number,message:string,code?:string,details?:unknown){super(message);this.status=status;this.code=code;this.details=details;}
}

export async function api<T>(path:string,init:RequestInit={}):Promise<T>{
  const headers=new Headers(init.headers);
  if(init.body&&!headers.has("content-type"))headers.set("content-type","application/json");
  const response=await fetch(`/api${path}`,{...init,headers,credentials:"include"});
  const contentType=response.headers.get("content-type")||"";
  const data=contentType.includes("application/json")?await response.json():await response.text();
  if(!response.ok){const body=data as {error?:string;code?:string;details?:unknown};throw new ApiClientError(response.status,body?.error||"Yêu cầu không thành công.",body?.code,body?.details);}
  return data as T;
}

export function money(value:number|string|null|undefined):string{
  return new Intl.NumberFormat("vi-VN",{style:"currency",currency:"VND",maximumFractionDigits:0}).format(Number(value||0));
}

export function dateTime(value:string|null|undefined):string{
  if(!value)return "—"; const date=new Date(value); return Number.isNaN(date.getTime())?value:date.toLocaleString("vi-VN");
}

export function dateOnly(value:string|null|undefined):string{
  if(!value)return "—"; const date=new Date(`${value}T00:00:00`); return Number.isNaN(date.getTime())?value:date.toLocaleDateString("vi-VN");
}

export function formJson(form:HTMLFormElement):Record<string,string>{return Object.fromEntries(new FormData(form).entries()) as Record<string,string>;}
