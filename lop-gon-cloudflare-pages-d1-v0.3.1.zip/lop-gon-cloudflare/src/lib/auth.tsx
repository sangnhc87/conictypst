import { createContext,useCallback,useContext,useEffect,useMemo,useState,type ReactNode } from "react";
import { api } from "./api";
import type { CurrentUser } from "../types";

interface AuthState{user:CurrentUser|null;loading:boolean;needsBootstrap:boolean;refresh:()=>Promise<void>;logout:()=>Promise<void>}
const AuthContext=createContext<AuthState|null>(null);

export function AuthProvider({children}:{children:ReactNode}){
  const [user,setUser]=useState<CurrentUser|null>(null); const [loading,setLoading]=useState(true); const [needsBootstrap,setNeedsBootstrap]=useState(false);
  const refresh=useCallback(async()=>{setLoading(true);try{const status=await api<{needsBootstrap:boolean}>("/auth/status");setNeedsBootstrap(status.needsBootstrap);if(!status.needsBootstrap){try{const me=await api<{user:CurrentUser}>("/auth/me");setUser(me.user);}catch{setUser(null);}}else setUser(null);}finally{setLoading(false);}},[]);
  useEffect(()=>{void refresh();},[refresh]);
  const logout=useCallback(async()=>{await api("/auth/logout",{method:"POST"});setUser(null);},[]);
  const value=useMemo(()=>({user,loading,needsBootstrap,refresh,logout}),[user,loading,needsBootstrap,refresh,logout]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export function useAuth(){const value=useContext(AuthContext);if(!value)throw new Error("AuthProvider missing");return value;}
