import { useState,type FormEvent } from "react";
import { Navigate,useNavigate } from "react-router-dom";
import { api,formJson } from "../lib/api";
import { useAuth } from "../lib/auth";
import { Button,Card,Field,Input } from "../components/ui";

export function LoginPage(){const{user,needsBootstrap,refresh}=useAuth();const navigate=useNavigate();const[error,setError]=useState("");const[busy,setBusy]=useState(false);if(needsBootstrap)return <Navigate to="/bootstrap" replace/>;if(user)return <Navigate to="/dashboard" replace/>;
 const submit=async(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();setBusy(true);setError("");try{const data=formJson(e.currentTarget);await api("/auth/login",{method:"POST",body:JSON.stringify(data)});await refresh();navigate("/dashboard");}catch(err){setError(err instanceof Error?err.message:"Không đăng nhập được.");}finally{setBusy(false)}};
 return <div className="auth-page"><Card className="auth-card"><div className="auth-logo">LG</div><h1>Đăng nhập Lớp Gọn</h1><p>Quản lý lớp học và học phí trên điện thoại.</p><form onSubmit={submit} className="form-stack"><Field label="Email"><Input name="email" type="email" autoComplete="email" required/></Field><Field label="Mật khẩu"><Input name="password" type="password" autoComplete="current-password" required/></Field>{error&&<div className="alert error">{error}</div>}<Button type="submit" disabled={busy}>{busy?"Đang đăng nhập…":"Đăng nhập"}</Button></form></Card></div>}
