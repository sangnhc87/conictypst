export type Role = "owner" | "admin" | "accountant" | "cashier" | "teacher";

export interface CurrentUser {
  userId: string;
  email: string;
  fullName: string;
  workspaceId: string;
  workspaceName: string;
  role: Role;
  maxUsers: number;
  maxStudents: number;
  isPlatformAdmin: boolean;
}

export interface Student {
  id: string;
  code: string;
  full_name: string;
  birth_date?: string | null;
  phone?: string | null;
  parent_name?: string | null;
  parent_phone?: string | null;
  school?: string | null;
  grade?: string | null;
  status: string;
}

export interface ClassItem {
  id: string;
  code: string;
  name: string;
  subject?: string | null;
  grade?: string | null;
  teacher_name?: string | null;
  schedule_text?: string | null;
  fee_amount: number;
  student_count?: number;
  status: string;
}
