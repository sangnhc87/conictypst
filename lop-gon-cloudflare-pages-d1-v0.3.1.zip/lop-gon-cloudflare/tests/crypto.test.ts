import { describe, expect, it } from 'vitest';
import { hashPassword, randomToken, sha256, verifyPassword } from '../server/crypto';

describe('bảo mật tài khoản', () => {
  it('băm và xác minh đúng mật khẩu', async () => {
    const hash = await hashPassword('MatKhau-123');
    expect(hash).not.toContain('MatKhau-123');
    expect(await verifyPassword('MatKhau-123', hash)).toBe(true);
    expect(await verifyPassword('SaiMatKhau', hash)).toBe(false);
  });

  it('sinh token khó đoán và băm ổn định', async () => {
    const a = randomToken(24);
    const b = randomToken(24);
    expect(a).not.toBe(b);
    expect(a.length).toBeGreaterThan(20);
    expect(await sha256(a)).toBe(await sha256(a));
  });
});
