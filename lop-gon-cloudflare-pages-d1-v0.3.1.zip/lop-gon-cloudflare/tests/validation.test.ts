import { describe, expect, it } from 'vitest';
import { integerMoney, validEmail, validPassword } from '../server/validation';

describe('kiểm tra dữ liệu đầu vào', () => {
  it('chỉ nhận tiền nguyên theo đồng', () => {
    expect(integerMoney('500000')).toBe(500000);
    expect(() => integerMoney('12.5')).toThrow();
    expect(() => integerMoney(0)).toThrow();
  });

  it('chuẩn hóa email và yêu cầu mật khẩu tối thiểu', () => {
    expect(validEmail('  OWNER@EXAMPLE.COM ')).toBe('owner@example.com');
    expect(() => validPassword('1234567')).toThrow();
  });
});
