SANG-MATH 1.1.0 — BO MAU PREVIEW CUA PR #3

Ban 1.1.0 chua phat hanh tren Typst Universe. Khong dung @preview/sang-math:1.1.0.
Cai Typst 0.15.0 hoac moi hon, giai nen ZIP, mo terminal tai thu muc nay.

Vi du:
typst compile --root . --package-path ./typst-packages examples/sang-math-1-1/01-legacy-bon-dang.typ 01.pdf
typst compile --root . --package-path ./typst-packages examples/sang-math-1-1/02-qr-va-phieu-12-4-6.typ 02.pdf

Moi file .typ co the copy/sua va bien dich. 12-4-6ngang.typ va tn-40.typ can nam cung thu muc voi mau include.
De van go truc tiep bang #tn/#ds/#tln/#tl; #sang-omr-qr tao QR dap an.
Tam phieu co state: 12-4-6ngang, ds-12, hybrid-28tn-12ds, thptqg-toan-2025, tln-10, tn-40, tn-50, tn-60.
Package co the tu dong tai @preview/cetz:0.5.2 va @preview/cades:0.3.1 neu may chua co cache.
