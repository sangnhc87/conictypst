# sang-3d 0.8.0 API

## Strict point declarations

```typ
sang3d.point(
  name,
  coordinate,
  definition: auto,
  label: auto,
  label-position: auto,
  label-distance: auto,
  show-point: true,
  show-label: true,
  role: "main",
  style: (:),
  metadata: (:),
)

sang3d.given-point(name, coordinate, ..options)

sang3d.derived-point(
  name,
  coordinate,
  kind,
  deps: (),
  parameters: (:),
  formula: none,
  ..options,
)
```

`deps` must refer only to points declared earlier in the same manifest or already present in the model being extended.

## Explicit figure

```typ
sang3d.figure3d(
  points: (
    sang3d.given-point("A", (0, 0, 0)),
    sang3d.given-point("B", (4, 0, 0)),
  ),
  objects: (
    sang3d.objects.segment("A", "B"),
  ),
  strict-order: true,
)
```

`objects` may contain point names only. Anonymous coordinates are rejected.

## Generated-point policy

```typ
sang3d.point-policy(
  name: auto,
  label: auto,
  label-position: auto,
  label-distance: auto,
  show-point: false,
  show-label: false,
  role: "main",
  style: (:),
  definition: auto,
)
```

Every field may be a constant or `context => value`. Context varies by constructor and includes stable fields such as `default-name`, `coordinate`, `index`, `ring`, `u`, `v`, `parameter`, `control`, and `prefix`.

Supported dense constructors include:

- `parametric-surface`, `graph-surface`, `sphere-surface`, `torus`;
- `surface-of-revolution`, `cylinder-between`, `cone-between`, `tube-between`;
- `sweep`, `loft`, `tube-along`, `ribbon-along`;
- `curves.model`;
- `implicit.surface`, `csg.build`;
- `sections.with-section`;
- `unfold`.

## Model inspection

```typ
sang3d.validate(fig)
sang3d.assert-valid(fig)
sang3d.point-at(fig, "A")
sang3d.definition-of(fig, "A")
sang3d.point-record(fig, "A")
sang3d.point-provenance(fig, "A")
sang3d.point-table(fig)
sang3d.inspect-model(fig)
```

## Object records

Low-level objects never own coordinates. They reference declared point names:

```typ
sang3d.objects.point("A")
sang3d.objects.segment("A", "B")
sang3d.objects.face(("A", "B", "C"))
sang3d.objects.polyline(("A", "M", "C"))
sang3d.objects.circle3d("O", radius, normal: normal)
sang3d.objects.plane-patch("O", normal)
```

## Rendering

```typ
sang3d.draw(
  input,
  view: "auto",
  camera: auto,
  theme: "textbook",
  quality: "normal",
  focus: auto,
  hidden: auto,
  visibility: auto,
  labels: auto,
  line: auto,
  material: auto,
  rules: (),
  show: (:),
  strict: true,
)
```

Quality presets: `"draft"`, `"normal"`, `"print"`, `"publication"`.

Visibility modes: `"none"`, `"convex"`, `"sampled"`, `"exact"`.

## Main namespaces

| Namespace | Purpose |
|---|---|
| `points` | Point declarations and generated-point policies |
| `definitions` | Definition records, provenance, traces, dependency checks |
| `objects` | Name-only semantic drawable records |
| `model` | Strict models, selectors, transforms, merge, validation |
| `camera` | Orthographic, perspective, named, orbit, and adaptive views |
| `styles` / `lines` | Themes, strokes, selectors, and line presets |
| `solids` | Polyhedra, prisms, pyramids, and regular solids |
| `surfaces` / `round` | Parametric and round solids |
| `revolution` | Arbitrary-axis motion and partial/full revolution |
| `euclid` | Euclidean constructions in arbitrary 3D planes |
| `constraints` | Constructive and nonlinear constraints |
| `modeling` | Sweep, loft, tubes, and ribbons |
| `curves` | Bezier, Hermite, splines, NURBS, Frenet data |
| `implicit` | Marching-tetrahedra level-set extraction |
| `csg` | Signed-distance primitives and Boolean composition |
| `symbolic` | Paired symbolic/numeric dimensions and measurements |
| `materials` | Textbook, clay, glass, x-ray, metal, toon, and custom materials |
| `textbook` | Educational solid constructors and annotations |
| `technical` | Views, sections, hatch, explode, assembly, and BOM |
| `unfolding` | Polyhedral flat nets |

## Named-point solid customization

Straight solids expose explicit names and per-point dictionaries:

```typ
sang3d.cuboid(
  names: ("A", "B", "C", "D", "E", "F", "G", "H"),
  point-options: (
    A: (label-content: $A$, label-position: "bottom-left"),
    E: (label-content: $E$, label-position: "top-left"),
  ),
  point-definitions: (
    // Optional complete custom definition registry.
  ),
)
```

Round and sampled solids use `point-policy` and `control-point-policy` because their point counts are configurable.

## Construction helpers

Construction helpers require existing point names:

```typ
sang3d.with-segment(fig, "A", "B")
sang3d.with-angle(fig, "A", "B", "C")
sang3d.with-circle(fig, "O", radius)
sang3d.with-plane(fig, "O", normal)
sang3d.with-dimension(fig, "A", "B")
```

Use `with-declared-point` before adding any object that needs a new point.
