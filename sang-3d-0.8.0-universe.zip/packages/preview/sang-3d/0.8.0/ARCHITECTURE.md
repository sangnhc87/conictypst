# Architecture — sang-3d 0.8.0

## Core boundary

The engine is divided into six layers:

1. **Numeric geometry** — vectors, matrices, axes, intersections, transforms.
2. **Point Definition Graph** — ordered declarations, definitions, dependencies, provenance, labels, and point styles.
3. **Semantic model** — objects that contain point names only.
4. **Modeling systems** — solids, surfaces, constraints, curves, CSG, sweep, sections, unfolding, and technical transforms.
5. **View systems** — camera search, projection, visibility, and label layout.
6. **CeTZ renderer** — the only backend-specific layer.

## Model schema

```typ
(
  kind: "sang-3d-model",
  schema: "sang-3d/model@4",
  points: (:),
  definitions: (:),
  point-options: (:),
  point-order: (),
  objects: (),
  meta: (:),
  styles: (:),
  strict-points: true,
)
```

The four point fields are parallel views of one ordered graph.

## Two-phase constructor contract

Every constructor follows:

```text
control declarations
→ generated declarations
→ declaration validation
→ object construction
→ model validation
```

This applies even to thousands of implicit/CSG mesh vertices.

## Dense-point policy

`points.from-policy` resolves policy fields per point. Its context carries semantic indices and parameters. The resolved declaration is stored before any mesh face or edge is created.

Major policy-enabled systems:

- parametric and revolution surfaces;
- spheres and spherical zones;
- round solids and tubes;
- curves;
- sweep and loft;
- implicit and CSG meshes;
- sections;
- unfolding.

## CSG controls

SDF primitives publish controls such as sphere center, box center, cylinder endpoints, cone apex/base center, and torus center/axis. Boolean trees deduplicate truly identical control declarations and reject same-name/different-coordinate collisions.

## Visibility and camera

The publication renderer uses projected polygon intersections and depth classification for exact hidden-line runs. Adaptive camera search scores projected area, edge readability, vertex separation, crossing penalties, balance, and optional focus normals.

## Labels

Point options flow from declarations to the global label solver. Semantic positions such as `top-right` are hard preferences. Generated-point policies may assign positions individually.

## Extension rule

A new geometric system is accepted only if it:

1. declares all points first;
2. provides semantic definitions;
3. exposes generated-point policy when point count is dynamic;
4. emits objects with names only;
5. passes strict validation;
6. preserves definitions through transforms and merges.
