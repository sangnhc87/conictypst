# Changelog

## 0.8.0 — Explicit Geometry

### Breaking strictness

- Standard models no longer repair anonymous object coordinates.
- `figure3d` requires ordered point declarations before objects.
- Derived-point dependencies must refer to earlier declarations.
- Duplicate generated names are errors; they are never silently suffixed.

### Point declaration system

- Added `point`, `given-point`, `derived-point`, `declare-points`, and `point-policy`.
- Added label content, semantic label position, label distance, visibility, role, style, metadata, and definition to every declaration.
- Added `point-order` and model schema `sang-3d/model@4`.
- Added strict forward-dependency and anonymous-coordinate validation.

### Generated geometry

- Parametric surfaces, revolution, torus, sphere, spherical zones, round solids, sweep, loft, curves, sections, unfolding, implicit surfaces, and CSG now expose generated-point policies.
- Centers, axes, poles, ring centers, CSG controls, curve controls, and unfold source references are public points.
- CSG Boolean trees reject conflicting control-point names.

### Release engineering

- Switched examples to `@preview/sang-3d:0.8.0` imports.
- Added `package.exclude` metadata for Universe bundles.
- Added explicit-point tests and stronger static checks.
- Fixed a duplicated `surface-of-revolution` declaration found during deep review.
