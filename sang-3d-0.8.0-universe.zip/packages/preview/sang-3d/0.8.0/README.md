# sang-3d 0.8.0 — Explicit Geometry Engine

`sang-3d` builds explainable 3D geometry, solid models, and technical illustrations in Typst, then projects them to CeTZ.

The central rule of version 0.8.0 is strict and simple:

> **Every point is declared, named, defined, and configurable before any object may use it.**

There is no silent point creation in the standard model path. A segment, face, circle, section, mesh, CSG result, sweep, or annotation may only reference names already present in the Point Definition Graph.

## Install

```typ
#import "@preview/sang-3d:0.8.0": sang3d
```

## Declare points first, objects second

```typ
#let point-manifest = (
  sang3d.given-point(
    "A", (0, 0, 0),
    label: $A$,
    label-position: "bottom-left",
  ),
  sang3d.given-point(
    "B", (4, 0, 0),
    label: $B$,
    label-position: "bottom-right",
  ),
  sang3d.derived-point(
    "M", (2, 0, 0), "midpoint",
    deps: ("A", "B"),
    parameters: (ratio: 1 / 2),
    label: $M$,
    label-position: "top",
  ),
)

#let fig = sang3d.figure3d(
  points: point-manifest,
  objects: (
    sang3d.objects.segment("A", "B", id: "AB"),
    sang3d.objects.point("M"),
  ),
)

#sang3d.draw(fig, quality: "publication", strict: true)
```

The declaration order is validated. `M` cannot depend on `A` or `B` unless both have already appeared.

## A point declaration owns everything about the point

```typ
sang3d.derived-point(
  "H",
  (1, 1, 0),
  "projection-on-plane",
  deps: ("S", "A", "B", "C"),
  parameters: (
    source: "S",
    plane: ("A", "B", "C"),
  ),
  label: $H$,
  label-position: "right",
  label-distance: 0.25,
  show-point: true,
  show-label: true,
  role: "accent",
)
```

Each record includes:

- stable public name;
- numeric coordinate;
- semantic definition kind;
- earlier dependencies;
- constructor parameters and provenance;
- label content and preferred label position;
- point/label visibility;
- role and local style.

## Generated points are public too

Dense constructors accept `point-policy` and `control-point-policy`. A policy may be a value or a function of each generated point's context.

```typ
#let cylinder = sang3d.cylinder-between(
  (0, 0, 0),
  (0, 0, 4),
  radius: 1.4,
  sides: 12,
  prefix: "CY",

  control-point-policy: sang3d.point-policy(
    name: ctx => if ctx.control == "base-center" { "O1" } else { "O2" },
    label: ctx => if ctx.control == "base-center" { $O_1$ } else { $O_2$ },
    label-position: "left",
    show-point: true,
    show-label: true,
  ),

  point-policy: sang3d.point-policy(
    name: ctx => "P-" + ctx.ring + "-" + str(ctx.index),
    label: ctx => if ctx.index == 0 { ctx.ring } else { auto },
    label-position: "right",
    show-point: ctx => ctx.index == 0,
    show-label: ctx => ctx.index == 0,
  ),
)
```

This policy system is supported by parametric surfaces, round solids, surfaces of revolution, sweep/loft, curves, implicit/CSG meshes, sections, and unfolding.

## Inspect and validate

```typ
#sang3d.point-table(fig)
#repr(sang3d.point-record(fig, "H"))
#repr(sang3d.point-provenance(fig, "H"))
#repr(sang3d.inspect-model(fig))
#assert(sang3d.validate(fig).len() == 0)
```

Strict validation rejects:

- anonymous coordinates inside objects;
- points without definitions;
- references to missing points;
- forward dependencies;
- dependency cycles;
- duplicate point names;
- conflicting CSG control-point names;
- malformed faces and edges.

## Smart publication rendering

```typ
#sang3d.draw(
  fig,
  quality: "publication",
  visibility: "exact",
  labels: (
    mode: "global",
    leader-lines: "auto",
  ),
  material: "textbook",
)
```

The renderer includes adaptive camera search, exact polygonal hidden-line splitting, semantic line styles, global label placement, materials, sections, and technical views.

## Twelve systems

1. Constructive and nonlinear constraints
2. CSG Boolean fields
3. Exact hidden-line rendering
4. Smart Camera 3.0
5. Global label solver
6. Symbolic–numeric geometry
7. Textbook geometry DSL
8. Sweep, loft, tube, ribbon, and revolution
9. Bezier, Hermite, Catmull–Rom, B-spline, rational Bezier, and NURBS
10. Implicit surfaces with welded public vertices
11. Material and shading presets
12. Technical drawing, sections, hatching, exploded assemblies, and BOM

All twelve systems produce the same strict model schema and Point Definition Graph.

## Important examples

- `examples/no-hidden-points.typ` — complete manual figure with explicit declarations
- `examples/generated-point-policy.typ` — custom names, labels, positions, and definitions for generated points
- `examples/revolution-toolbox.typ` — rotation around named geometry
- `examples/round-solids.typ` — cylinders, cones, spheres, tubes, and caps
- `examples/curves-csg.typ` — curves, implicit surfaces, and Boolean modeling
- `examples/textbook-technical.typ` — textbook and technical drawing workflows

## Development validation

```bash
python3 scripts/check_package.py
python3 scripts/numeric_audit.py
```

The archive was produced without a Typst executable in the build environment. Static and independent numerical audits pass, but real Typst/CeTZ compilation remains a required release gate before submitting to Typst Universe. See `VALIDATION.md`.

## Scope

`sang-3d` targets mathematical publishing, education, and technical illustration. Its CSG and dimensions are not a tolerance-certified manufacturing CAD kernel.
