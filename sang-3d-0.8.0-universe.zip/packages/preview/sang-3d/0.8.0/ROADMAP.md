# Roadmap after 0.8.0

## Release gates before Typst Universe

- Compile every example on Typst 0.14.x and the current stable Typst release.
- Render a visual gallery and store regression images.
- Run package linting and a compiler CI matrix.
- Confirm CeTZ output for exact hidden lines, global labels, CSG meshes, sections, and technical sheets.
- Reduce or namespace unstable low-level exports before 1.0.

## 0.9 priorities

- Measured text boxes from Typst layout feedback for label optimization.
- Better automatic label-position stability across camera changes.
- Analytic silhouettes for common quadrics before tessellation.
- Unfold overlap optimization.
- More complete ISO-style technical dimensions and hatch patterns.
- Performance profiling for large implicit meshes.

## 1.0 criteria

- Compiler-verified examples and tests.
- Stable public namespaces.
- Visual regression suite.
- Migration guide and semantic-versioning policy.
- Universe-ready gallery and documentation.
