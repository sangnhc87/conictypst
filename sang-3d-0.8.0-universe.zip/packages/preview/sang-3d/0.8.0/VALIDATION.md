# Validation — sang-3d 0.8.0

## Completed in this build environment

```bash
python3 scripts/check_package.py
python3 scripts/numeric_audit.py
```

The static checker verifies:

- required package files;
- Typst delimiter balance;
- local import targets;
- duplicate top-level declarations;
- pinned CeTZ dependency;
- manifest/version/exclude metadata;
- package-style imports in examples;
- model schema `sang-3d/model@4`;
- strict rendering validation;
- generated-point policy presence in dense systems;
- expected public APIs;
- twelve-system documentation matrix.

The numerical audit verifies vectors, matrices, rotations, topology, sections, surfaces, sphere/icosahedron topology, plane intersections, skew lines, exact visibility splitting, constructive constraints, nonlinear constraints, sweep frames, unfolding length preservation, curve formulas, SDF/CSG operations, implicit extraction, symbolic measurements, welding, hatching, and the twelve-system feature matrix.


## Current audit result

```text
STATIC CHECK OK: 69 Typst files, 9527 counted source lines
NUMERIC AUDIT OK
EXTENDED AUDIT OK
REVOLUTION AUDIT OK
SMART GEOMETRY AUDIT OK
SMART MODELING AUDIT OK
TWELVE-SYSTEM AUDIT OK
```

## Explicit-point contract checks

`tests/explicit-points.typ` verifies:

- ordered given/derived declarations;
- label positions stored in point options;
- `points.len() == definitions.len()`;
- point-policy naming for round solids;
- named center controls before ring points;
- public CSG primitive controls;
- strict validation of generated implicit vertices.

## Required compiler gate

This environment does not contain Typst CLI, so the following commands have not been run here:

```bash
typst compile examples/no-hidden-points.typ build/no-hidden-points.pdf
typst compile examples/revolution-toolbox.typ build/revolution-toolbox.pdf
typst compile examples/round-solids.typ build/round-solids.pdf
typst compile examples/curves-csg.typ build/curves-csg.pdf
typst compile examples/textbook-technical.typ build/textbook-technical.pdf
typst compile hdsd-sang-3d.typ build/gallery.pdf
```

Before a Universe pull request, install the package under the local preview package path so its examples can resolve:

```typ
#import "@preview/sang-3d:0.8.0": sang3d
```

## Honest limitations

- No compiler/CeTZ render verification was possible in this container.
- CSG is signed-distance-field based, not manufacturing-grade B-rep Boolean geometry.
- Exact visibility is exact for tessellated polygonal input.
- Label boxes are estimated in geometry space.
- Technical drawing is publication-oriented, not a complete ISO/GD&T implementation.
