# Advanced Modeling in sang-3d 0.6

Version 0.6 adds five connected systems:

1. Advanced 3D curves: Bezier, Hermite, Catmull-Rom, B-spline, Frenet frames, curvature and arc length.
2. Implicit surfaces generated with marching tetrahedra.
3. Signed-distance CSG: union, intersection, subtraction, smooth union, shells and transforms.
4. Paired symbolic/numeric dimensions and measurements.
5. Materials, textbook constructors and technical drawing helpers.

## CSG model

CSG is field-based rather than polygon-boolean based. Each primitive stores a signed-distance function and conservative bounds. Boolean operations compose the fields, and `csg.build` samples the result into a polygonal model.

This design is robust for rounded unions, drilling, shells and mixed primitives. It does not yet preserve analytic face identities or produce manufacturing-grade watertight meshes.

## Implicit extraction

`implicit.surface` divides each grid cell into six tetrahedra. Every tetrahedron is intersected against the requested level set. Intersection polygons are sorted using a finite-difference gradient and emitted as face objects.

Higher resolution improves detail but increases Typst evaluation cost rapidly. Resolutions from 10 to 20 per axis are recommended for documents.

## Curve frames

Sweep paths can be created from the advanced curve functions. Differential helpers provide tangent, normal, binormal, curvature, approximate arc length, and point-at-length queries.

## Symbolic geometry

A symbolic scalar stores both a display symbol and a numeric render value. Symbolic constructors attach this data to model metadata, so formulas and drawings remain synchronized.
