# Point Definition Graph — 0.8.0 contract

## Invariant

For every model:

```text
points.keys() == definitions.keys() == point-options.keys()
```

`point-order` records declaration order. An object can reference only a name in `points`. A derived point can depend only on names that appear earlier in `point-order`.

## Declaration phase

```typ
#let manifest = (
  sang3d.given-point("A", (0, 0, 0)),
  sang3d.given-point("B", (4, 0, 0)),
  sang3d.derived-point(
    "M", (2, 0, 0), "midpoint",
    deps: ("A", "B"),
  ),
)
```

The declaration contains geometry and presentation data. The point is not hidden inside an object.

## Object phase

```typ
#let fig = sang3d.figure3d(
  points: manifest,
  objects: (
    sang3d.objects.segment("A", "B"),
    sang3d.objects.point("M"),
  ),
)
```

The object phase cannot add points implicitly.

## Generated points

A constructor must execute two phases internally:

```text
calculate coordinates
→ create ordered point declarations
→ validate names and dependencies
→ create objects using declaration names
→ return strict model
```

`point-policy` exposes each generated declaration to the caller. It can customize names, labels, label positions, visibility, roles, styles, and definitions.

## Control points

Centers, axes, profile controls, curve controls, CSG primitive controls, and source references are part of the same graph. For example, a cylinder declares both center points before its ring points. Each ring point depends on the corresponding center.

## No automatic repair

The standard model path does not materialize anonymous coordinates, rename collisions, or create missing definitions. It reports an error. Legacy materialization exists only as an explicitly disabled compatibility branch and is not used by `figure3d` or strict constructors.

## Transformation provenance

Transforms preserve point names and append transformation information to definitions/provenance. Merges prefix points only when the caller explicitly asks for a prefix. Conflicting names are never silently changed inside one point manifest.

## Validation failures

The validator reports:

- missing definitions;
- anonymous object coordinates;
- unknown point references;
- forward dependencies;
- cycles;
- duplicate/conflicting names;
- invalid face cardinality;
- invalid object fields.
