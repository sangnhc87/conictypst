# Smart Geometry 0.5

This note describes the high-level design of the 0.5 systems.

## One-line default

```typ
#sang3d.draw(fig)
```

## Publication preset

```typ
#sang3d.draw(
  fig,
  quality: "publication",
  visibility: "exact",
  labels: (mode: "global", leader-lines: "auto"),
)
```

## Core additions

- Exact polygonal visibility boundaries.
- Adaptive overlap-aware camera selection.
- Global iterative label placement.
- Constructive point dependency constraints.
- Sweep and loft meshes with transported frames.
- Automatic polyhedral face-tree unfolding.

See `examples/smart-geometry.typ` and `tests/smart-geometry.typ`.
