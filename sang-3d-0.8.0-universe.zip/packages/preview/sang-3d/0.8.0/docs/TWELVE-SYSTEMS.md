# Twelve-System Completion Contract

Version 0.8.0 defines “complete” at the Typst publication and mathematical-illustration scope, not at manufacturing-CAD scope.

## 1. Constraint geometry

Complete scope:

- dependency-ordered constructive rules;
- nonlinear numeric residual solver;
- distance, coincidence, line/plane/sphere incidence;
- collinearity, coplanarity, parallelism, perpendicularity;
- angle and equal-distance equations;
- custom residuals;
- convergence metadata and public solved-point definitions.

## 2. Constructive solid geometry

Complete scope:

- sphere, box, rounded box, cylinder, cone, capsule, ellipsoid, torus, plane;
- union, intersection, subtraction, XOR, complement;
- smooth union/intersection/subtraction;
- shell, offset, translate, rotate, scale, clip;
- inspectable operation tree;
- extraction to a public welded mesh.

This is signed-distance-field CSG. It is intended for diagrams, education, and illustrative technical models, not tolerance-critical CAD export.

## 3. Exact hidden line

- projected edge/face boundary splitting;
- per-interval depth classification;
- orthographic and perspective support;
- visible, dashed-hidden, solid-hidden, and removed-hidden policies.

## 4. Smart Camera 3.0

- broad candidate search;
- local refinement;
- projected area and balance scoring;
- short-edge, vertex-overlap, and edge-crossing penalties;
- focus normal and section visibility preferences;
- auto fit.

## 5. Global labels

- multiple candidates per label;
- global iterative collision reduction;
- edge and point clearance;
- viewport penalty;
- leader-line policy;
- stable semantic point options.

## 6. Symbolic–numeric geometry

- symbolic scalar and numeric value pairing;
- arithmetic expression composition;
- cube, cuboid, prism, pyramid, cylinder, cone, frustum, sphere, torus, ellipsoid;
- volume, total area, lateral area, base area, diagonal, slant height;
- point-level symbolic coordinate linking;
- parameter tables and formatted formulas.

## 7. Textbook DSL

- polyhedra and solids with conventional points;
- base centers, axes, radii, generators, heights, right-angle marks;
- common perpendicular for skew lines;
- line–plane angle and dihedral-angle helpers;
- compound configurations such as cone-inscribed-in-sphere.

## 8. Sweep and loft

- arbitrary profile and path;
- parallel-transport-style moving frame;
- scale and twist functions;
- open/closed profile and path;
- caps, mesh and face modes;
- tube and ribbon convenience APIs;
- multi-section loft.

## 9. Advanced curves

- Bezier and rational Bezier;
- cubic Bezier;
- Hermite;
- Catmull–Rom;
- B-spline and NURBS;
- tangent, normal, binormal, Frenet frame;
- curvature and torsion;
- arc length, point at length, and arc-length reparameterization.

## 10. Implicit surfaces

- arbitrary scalar field and iso-level;
- marching tetrahedra;
- approximate gradient orientation;
- welded public vertices;
- provenance by cell, tetrahedron, and level;
- face and wire-mesh output.

## 11. Materials and shading

- semantic material patches;
- ambient and diffuse terms;
- illustrative specular and rim terms;
- contrast, opacity, quantized tones;
- double-sided rendering;
- textbook, clay, matte, glass, x-ray, metal, toon, blueprint, technical, section, and wireframe presets;
- layered materials and selector-scoped application.

## 12. Technical drawing

- orthographic and isometric sheets;
- exact hidden-line technical views;
- bounding dimensions;
- exploded selections;
- section cap generation;
- clipped hatch lines;
- assemblies;
- BOM data and table;
- drawing-package composition.

## Mandatory cross-system invariant

All twelve systems must return `sang-3d/model@4` models that satisfy:

```typ
#assert(model.points.len() == model.definitions.len())
#assert(sang3d.validate(model).len() == 0)
```
