#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.2cm)

= Role, tag, point and renderer customization

#let fig = {
  let value = sang3d.regular-pyramid(5, radius: 2.4, height: 3.6)
  value = sang3d.patch-tag(value, "edges", (role: "strong"))
  value = sang3d.patch-object(value, "side-1", (role: "accent", cull: false))
  value = sang3d.with-point-option(value, "S", (
    label-content: $S$,
    label-distance: 0.34,
    label-priority: 100,
    radius: 0.075,
  ))
  value
}

#let custom-theme = sang3d.theme("violet", overrides: (
  roles: (
    strong: (stroke: (paint: rgb("111827"), thickness: 1.45pt)),
    accent: (fill: rgb("7C3AED").transparentize(72%)),
  ),
  visibility: (mode: "sampled", samples: 28, hidden-lines: "dashed"),
  label: (offset: 0.28, separation: 0.38),
))

#sang3d.render-model(
  fig,
  camera: sang3d.camera.auto(view: "best", prefer: "balanced"),
  style: custom-theme,
)
