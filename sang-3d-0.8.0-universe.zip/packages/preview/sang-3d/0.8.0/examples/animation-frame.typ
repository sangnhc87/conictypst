#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.2cm)

= Frame helpers

#let source = sang3d.cube(size: 2, labels: false)
#let frames = sang3d.orbit-frames(source, count: 12, axis: (0, 0, 1))

// Render any frame; a document can loop over this array to create pages.
#sang3d.render-model(
  frames.at(3),
  camera: sang3d.camera.isometric(),
  style: sang3d.theme("amber"),
)
