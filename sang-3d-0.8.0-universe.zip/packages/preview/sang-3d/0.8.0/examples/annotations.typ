#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.2cm)

= Dimensions, equal marks, and dihedral angles

#let fig = {
  let value = sang3d.cuboid(width: 4, depth: 3, height: 3.2)
  value = sang3d.with-dimension(value, "A", "B", offset: (0, -0.55, 0), label: $4$)
  value = sang3d.with-dimension(value, "B", "C", offset: (0.5, 0, 0), label: $3$)
  value = sang3d.with-ticks(value, "A1", "B1", count: 1)
  value = sang3d.with-ticks(value, "D1", "C1", count: 1)
  value = sang3d.with-dihedral(
    value,
    "A",
    (1, 0, 0),
    (0, 0, 1),
    (0, -1, 0),
    label: $theta$,
  )
  value
}

#sang3d.render-model(
  fig,
  camera: sang3d.camera.auto(view: "best", prefer: "show-height"),
  style: sang3d.theme("textbook", accent: rgb("2563EB")),
)
