#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.2cm)

= Named geometric constructions

#let fig = {
  let value = sang3d.tetrahedron(size: 4)
  value = sang3d.midpoint(value, "M", "A", "B", role: "accent")
  value = sang3d.centroid(value, "G", ("A", "B", "C"), role: "accent")
  let base-plane = sang3d.plane-through(value.points.A, value.points.B, value.points.C)
  value = sang3d.project-on-plane(value, "H", "S", base-plane, role: "construction")
  value = sang3d.with-right-angle(value, "H", "A", "S", role: "accent")
  value = sang3d.with-angle(value, "A", "B", "S", label: $alpha$, role: "accent")
  value = sang3d.with-segment(value, "S", "G", role: "construction", tags: ("median",))
  value
}

#sang3d.render-model(fig, camera: sang3d.camera.auto(view: "best"), style: sang3d.theme("red"))
