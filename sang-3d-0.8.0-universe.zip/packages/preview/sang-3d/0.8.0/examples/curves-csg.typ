#import "@preview/sang-3d:0.8.0": sang3d

#set page(width: 21cm, height: auto, margin: 1.4cm)

= Curves and CSG

== Cubic Bezier tube

#let controls = (
  (-3, 0, 0),
  (-1, 3, 1),
  (2, -2, 3),
  (4, 1, 4),
)
#let path = sang3d.curves.bezier(controls)
#let tube = sang3d.tube-along(path, radius: 0.18, sides: 12, path-steps: 40)

#sang3d.draw(tube, material: "clay", quality: "print")

== Signed-distance CSG

#let outer = sang3d.csg.union(
  sang3d.csg.box(center: (0, 0, 0), size: (4, 3, 2.6)),
  sang3d.csg.sphere(center: (0, 0, 1.3), radius: 1.65),
)
#let bore = sang3d.csg.cylinder(a: (0, 0, -2), b: (0, 0, 4), radius: 0.62)
#let field = sang3d.csg.subtract(outer, bore)
#let body = sang3d.csg.build(field, resolution: (16, 14, 14), prefix: "BODY")

#sang3d.draw(body, material: "clay", quality: "print", show: (points: false, labels: false))
