#import "@preview/sang-3d:0.8.0": sang3d

#set page(width: 16cm, height: 12cm, margin: 8mm)

#let fr = sang3d.euclid.frame(
  origin: (0, 0, 0),
  normal: (1, 1, 1),
  x-direction: (1, -1, 0),
)
#let rectangle = sang3d.euclid.polygon(
  ((-2, -1.2), (2, -1.2), (2, 1.2), (-2, 1.2)),
  frame: fr,
  names: ("A", "B", "C", "D"),
  prefix: "R",
  labels: true,
  role: "main",
)
#let a = rectangle.points.at("A")
#let b = rectangle.points.at("B")
#let c = rectangle.points.at("C")
#let circum = sang3d.euclid.circumcircle(a, b, c, role: "accent")
#let plane = sang3d.euclid.plane(
  center: fr.origin,
  normal: fr.normal,
  width: 5.5,
  height: 4,
  x-direction: fr.u,
  grid: (6, 4),
)
#let fig = sang3d.merge-many((plane, rectangle, circum), prefixes: ("P-", "", "C-"))

#sang3d.draw(
  fig,
  focus: (normal: fr.normal),
  quality: "print",
  theme: "blue",
  rules: (
    sang3d.line-rule((tag: "euclid-edge"), pattern: "solid", role: "main", thickness: 1.05pt),
    sang3d.line-rule((tag: "euclid-plane"), pattern: "dotted", role: "auxiliary", thickness: 0.45pt),
  ),
)
