#import "@preview/sang-3d:0.8.0": sang3d

#set page(width: 18cm, height: auto, margin: 1cm)

= Generated points remain explicit

#let ring-policy = sang3d.point-policy(
  name: ctx => "P-" + ctx.ring + "-" + str(ctx.index + 1),
  label: ctx => if ctx.index == 0 { ctx.ring } else { auto },
  label-position: ctx => if ctx.ring.contains("top") { "top" } else { "bottom" },
  show-point: ctx => ctx.index == 0,
  show-label: ctx => ctx.index == 0,
  definition: ctx => (
    kind: "named-cylinder-ring-point",
    deps: ctx.deps,
    parameters: (
      ring: ctx.ring,
      angle: ctx.angle,
      index: ctx.index,
    ),
  ),
)

#let center-policy = sang3d.point-policy(
  name: ctx => if ctx.control == "base-center" { "O1" } else { "O2" },
  label: ctx => if ctx.control == "base-center" { $O_1$ } else { $O_2$ },
  label-position: "left",
  show-point: true,
  show-label: true,
)

#let fig = sang3d.cylinder-between(
  (0, 0, 0),
  (1, 0.5, 4),
  radius: 1.3,
  sides: 12,
  prefix: "CY",
  point-policy: ring-policy,
  control-point-policy: center-policy,
)

#sang3d.draw(fig, quality: "publication", strict: true)

== Point manifest

#sang3d.point-table(fig)
