#import "@preview/sang-3d:0.8.0": sang3d

#set page(width: 14cm, height: 10cm, margin: 8mm)

#let fig = {
  let value = sang3d.cuboid(width: 4, depth: 3, height: 3, labels: false)
  value = sang3d.patch-object(value, "edge-1", (stroke: sang3d.stroke(pattern: "dash-dot", thickness: 1.2pt)))
  value = sang3d.patch-tag(value, "edges", (role: "strong"))
  value
}

#sang3d.draw(
  fig,
  theme: "technical",
  quality: "print",
  hidden: "dashed",
  rules: (
    sang3d.line-rule((role: "strong"), pattern: "long-dash", role: "strong", thickness: 0.95pt),
    sang3d.line-rule((tag: "construction"), pattern: "dotted", role: "construction"),
  ),
)
