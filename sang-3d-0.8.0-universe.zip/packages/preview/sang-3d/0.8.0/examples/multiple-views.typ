#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1cm)

= Synchronized views

#let fig = sang3d.regular-pyramid(5, radius: 2, height: 3.2, labels: false)

#sang3d.render-views(
  fig,
  (
    sang3d.camera.isometric(),
    sang3d.camera.front(),
    sang3d.camera.top(),
    sang3d.camera.cabinet(),
  ),
  columns: 2,
  captions: ([Isometric], [Front], [Top], [Cabinet]),
  style: sang3d.theme("wireframe"),
  length: 5.4cm,
)
