#import "@preview/sang-3d:0.8.0": sang3d

#set page(width: 18cm, height: auto, margin: 1.2cm)

= Explicit point declarations before objects

// Every point is declared here, in dependency order. Each declaration owns
// its name, coordinate, geometric definition, label and label position.
#let point-manifest = (
  sang3d.given-point(
    "A", (0, 0, 0),
    label: $A$,
    label-position: "bottom-left",
  ),
  sang3d.given-point(
    "B", (4, 0, 0),
    label: $B$,
    label-position: "bottom-right",
  ),
  sang3d.given-point(
    "C", (0, 3, 0),
    label: $C$,
    label-position: "top-left",
  ),
  sang3d.given-point(
    "S", (1, 1, 4),
    label: $S$,
    label-position: "top",
  ),

  sang3d.derived-point(
    "M", (2, 0, 0), "midpoint",
    deps: ("A", "B"),
    parameters: (ratio: 1 / 2),
    label: $M$,
    label-position: "bottom",
  ),
  sang3d.derived-point(
    "G", (4 / 3, 1, 0), "centroid",
    deps: ("A", "B", "C"),
    label: $G$,
    label-position: "bottom-right",
  ),
  sang3d.derived-point(
    "H", (1, 1, 0), "projection-on-plane",
    deps: ("S", "A", "B", "C"),
    parameters: (source: "S", plane: ("A", "B", "C")),
    label: $H$,
    label-position: "right",
  ),
)

// Objects are created only after the complete point manifest exists. They
// contain point names, never anonymous coordinate tuples.
#let fig = sang3d.figure3d(
  points: point-manifest,
  objects: (
    sang3d.objects.face(("A", "B", "C"), id: "base"),
    sang3d.objects.segment("S", "A", id: "SA"),
    sang3d.objects.segment("S", "B", id: "SB"),
    sang3d.objects.segment("S", "C", id: "SC"),
    sang3d.objects.segment("A", "B", id: "AB"),
    sang3d.objects.segment("S", "H", id: "altitude", role: "accent"),
    sang3d.objects.segment("C", "G", id: "median-CG", role: "construction"),
  ),
)

#sang3d.draw(fig, quality: "publication", strict: true)

== Public point registry

#sang3d.point-table(fig)

== Provenance of H

#repr(sang3d.point-provenance(fig, "H"))

== Strict validation

#repr(sang3d.validate(fig))
