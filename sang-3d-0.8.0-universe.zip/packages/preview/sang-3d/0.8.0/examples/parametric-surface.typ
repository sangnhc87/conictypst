#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.2cm)

= Parametric surface

#let surface = sang3d.graph-surface(
  (x, y) => 0.55 * calc.sin(1.4 * x) * calc.cos(1.2 * y),
  x: (-2.5, 2.5, 14),
  y: (-2.2, 2.2, 12),
  role: "surface",
)

#let axes = sang3d.axes3d(length: 3, negative: 3)
#let fig = sang3d.merge(surface, axes, prefix: "axis-")

#sang3d.render-model(
  fig,
  camera: sang3d.camera.orbit(azimuth: 42deg, elevation: 28deg),
  style: sang3d.theme("cyan", overrides: (
    visibility: (mode: "sampled", samples: 12),
  )),
  show-points: false,
)
