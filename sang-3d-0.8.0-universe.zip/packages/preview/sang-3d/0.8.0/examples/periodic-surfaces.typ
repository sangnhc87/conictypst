#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.1cm)

= Seam-safe periodic surfaces

#let ring = sang3d.torus(major-steps: 24, minor-steps: 10, prefix: "T")
#let ball = sang3d.translate(
  sang3d.sphere-surface(radius: 1.35, latitudes: 10, longitudes: 18, prefix: "B"),
  (4.4, 0, 0),
)
#let sc = sang3d.scene.scene(children: (
  sang3d.node3d(ring, prefix: "ring-", styles: (roles: (surface: (fill: rgb("0891B2").transparentize(88%)),))),
  sang3d.node3d(ball, prefix: "ball-", styles: (roles: (surface: (fill: rgb("7C3AED").transparentize(88%)),))),
))

#sang3d.render-model(
  sc,
  camera: sang3d.camera.auto(view: "best"),
  style: sang3d.theme("technical"),
  show-points: false,
)
