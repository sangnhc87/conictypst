#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.2cm)

= Reusable projected geometry data

#let fig = sang3d.tetrahedron(size: 3)
#let projected = sang3d.project-model(
  fig,
  camera: sang3d.camera.isometric(),
)

The projected coordinate of $S$ is:

#repr(projected.points.at("S"))

#sang3d.render-model(fig, camera: projected.camera, style: sang3d.theme("green"))
