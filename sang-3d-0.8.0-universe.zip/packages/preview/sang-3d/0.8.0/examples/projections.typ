#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.1cm)

#let fig = sang3d.cube(size: 3, labels: false)

#grid(
  columns: 2,
  gutter: 10pt,
  [*Orthographic*\
   #sang3d.render-model(fig, camera: sang3d.camera.isometric(), length: 6cm)],
  [*Perspective*\
   #sang3d.render-model(fig, camera: sang3d.camera.orbit(azimuth: 45deg, elevation: 28deg, perspective: true), length: 6cm)],
  [*Cabinet*\
   #sang3d.render-model(fig, camera: sang3d.camera.cabinet(), length: 6cm)],
  [*Top*\
   #sang3d.render-model(fig, camera: sang3d.camera.top(), length: 6cm)],
)
