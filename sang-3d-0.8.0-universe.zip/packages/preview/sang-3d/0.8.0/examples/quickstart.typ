#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.5cm)

= Quick start

#let solid = sang3d.cuboid(width: 4, depth: 3, height: 3.5)

#sang3d.render-model(
  solid,
  camera: sang3d.camera.auto(view: "best"),
  style: sang3d.theme("blue"),
)
