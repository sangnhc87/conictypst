#import "@preview/sang-3d:0.8.0": sang3d

#set page(width: 16cm, height: 12cm, margin: 8mm)

= Arbitrary-axis rotation

#let ax = sang3d.axis-through((0, 0, 0), (1, 1, 2))
#let source = sang3d.euclid.rectangle(
  width: 1.6,
  height: 1.0,
  center: (2, 0, 0),
  normal: (0, 1, 0),
  labels: false,
  face: false,
)
#let states = sang3d.revolution.turn(
  source,
  ax,
  140deg,
  mode: "copies",
  steps: 6,
)
#let path = sang3d.revolution.orbit(
  (2, 0, 0),
  ax,
  angle: 140deg,
  show-axis: true,
  show-radius: true,
  label: $alpha$,
)
#let scene = sang3d.merge(states, path, prefix: "path-")

#sang3d.draw(
  scene,
  view: "auto",
  quality: "print",
  theme: "technical",
  line: sang3d.line-preset("strong"),
)

= Partial solid of revolution

#let profile(t) = (1.1 + 0.45 * calc.sin(180deg * t), 3 * t)
#let partial = sang3d.surface-of-revolution(
  profile,
  t: (0, 1, 18),
  angle: 230deg,
  angle-steps: 36,
  around: sang3d.axis3d(point: (-1, 0, 0), direction: (0.3, 0.4, 1)),
  profile-mode: "radius-height",
  prefix: "V",
)

#sang3d.draw(partial, quality: "print", theme: "violet")

= Rotate one object around another object

#let mechanism-base = sang3d.figure3d(
  points: (
    sang3d.given-point("A", (0, 0, 0), label: $A$, label-position: "left"),
    sang3d.given-point("B", (0, 0, 3), label: $B$, label-position: "top"),
    sang3d.given-point("P", (2, 0, 0.5), label: $P$, label-position: "bottom"),
    sang3d.given-point("Q", (2, 0, 2.5), label: $Q$, label-position: "right"),
  ),
  objects: (
    sang3d.objects.segment("A", "B", id: "hinge", role: "axis"),
    sang3d.objects.segment("P", "Q", id: "bar", role: "strong", tags: ("moving",)),
  ),
)
#let mechanism = sang3d.revolution.turn-around(
  mechanism-base,
  "hinge",
  120deg,
  target: (tag: "moving"),
  mode: "copies",
  steps: 5,
)

#sang3d.draw(
  mechanism,
  quality: "print",
  rules: (
    sang3d.lines.rule((role: "axis"), pattern: "center", role: "axis"),
  ),
)
