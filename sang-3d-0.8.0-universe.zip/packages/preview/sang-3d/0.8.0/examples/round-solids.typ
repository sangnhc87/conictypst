#import "@preview/sang-3d:0.8.0": sang3d

#set page(width: 17cm, height: 13cm, margin: 8mm)

#let c = sang3d.cylinder-between(
  (-4, -1, 0),
  (-2, 1, 3),
  radius: 0.9,
  sides: 32,
  prefix: "C",
)
#let n = sang3d.cone-between(
  (0, -1, 0),
  (1, 1, 3.5),
  radius: 1.25,
  sides: 32,
  prefix: "N",
)
#let tube = sang3d.tube-between(
  (3, -1, 0),
  (4, 1, 3),
  outer-radius: 1.1,
  inner-radius: 0.65,
  sides: 32,
  prefix: "U",
)
#let cap = sang3d.spherical-cap(
  radius: 1.6,
  height: 0.85,
  center: (-2.5, 4, 0),
  axis: (0.3, 0.2, 1),
  prefix: "K",
)
#let capsule = sang3d.capsule(
  (1.5, 3.5, 0),
  (3.5, 4.5, 2.5),
  radius: 0.65,
  prefix: "Q",
)

#let all = sang3d.merge-many((c, n, tube, cap, capsule))

#sang3d.draw(
  all,
  quality: "print",
  theme: "textbook",
  hidden: "dashed",
  rules: (
    sang3d.line-rule((tag: "tube"), pattern: "dash-dot", role: "surface", thickness: 0.7pt),
  ),
)

#pagebreak()

= Elliptic round solids

#let ec = sang3d.round.elliptic-cylinder-between(
  (-2, 0, 0),
  (-1, 1, 4),
  radii: (1.5, 0.7),
  twist: 25deg,
  prefix: "EC",
)
#let en = sang3d.round.elliptic-cone-between(
  (2, 0, 0),
  (3, 1, 4),
  radii: (1.5, 0.7),
  prefix: "EN",
)
#sang3d.draw(sang3d.merge(ec, en), quality: "print", theme: "technical")
