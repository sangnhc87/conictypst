#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.2cm)

= Scene graph

#let left = sang3d.node3d(
  sang3d.cube(size: 2, labels: false),
  prefix: "L-",
  transform: sang3d.transform3d.translation((-2.2, 0, 0)),
  styles: (roles: (main: (fill: rgb("0891B2").transparentize(88%)),)),
)

#let right-transform = sang3d.transform3d.compose((
  sang3d.transform3d.translation((2.0, 0.4, 0.2)),
  sang3d.transform3d.rotation-z(22deg),
  sang3d.transform3d.scaling((1.0, 0.8, 1.25)),
))

#let right = sang3d.node3d(
  sang3d.regular-prism(6, radius: 1.35, height: 2.4, labels: false),
  prefix: "R-",
  transform: right-transform,
  styles: (roles: (main: (fill: rgb("D97706").transparentize(88%)),)),
)

#let sc = sang3d.scene.scene(children: (left, right))

#sang3d.render-model(sc, camera: sang3d.camera.auto(view: "best"))
