#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.2cm)

= Automatic convex section

#let fig = sang3d.cuboid(width: 4, depth: 3, height: 3.4)
#let pl = sang3d.plane-through(
  fig.points.at("A1"),
  fig.points.at("B"),
  fig.points.at("D1"),
)
#let result = sang3d.with-section(
  fig,
  pl,
  prefix: "M",
  show-plane: true,
  plane-width: 5.5,
  plane-height: 4.5,
  plane-grid: (6, 5),
)

#sang3d.render-model(
  result.model,
  camera: sang3d.camera.auto(view: "best"),
  style: sang3d.theme("green"),
)
