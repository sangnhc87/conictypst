#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 12mm)

= sang-3d 0.5 — Smart Geometry

== Constraint graph

#let constrained = sang3d.constraints.solve(
  seed: (
    A: (0, 0, 0),
    B: (4, 0, 0),
    C: (0, 3, 0),
    S: (1.2, 1, 4),
  ),
  constraints: (
    sang3d.constraints.midpoint("M", "A", "B"),
    sang3d.constraints.centroid("G", ("A", "B", "C")),
    sang3d.constraints.project-plane("H", "S", sang3d.constraints.plane-through("A", "B", "C")),
  ),
  objects-list: (
    sang3d.objects.segment("A", "B", id: "AB"),
    sang3d.objects.segment("B", "C", id: "BC"),
    sang3d.objects.segment("C", "A", id: "CA"),
    sang3d.objects.segment("S", "H", id: "height", role: "accent"),
  ),
)

#sang3d.draw(constrained, quality: "print", focus: (normal: (0, 0, 1)))

== Sweep along a helix

#let spring = sang3d.tube-along(
  sang3d.helix(radius: 1.8, pitch: 0.7, turns: 3),
  radius: 0.16,
  sides: 12,
  path-steps: 48,
)

#sang3d.draw(spring, quality: "publication", labels: (mode: "global", leader-lines: false))

== Loft

#let lofted = sang3d.loft((
  ((-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0)),
  ((-1.4, 0, 2), (0, -0.8, 2), (1.4, 0, 2), (0, 0.8, 2)),
  ((-0.6, -0.6, 4), (0.6, -0.6, 4), (0.6, 0.6, 4), (-0.6, 0.6, 4)),
), prefix: "L")

#sang3d.draw(lofted, visibility: "exact", theme: "technical")

== Unfold a cube

#let net = sang3d.unfold(sang3d.cube(size: 2, labels: false), root-face: "bottom", labels: true)

#sang3d.draw(
  net,
  view: "top",
  theme: "technical",
  visibility: "none",
  labels: "global",
)
