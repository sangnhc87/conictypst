#import "@preview/sang-3d:0.8.0": sang3d

#set page(width: 15cm, height: 11cm, margin: 8mm)

#let fig = sang3d.regular-pyramid(5, radius: 2.4, height: 3.7)

#let rules = (
  sang3d.style-rule(
    (tag: "edges"),
    (roles: (main: (stroke: (paint: rgb("243B53"), thickness: 1.15pt)))),
  ),
  sang3d.style-rule(
    (id: "side-1"),
    (roles: (main: (fill: rgb("F59E0B").transparentize(72%)))),
  ),
  sang3d.style-rule(
    (kind: "point"),
    (point: (radius: 0.072, fill: white)),
  ),
)

#sang3d.render-model(
  fig,
  camera: sang3d.camera.auto(view: "best", prefer: "show-height"),
  style: sang3d.theme("violet"),
  style-rules: rules,
)
