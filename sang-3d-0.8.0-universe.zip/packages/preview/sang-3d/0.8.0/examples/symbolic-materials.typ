#import "@preview/sang-3d:0.8.0": sang3d

#set page(width: 21cm, height: auto, margin: 1.4cm)

= Symbolic measurements and materials

#let R = sang3d.symbolic.scalar([$R$], 2)
#let h = sang3d.symbolic.scalar([$h$], 4)
#let cone = sang3d.symbolic.cone(radius: R, height: h)

#sang3d.draw(cone, material: "glass", quality: "print")

Volume: #sang3d.symbolic.formula(sang3d.symbolic.volume(cone), name: $V$)

Slant height: #sang3d.symbolic.formula(sang3d.symbolic.slant-height(cone), name: $l$, approximate: true)

#let box = sang3d.symbolic.cuboid(
  width: sang3d.symbolic.scalar([$a$], 4),
  depth: sang3d.symbolic.scalar([$b$], 3),
  height: sang3d.symbolic.scalar([$c$], 2),
)

#sang3d.draw(box, material: "blueprint", view: "isometric")

Diagonal: #sang3d.symbolic.formula(sang3d.symbolic.diagonal(box), name: $d$)
