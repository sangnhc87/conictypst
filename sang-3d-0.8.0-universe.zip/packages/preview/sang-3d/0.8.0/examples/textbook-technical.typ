#import "@preview/sang-3d:0.8.0": sang3d

#set page(width: 21cm, height: auto, margin: 1.4cm)

= Textbook and technical drawing

#let pyramid = sang3d.textbook.regular-pyramid(
  n: 4,
  radius: 2.4,
  height: 3.8,
  rotation: 45deg,
)

#sang3d.draw(pyramid, quality: "publication")

#let dimensioned = sang3d.technical.auto-dimensions(
  sang3d.cuboid(width: 4, depth: 3, height: 2.5, labels: false),
  labels: ([$a$], [$b$], [$h$]),
)

#sang3d.draw(dimensioned, theme: "technical", view: "isometric", visibility: "exact")

#sang3d.technical.sheet(
  dimensioned,
  views: ("front", "top", "right", "isometric"),
  columns: 2,
)
