#import "@preview/sang-3d:0.8.0": sang3d

#set page(margin: 1.2cm)
#set text(font: "New Computer Modern", size: 10pt)

= sang-3d 0.8.0 — twelve-system gallery

== Smart camera + exact hidden lines
#let box3d = sang3d.cuboid(width: 4.2, depth: 3, height: 3.4)
#sang3d.render-model(box3d, camera: sang3d.camera.auto(view: "best"), style: sang3d.theme("blue"))

== Automatic section and construction plane
#let pl = sang3d.plane-through(box3d.points.A1, box3d.points.B, box3d.points.D1)
#let cut = sang3d.with-section(box3d, pl, prefix: "M", show-plane: true, plane-grid: (5, 4))
#sang3d.render-model(cut.model, camera: sang3d.camera.auto(view: "best"), style: sang3d.theme("green"))

== Scene graph
#let sc = sang3d.scene.scene(children: (
  sang3d.node3d(sang3d.octahedron(radius: 1.5, labels: false), prefix: "O-", transform: sang3d.transform3d.translation((-2, 0, 0))),
  sang3d.node3d(sang3d.regular-frustum(6, radius: 1.5, height: 2.6, labels: false), prefix: "F-", transform: sang3d.transform3d.translation((2, 0, -1.2))),
))
#sang3d.render-model(sc, camera: sang3d.camera.auto(view: "best"), style: sang3d.theme("violet"))

== Parametric graph surface
#let graph3d = sang3d.graph-surface((x, y) => 0.6 * calc.sin(x) * calc.cos(y), x: (-2.4, 2.4, 12), y: (-2.4, 2.4, 12))
#sang3d.render-model(graph3d, camera: sang3d.camera.orbit(azimuth: 45deg, elevation: 30deg), style: sang3d.theme("cyan"), show-points: false)

== Torus
#let ring = sang3d.torus(major-steps: 20, minor-steps: 8)
#sang3d.render-model(ring, camera: sang3d.camera.orbit(azimuth: 42deg, elevation: 25deg), style: sang3d.theme("amber"), show-points: false)


== Arbitrary-axis rotation through alpha
#let rotation-axis = sang3d.axis-through((0, 0, 0), (1, 1, 2))
#let source-shape = sang3d.euclid.rectangle(width: 1.5, height: 1, center: (2, 0, 0), normal: (0, 1, 0), labels: false, face: false)
#let rotation-states = sang3d.revolution.turn(source-shape, rotation-axis, 140deg, mode: "copies", steps: 5)
#let rotation-path = sang3d.revolution.orbit((2, 0, 0), rotation-axis, angle: 140deg, show-axis: true, show-radius: true, label: $alpha$)
#sang3d.draw(sang3d.merge(rotation-states, rotation-path, prefix: "P-"), theme: "technical", quality: "print")

== Arbitrary-direction round solids
#let round-scene = sang3d.merge-many((
  sang3d.cylinder-between((-3, 0, 0), (-2, 1, 3), radius: 0.8, prefix: "C"),
  sang3d.cone-between((0, 0, 0), (1, 1, 3.4), radius: 1.1, prefix: "N"),
  sang3d.tube-between((3, 0, 0), (4, 1, 3), outer-radius: 1, inner-radius: 0.55, prefix: "U"),
))
#sang3d.draw(round-scene, theme: "textbook", quality: "print")

== Euclidean geometry in an oblique plane
#let eframe = sang3d.euclid.frame(normal: (1, 1, 1), x-direction: (1, -1, 0))
#let epoly = sang3d.euclid.regular-polygon(5, radius: 2, normal: eframe.normal, x-direction: eframe.u, labels: true)
#let ecircle = sang3d.euclid.circumcircle(epoly.points.at("A1"), epoly.points.at("A2"), epoly.points.at("A3"))
#sang3d.draw(sang3d.merge(epoly, ecircle, prefix: "C-"), focus: (normal: eframe.normal), quality: "print")


== Constraint graph
#let constrained = sang3d.constraints.solve(
  seed: (A: (0,0,0), B: (4,0,0), C: (0,3,0), S: (1,1,4)),
  constraints: (
    sang3d.constraints.midpoint("M", "A", "B"),
    sang3d.constraints.project-plane("H", "S", sang3d.constraints.plane-through("A", "B", "C")),
  ),
  objects-list: (
    sang3d.objects.segment("A", "B"),
    sang3d.objects.segment("B", "C"),
    sang3d.objects.segment("C", "A"),
    sang3d.objects.segment("S", "H", role: "accent"),
  ),
)
#sang3d.draw(constrained, quality: "publication", visibility: "exact")

== Sweep along a helix
#let spring = sang3d.tube-along(sang3d.helix(radius: 1.8, pitch: 0.65, turns: 2.5), radius: 0.14, sides: 12, path-steps: 42)
#sang3d.draw(spring, quality: "print", show: (points: false, labels: false))

== Automatic unfolding
#let cube-net = sang3d.unfold(sang3d.cube(size: 2, labels: false), root-face: "bottom", labels: true)
#sang3d.draw(cube-net, view: "top", visibility: "none", theme: "technical")
