#import "src/core.typ" as core-module
#import "src/transform.typ" as transform-module
#import "src/styles.typ" as styles-module
#import "src/camera.typ" as camera-module
#import "src/objects.typ" as objects-module
#import "src/model.typ" as model-module
#import "src/definitions.typ" as definitions-module
#import "src/points.typ" as points-module
#import "src/scene.typ" as scene-module
#import "src/constructions.typ" as constructions-module
#import "src/sections.typ" as sections-module
#import "src/solids.typ" as solids-module
#import "src/surfaces.typ" as surfaces-module
#import "src/revolution.typ" as revolution-module
#import "src/euclid.typ" as euclid-module
#import "src/constraints.typ" as constraints-module
#import "src/modeling.typ" as modeling-module
#import "src/unfold.typ" as unfold-module
#import "src/visibility.typ" as visibility-module
#import "src/layout.typ" as layout-module
#import "src/render.typ" as render-module
#import "src/projection.typ" as projection-module
#import "src/animation.typ" as animation-module
#import "src/symbolic.typ" as symbolic-module
#import "src/curves.typ" as curves-module
#import "src/implicit.typ" as implicit-module
#import "src/csg.typ" as csg-module
#import "src/materials.typ" as materials-module
#import "src/textbook.typ" as textbook-module
#import "src/technical.typ" as technical-module

// Namespaced modules.
#let core = core-module
#let transform3d = transform-module
#let styles = styles-module
#let camera = camera-module
#let objects = objects-module
#let model = model-module
#let definitions = definitions-module
#let points = points-module
#let scene = scene-module
#let constructions = constructions-module
#let sections = sections-module
#let solids = solids-module
#let surfaces = surfaces-module
#let revolution = revolution-module
#let euclid = euclid-module
#let constraints = constraints-module
#let modeling = modeling-module
#let unfolding = unfold-module
#let visibility = visibility-module
#let layout = layout-module
#let projection = projection-module
#let animation = animation-module
#let symbolic = symbolic-module
#let curves = curves-module
#let implicit = implicit-module
#let csg = csg-module
#let materials = materials-module
#let textbook = textbook-module
#let technical = technical-module

// Numeric geometry.
#let vec3 = core-module.vec3
#let line3d = core-module.line
#let line-through = core-module.line-through
#let ray3d = core-module.ray
#let plane = core-module.plane
#let plane-through = core-module.plane-through
#let sphere3d = core-module.sphere
#let project-point-plane = core-module.project-point-plane
#let project-point-line = core-module.project-point-line
#let line-plane-intersection = core-module.line-plane-intersection
#let plane-plane-intersection = core-module.plane-plane-intersection
#let line-line-closest = core-module.line-line-closest
#let line-line-distance = core-module.line-line-distance
#let angle-line-line = core-module.angle-line-line
#let angle-line-plane = core-module.angle-line-plane
#let angle-plane-plane = core-module.angle-plane-plane
#let line-sphere-intersections = core-module.line-sphere-intersections
#let sphere-plane-intersection = core-module.sphere-plane-intersection
#let axis3d = core-module.axis
#let axis-through = core-module.axis-through
#let rotate-point-axis = core-module.rotate-around-axis

// Themes and rendering.
#let theme = styles-module.theme
#let style-rule = styles-module.rule
#let style-matches = styles-module.matches
#let stroke = styles-module.stroke
#let line-preset = styles-module.line-preset
#let line-rule = styles-module.line-rule
#let quality-style = styles-module.quality
#let draw-model = render-module.draw-model
#let render-model = render-module.render-model
#let draw = render-module.draw
#let scene3d = render-module.scene3d
#let render-views = render-module.render-views

// Models and scene graph.
#let geometry3d = model-module.model
#let figure3d = model-module.figure
#let point = points-module.point
#let given-point = points-module.given
#let derived-point = points-module.derived
#let point-policy = points-module.policy
#let declare-points = points-module.declare
#let point-manifest-table = points-module.declaration-table
#let node3d = scene-module.node
#let group3d = scene-module.node
#let scene-model = scene-module.scene
#let flatten-scene = scene-module.flatten
#let point-at = model-module.point-at
#let definition-at = model-module.definition-at
#let definition-of = model-module.definition-of
#let point-record = model-module.point-record
#let point-provenance = model-module.provenance
#let point-table = model-module.point-table
#let inspect-model = model-module.inspect
#let assert-valid = model-module.assert-valid
#let point-names = model-module.point-names
#let object-at = model-module.object-at
#let select = model-module.select
#let objects-with-tag = model-module.objects-with-tag
#let objects-of-kind = model-module.objects-of-kind
#let objects-with-role = model-module.objects-with-role
#let with-point = model-module.with-point
#let with-declared-point = model-module.with-declared-point
#let with-points = model-module.with-points
#let alias-point = model-module.alias-point
#let with-object = model-module.with-object
#let with-objects = model-module.with-objects
#let with-styles = model-module.with-styles
#let with-point-option = model-module.with-point-option
#let with-point-options = model-module.with-point-options
#let patch = model-module.patch
#let patch-object = model-module.patch-object
#let patch-tag = model-module.patch-tag
#let patch-kind = model-module.patch-kind
#let patch-role = model-module.patch-role
#let hide = model-module.hide
#let show = model-module.show
#let remove = model-module.remove
#let hide-object = model-module.hide-object
#let show-object = model-module.show-object
#let merge = model-module.merge
#let merge-many = model-module.merge-many
#let prefixed = model-module.prefixed
#let translate = model-module.translate
#let scale = model-module.scale
#let rotate-x = model-module.rotate-x
#let rotate-y = model-module.rotate-y
#let rotate-z = model-module.rotate-z
#let rotate-axis = model-module.rotate-axis
#let rotate-around = model-module.rotate-around
#let rotate-through = model-module.rotate-through
#let validate = model-module.validate

// Construction helpers.
#let add-point = constructions-module.add-point
#let with-segment = constructions-module.with-segment
#let with-vector = constructions-module.with-vector
#let with-line = constructions-module.with-line
#let midpoint = constructions-module.midpoint
#let divide = constructions-module.divide
#let centroid = constructions-module.centroid
#let translated-point = constructions-module.translated-point
#let project-on-line = constructions-module.project-on-line
#let project-on-plane = constructions-module.project-on-plane
#let intersect-line-plane = constructions-module.intersect-line-plane
#let with-angle = constructions-module.with-angle
#let with-right-angle = constructions-module.with-right-angle
#let with-circle = constructions-module.with-circle
#let with-plane = constructions-module.with-plane
#let axes3d = constructions-module.axes
#let with-dimension = constructions-module.with-dimension
#let with-ticks = constructions-module.with-ticks
#let with-dihedral = constructions-module.with-dihedral
#let intersect-planes = constructions-module.intersect-planes
#let closest-lines = constructions-module.closest-lines

// Sections.
#let section-points = sections-module.section-points
#let with-section = sections-module.with-section
#let section-through = sections-module.through-points

// Solids.
#let polyhedron = solids-module.polyhedron
#let cube = solids-module.cube
#let cuboid = solids-module.cuboid
#let prism = solids-module.prism
#let extrude = solids-module.extrude
#let pyramid = solids-module.pyramid
#let frustum = solids-module.frustum
#let regular-base = solids-module.regular-base
#let regular-prism = solids-module.regular-prism
#let regular-pyramid = solids-module.regular-pyramid
#let regular-frustum = solids-module.regular-frustum
#let tetrahedron = solids-module.tetrahedron
#let octahedron = solids-module.octahedron
#let icosahedron = solids-module.icosahedron

// Curved and parametric surfaces.
#let parametric-surface = surfaces-module.parametric
#let graph-surface = surfaces-module.graph
#let sphere-surface = surfaces-module.sphere
#let torus = surfaces-module.torus
#let surface-of-revolution = surfaces-module.surface-of-revolution
#let cylinder = surfaces-module.cylinder
#let cone = surfaces-module.cone
#let truncated-cone = surfaces-module.truncated-cone
#let ellipsoid = surfaces-module.ellipsoid
#let revolve-points = surfaces-module.revolve-points
#let cylinder-between = surfaces-module.cylinder-between
#let cone-between = surfaces-module.cone-between
#let frustum-between = surfaces-module.frustum-between
#let tube-between = surfaces-module.tube-between
#let hemisphere = surfaces-module.hemisphere
#let spherical-cap = surfaces-module.spherical-cap
#let spherical-zone = surfaces-module.spherical-zone
#let capsule = surfaces-module.capsule
#let elliptic-cylinder-between = surfaces-module.elliptic-cylinder-between
#let elliptic-cone-between = surfaces-module.elliptic-cone-between

// Curated ergonomic namespaces.
#let round = (
  surface: surface-of-revolution,
  revolve-points: revolve-points,
  cylinder: cylinder,
  cylinder-between: cylinder-between,
  elliptic-cylinder-between: elliptic-cylinder-between,
  cone: cone,
  cone-between: cone-between,
  elliptic-cone-between: elliptic-cone-between,
  truncated-cone: truncated-cone,
  frustum-between: frustum-between,
  tube-between: tube-between,
  sphere: sphere-surface,
  ellipsoid: ellipsoid,
  hemisphere: hemisphere,
  spherical-cap: spherical-cap,
  spherical-zone: spherical-zone,
  capsule: capsule,
  torus: torus,
)

#let lines = (
  stroke: stroke,
  preset: line-preset,
  rule: line-rule,
  dash-pattern: styles-module.dash-pattern,
)


// Smart geometry 0.5.
#let solve-constraints = constraints-module.solve
#let reactive = constraints-module.reactive
#let solve-numeric = constraints-module.solve-numeric
#let sweep = modeling-module.sweep
#let loft = modeling-module.loft
#let tube-along = modeling-module.tube-along
#let ribbon-along = modeling-module.ribbon-along
#let helix = modeling-module.helix
#let unfold = unfold-module.net

// Smart geometry 0.6: symbolic, curves, implicit modeling, CSG, materials, and technical drawing.
#let symbolic-scalar = symbolic-module.scalar
#let symbolic-formula = symbolic-module.formula
#let symbolic-volume = symbolic-module.volume
#let symbolic-surface-area = symbolic-module.surface-area
#let symbolic-diagonal = symbolic-module.diagonal
#let bezier3d = curves-module.bezier
#let cubic-bezier3d = curves-module.cubic-bezier
#let hermite3d = curves-module.hermite
#let catmull-rom3d = curves-module.catmull-rom
#let bspline3d = curves-module.bspline
#let rational-bezier3d = curves-module.rational-bezier
#let nurbs3d = curves-module.nurbs
#let curve-torsion = curves-module.torsion
#let curve3d = curves-module.model
#let curve-length = curves-module.arc-length
#let frenet-frame = curves-module.frenet-frame
#let implicit-surface = implicit-module.surface
#let csg-build = csg-module.build
#let material = materials-module.material
#let material-preset = materials-module.preset
#let apply-material = materials-module.apply
#let technical-sheet = technical-module.sheet
#let exploded-view = technical-module.explode
#let section-view = technical-module.section-view
#let technical-assembly = technical-module.assembly
#let technical-bom = technical-module.bom
#let technical-drawing-package = technical-module.drawing-package

// Projection data and frame generation.
#let project-model = projection-module.project-model
#let projected-points = projection-module.point-map
#let animation-frames = animation-module.frames
#let orbit-frames = animation-module.orbit-frames
#let translation-frames = animation-module.interpolate-translation

#let sang3d = (
  core: core-module,
  transform: transform-module,
  styles: styles-module,
  camera: camera-module,
  objects: objects-module,
  model: model-module,
  definitions: definitions-module,
  points: points-module,
  scene: scene-module,
  constructions: constructions-module,
  sections: sections-module,
  solids: solids-module,
  surfaces: surfaces-module,
  revolution: revolution-module,
  euclid: euclid-module,
  constraints: constraints-module,
  modeling: modeling-module,
  unfolding: unfold-module,
  round: round,
  lines: lines,
  sweep: sweep,
  loft: loft,
  tube-along: tube-along,
  ribbon-along: ribbon-along,
  helix: helix,
  unfold: unfold,
  reactive: reactive,
  solve-numeric: solve-numeric,
  visibility: visibility-module,
  layout: layout-module,
  projection: projection-module,
  animation: animation-module,
  symbolic: symbolic-module,
  curves: curves-module,
  implicit: implicit-module,
  csg: csg-module,
  materials: materials-module,
  textbook: textbook-module,
  technical: technical-module,
  render: render-module,
  theme: theme,
  style-rule: style-rule,
  style-matches: style-matches,
  geometry3d: geometry3d,
  figure3d: figure3d,
  point: point,
  given-point: given-point,
  derived-point: derived-point,
  point-policy: point-policy,
  declare-points: declare-points,
  point-manifest-table: point-manifest-table,
  scene3d: scene3d,
  render-model: render-model,
  draw: draw,
  render-views: render-views,
  cube: cube,
  cuboid: cuboid,
  prism: prism,
  pyramid: pyramid,
  polyhedron: polyhedron,
  cylinder: cylinder,
  cone: cone,
  sphere: sphere-surface,
  torus: torus,
  cylinder-between: cylinder-between,
  cone-between: cone-between,
  frustum-between: frustum-between,
  tube-between: tube-between,
  hemisphere: hemisphere,
  spherical-cap: spherical-cap,
  capsule: capsule,
  elliptic-cylinder-between: elliptic-cylinder-between,
  elliptic-cone-between: elliptic-cone-between,
  parametric-surface: parametric-surface,
  project-model: project-model,
  with-dimension: with-dimension,
  with-ticks: with-ticks,
  with-dihedral: with-dihedral,
  bezier3d: bezier3d,
  cubic-bezier3d: cubic-bezier3d,
  catmull-rom3d: catmull-rom3d,
  bspline3d: bspline3d,
  rational-bezier3d: rational-bezier3d,
  nurbs3d: nurbs3d,
  curve3d: curve3d,
  implicit-surface: implicit-surface,
  csg-build: csg-build,
  material: material,
  material-preset: material-preset,
  apply-material: apply-material,
  technical-sheet: technical-sheet,
  exploded-view: exploded-view,
  section-view: section-view,
  technical-assembly: technical-assembly,
  technical-bom: technical-bom,
  technical-drawing-package: technical-drawing-package,
  point-table: point-table,
  inspect-model: inspect-model,
  assert-valid: assert-valid,
  orbit-frames: orbit-frames,
)
