#import "model.typ" as models
#import "transform.typ" as transforms

#let frames(fig, matrices) = matrices.map(matrix => models.transform(fig, matrix))
#let orbit-frames(fig, count: 24, axis: (0, 0, 1), turn: 360deg, origin: (0, 0, 0)) = range(count).map(index =>
  models.transform(fig, transforms.around(transforms.rotation-axis(axis, turn * index / count), origin))
)
#let interpolate-translation(fig, start, finish, count: 12) = range(count).map(index => {
  let t = if count <= 1 { 0 } else { index / (count - 1) }
  let delta = (
    start.at(0) + (finish.at(0) - start.at(0)) * t,
    start.at(1) + (finish.at(1) - start.at(1)) * t,
    start.at(2) + (finish.at(2) - start.at(2)) * t,
  )
  models.translate(fig, delta)
})
