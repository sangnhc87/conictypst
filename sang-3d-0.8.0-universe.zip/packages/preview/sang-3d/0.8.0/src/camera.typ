#import "core.typ" as core

#let orthographic(position: (8, 7, 6), target: (0, 0, 0), up: (0, 0, 1), zoom: 1.0, name: "orthographic") = (
  kind: "orthographic", position: position, target: target, up: up, zoom: zoom, name: name,
)
#let perspective(position: (8, 7, 6), target: (0, 0, 0), up: (0, 0, 1), focal-length: 5.0, near: 0.05, zoom: 1.0, name: "perspective") = (
  kind: "perspective", position: position, target: target, up: up, focal-length: focal-length, near: near, zoom: zoom, name: name,
)
#let oblique(target: (0, 0, 0), angle: 35deg, depth-scale: 0.5, distance: 10, zoom: 1.0, name: "oblique") = (
  kind: "oblique", position: core.add3(target, (0, -distance, 0)), target: target, up: (0, 0, 1), angle: angle, depth-scale: depth-scale, zoom: zoom, name: name,
)
#let cavalier(target: (0, 0, 0), angle: 45deg, distance: 10, zoom: 1.0) = oblique(target: target, angle: angle, depth-scale: 1, distance: distance, zoom: zoom, name: "cavalier")
#let cabinet(target: (0, 0, 0), angle: 45deg, distance: 10, zoom: 1.0) = oblique(target: target, angle: angle, depth-scale: 0.5, distance: distance, zoom: zoom, name: "cabinet")

#let _perspective-camera = perspective

#let orbit(azimuth: 45deg, elevation: 30deg, target: (0, 0, 0), distance: 10, perspective: false, focal-length: 5.0, zoom: 1.0, name: "orbit") = {
  let horizontal = distance * calc.cos(elevation)
  let offset = (
    horizontal * calc.cos(azimuth),
    horizontal * calc.sin(azimuth),
    distance * calc.sin(elevation),
  )
  if perspective {
    _perspective-camera(position: core.add3(target, offset), target: target, focal-length: focal-length, zoom: zoom, name: name)
  } else {
    orthographic(position: core.add3(target, offset), target: target, zoom: zoom, name: name)
  }
}

#let isometric(target: (0, 0, 0), distance: 10, zoom: 1.0) = orbit(azimuth: 45deg, elevation: 35.264deg, target: target, distance: distance, zoom: zoom, name: "isometric")
#let dimetric(target: (0, 0, 0), distance: 10, zoom: 1.0) = orbit(azimuth: 38deg, elevation: 24deg, target: target, distance: distance, zoom: zoom, name: "dimetric")
#let front(target: (0, 0, 0), distance: 10) = orthographic(position: core.add3(target, (0, -distance, 0)), target: target, name: "front")
#let rear(target: (0, 0, 0), distance: 10) = orthographic(position: core.add3(target, (0, distance, 0)), target: target, name: "rear")
#let right(target: (0, 0, 0), distance: 10) = orthographic(position: core.add3(target, (distance, 0, 0)), target: target, name: "right")
#let left(target: (0, 0, 0), distance: 10) = orthographic(position: core.add3(target, (-distance, 0, 0)), target: target, name: "left")
#let top(target: (0, 0, 0), distance: 10) = orthographic(position: core.add3(target, (0, 0, distance)), target: target, up: (0, 1, 0), name: "top")
#let bottom(target: (0, 0, 0), distance: 10) = orthographic(position: core.add3(target, (0, 0, -distance)), target: target, up: (0, 1, 0), name: "bottom")

#let auto(
  view: "best",
  target: auto,
  distance: auto,
  perspective: false,
  focal-length: 5.0,
  zoom: 1.0,
  candidates: auto,
  prefer: "balanced",
  focus-normal: auto,
  search: "adaptive",
  candidate-count: 24,
  avoid-overlap: true,
) = (
  kind: if perspective { "perspective" } else { "orthographic" },
  auto: true,
  view: view,
  target: target,
  distance: distance,
  focal-length: focal-length,
  zoom: zoom,
  candidates: candidates,
  prefer: prefer,
  focus-normal: focus-normal,
  search: search,
  candidate-count: candidate-count,
  avoid-overlap: avoid-overlap,
  up: (0, 0, 1),
  name: "auto-" + view,
)

#let basis(cam) = {
  let forward = core.unit3(core.sub3(cam.target, cam.position), fallback: (0, 1, 0))
  let raw-right = core.cross3(forward, cam.up)
  let right = if core.norm3(raw-right) <= core.epsilon {
    core.unit3(core.cross3(forward, (0, 1, 0)), fallback: (1, 0, 0))
  } else { core.unit3(raw-right) }
  let up = core.unit3(core.cross3(right, forward), fallback: (0, 0, 1))
  (forward: forward, right: right, up: up)
}

#let view-direction(cam, point: auto) = {
  if cam.kind == "perspective" and point != auto {
    core.unit3(core.sub3(point, cam.position), fallback: basis(cam).forward)
  } else if cam.kind == "oblique" {
    core.unit3((-cam.depth-scale * calc.cos(cam.angle), 1, -cam.depth-scale * calc.sin(cam.angle)), fallback: (0, 1, 0))
  } else { basis(cam).forward }
}

#let to-camera-direction(cam, point) = if cam.kind == "perspective" {
  core.unit3(core.sub3(cam.position, point), fallback: core.neg3(view-direction(cam, point: point)))
} else { core.neg3(view-direction(cam, point: point)) }

#let project-raw(cam, point) = {
  if cam.kind == "oblique" {
    let q = core.sub3(point, cam.target)
    let recede = core.y3(q) * cam.depth-scale
    return (
      x: (core.x3(q) + recede * calc.cos(cam.angle)) * cam.zoom,
      y: (core.z3(q) + recede * calc.sin(cam.angle)) * cam.zoom,
      depth: core.distance3(cam.position, point),
      camera: (core.x3(q), core.z3(q), core.y3(q)),
    )
  }
  let frame = basis(cam)
  let q = core.sub3(point, cam.position)
  let cx = core.dot3(q, frame.right)
  let cy = core.dot3(q, frame.up)
  let cz = core.dot3(q, frame.forward)
  if cam.kind == "perspective" {
    let depth = calc.max(cam.at("near", default: 0.05), cz)
    let factor = cam.focal-length / depth * cam.zoom
    (x: cx * factor, y: cy * factor, depth: cz, camera: (cx, cy, cz))
  } else {
    (x: cx * cam.zoom, y: cy * cam.zoom, depth: cz, camera: (cx, cy, cz))
  }
}

#let _distance2(a, b) = calc.sqrt((a.at(0) - b.at(0))*(a.at(0) - b.at(0)) + (a.at(1) - b.at(1))*(a.at(1) - b.at(1)))
#let _cross2(a, b) = a.at(0) * b.at(1) - a.at(1) * b.at(0)
#let _sub2(a, b) = (a.at(0) - b.at(0), a.at(1) - b.at(1))
#let _segments-cross(a, b, c, d, tolerance: 1e-8) = {
  let r = _sub2(b, a)
  let s = _sub2(d, c)
  let denominator = _cross2(r, s)
  if calc.abs(denominator) <= tolerance { return false }
  let offset = _sub2(c, a)
  let t = _cross2(offset, s) / denominator
  let u = _cross2(offset, r) / denominator
  t > tolerance and t < 1 - tolerance and u > tolerance and u < 1 - tolerance
}

#let _candidate-score(cam, points, edges, prefer, focus-normal: auto, avoid-overlap: true) = {
  let sample-points = if points.len() > 96 { points.slice(0, 96) } else { points }
  let sample-edges = if edges.len() > 72 { edges.slice(0, 72) } else { edges }
  let projected = sample-points.map(point => project-raw(cam, point))
  if projected.len() == 0 { return 0 }
  let points2 = projected.map(point => (point.x, point.y))
  let xs = projected.map(point => point.x)
  let ys = projected.map(point => point.y)
  let span-x = calc.max(1e-8, calc.max(..xs) - calc.min(..xs))
  let span-y = calc.max(1e-8, calc.max(..ys) - calc.min(..ys))
  let diagonal = calc.sqrt(span-x*span-x + span-y*span-y)
  let area = span-x * span-y
  let projected-edges = sample-edges.map(edge => {
    let a = project-raw(cam, edge.at(0))
    let b = project-raw(cam, edge.at(1))
    (a: (a.x, a.y), b: (b.x, b.y), length: calc.sqrt((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y)))
  })
  let edge-score = if projected-edges.len() == 0 { 1 } else { projected-edges.map(edge => edge.length).sum() / projected-edges.len() }
  let short-edge-penalty = if projected-edges.len() == 0 { 0 } else {
    let threshold = calc.max(1e-8, diagonal * 0.025)
    projected-edges.map(edge => calc.max(0, threshold - edge.length)).sum() / threshold
  }
  let vertex-penalty = 0
  if avoid-overlap {
    let threshold = calc.max(1e-8, diagonal * 0.035)
    for i in range(points2.len()) {
      for j in range(i + 1, points2.len()) {
        let gap = _distance2(points2.at(i), points2.at(j))
        if gap < threshold { vertex-penalty += (threshold - gap) / threshold }
      }
    }
  }
  let crossing-penalty = 0
  if avoid-overlap {
    for i in range(projected-edges.len()) {
      for j in range(i + 1, projected-edges.len()) {
        let first = projected-edges.at(i)
        let second = projected-edges.at(j)
        let shares = _distance2(first.a, second.a) < 1e-7 or _distance2(first.a, second.b) < 1e-7 or _distance2(first.b, second.a) < 1e-7 or _distance2(first.b, second.b) < 1e-7
        if not shares and _segments-cross(first.a, first.b, second.a, second.b) { crossing-penalty += 1 }
      }
    }
  }
  let balance = calc.min(span-x, span-y) / calc.max(span-x, span-y)
  let center = core.centroid3(sample-points)
  let radius = core.bounds3(sample-points).radius
  let projected-axis-length(direction) = {
    let a = project-raw(cam, center)
    let b = project-raw(cam, core.add3(center, core.mul3(direction, calc.max(1, radius))))
    calc.sqrt((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y))
  }
  let height-score = projected-axis-length((0, 0, 1))
  let base-score = projected-axis-length((1, 0, 0)) + projected-axis-length((0, 1, 0))
  let section-score = if focus-normal == auto { balance * area } else {
    let section-basis = core.basis-from-normal(focus-normal)
    projected-axis-length(section-basis.u) * projected-axis-length(section-basis.v)
  }
  let semantic = if prefer == "wide" { span-x * 0.4 }
    else if prefer == "tall" { span-y * 0.4 }
    else if prefer == "show-height" { height-score * 2.2 }
    else if prefer == "show-base" { base-score * 1.2 }
    else if prefer == "show-section" { section-score * 1.8 }
    else { balance * area * 0.35 }
  area + edge-score + semantic - short-edge-penalty * area * 0.02 - vertex-penalty * area * 0.025 - crossing-penalty * area * 0.012
}

#let _generated-candidates(count: 24) = {
  let elevations = if count >= 48 { (16deg, 26deg, 36deg, 46deg) } else { (20deg, 32deg, 44deg) }
  let azimuth-count = calc.max(4, calc.ceil(count / elevations.len()))
  let output = ()
  for elevation in elevations {
    for index in range(azimuth-count) { output.push((360deg * index / azimuth-count + 15deg, elevation)) }
  }
  output
}

#let _view-camera(view, target, distance, perspective-mode, focal-length, zoom) = {
  if view == "front" { front(target: target, distance: distance) }
  else if view == "rear" { rear(target: target, distance: distance) }
  else if view == "right" { right(target: target, distance: distance) }
  else if view == "left" { left(target: target, distance: distance) }
  else if view == "top" { top(target: target, distance: distance) }
  else if view == "bottom" { bottom(target: target, distance: distance) }
  else if view == "dimetric" { orbit(azimuth: 38deg, elevation: 24deg, target: target, distance: distance, perspective: perspective-mode, focal-length: focal-length, zoom: zoom, name: "dimetric") }
  else { orbit(azimuth: 45deg, elevation: 35.264deg, target: target, distance: distance, perspective: perspective-mode, focal-length: focal-length, zoom: zoom, name: "isometric") }
}

#let resolve(cam, points, edges: ()) = {
  if not cam.at("auto", default: false) { return cam }
  let bounds = core.bounds3(points)
  let target = if cam.target == auto { bounds.center } else { cam.target }
  let distance = if cam.distance == auto { calc.max(8, bounds.radius * 4) } else { cam.distance }
  if cam.view != "best" {
    return _view-camera(cam.view, target, distance, cam.kind == "perspective", cam.focal-length, cam.zoom)
  }
  let candidates = if cam.candidates == auto { _generated-candidates(count: cam.at("candidate-count", default: 24)) } else { cam.candidates }
  let best = none
  let best-angle = candidates.first()
  let best-score = -1e20
  for candidate in candidates {
    let current = orbit(
      azimuth: candidate.at(0), elevation: candidate.at(1), target: target, distance: distance,
      perspective: cam.kind == "perspective", focal-length: cam.focal-length, zoom: cam.zoom, name: "auto-best",
    )
    let score = _candidate-score(
      current, points, edges, cam.prefer,
      focus-normal: cam.at("focus-normal", default: auto),
      avoid-overlap: cam.at("avoid-overlap", default: true),
    )
    if score > best-score { best = current; best-angle = candidate; best-score = score }
  }
  if cam.at("search", default: "adaptive") == "adaptive" {
    let refinements = ()
    for da in (-10deg, -5deg, 0deg, 5deg, 10deg) {
      for de in (-8deg, -4deg, 0deg, 4deg, 8deg) {
        refinements.push((best-angle.at(0) + da, core.clamp(best-angle.at(1) + de, 8deg, 78deg)))
      }
    }
    for candidate in refinements {
      let current = orbit(
        azimuth: candidate.at(0), elevation: candidate.at(1), target: target, distance: distance,
        perspective: cam.kind == "perspective", focal-length: cam.focal-length, zoom: cam.zoom, name: "auto-adaptive",
      )
      let score = _candidate-score(
        current, points, edges, cam.prefer,
        focus-normal: cam.at("focus-normal", default: auto),
        avoid-overlap: cam.at("avoid-overlap", default: true),
      )
      if score > best-score { best = current; best-score = score }
    }
  }
  best
}

#let prepare(cam, points, edges: (), width: 8.0, height: 6.2, padding: 0.10) = {
  let resolved = resolve(cam, points, edges: edges)
  let projected = points.map(point => project-raw(resolved, point))
  if projected.len() == 0 { return (: ..resolved, fit-scale: 1, fit-center: (0, 0), viewport: (width, height)) }
  let xs = projected.map(point => point.x)
  let ys = projected.map(point => point.y)
  let x-min = calc.min(..xs); let x-max = calc.max(..xs)
  let y-min = calc.min(..ys); let y-max = calc.max(..ys)
  let span-x = calc.max(1e-6, x-max - x-min)
  let span-y = calc.max(1e-6, y-max - y-min)
  let usable-width = width * (1 - 2 * padding)
  let usable-height = height * (1 - 2 * padding)
  let fit-scale = calc.min(usable-width / span-x, usable-height / span-y)
  (: ..resolved,
    fit-scale: fit-scale,
    fit-center: ((x-min + x-max) / 2, (y-min + y-max) / 2),
    viewport: (width, height),
  )
}

#let project(cam, point) = {
  let raw = project-raw(cam, point)
  let center = cam.at("fit-center", default: (0, 0))
  let scale = cam.at("fit-scale", default: 1)
  ((raw.x - center.at(0)) * scale, (raw.y - center.at(1)) * scale, raw.depth)
}

#let named(name, target: (0, 0, 0), distance: 10, zoom: 1.0, perspective-mode: false, focal-length: 5.0) = {
  if name == "front" { front(target: target, distance: distance) }
  else if name == "rear" { rear(target: target, distance: distance) }
  else if name == "right" { right(target: target, distance: distance) }
  else if name == "left" { left(target: target, distance: distance) }
  else if name == "top" { top(target: target, distance: distance) }
  else if name == "bottom" { bottom(target: target, distance: distance) }
  else if name == "dimetric" { orbit(azimuth: 38deg, elevation: 24deg, target: target, distance: distance, perspective: perspective-mode, focal-length: focal-length, zoom: zoom, name: "dimetric") }
  else if name == "cabinet" { cabinet(target: target, distance: distance, zoom: zoom) }
  else if name == "cavalier" { cavalier(target: target, distance: distance, zoom: zoom) }
  else if name == "perspective" { perspective(position: core.add3(target, (8, 7, 6)), target: target, focal-length: focal-length, zoom: zoom) }
  else { orbit(azimuth: 45deg, elevation: 35.264deg, target: target, distance: distance, perspective: perspective-mode, focal-length: focal-length, zoom: zoom, name: "isometric") }
}
