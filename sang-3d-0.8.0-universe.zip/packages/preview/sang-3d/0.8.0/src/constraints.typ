// Constructive constraint graph for reactive 3D geometry.
// Rules are resolved in dependency order; each rule creates one named point.
#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "definitions.typ" as definitions

#let _rule(kind, name, deps, compute, meta: (:)) = (
  kind: kind,
  name: name,
  deps: deps,
  compute: compute,
  meta: meta,
)

#let fixed(name, point) = _rule("fixed", name, (), _ => point)
#let alias(name, source) = _rule("alias", name, (source,), points => points.at(source))
#let midpoint(name, a, b) = _rule("midpoint", name, (a, b), points => core.midpoint3(points.at(a), points.at(b)))
#let divide(name, a, b, ratio: 0.5) = _rule("divide", name, (a, b), points => core.lerp3(points.at(a), points.at(b), ratio), meta: (ratio: ratio))
#let translated(name, source, vector) = _rule("translated", name, (source,), points => core.add3(points.at(source), vector), meta: (vector: vector))
#let centroid(name, refs) = _rule("centroid", name, refs, points => core.centroid3(refs.map(ref => points.at(ref))))

#let plane-through(a, b, c) = (kind: "constraint-plane-through", refs: (a, b, c))
#let plane-normal(point, normal) = (kind: "constraint-plane-normal", point: point, normal: normal)

#let _resolve(points, ref) = if type(ref) == str { points.at(ref) } else { ref }
#let _plane-deps(spec) = if type(spec) == dictionary and spec.at("kind", default: none) == "constraint-plane-through" { spec.refs.filter(ref => type(ref) == str) }
  else if type(spec) == dictionary and spec.at("kind", default: none) == "constraint-plane-normal" and type(spec.point) == str { (spec.point,) }
  else { () }
#let _resolve-plane(points, spec) = {
  if type(spec) == dictionary and spec.at("kind", default: none) == "constraint-plane-through" {
    return core.plane-through(..spec.refs.map(ref => _resolve(points, ref)))
  }
  if type(spec) == dictionary and spec.at("kind", default: none) == "constraint-plane-normal" {
    return core.plane(spec.normal, point: _resolve(points, spec.point))
  }
  spec
}

#let project-line(name, source, a, b) = _rule(
  "project-line", name, (source, a, b),
  points => core.project-point-line(points.at(source), core.line-through(points.at(a), points.at(b))),
)

#let project-plane(name, source, onto) = _rule(
  "project-plane", name, (source,) + _plane-deps(onto),
  points => core.project-point-plane(points.at(source), _resolve-plane(points, onto)),
)

#let intersect-line-plane(name, a, b, with-plane) = _rule(
  "line-plane-intersection", name, (a, b) + _plane-deps(with-plane),
  points => {
    let hit = core.line-plane-intersection(core.line-through(points.at(a), points.at(b)), _resolve-plane(points, with-plane))
    if hit == none { panic("sang-3d.constraints: line and plane do not meet") }
    hit.point
  },
)

#let rotated(name, source, around, angle) = {
  let deps = (source,)
  if type(around) == tuple { deps += around.filter(ref => type(ref) == str) }
  _rule("rotated", name, deps, points => {
    let ax = if type(around) == tuple {
      core.axis-through(_resolve(points, around.at(0)), _resolve(points, around.at(1)))
    } else { around }
    core.rotate-around-axis(points.at(source), ax, angle)
  }, meta: (angle: angle))
}

#let mirrored-plane(name, source, across) = _rule(
  "mirrored-plane", name, (source,) + _plane-deps(across),
  points => {
    let pl = _resolve-plane(points, across)
    let p = points.at(source)
    core.sub3(p, core.mul3(pl.normal, 2 * core.plane-value(pl, p)))
  },
)

#let on-line(name, a, b, parameter: 0.5) = divide(name, a, b, ratio: parameter)
#let on-circle(name, center, normal, radius, angle: 0deg, start-direction: auto) = _rule(
  "on-circle", name, (center,), points => {
    let frame = core.basis-from-normal(normal, preferred-u: start-direction)
    core.add3(points.at(center), core.add3(core.mul3(frame.u, radius * calc.cos(angle)), core.mul3(frame.v, radius * calc.sin(angle))))
  }, meta: (radius: radius, angle: angle),
)

#let custom(name, deps, compute, meta: (:)) = _rule("custom", name, deps, compute, meta: meta)

#let solve(
  seed: (:),
  constraints: (),
  passes: auto,
  strict: true,
  point-objects: true,
  labels: true,
  objects-list: (),
  styles: (:),
  meta: (:),
) = {
  let points = (: ..seed)
  let point-definitions = (:)
  for (name, coordinate) in seed { point-definitions.insert(name, definitions.given(coordinate, meta: (source: "constraint-seed"))) }
  let pending = constraints
  let limit = if passes == auto { calc.max(1, constraints.len() + 1) } else { passes }
  let resolved = ()
  for pass in range(limit) {
    if pending.len() == 0 { break }
    let next = ()
    let progress = false
    for rule in pending {
      let ready = rule.deps.all(dep => type(dep) != str or dep in points)
      if ready {
        let coordinate = rule.compute(points)
        points.insert(rule.name, coordinate)
        point-definitions.insert(rule.name, definitions.derived(
          rule.kind,
          deps: rule.deps.filter(dep => type(dep) == str),
          coordinate: coordinate,
          parameters: rule.meta,
          meta: (source: "constructive-constraint"),
        ))
        resolved.push(rule)
        progress = true
      } else { next.push(rule) }
    }
    pending = next
    if not progress { break }
  }
  if strict and pending.len() > 0 {
    let missing = pending.map(rule => rule.name + " <- " + repr(rule.deps.filter(dep => type(dep) == str and dep not in points)))
    panic("sang-3d.constraints: unresolved rules: " + missing.join(", "))
  }
  let generated = if point-objects {
    points.keys().map(name => objects.point(name, label: if labels { auto } else { false }, tags: ("constraint-point",)))
  } else { () }
  models.model(
    points: points,
    definitions: point-definitions,
    point-order: points.keys(),
    objects: objects-list + generated,
    styles: styles,
    meta: (: ..meta, kind: "constraint-model", resolved: resolved.map(rule => rule.name), unresolved: pending.map(rule => rule.name)),
  )
}

#let reactive = solve


// Numeric nonlinear constraints -------------------------------------------------
#let unknown(name, initial: (0, 0, 0), fixed-axes: ()) = (
  kind: "numeric-unknown",
  name: name,
  initial: initial,
  fixed-axes: fixed-axes,
)

#let _numeric(kind, deps, residual, weight: 1, meta: (:)) = (
  kind: kind,
  deps: deps,
  residual: residual,
  weight: weight,
  meta: meta,
)

#let distance-eq(a, b, value, weight: 1) = _numeric(
  "distance",
  (a, b),
  points => core.distance3(points.at(a), points.at(b)) - value,
  weight: weight,
  meta: (value: value),
)

#let coincident(a, b, weight: 1) = _numeric(
  "coincident",
  (a, b),
  points => core.distance3(points.at(a), points.at(b)),
  weight: weight,
)

#let on-plane-eq(point, plane-spec, weight: 1) = _numeric(
  "on-plane",
  (point,) + _plane-deps(plane-spec),
  points => core.plane-value(_resolve-plane(points, plane-spec), points.at(point)),
  weight: weight,
)

#let on-sphere-eq(point, center, radius, weight: 1) = _numeric(
  "on-sphere",
  (point, center),
  points => core.distance3(points.at(point), points.at(center)) - radius,
  weight: weight,
  meta: (radius: radius),
)

#let collinear-eq(a, b, c, weight: 1) = _numeric(
  "collinear",
  (a, b, c),
  points => core.norm3(core.cross3(core.sub3(points.at(b), points.at(a)), core.sub3(points.at(c), points.at(a)))),
  weight: weight,
)

#let coplanar-eq(a, b, c, d, weight: 1) = _numeric(
  "coplanar",
  (a, b, c, d),
  points => core.dot3(
    core.cross3(core.sub3(points.at(b), points.at(a)), core.sub3(points.at(c), points.at(a))),
    core.sub3(points.at(d), points.at(a)),
  ),
  weight: weight,
)

#let perpendicular-eq(a, b, c, d, weight: 1) = _numeric(
  "perpendicular",
  (a, b, c, d),
  points => core.dot3(
    core.unit3(core.sub3(points.at(b), points.at(a))),
    core.unit3(core.sub3(points.at(d), points.at(c))),
  ),
  weight: weight,
)

#let parallel-eq(a, b, c, d, weight: 1) = _numeric(
  "parallel",
  (a, b, c, d),
  points => core.norm3(core.cross3(
    core.unit3(core.sub3(points.at(b), points.at(a))),
    core.unit3(core.sub3(points.at(d), points.at(c))),
  )),
  weight: weight,
)

#let angle-eq(a, vertex, b, value, weight: 1) = _numeric(
  "angle",
  (a, vertex, b),
  points => (core.angle-between3(
    core.sub3(points.at(a), points.at(vertex)),
    core.sub3(points.at(b), points.at(vertex)),
  ) - value) / 1rad,
  weight: weight,
  meta: (value: value),
)

#let equal-distance(a, b, c, d, weight: 1) = _numeric(
  "equal-distance",
  (a, b, c, d),
  points => core.distance3(points.at(a), points.at(b)) - core.distance3(points.at(c), points.at(d)),
  weight: weight,
)

#let numeric-custom(deps, residual, weight: 1, kind: "custom-numeric", meta: (:)) = _numeric(kind, deps, residual, weight: weight, meta: meta)

#let _objective(points, equations) = {
  let total = 0
  for equation in equations {
    let value = equation.residual(points)
    if type(value) == array {
      for component in value { total += equation.weight * component * component }
    } else { total += equation.weight * value * value }
  }
  total
}

#let _axis-coordinate(point, axis) = point.at(axis)
#let _replace-axis(point, axis, value) = if axis == 0 { (value, point.at(1), point.at(2)) }
  else if axis == 1 { (point.at(0), value, point.at(2)) }
  else { (point.at(0), point.at(1), value) }

#let solve-numeric(
  seed: (:),
  unknowns: (),
  equations: (),
  iterations: 160,
  tolerance: 1e-8,
  step: 1e-4,
  learning-rate: 0.18,
  damping: 0.995,
  strict: true,
  point-objects: true,
  labels: true,
  objects-list: (),
  styles: (:),
  meta: (:),
) = {
  let points = (: ..seed)
  for item in unknowns { points.insert(item.name, item.initial) }
  for equation in equations {
    for dep in equation.deps { if dep not in points { panic("sang-3d.constraints.solve-numeric: missing point " + dep) } }
  }
  let rate = learning-rate
  let previous = _objective(points, equations)
  let completed = 0
  for iteration in range(iterations) {
    completed = iteration + 1
    if previous <= tolerance { break }
    let gradients = (:)
    for item in unknowns {
      let point = points.at(item.name)
      let gradient = (0, 0, 0)
      for axis in range(3) {
        if not item.fixed-axes.contains(axis) {
          let plus-points = (: ..points)
          let minus-points = (: ..points)
          plus-points.insert(item.name, _replace-axis(point, axis, _axis-coordinate(point, axis) + step))
          minus-points.insert(item.name, _replace-axis(point, axis, _axis-coordinate(point, axis) - step))
          let derivative = (_objective(plus-points, equations) - _objective(minus-points, equations)) / (2 * step)
          gradient = _replace-axis(gradient, axis, derivative)
        }
      }
      gradients.insert(item.name, gradient)
    }
    let candidate = (: ..points)
    for item in unknowns {
      candidate.insert(item.name, core.sub3(points.at(item.name), core.mul3(gradients.at(item.name), rate)))
    }
    let score = _objective(candidate, equations)
    if score <= previous {
      points = candidate
      previous = score
      rate *= damping
    } else {
      rate *= 0.5
    }
  }
  if strict and previous > tolerance { panic("sang-3d.constraints.solve-numeric: did not converge; objective=" + str(previous)) }
  let registry = (:)
  let unknown-names = unknowns.map(item => item.name)
  for (name, coordinate) in seed { registry.insert(name, definitions.given(coordinate, meta: (source: "numeric-seed"))) }
  for item in unknowns {
    let deps = ()
    for equation in equations.filter(eq => eq.deps.contains(item.name)) {
      for dep in equation.deps {
        if dep != item.name and not unknown-names.contains(dep) and not deps.contains(dep) { deps.push(dep) }
      }
    }
    registry.insert(item.name, definitions.derived(
      "numeric-solved",
      deps: deps,
      coordinate: points.at(item.name),
      parameters: (iterations: completed, objective: previous),
      meta: (
        equations: equations.filter(eq => eq.deps.contains(item.name)).map(eq => eq.kind),
        coupled-unknowns: equations.filter(eq => eq.deps.contains(item.name)).map(eq => eq.deps.filter(dep => unknown-names.contains(dep) and dep != item.name)).flatten(),
      ),
    ))
  }
  let generated = if point-objects { points.keys().map(name => objects.point(name, label: if labels { auto } else { false }, tags: ("numeric-point",))) } else { () }
  models.model(
    points: points,
    definitions: registry,
    point-order: points.keys(),
    objects: objects-list + generated,
    styles: styles,
    meta: (: ..meta, kind: "numeric-constraint-model", objective: previous, iterations: completed, converged: previous <= tolerance),
  )
}
