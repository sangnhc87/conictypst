#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "definitions.typ" as definitions

#let resolve(fig, ref) = if type(ref) == str { fig.points.at(ref) } else { ref }

#let _require-ref(value, context) = {
  if type(value) != str { panic("sang-3d." + context + ": expected a previously declared point name") }
  value
}

#let add-point(fig, name, coordinate, definition: auto, label: auto, point: true, role: "main", tags: (), options: (:)) = {
  let actual-definition = if definition == auto { definitions.given(coordinate, label: label, meta: (source: "add-point")) } else { definition }
  let output = models.with-point(fig, name, coordinate, definition: actual-definition)
  output = models.with-object(output, objects.point(name, label: label, point: point, role: role, tags: tags))
  if options.len() > 0 { output = models.with-point-option(output, name, options) }
  output
}

#let with-segment(fig, a, b, id: none, role: "main", tags: (), stroke: auto, mark: none, visibility: auto) = models.with-object(
  fig, objects.segment(_require-ref(a, "with-segment"), _require-ref(b, "with-segment"), id: id, role: role, tags: tags, stroke: stroke, mark: mark, visibility: visibility),
)
#let with-vector(fig, a, b, id: none, role: "accent", tags: (), stroke: auto, mark: (end: ">"), visibility: auto) = models.with-object(
  fig, objects.vector(_require-ref(a, "with-vector"), _require-ref(b, "with-vector"), id: id, role: role, tags: tags, stroke: stroke, mark: mark, visibility: visibility),
)
#let with-line(fig, a, b, extent: (-5, 5), id: none, names: auto, role: "construction", tags: (), mark: none) = {
  if type(a) != str or type(b) != str { panic("sang-3d.with-line: a and b must be names of declared points") }
  let line = core.line-through(resolve(fig, a), resolve(fig, b))
  let stem = if id == none { "line-" + a + "-" + b } else { id }
  let actual-names = if names == auto { (stem + "-start", stem + "-end") } else { names }
  let start-coordinate = core.line-point(line, extent.at(0))
  let end-coordinate = core.line-point(line, extent.at(1))
  let output = add-point(fig, actual-names.at(0), start-coordinate, definition: definitions.derived("line-extension-point", deps: (a, b), coordinate: start-coordinate, parameters: (parameter: extent.at(0),)), point: false)
  output = add-point(output, actual-names.at(1), end-coordinate, definition: definitions.derived("line-extension-point", deps: (a, b), coordinate: end-coordinate, parameters: (parameter: extent.at(1),)), point: false)
  with-segment(output, actual-names.at(0), actual-names.at(1), id: id, role: role, tags: tags + ("line",), mark: mark, visibility: "always")
}

#let midpoint(fig, name, a, b, label: auto, point: true, role: "main", tags: ()) = {
  let coordinate = core.midpoint3(resolve(fig, a), resolve(fig, b))
  add-point(fig, name, coordinate, definition: definitions.midpoint(a, b, coordinate: coordinate), label: label, point: point, role: role, tags: tags + ("midpoint",))
}
#let divide(fig, name, a, b, ratio: 0.5, label: auto, point: true, role: "main", tags: ()) = {
  let coordinate = core.lerp3(resolve(fig, a), resolve(fig, b), ratio)
  add-point(fig, name, coordinate, definition: definitions.division(a, b, ratio, coordinate: coordinate), label: label, point: point, role: role, tags: tags + ("division",))
}
#let centroid(fig, name, refs, label: auto, point: true, role: "main", tags: ()) = {
  let coordinate = core.centroid3(refs.map(ref => resolve(fig, ref)))
  add-point(fig, name, coordinate, definition: definitions.centroid(refs, coordinate: coordinate), label: label, point: point, role: role, tags: tags + ("centroid",))
}
#let translated-point(fig, name, source, delta, label: auto, point: true, role: "main", tags: ()) = {
  let coordinate = core.add3(resolve(fig, source), delta)
  add-point(fig, name, coordinate, definition: definitions.derived("translated", deps: (source,), coordinate: coordinate, parameters: (delta: delta)), label: label, point: point, role: role, tags: tags + ("translated",))
}

#let project-on-line(fig, name, point, a, b, label: auto, point-marker: true, role: "construction", tags: (), draw-perpendicular: true) = {
  let foot = core.project-point-line(resolve(fig, point), core.line-through(resolve(fig, a), resolve(fig, b)))
  let output = add-point(fig, name, foot, definition: definitions.projection(point, (a, b), coordinate: foot, kind: "projection-on-line"), label: label, point: point-marker, role: role, tags: tags + ("projection",))
  if draw-perpendicular { output = with-segment(output, point, name, role: role, tags: tags + ("perpendicular",)) }
  output
}

#let project-on-plane(fig, name, point, pl, label: auto, point-marker: true, role: "construction", tags: (), draw-perpendicular: true) = {
  let foot = core.project-point-plane(resolve(fig, point), pl)
  let output = add-point(fig, name, foot, definition: definitions.derived("projection-on-plane", deps: (point,), coordinate: foot, parameters: (plane: pl,)), label: label, point: point-marker, role: role, tags: tags + ("projection",))
  if draw-perpendicular { output = with-segment(output, point, name, role: role, tags: tags + ("perpendicular",)) }
  output
}

#let intersect-line-plane(fig, name, a, b, pl, label: auto, point: true, role: "accent", tags: ()) = {
  let hit = core.line-plane-intersection(core.line-through(resolve(fig, a), resolve(fig, b)), pl)
  if hit == none { return (model: fig, point: none) }
  (model: add-point(fig, name, hit.point, definition: definitions.intersection((a, b), coordinate: hit.point, kind: "line-plane-intersection", parameters: (plane: pl,)), label: label, point: point, role: role, tags: tags + ("intersection",)), point: hit.point)
}

#let with-angle(fig, origin, a, b, radius: 0.55, label: none, id: none, role: "accent", tags: (), options: (:)) = models.with-object(
  fig, objects.angle3d(_require-ref(origin, "with-angle"), _require-ref(a, "with-angle"), _require-ref(b, "with-angle"), radius: radius, label: label, id: id, role: role, tags: tags, options: options),
)
#let with-right-angle(fig, origin, a, b, size: 0.35, id: none, role: "accent", tags: ()) = models.with-object(
  fig, objects.right-angle3d(_require-ref(origin, "with-right-angle"), _require-ref(a, "with-right-angle"), _require-ref(b, "with-right-angle"), size: size, id: id, role: role, tags: tags),
)
#let with-circle(fig, center, radius, normal: (0, 0, 1), id: none, role: "main", tags: (), stroke: auto, fill: none, segments: 72) = models.with-object(
  fig, objects.circle3d(_require-ref(center, "with-circle"), radius, normal: normal, id: id, role: role, tags: tags, stroke: stroke, fill: fill, segments: segments),
)
#let with-plane(fig, center, normal, width: 4, height: 3, id: none, role: "auxiliary", tags: (), fill: auto, stroke: auto, grid: none, u: auto) = models.with-object(
  fig, objects.plane-patch(_require-ref(center, "with-plane"), normal, width: width, height: height, id: id, role: role, tags: tags, fill: fill, stroke: stroke, grid: grid, u: u),
)

#let axes(length: 3, origin: (0, 0, 0), origin-name: "O", labels: ($x$, $y$, $z$), role: "axis", negative: 0, mark: (end: ">")) = {
  let points = (:)
  let registry = (:)
  let options = (:)
  let order = (origin-name,)
  points.insert(origin-name, origin)
  registry.insert(origin-name, definitions.given(origin, label: $O$, meta: (source: "axes-origin")))
  options.insert(origin-name, (label-content: $O$, show-point: true, show-label: false, role: role))
  let items = ()
  let directions = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
  let ids = ("x-axis", "y-axis", "z-axis")
  let letters = ("X", "Y", "Z")
  for i in range(3) {
    let direction = directions.at(i)
    let a-name = letters.at(i) + "-"
    let b-name = letters.at(i) + "+"
    let a = core.add3(origin, core.mul3(direction, -negative))
    let b = core.add3(origin, core.mul3(direction, length))
    points.insert(a-name, a)
    points.insert(b-name, b)
    registry.insert(a-name, definitions.derived("axis-endpoint", deps: (origin-name,), coordinate: a, parameters: (axis: ids.at(i), direction: "negative", distance: negative)))
    registry.insert(b-name, definitions.derived("axis-endpoint", deps: (origin-name,), coordinate: b, parameters: (axis: ids.at(i), direction: "positive", distance: length)))
    options.insert(a-name, (show-point: false, show-label: false, role: role))
    options.insert(b-name, (label-content: if labels == none { auto } else { labels.at(i) }, show-point: false, show-label: labels != none, role: role))
    order += (a-name, b-name)
    items.push(objects.segment(a-name, b-name, id: ids.at(i), role: role, tags: ("axis",), mark: mark, visibility: "always"))
    if labels != none { items.push(objects.label(b-name, labels.at(i), offset: (0.16, 0.16), role: role, tags: ("axis-label",))) }
  }
  models.model(points: points, definitions: registry, point-options: options, point-order: order, objects: items, meta: (kind: "axes3d"))
}

#let distance(fig, a, b) = core.distance3(resolve(fig, a), resolve(fig, b))
#let angle(fig, origin, a, b) = core.angle-between3(core.sub3(resolve(fig, a), resolve(fig, origin)), core.sub3(resolve(fig, b), resolve(fig, origin)))

#let intersect-planes(a, b) = core.plane-plane-intersection(a, b)
#let closest-lines(a, b, tolerance: 1e-7) = core.line-line-closest(a, b, tolerance: tolerance)

#let with-dimension(fig, a, b, offset: (0, 0, 0), label: auto, id: none, role: "dimension", tags: (), mark: auto, extension: true, options: (:)) = models.with-object(
  fig, objects.dimension3d(_require-ref(a, "with-dimension"), _require-ref(b, "with-dimension"), offset: offset, label: label, id: id, role: role, tags: tags, mark: mark, extension: extension, options: options),
)
#let with-ticks(fig, a, b, count: 1, size: auto, normal: auto, position: 0.5, spacing: 0.12, id: none, role: "annotation", tags: (), options: (:)) = models.with-object(
  fig, objects.ticks3d(_require-ref(a, "with-ticks"), _require-ref(b, "with-ticks"), count: count, size: size, normal: normal, position: position, spacing: spacing, id: id, role: role, tags: tags, options: options),
)
#let with-dihedral(fig, origin, edge-direction, normal-a, normal-b, radius: 0.6, label: none, id: none, role: "annotation", tags: (), options: (:)) = models.with-object(
  fig, objects.dihedral3d(_require-ref(origin, "with-dihedral"), edge-direction, normal-a, normal-b, radius: radius, label: label, id: id, role: role, tags: tags, options: options),
)

#let line-line-distance(a, b) = core.line-line-distance(a, b)
#let line-line-angle(a, b) = core.angle-line-line(a, b)
#let line-plane-angle(line, plane) = core.angle-line-plane(line, plane)
#let plane-plane-angle(a, b) = core.angle-plane-plane(a, b)
