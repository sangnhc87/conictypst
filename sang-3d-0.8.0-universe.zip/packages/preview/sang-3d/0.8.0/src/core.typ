// sang-3d numeric kernel. This module intentionally has no CeTZ dependency.

#let epsilon = 1e-8
#let clamp(value, low, high) = calc.max(low, calc.min(high, value))
#let approx(a, b, tolerance: 1e-7) = calc.abs(a - b) <= tolerance

#let vec3(x, y, z) = (x, y, z)
#let x3(v) = v.at(0)
#let y3(v) = v.at(1)
#let z3(v) = v.at(2)
#let add3(a, b) = (x3(a) + x3(b), y3(a) + y3(b), z3(a) + z3(b))
#let sub3(a, b) = (x3(a) - x3(b), y3(a) - y3(b), z3(a) - z3(b))
#let neg3(v) = (-x3(v), -y3(v), -z3(v))
#let mul3(v, scalar) = (x3(v) * scalar, y3(v) * scalar, z3(v) * scalar)
#let div3(v, scalar) = if calc.abs(scalar) <= epsilon {
  panic("sang-3d: division by zero")
} else { mul3(v, 1 / scalar) }
#let hadamard3(a, b) = (x3(a) * x3(b), y3(a) * y3(b), z3(a) * z3(b))
#let dot3(a, b) = x3(a) * x3(b) + y3(a) * y3(b) + z3(a) * z3(b)
#let cross3(a, b) = (
  y3(a) * z3(b) - z3(a) * y3(b),
  z3(a) * x3(b) - x3(a) * z3(b),
  x3(a) * y3(b) - y3(a) * x3(b),
)
#let norm3(v) = calc.sqrt(dot3(v, v))
#let distance3(a, b) = norm3(sub3(a, b))
#let unit3(v, fallback: (1, 0, 0)) = {
  let length = norm3(v)
  if length <= epsilon { fallback } else { div3(v, length) }
}
#let almost-equal3(a, b, tolerance: 1e-7) = distance3(a, b) <= tolerance
#let midpoint3(a, b) = mul3(add3(a, b), 0.5)
#let lerp3(a, b, t) = add3(a, mul3(sub3(b, a), t))
#let angle-between3(a, b) = {
  let denominator = norm3(a) * norm3(b)
  if denominator <= epsilon { 0deg } else {
    calc.acos(clamp(dot3(a, b) / denominator, -1, 1))
  }
}
#let reflect3(v, normal) = sub3(v, mul3(unit3(normal), 2 * dot3(v, unit3(normal))))

#let centroid3(points) = {
  if points.len() == 0 { return (0, 0, 0) }
  let total = (0, 0, 0)
  for point in points { total = add3(total, point) }
  div3(total, points.len())
}

#let polygon-normal(points) = {
  if points.len() < 3 { return (0, 0, 0) }
  // Newell's method works for arbitrary planar polygons.
  let normal = (0, 0, 0)
  for i in range(points.len()) {
    let a = points.at(i)
    let b = points.at(calc.rem-euclid(i + 1, points.len()))
    normal = add3(normal, (
      (y3(a) - y3(b)) * (z3(a) + z3(b)),
      (z3(a) - z3(b)) * (x3(a) + x3(b)),
      (x3(a) - x3(b)) * (y3(a) + y3(b)),
    ))
  }
  unit3(normal, fallback: (0, 0, 0))
}

#let polygon-area3(points) = {
  if points.len() < 3 { return 0 }
  let origin = points.first()
  let area = 0
  for i in range(1, points.len() - 1) {
    area += norm3(cross3(sub3(points.at(i), origin), sub3(points.at(i + 1), origin))) / 2
  }
  area
}

#let bounds3(points) = {
  if points.len() == 0 {
    return (min: (0, 0, 0), max: (0, 0, 0), center: (0, 0, 0), size: (0, 0, 0), radius: 0)
  }
  let low = points.first()
  let high = points.first()
  for point in points.slice(1) {
    low = (calc.min(x3(low), x3(point)), calc.min(y3(low), y3(point)), calc.min(z3(low), z3(point)))
    high = (calc.max(x3(high), x3(point)), calc.max(y3(high), y3(point)), calc.max(z3(high), z3(point)))
  }
  let center = midpoint3(low, high)
  (min: low, max: high, center: center, size: sub3(high, low), radius: distance3(low, high) / 2)
}

#let orthogonal3(normal) = {
  let n = unit3(normal, fallback: (0, 0, 1))
  let helper = if calc.abs(z3(n)) < 0.85 { (0, 0, 1) } else { (0, 1, 0) }
  unit3(cross3(helper, n), fallback: (1, 0, 0))
}

#let basis-from-normal(normal, preferred-u: auto) = {
  let n = unit3(normal, fallback: (0, 0, 1))
  let raw-u = if preferred-u == auto { orthogonal3(n) } else {
    sub3(preferred-u, mul3(n, dot3(preferred-u, n)))
  }
  let u = unit3(raw-u, fallback: orthogonal3(n))
  let v = unit3(cross3(n, u), fallback: (0, 1, 0))
  (u: u, v: v, normal: n)
}

#let rotate-x(p, angle, origin: (0, 0, 0)) = {
  let q = sub3(p, origin)
  let c = calc.cos(angle)
  let s = calc.sin(angle)
  add3(origin, (x3(q), y3(q) * c - z3(q) * s, y3(q) * s + z3(q) * c))
}
#let rotate-y(p, angle, origin: (0, 0, 0)) = {
  let q = sub3(p, origin)
  let c = calc.cos(angle)
  let s = calc.sin(angle)
  add3(origin, (x3(q) * c + z3(q) * s, y3(q), -x3(q) * s + z3(q) * c))
}
#let rotate-z(p, angle, origin: (0, 0, 0)) = {
  let q = sub3(p, origin)
  let c = calc.cos(angle)
  let s = calc.sin(angle)
  add3(origin, (x3(q) * c - y3(q) * s, x3(q) * s + y3(q) * c, z3(q)))
}

#let line(point, direction, id: none) = (
  kind: "line3d", id: id, point: point, direction: unit3(direction),
)
#let line-through(a, b, id: none) = line(a, sub3(b, a), id: id)
#let ray(origin, direction, id: none) = (
  kind: "ray3d", id: id, origin: origin, direction: unit3(direction),
)
#let plane(normal, point: (0, 0, 0), id: none) = {
  let n = unit3(normal, fallback: (0, 0, 1))
  (kind: "plane3d", id: id, normal: n, point: point, d: -dot3(n, point))
}
#let plane-through(a, b, c, id: none) = plane(cross3(sub3(b, a), sub3(c, a)), point: a, id: id)
#let sphere(center, radius, id: none) = (kind: "sphere3d", id: id, center: center, radius: radius)

#let line-point(ln, t) = add3(ln.point, mul3(ln.direction, t))
#let plane-value(pl, point) = dot3(pl.normal, point) + pl.d
#let project-point-plane(point, pl) = sub3(point, mul3(pl.normal, plane-value(pl, point)))
#let project-point-line(point, ln) = line-point(ln, dot3(sub3(point, ln.point), ln.direction))
#let distance-point-line(point, ln) = distance3(point, project-point-line(point, ln))
#let distance-point-plane(point, pl) = calc.abs(plane-value(pl, point))

#let line-plane-intersection(ln, pl, tolerance: 1e-7) = {
  let denominator = dot3(pl.normal, ln.direction)
  if calc.abs(denominator) <= tolerance { return none }
  let t = -(dot3(pl.normal, ln.point) + pl.d) / denominator
  (point: line-point(ln, t), parameter: t)
}

#let segment-plane-intersection(a, b, pl, tolerance: 1e-7) = {
  let da = plane-value(pl, a)
  let db = plane-value(pl, b)
  if calc.abs(da) <= tolerance and calc.abs(db) <= tolerance { return none }
  if (da > tolerance and db > tolerance) or (da < -tolerance and db < -tolerance) { return none }
  let denominator = da - db
  if calc.abs(denominator) <= tolerance { return none }
  let t = da / denominator
  if t < -tolerance or t > 1 + tolerance { none } else {
    lerp3(a, b, clamp(t, 0, 1))
  }
}

#let plane-plane-intersection(a, b, tolerance: 1e-7) = {
  let direction = cross3(a.normal, b.normal)
  let denominator = dot3(direction, direction)
  if denominator <= tolerance { return none }
  // Point on the intersection line derived from the two plane equations.
  let point = div3(
    add3(mul3(cross3(direction, b.normal), a.d), mul3(cross3(a.normal, direction), b.d)),
    denominator,
  )
  line(point, direction)
}

#let segment-sphere-intersections(a, b, sph, tolerance: 1e-7) = {
  let direction = sub3(b, a)
  let offset = sub3(a, sph.center)
  let qa = dot3(direction, direction)
  let qb = 2 * dot3(offset, direction)
  let qc = dot3(offset, offset) - sph.radius * sph.radius
  let discriminant = qb * qb - 4 * qa * qc
  if qa <= tolerance or discriminant < -tolerance { return () }
  let root = calc.sqrt(calc.max(0, discriminant))
  let ts = if root <= tolerance { (-qb / (2 * qa),) } else {
    ((-qb - root) / (2 * qa), (-qb + root) / (2 * qa))
  }
  ts.filter(t => t >= -tolerance and t <= 1 + tolerance).map(t => lerp3(a, b, clamp(t, 0, 1)))
}

#let unique-points3(points, tolerance: 1e-6) = {
  let output = ()
  for point in points {
    if not output.any(other => distance3(point, other) <= tolerance) { output.push(point) }
  }
  output
}

#let sort-points-on-plane(points, pl) = {
  if points.len() <= 2 { return points }
  let center = centroid3(points)
  let basis = basis-from-normal(pl.normal)
  points.sorted(key: point => {
    let q = sub3(point, center)
    calc.atan2(dot3(q, basis.u), dot3(q, basis.v))
  })
}

// Analytic 3D geometry helpers.
#let line-line-closest(a, b, tolerance: 1e-7) = {
  let u = unit3(a.direction)
  let v = unit3(b.direction)
  let w = sub3(a.point, b.point)
  let aa = dot3(u, u)
  let bb = dot3(u, v)
  let cc = dot3(v, v)
  let dd = dot3(u, w)
  let ee = dot3(v, w)
  let denominator = aa * cc - bb * bb
  if calc.abs(denominator) <= tolerance {
    let point-a = a.point
    let point-b = project-point-line(point-a, b)
    return (parallel: true, point-a: point-a, point-b: point-b, parameter-a: 0, parameter-b: dot3(sub3(point-a, b.point), v), distance: distance3(point-a, point-b))
  }
  let ta = (bb * ee - cc * dd) / denominator
  let tb = (aa * ee - bb * dd) / denominator
  let point-a = line-point(a, ta)
  let point-b = line-point(b, tb)
  (parallel: false, point-a: point-a, point-b: point-b, parameter-a: ta, parameter-b: tb, distance: distance3(point-a, point-b))
}

#let line-line-distance(a, b, tolerance: 1e-7) = line-line-closest(a, b, tolerance: tolerance).distance
#let angle-line-line(a, b) = angle-between3(a.direction, b.direction)
#let acute-angle(angle) = if angle > 90deg { 180deg - angle } else { angle }
#let angle-line-plane(ln, pl) = 90deg - acute-angle(angle-between3(ln.direction, pl.normal))
#let angle-plane-plane(a, b) = acute-angle(angle-between3(a.normal, b.normal))

#let line-sphere-intersections(ln, sph, tolerance: 1e-7) = {
  let offset = sub3(ln.point, sph.center)
  let qa = dot3(ln.direction, ln.direction)
  let qb = 2 * dot3(offset, ln.direction)
  let qc = dot3(offset, offset) - sph.radius * sph.radius
  let discriminant = qb * qb - 4 * qa * qc
  if qa <= tolerance or discriminant < -tolerance { return () }
  let root = calc.sqrt(calc.max(0, discriminant))
  let ts = if root <= tolerance { (-qb / (2 * qa),) } else {
    ((-qb - root) / (2 * qa), (-qb + root) / (2 * qa))
  }
  ts.map(t => (point: line-point(ln, t), parameter: t))
}

#let sphere-plane-intersection(sph, pl, tolerance: 1e-7) = {
  let signed = plane-value(pl, sph.center)
  let distance = calc.abs(signed)
  if distance > sph.radius + tolerance { return none }
  let center = sub3(sph.center, mul3(pl.normal, signed))
  let radius = calc.sqrt(calc.max(0, sph.radius * sph.radius - distance * distance))
  (kind: "circle3d", center: center, normal: pl.normal, radius: radius, tangent: radius <= tolerance)
}

#let closest-point-segment(point, a, b) = {
  let direction = sub3(b, a)
  let denominator = dot3(direction, direction)
  if denominator <= epsilon { return (point: a, parameter: 0, distance: distance3(point, a)) }
  let t = clamp(dot3(sub3(point, a), direction) / denominator, 0, 1)
  let closest = lerp3(a, b, t)
  (point: closest, parameter: t, distance: distance3(point, closest))
}

#let signed-volume6(a, b, c, d) = dot3(sub3(b, a), cross3(sub3(c, a), sub3(d, a)))
#let coplanar(a, b, c, d, tolerance: 1e-7) = calc.abs(signed-volume6(a, b, c, d)) <= tolerance

// Oriented axes and rotation around an arbitrary 3D line.
#let axis(point: (0, 0, 0), direction: (0, 0, 1), id: none) = (
  kind: "axis3d",
  id: id,
  point: point,
  direction: unit3(direction, fallback: (0, 0, 1)),
)
#let axis-through(a, b, id: none) = axis(point: a, direction: sub3(b, a), id: id)
#let axis-line(value) = if value.kind == "axis3d" {
  line(value.point, value.direction, id: value.id)
} else { value }
#let axis-point(value) = if value.kind == "axis3d" { value.point } else { value.point }
#let axis-direction(value) = if value.kind == "axis3d" { value.direction } else { value.direction }

#let rotate-around-axis(point, ax, angle) = {
  let origin = axis-point(ax)
  let direction = unit3(axis-direction(ax), fallback: (0, 0, 1))
  let q = sub3(point, origin)
  let c = calc.cos(angle)
  let s = calc.sin(angle)
  // Rodrigues' formula around the line origin + t * direction.
  add3(origin, add3(
    add3(mul3(q, c), mul3(cross3(direction, q), s)),
    mul3(direction, dot3(direction, q) * (1 - c)),
  ))
}
#let rotate-vector-axis(vector, ax, angle) = {
  let direction = unit3(axis-direction(ax), fallback: (0, 0, 1))
  let c = calc.cos(angle)
  let s = calc.sin(angle)
  add3(
    add3(mul3(vector, c), mul3(cross3(direction, vector), s)),
    mul3(direction, dot3(direction, vector) * (1 - c)),
  )
}
#let orbit-radius(point, ax) = distance-point-line(point, axis-line(ax))
#let orbit-center(point, ax) = project-point-line(point, axis-line(ax))
#let orbit-point(point, ax, angle) = rotate-around-axis(point, ax, angle)
