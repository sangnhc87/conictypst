// Signed-distance field primitives and constructive solid geometry.
#import "core.typ" as core
#import "implicit.typ" as implicit
#import "points.typ" as point-declarations

#let field(function, bounds, name: "field", meta: (:), control-points: ()) = (
  kind: "sang-3d-field",
  function: function,
  bounds: bounds,
  name: name,
  meta: meta,
  control-points: control-points,
)

#let value(shape, point) = shape.function(point)
#let _controls(shapes) = {
  // Boolean trees can mention the same primitive more than once (for example
  // XOR expands to two subtract nodes). Keep one public declaration per name,
  // but never rename conflicting declarations silently.
  let output = ()
  let seen = (:)
  for shape in shapes {
    for declaration in shape.at("control-points", default: ()) {
      let name = declaration.name
      if name in seen {
        let previous = seen.at(name)
        if not core.almost-equal3(previous.coordinate, declaration.coordinate) {
          panic("sang-3d.csg: control point " + name + " is declared twice with different coordinates; give every primitive a unique id")
        }
      } else {
        seen.insert(name, declaration)
        output.push(declaration)
      }
    }
  }
  output
}
#let _control-name(id, suffix) = id + "-" + suffix
#let _control(declaration, fallback-name, coordinate, kind, parameters: (:), label: auto, label-position: auto) = if declaration == auto {
  point-declarations.derived(fallback-name, coordinate, kind, parameters: parameters, label: label, label-position: label-position, show-point: false, show-label: label != auto)
} else { declaration }
#let _mapped-controls(shape, operation, transform, suffix) = {
  let output = ()
  for declaration in shape.at("control-points", default: ()) {
    let options = declaration.options
    output.push(point-declarations.point(
      declaration.name + "-" + suffix,
      transform(declaration.coordinate),
      definition: (
        kind: "transformed-control-point",
        deps: (),
        coordinate: transform(declaration.coordinate),
        parameters: (source-name: declaration.name, operation: operation),
        meta: (source-definition: declaration.definition),
      ),
      label: options.at("label-content", default: auto),
      label-position: options.at("label-position", default: auto),
      label-distance: options.at("label-distance", default: auto),
      show-point: options.at("show-point", default: false),
      show-label: options.at("show-label", default: false),
      role: options.at("role", default: "main"),
      style: options.at("style", default: (:)),
    ))
  }
  output
}
#let _merge-bounds(a, b) = (
  (calc.min(a.at(0).at(0), b.at(0).at(0)), calc.max(a.at(0).at(1), b.at(0).at(1))),
  (calc.min(a.at(1).at(0), b.at(1).at(0)), calc.max(a.at(1).at(1), b.at(1).at(1))),
  (calc.min(a.at(2).at(0), b.at(2).at(0)), calc.max(a.at(2).at(1), b.at(2).at(1))),
)
#let _intersect-bounds(a, b) = (
  (calc.max(a.at(0).at(0), b.at(0).at(0)), calc.min(a.at(0).at(1), b.at(0).at(1))),
  (calc.max(a.at(1).at(0), b.at(1).at(0)), calc.min(a.at(1).at(1), b.at(1).at(1))),
  (calc.max(a.at(2).at(0), b.at(2).at(0)), calc.min(a.at(2).at(1), b.at(2).at(1))),
)

#let sphere(center: (0, 0, 0), radius: 1, id: "sphere", center-point: auto) = {
  let cdecl = _control(center-point, _control-name(id, "center"), center, "csg-sphere-center", parameters: (radius: radius, primitive: id))
  let c = cdecl.coordinate
  field(
    point => core.distance3(point, c) - radius,
    ((core.x3(c) - radius, core.x3(c) + radius), (core.y3(c) - radius, core.y3(c) + radius), (core.z3(c) - radius, core.z3(c) + radius)),
    name: id,
    meta: (primitive: "sphere", center: c, radius: radius, center-name: cdecl.name),
    control-points: (cdecl,),
  )
}

#let box(center: (0, 0, 0), size: (2, 2, 2), id: "box", center-point: auto) = {
  let cdecl = _control(center-point, _control-name(id, "center"), center, "csg-box-center", parameters: (size: size, primitive: id))
  let c = cdecl.coordinate
  let half = core.mul3(size, 0.5)
  field(
    point => {
      let q = (
        calc.abs(core.x3(point) - core.x3(c)) - core.x3(half),
        calc.abs(core.y3(point) - core.y3(c)) - core.y3(half),
        calc.abs(core.z3(point) - core.z3(c)) - core.z3(half),
      )
      let outside = core.norm3((calc.max(core.x3(q), 0), calc.max(core.y3(q), 0), calc.max(core.z3(q), 0)))
      outside + calc.min(calc.max(core.x3(q), core.y3(q), core.z3(q)), 0)
    },
    ((core.x3(c) - core.x3(half), core.x3(c) + core.x3(half)), (core.y3(c) - core.y3(half), core.y3(c) + core.y3(half)), (core.z3(c) - core.z3(half), core.z3(c) + core.z3(half))),
    name: id,
    meta: (primitive: "box", center: c, size: size, center-name: cdecl.name),
    control-points: (cdecl,),
  )
}

#let cylinder(a: (0, 0, -1), b: (0, 0, 1), radius: 1, id: "cylinder", a-point: auto, b-point: auto) = {
  let adecl = _control(a-point, _control-name(id, "A"), a, "csg-cylinder-axis-start", parameters: (radius: radius, primitive: id))
  let bdecl = _control(b-point, _control-name(id, "B"), b, "csg-cylinder-axis-end", parameters: (radius: radius, primitive: id))
  let pa = adecl.coordinate
  let pb = bdecl.coordinate
  let direction = core.unit3(core.sub3(pb, pa), fallback: (0, 0, 1))
  let center = core.midpoint3(pa, pb)
  let half-height = core.distance3(pa, pb) / 2
  let pad = radius
  field(
    point => {
      let offset = core.sub3(point, center)
      let axial-coordinate = core.dot3(offset, direction)
      let radial-vector = core.sub3(offset, core.mul3(direction, axial-coordinate))
      let radial = core.norm3(radial-vector) - radius
      let axial = calc.abs(axial-coordinate) - half-height
      core.norm3((calc.max(radial, 0), calc.max(axial, 0), 0)) + calc.min(calc.max(radial, axial), 0)
    },
    (
      (calc.min(core.x3(pa), core.x3(pb)) - pad, calc.max(core.x3(pa), core.x3(pb)) + pad),
      (calc.min(core.y3(pa), core.y3(pb)) - pad, calc.max(core.y3(pa), core.y3(pb)) + pad),
      (calc.min(core.z3(pa), core.z3(pb)) - pad, calc.max(core.z3(pa), core.z3(pb)) + pad),
    ),
    name: id,
    meta: (primitive: "cylinder", a: pa, b: pb, radius: radius, a-name: adecl.name, b-name: bdecl.name),
    control-points: (adecl, bdecl),
  )
}

#let torus(center: (0, 0, 0), axis: (0, 0, 1), major-radius: 1.5, minor-radius: 0.4, id: "torus", center-point: auto, axis-point: auto) = {
  let cdecl = _control(center-point, _control-name(id, "center"), center, "csg-torus-center", parameters: (major-radius: major-radius, minor-radius: minor-radius, primitive: id))
  let axis-coordinate = core.add3(cdecl.coordinate, core.unit3(axis, fallback: (0, 0, 1)))
  let adecl = _control(axis-point, _control-name(id, "axis"), axis-coordinate, "csg-torus-axis-point", parameters: (primitive: id))
  let direction = core.sub3(adecl.coordinate, cdecl.coordinate)
  let basis = core.basis-from-normal(direction)
  let total = major-radius + minor-radius
  let c = cdecl.coordinate
  field(
    point => {
      let q = core.sub3(point, c)
      let axial = core.dot3(q, basis.normal)
      let planar = calc.sqrt(calc.pow(core.dot3(q, basis.u), 2) + calc.pow(core.dot3(q, basis.v), 2)) - major-radius
      calc.sqrt(planar * planar + axial * axial) - minor-radius
    },
    ((core.x3(c) - total, core.x3(c) + total), (core.y3(c) - total, core.y3(c) + total), (core.z3(c) - total, core.z3(c) + total)),
    name: id,
    meta: (primitive: "torus", center: c, axis: direction, major-radius: major-radius, minor-radius: minor-radius, center-name: cdecl.name, axis-name: adecl.name),
    control-points: (cdecl, adecl),
  )
}

#let plane(point: (0, 0, 0), normal: (0, 0, 1), bounds: ((-4, 4), (-4, 4), (-4, 4)), id: "plane", point-declaration: auto) = {
  let pdecl = _control(point-declaration, _control-name(id, "point"), point, "csg-plane-point", parameters: (normal: normal, primitive: id))
  let n = core.unit3(normal, fallback: (0, 0, 1))
  field(p => core.dot3(core.sub3(p, pdecl.coordinate), n), bounds, name: id, meta: (primitive: "plane", point: pdecl.coordinate, normal: n, point-name: pdecl.name), control-points: (pdecl,))
}

#let union(a, b, others: ()) = {
  let all = (a, b) + others
  let bounds = all.first().bounds
  for item in all.slice(1) { bounds = _merge-bounds(bounds, item.bounds) }
  field(point => {
    let result = all.first().function(point)
    for item in all.slice(1) { result = calc.min(result, item.function(point)) }
    result
  }, bounds, name: "union", meta: (operation: "union", children: all), control-points: _controls(all))
}

#let intersection(a, b, others: ()) = {
  let all = (a, b) + others
  let bounds = all.first().bounds
  for item in all.slice(1) { bounds = _intersect-bounds(bounds, item.bounds) }
  field(point => {
    let result = all.first().function(point)
    for item in all.slice(1) { result = calc.max(result, item.function(point)) }
    result
  }, bounds, name: "intersection", meta: (operation: "intersection", children: all), control-points: _controls(all))
}

#let subtract(a, b) = field(
  point => calc.max(a.function(point), -b.function(point)),
  a.bounds,
  name: "subtract",
  meta: (operation: "subtract", children: (a, b)),
  control-points: _controls((a, b)),
)

#let smooth-union(a, b, radius: 0.25) = field(
  point => {
    let da = a.function(point)
    let db = b.function(point)
    let h = core.clamp(0.5 + 0.5 * (db - da) / radius, 0, 1)
    db * (1 - h) + da * h - radius * h * (1 - h)
  },
  _merge-bounds(a.bounds, b.bounds),
  name: "smooth-union",
  meta: (operation: "smooth-union", children: (a, b), radius: radius),
  control-points: _controls((a, b)),
)

#let translate(shape, offset) = field(
  point => shape.function(core.sub3(point, offset)),
  (
    (shape.bounds.at(0).at(0) + core.x3(offset), shape.bounds.at(0).at(1) + core.x3(offset)),
    (shape.bounds.at(1).at(0) + core.y3(offset), shape.bounds.at(1).at(1) + core.y3(offset)),
    (shape.bounds.at(2).at(0) + core.z3(offset), shape.bounds.at(2).at(1) + core.z3(offset)),
  ),
  name: shape.name + "-translated",
  meta: (operation: "translate", child: shape, offset: offset),
  control-points: _mapped-controls(shape, "translate", point => core.add3(point, offset), "translated"),
)

#let rotate(shape, axis: core.axis(), angle: 0deg, bounds: auto) = field(
  point => shape.function(core.rotate-around-axis(point, axis, -angle)),
  if bounds == auto { shape.bounds } else { bounds },
  name: shape.name + "-rotated",
  meta: (operation: "rotate", child: shape, axis: axis, angle: angle),
  control-points: _mapped-controls(shape, "rotate", point => core.rotate-around-axis(point, axis, angle), "rotated"),
)

#let shell(shape, thickness: 0.15) = field(
  point => calc.abs(shape.function(point)) - thickness / 2,
  shape.bounds,
  name: shape.name + "-shell",
  meta: (operation: "shell", child: shape, thickness: thickness),
  control-points: shape.at("control-points", default: ()),
)

#let build(shape, resolution: (16, 16, 16), prefix: "CSG", role: "surface", faces: true, mesh: false, cull: false, weld: true, weld-tolerance: 1e-6, point-policy: auto) = implicit.from-field(
  shape,
  resolution: resolution,
  prefix: prefix,
  role: role,
  faces: faces,
  mesh: mesh,
  cull: cull,
  tags: ("csg", shape.name),
  weld: weld,
  weld-tolerance: weld-tolerance,
  point-policy: point-policy,
)

// Extended 0.7 primitives and operators ---------------------------------------
#let ellipsoid(center: (0, 0, 0), radii: (1, 1, 1), id: "ellipsoid", center-point: auto) = {
  let cdecl = _control(center-point, _control-name(id, "center"), center, "csg-ellipsoid-center", parameters: (radii: radii, primitive: id))
  let c = cdecl.coordinate
  let minimum = calc.min(core.x3(radii), core.y3(radii), core.z3(radii))
  field(
    point => {
      let q = core.sub3(point, c)
      (core.norm3((core.x3(q) / core.x3(radii), core.y3(q) / core.y3(radii), core.z3(q) / core.z3(radii))) - 1) * minimum
    },
    (
      (core.x3(c) - core.x3(radii), core.x3(c) + core.x3(radii)),
      (core.y3(c) - core.y3(radii), core.y3(c) + core.y3(radii)),
      (core.z3(c) - core.z3(radii), core.z3(c) + core.z3(radii)),
    ),
    name: id,
    meta: (primitive: "ellipsoid", center: c, radii: radii, center-name: cdecl.name),
    control-points: (cdecl,),
  )
}

#let capsule(a: (0, 0, -1), b: (0, 0, 1), radius: 0.5, id: "capsule", a-point: auto, b-point: auto) = {
  let adecl = _control(a-point, _control-name(id, "A"), a, "csg-capsule-axis-start", parameters: (radius: radius, primitive: id))
  let bdecl = _control(b-point, _control-name(id, "B"), b, "csg-capsule-axis-end", parameters: (radius: radius, primitive: id))
  let pa = adecl.coordinate
  let pb = bdecl.coordinate
  let ab = core.sub3(pb, pa)
  let denominator = core.dot3(ab, ab)
  field(
    point => {
      let t = if denominator <= core.epsilon { 0 } else { core.clamp(core.dot3(core.sub3(point, pa), ab) / denominator, 0, 1) }
      core.distance3(point, core.lerp3(pa, pb, t)) - radius
    },
    (
      (calc.min(core.x3(pa), core.x3(pb)) - radius, calc.max(core.x3(pa), core.x3(pb)) + radius),
      (calc.min(core.y3(pa), core.y3(pb)) - radius, calc.max(core.y3(pa), core.y3(pb)) + radius),
      (calc.min(core.z3(pa), core.z3(pb)) - radius, calc.max(core.z3(pa), core.z3(pb)) + radius),
    ),
    name: id,
    meta: (primitive: "capsule", a: pa, b: pb, radius: radius, a-name: adecl.name, b-name: bdecl.name),
    control-points: (adecl, bdecl),
  )
}

#let cone(apex: (0, 0, 1), base: (0, 0, -1), radius: 1, id: "cone", apex-point: auto, base-point: auto) = {
  let adecl = _control(apex-point, _control-name(id, "apex"), apex, "csg-cone-apex", parameters: (radius: radius, primitive: id))
  let bdecl = _control(base-point, _control-name(id, "base-center"), base, "csg-cone-base-center", parameters: (radius: radius, primitive: id))
  let pa = adecl.coordinate
  let pb = bdecl.coordinate
  let direction = core.unit3(core.sub3(pb, pa), fallback: (0, 0, -1))
  let height = core.distance3(pa, pb)
  let bounds = (
    (calc.min(core.x3(pa), core.x3(pb)) - radius, calc.max(core.x3(pa), core.x3(pb)) + radius),
    (calc.min(core.y3(pa), core.y3(pb)) - radius, calc.max(core.y3(pa), core.y3(pb)) + radius),
    (calc.min(core.z3(pa), core.z3(pb)) - radius, calc.max(core.z3(pa), core.z3(pb)) + radius),
  )
  field(
    point => {
      let q = core.sub3(point, pa)
      let axial = core.dot3(q, direction)
      let radial = core.norm3(core.sub3(q, core.mul3(direction, axial)))
      let expected = radius * core.clamp(axial / height, 0, 1)
      let side = radial - expected
      let cap-a = -axial
      let cap-b = axial - height
      calc.max(side, calc.max(cap-a, cap-b))
    },
    bounds,
    name: id,
    meta: (primitive: "cone", apex: pa, base: pb, radius: radius, apex-name: adecl.name, base-name: bdecl.name),
    control-points: (adecl, bdecl),
  )
}

#let rounded-box(center: (0, 0, 0), size: (2, 2, 2), radius: 0.2, id: "rounded-box", center-point: auto) = {
  let cdecl = _control(center-point, _control-name(id, "center"), center, "csg-rounded-box-center", parameters: (size: size, radius: radius, primitive: id))
  let c = cdecl.coordinate
  let half = core.mul3(size, 0.5)
  field(
    point => {
      let q = (
        calc.abs(core.x3(point) - core.x3(c)) - core.x3(half) + radius,
        calc.abs(core.y3(point) - core.y3(c)) - core.y3(half) + radius,
        calc.abs(core.z3(point) - core.z3(c)) - core.z3(half) + radius,
      )
      core.norm3((calc.max(core.x3(q), 0), calc.max(core.y3(q), 0), calc.max(core.z3(q), 0))) + calc.min(calc.max(core.x3(q), calc.max(core.y3(q), core.z3(q))), 0) - radius
    },
    (
      (core.x3(c) - core.x3(half), core.x3(c) + core.x3(half)),
      (core.y3(c) - core.y3(half), core.y3(c) + core.y3(half)),
      (core.z3(c) - core.z3(half), core.z3(c) + core.z3(half)),
    ),
    name: id,
    meta: (primitive: "rounded-box", center: c, size: size, radius: radius, center-name: cdecl.name),
    control-points: (cdecl,),
  )
}

#let complement(shape) = field(point => -shape.function(point), shape.bounds, name: "complement", meta: (operation: "complement", child: shape), control-points: shape.at("control-points", default: ()))
#let difference = subtract
#let xor(a, b) = union(subtract(a, b), subtract(b, a))
#let offset(shape, amount) = field(point => shape.function(point) - amount, shape.bounds, name: shape.name + "-offset", meta: (operation: "offset", child: shape, amount: amount), control-points: shape.at("control-points", default: ()))

#let smooth-intersection(a, b, radius: 0.25) = field(
  point => {
    let da = a.function(point)
    let db = b.function(point)
    let h = core.clamp(0.5 - 0.5 * (db - da) / radius, 0, 1)
    db * (1 - h) + da * h + radius * h * (1 - h)
  },
  _intersect-bounds(a.bounds, b.bounds),
  name: "smooth-intersection",
  meta: (operation: "smooth-intersection", children: (a, b), radius: radius),
  control-points: _controls((a, b)),
)

#let smooth-subtract(a, b, radius: 0.25) = smooth-intersection(a, complement(b), radius: radius)

#let scale(shape, factors: (1, 1, 1), center: (0, 0, 0), bounds: auto) = {
  let minimum = calc.min(calc.abs(core.x3(factors)), calc.abs(core.y3(factors)), calc.abs(core.z3(factors)))
  field(
    point => {
      let q = core.sub3(point, center)
      shape.function(core.add3(center, (core.x3(q) / core.x3(factors), core.y3(q) / core.y3(factors), core.z3(q) / core.z3(factors)))) * minimum
    },
    if bounds == auto { shape.bounds } else { bounds },
    name: shape.name + "-scaled",
    meta: (operation: "scale", child: shape, factors: factors, center: center),
    control-points: _mapped-controls(shape, "scale", point => core.add3(center, (
      core.x3(core.sub3(point, center)) * core.x3(factors),
      core.y3(core.sub3(point, center)) * core.y3(factors),
      core.z3(core.sub3(point, center)) * core.z3(factors),
    )), "scaled"),
  )
}

#let clip(shape, clipping-plane, keep: "negative") = {
  let half-space = plane(point: clipping-plane.point, normal: clipping-plane.normal, bounds: shape.bounds)
  if keep == "negative" { intersection(shape, half-space) } else { intersection(shape, complement(half-space)) }
}

#let tree(shape) = {
  let meta = shape.meta
  let children = meta.at("children", default: ())
  if children.len() == 0 and "child" in meta { children = (meta.child,) }
  (
    name: shape.name,
    operation: meta.at("operation", default: meta.at("primitive", default: "field")),
    bounds: shape.bounds,
    children: children.map(tree),
  )
}
