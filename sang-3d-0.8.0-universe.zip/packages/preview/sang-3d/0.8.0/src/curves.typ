// Advanced parametric curves, differential frames, and curve visualization.
#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "definitions.typ" as definitions
#import "points.typ" as point-declarations

#let clamp01(t) = core.clamp(t, 0, 1)

#let sample(curve, steps: 48, domain: (0, 1), closed: false) = {
  if steps < 1 { panic("sang-3d.curves.sample: steps must be positive") }
  let count = if closed { steps } else { steps + 1 }
  range(count).map(index => {
    let t = domain.at(0) + (domain.at(1) - domain.at(0)) * index / steps
    curve(t)
  })
}

#let bezier(points) = {
  if points.len() < 2 { panic("sang-3d.curves.bezier: at least two control points are required") }
  t => {
    let work = points
    let u = clamp01(t)
    while work.len() > 1 {
      work = range(work.len() - 1).map(index => core.lerp3(work.at(index), work.at(index + 1), u))
    }
    work.first()
  }
}

#let cubic-bezier(p0, p1, p2, p3) = bezier((p0, p1, p2, p3))

#let hermite(p0, p1, tangent0, tangent1) = t => {
  let u = clamp01(t)
  let u2 = u * u
  let u3 = u2 * u
  core.add3(
    core.add3(core.mul3(p0, 2*u3 - 3*u2 + 1), core.mul3(tangent0, u3 - 2*u2 + u)),
    core.add3(core.mul3(p1, -2*u3 + 3*u2), core.mul3(tangent1, u3 - u2)),
  )
}

#let catmull-rom(points, tension: 0.5, closed: false) = {
  if points.len() < 4 { panic("sang-3d.curves.catmull-rom: at least four points are required") }
  let segment-count = if closed { points.len() } else { points.len() - 3 }
  let at(index) = if closed { points.at(calc.rem-euclid(index, points.len())) } else { points.at(core.clamp(index, 0, points.len() - 1)) }
  t => {
    let scaled = core.clamp(t, 0, 1) * segment-count
    let segment = calc.min(segment-count - 1, calc.floor(scaled))
    let u = scaled - segment
    let offset = if closed { segment } else { segment + 1 }
    let p0 = at(offset - 1)
    let p1 = at(offset)
    let p2 = at(offset + 1)
    let p3 = at(offset + 2)
    let m1 = core.mul3(core.sub3(p2, p0), tension)
    let m2 = core.mul3(core.sub3(p3, p1), tension)
    hermite(p1, p2, m1, m2)(u)
  }
}

#let _basis(i, degree, knots, t) = {
  if degree == 0 {
    if (knots.at(i) <= t and t < knots.at(i + 1)) or (t == knots.last() and knots.at(i + 1) == knots.last()) { 1 } else { 0 }
  } else {
    let left-den = knots.at(i + degree) - knots.at(i)
    let right-den = knots.at(i + degree + 1) - knots.at(i + 1)
    let left = if calc.abs(left-den) <= core.epsilon { 0 } else { (t - knots.at(i)) / left-den * _basis(i, degree - 1, knots, t) }
    let right = if calc.abs(right-den) <= core.epsilon { 0 } else { (knots.at(i + degree + 1) - t) / right-den * _basis(i + 1, degree - 1, knots, t) }
    left + right
  }
}

#let bspline(points, degree: 3, knots: auto) = {
  if degree < 1 or degree >= points.len() { panic("sang-3d.curves.bspline: degree must be between 1 and points.len()-1") }
  let n = points.len()
  let actual-knots = if knots != auto { knots } else {
    let inner = n - degree - 1
    let values = ()
    for _ in range(degree + 1) { values.push(0) }
    for i in range(1, inner + 1) { values.push(i / (inner + 1)) }
    for _ in range(degree + 1) { values.push(1) }
    values
  }
  if actual-knots.len() != n + degree + 1 { panic("sang-3d.curves.bspline: knot count must equal points.len()+degree+1") }
  t => {
    let u = clamp01(t)
    if u <= core.epsilon { return points.first() }
    if u >= 1 - core.epsilon { return points.last() }
    let result = (0, 0, 0)
    for i in range(n) { result = core.add3(result, core.mul3(points.at(i), _basis(i, degree, actual-knots, u))) }
    result
  }
}

#let tangent(curve, t, step: 1e-4) = core.unit3(core.sub3(curve(core.clamp(t + step, 0, 1)), curve(core.clamp(t - step, 0, 1))), fallback: (1, 0, 0))
#let second-derivative(curve, t, step: 1e-3) = core.mul3(core.add3(core.sub3(curve(core.clamp(t + step, 0, 1)), core.mul3(curve(t), 2)), curve(core.clamp(t - step, 0, 1))), 1 / (step * step))

#let frenet-frame(curve, t, step: 1e-3, fallback-up: (0, 0, 1)) = {
  let tv = tangent(curve, t, step: step)
  let acceleration = second-derivative(curve, t, step: step)
  let normal-raw = core.sub3(acceleration, core.mul3(tv, core.dot3(acceleration, tv)))
  let nv = core.unit3(normal-raw, fallback: core.unit3(core.sub3(fallback-up, core.mul3(tv, core.dot3(fallback-up, tv))), fallback: core.orthogonal3(tv)))
  let bv = core.unit3(core.cross3(tv, nv), fallback: core.orthogonal3(tv))
  (origin: curve(t), tangent: tv, normal: nv, binormal: bv)
}

#let curvature(curve, t, step: 1e-3) = {
  let first = core.mul3(core.sub3(curve(core.clamp(t + step, 0, 1)), curve(core.clamp(t - step, 0, 1))), 1 / (2 * step))
  let second = second-derivative(curve, t, step: step)
  let denominator = calc.pow(core.norm3(first), 3)
  if denominator <= core.epsilon { 0 } else { core.norm3(core.cross3(first, second)) / denominator }
}

#let arc-length(curve, start: 0, end: 1, steps: 128) = {
  let points = range(steps + 1).map(i => curve(start + (end - start) * i / steps))
  let length = 0
  for i in range(steps) { length += core.distance3(points.at(i), points.at(i + 1)) }
  length
}

#let point-at-length(curve, distance, steps: 160) = {
  let points = range(steps + 1).map(i => curve(i / steps))
  let total = 0
  let lengths = (0,)
  for i in range(steps) {
    total += core.distance3(points.at(i), points.at(i + 1))
    lengths.push(total)
  }
  let target = core.clamp(distance, 0, total)
  let index = 0
  while index < steps - 1 and lengths.at(index + 1) < target { index += 1 }
  let span = lengths.at(index + 1) - lengths.at(index)
  let local = if span <= core.epsilon { 0 } else { (target - lengths.at(index)) / span }
  core.lerp3(points.at(index), points.at(index + 1), local)
}

#let model(
  curve,
  steps: 64,
  domain: (0, 1),
  closed: false,
  prefix: "CV",
  role: "strong",
  control-points: (),
  show-control: false,
  mark: none,
  tags: (),
  point-policy: auto,
  control-point-policy: auto,
) = {
  let coordinates = sample(curve, steps: steps, domain: domain, closed: closed)
  let declarations = ()
  let control-names = ()

  // Curve controls are declared first; sampled points can therefore record a
  // real dependency on the controls that define the curve.
  for (index, coordinate) in control-points.enumerate() {
    let declaration = point-declarations.from-policy(
      prefix + "-control-" + str(index),
      coordinate,
      "curve-control",
      parameters: (index: index, curve: prefix),
      policy: control-point-policy,
      context: (index: index, curve: prefix, control: true),
    )
    declarations.push(declaration)
    control-names.push(declaration.name)
  }

  let names = ()
  for (index, coordinate) in coordinates.enumerate() {
    let parameter = domain.at(0) + (domain.at(1) - domain.at(0)) * index / steps
    let declaration = point-declarations.from-policy(
      prefix + "-" + str(index),
      coordinate,
      "curve-sample",
      deps: control-names,
      parameters: (index: index, parameter: parameter, curve: prefix),
      policy: point-policy,
      context: (index: index, parameter: parameter, curve: prefix, sample-count: coordinates.len()),
    )
    declarations.push(declaration)
    names.push(declaration.name)
  }
  let declared = point-declarations.declare(declarations)

  let additions = ()
  for declaration in declarations {
    let options = declaration.options
    if options.at("show-point", default: false) or options.at("show-label", default: false) {
      additions.push(objects.point(
        declaration.name,
        role: options.at("role", default: if control-names.contains(declaration.name) { "construction" } else { role }),
        point: options.at("show-point", default: false),
        label: if options.at("show-label", default: false) { options.at("label-content", default: auto) } else { none },
        tags: tags + (if control-names.contains(declaration.name) { "control-point" } else { "curve-sample" },),
      ))
    }
  }

  additions.push(objects.polyline(names, id: prefix + "-curve", role: role, close: closed, mark: mark, tags: tags + ("curve3d",)))
  if show-control and control-names.len() > 0 {
    for name in control-names {
      if not additions.any(item => item.kind == "point" and item.name == name) {
        additions.push(objects.point(name, role: "construction", tags: tags + ("control-point",)))
      }
    }
    additions.push(objects.polyline(control-names, id: prefix + "-control-polygon", role: "construction", tags: tags + ("control-polygon",)))
  }
  models.model(
    points: declared.points,
    definitions: declared.definitions,
    point-options: declared.point-options,
    point-order: declared.order,
    objects: additions,
    meta: (kind: "curve3d", closed: closed, controls: control-names),
  )
}


// Rational curves and arc-length reparameterization ---------------------------
#let rational-bezier(points, weights: auto) = {
  let actual = if weights == auto { points.map(_ => 1) } else { weights }
  if actual.len() != points.len() { panic("sang-3d.curves.rational-bezier: weights must match points") }
  let weighted = points.enumerate().map(pair => core.mul3(pair.at(1), actual.at(pair.at(0))))
  let numerator = bezier(weighted)
  let denominator = bezier(actual.map(value => (value, 0, 0)))
  t => {
    let d = core.x3(denominator(t))
    if calc.abs(d) <= core.epsilon { panic("sang-3d.curves.rational-bezier: zero homogeneous weight") }
    core.mul3(numerator(t), 1 / d)
  }
}

#let nurbs(points, degree: 3, weights: auto, knots: auto) = {
  let actual-weights = if weights == auto { points.map(_ => 1) } else { weights }
  if actual-weights.len() != points.len() { panic("sang-3d.curves.nurbs: weights must match points") }
  let n = points.len()
  let actual-knots = if knots != auto { knots } else {
    let values = ()
    for _ in range(degree + 1) { values.push(0) }
    let inner = n - degree - 1
    for i in range(1, inner + 1) { values.push(i / (inner + 1)) }
    for _ in range(degree + 1) { values.push(1) }
    values
  }
  if actual-knots.len() != n + degree + 1 { panic("sang-3d.curves.nurbs: knot count must equal points.len()+degree+1") }
  t => {
    let u = clamp01(t)
    if u <= core.epsilon { return points.first() }
    if u >= 1 - core.epsilon { return points.last() }
    let numerator = (0, 0, 0)
    let denominator = 0
    for i in range(n) {
      let influence = _basis(i, degree, actual-knots, u) * actual-weights.at(i)
      numerator = core.add3(numerator, core.mul3(points.at(i), influence))
      denominator += influence
    }
    if calc.abs(denominator) <= core.epsilon { panic("sang-3d.curves.nurbs: zero homogeneous denominator") }
    core.mul3(numerator, 1 / denominator)
  }
}

#let torsion(curve, t, step: 2e-3) = {
  let p0 = curve(core.clamp(t - 2 * step, 0, 1))
  let p1 = curve(core.clamp(t - step, 0, 1))
  let p2 = curve(t)
  let p3 = curve(core.clamp(t + step, 0, 1))
  let p4 = curve(core.clamp(t + 2 * step, 0, 1))
  let first = core.mul3(core.sub3(p3, p1), 1 / (2 * step))
  let second = core.mul3(core.add3(core.sub3(p3, core.mul3(p2, 2)), p1), 1 / (step * step))
  let third = core.mul3(core.add3(core.sub3(p4, core.mul3(p3, 2)), core.sub3(core.mul3(p1, 2), p0)), 1 / (2 * step * step * step))
  let cross = core.cross3(first, second)
  let denominator = core.dot3(cross, cross)
  if denominator <= core.epsilon { 0 } else { core.dot3(cross, third) / denominator }
}

#let arc-length-table(curve, steps: 160) = {
  let entries = ((t: 0, length: 0, point: curve(0)),)
  let total = 0
  let previous = curve(0)
  for i in range(1, steps + 1) {
    let t = i / steps
    let point = curve(t)
    total += core.distance3(previous, point)
    entries.push((t: t, length: total, point: point))
    previous = point
  }
  (entries: entries, total: total)
}

#let by-arc-length(curve, steps: 160) = {
  let table = arc-length-table(curve, steps: steps)
  u => {
    let target = core.clamp(u, 0, 1) * table.total
    let index = 0
    while index < table.entries.len() - 2 and table.entries.at(index + 1).length < target { index += 1 }
    let a = table.entries.at(index)
    let b = table.entries.at(index + 1)
    let span = b.length - a.length
    let local = if span <= core.epsilon { 0 } else { (target - a.length) / span }
    curve(a.t + (b.t - a.t) * local)
  }
}
