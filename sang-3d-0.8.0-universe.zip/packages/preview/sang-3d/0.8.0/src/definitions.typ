// Public point-definition graph and provenance utilities.
// Every geometric point has a stable name, a coordinate, dependencies, and a definition.

#let given(coordinate, label: auto, meta: (:)) = (
  kind: "given",
  deps: (),
  coordinate: coordinate,
  label: label,
  parameters: (:),
  meta: meta,
)

#let derived(kind, deps: (), coordinate: auto, parameters: (:), formula: none, meta: (:)) = (
  kind: kind,
  deps: deps,
  coordinate: coordinate,
  parameters: parameters,
  formula: formula,
  meta: meta,
)

#let generated(coordinate, source: "constructor", object: none, field: none, index: none, meta: (:)) = derived(
  "generated",
  coordinate: coordinate,
  parameters: (source: source, object: object, field: field, index: index),
  meta: meta,
)

#let materialized(coordinate, object: none, field: none, index: none) = derived(
  "materialized-coordinate",
  coordinate: coordinate,
  parameters: (object: object, field: field, index: index),
)

#let alias(source, coordinate: auto) = derived("alias", deps: (source,), coordinate: coordinate, parameters: (source: source,))
#let midpoint(a, b, coordinate: auto) = derived("midpoint", deps: (a, b), coordinate: coordinate, parameters: (a: a, b: b))
#let division(a, b, ratio, coordinate: auto) = derived("division", deps: (a, b), coordinate: coordinate, parameters: (a: a, b: b, ratio: ratio))
#let centroid(refs, coordinate: auto) = derived("centroid", deps: refs, coordinate: coordinate, parameters: (points: refs,))
#let projection(source, target, coordinate: auto, kind: "projection") = derived(kind, deps: (source,) + target, coordinate: coordinate, parameters: (source: source, target: target))
#let intersection(deps, coordinate: auto, kind: "intersection", parameters: (:)) = derived(kind, deps: deps, coordinate: coordinate, parameters: parameters)
#let transformed(source, coordinate, operation: "transform", parameters: (:)) = derived(
  "transformed",
  deps: (source,),
  coordinate: coordinate,
  parameters: (: operation: operation, ..parameters),
)


#let manifest(points, kind: "declared-generated", deps: (), parameters: (:), source: "constructor") = {
  let output = (:)
  for (name, coordinate) in points {
    output.insert(name, derived(kind, deps: deps, coordinate: coordinate, parameters: (: source: source, name: name, ..parameters)))
  }
  output
}

#let ensure(points, supplied: auto, source: "model", strict: true) = {
  if strict and supplied == auto and points.len() > 0 {
    panic("sang-3d: every point needs an explicit definition; pass definitions or use figure3d with point declarations")
  }
  let registry = if supplied == auto { (:) } else { (: ..supplied) }
  for (name, coordinate) in points {
    if name not in registry {
      if strict { panic("sang-3d: point " + name + " has no explicit definition") }
      registry.insert(name, generated(coordinate, source: source, field: "points", meta: (legacy-implicit-definition: true)))
    } else {
      let item = registry.at(name)
      if type(item) != dictionary {
        if strict { panic("sang-3d: definition for point " + name + " must be a dictionary") }
        item = generated(coordinate, source: source, meta: (legacy-definition: item))
      }
      if item.at("coordinate", default: auto) == auto { item = (: ..item, coordinate: coordinate) }
      if "deps" not in item { item = (: ..item, deps: ()) }
      if "parameters" not in item { item = (: ..item, parameters: (:)) }
      registry.insert(name, item)
    }
  }
  registry
}

#let coordinate(registry, name, default: none) = {
  let item = registry.at(name, default: none)
  if item == none { default } else { item.at("coordinate", default: default) }
}
#let dependencies(registry, name) = registry.at(name).at("deps", default: ())
#let kind(registry, name) = registry.at(name).at("kind", default: "unknown")

#let _rename-value(value, prefix) = {
  if type(value) == str { prefix + value }
  else if type(value) == array { value.map(item => _rename-value(item, prefix)) }
  else { value }
}

#let renamed(registry, prefix) = {
  let output = (:)
  for (name, item) in registry {
    let deps = item.at("deps", default: ()).map(dep => if type(dep) == str { prefix + dep } else { dep })
    let parameters = item.at("parameters", default: (:))
    // Only dependency-bearing fields are renamed; numeric/text parameters remain untouched.
    for key in ("source", "a", "b", "center", "point", "origin") {
      if key in parameters and type(parameters.at(key)) == str { parameters.insert(key, prefix + parameters.at(key)) }
    }
    if "points" in parameters and type(parameters.points) == array {
      parameters.insert("points", parameters.points.map(ref => if type(ref) == str { prefix + ref } else { ref }))
    }
    output.insert(prefix + name, (: ..item, deps: deps, parameters: parameters))
  }
  output
}

#let trace(registry, name, visited: ()) = {
  if visited.contains(name) { return ((name: name, cycle: true),) }
  let item = registry.at(name, default: none)
  if item == none { return ((name: name, missing: true),) }
  let output = ((name: name, kind: item.kind, coordinate: item.at("coordinate", default: auto), deps: item.at("deps", default: ())),)
  for dep in item.at("deps", default: ()) {
    if type(dep) == str { output += trace(registry, dep, visited: visited + (name,)) }
  }
  output
}

#let cycles(registry) = {
  let found = ()
  let visit(name, path) = {
    if path.contains(name) {
      found.push(path + (name,))
      return
    }
    let item = registry.at(name, default: none)
    if item == none { return }
    for dep in item.at("deps", default: ()) {
      if type(dep) == str { visit(dep, path + (name,)) }
    }
  }
  for name in registry.keys() { visit(name, ()) }
  found
}

#let describe(item) = {
  let k = item.at("kind", default: "unknown")
  let deps = item.at("deps", default: ())
  if deps.len() == 0 { k } else { k + "(" + deps.map(str).join(", ") + ")" }
}

#let point-table(fig, include-coordinate: true) = {
  let rows = (([Point], [Definition], [Dependencies]),)
  if include-coordinate { rows = (([Point], [Coordinate], [Definition], [Dependencies]),) }
  for name in fig.points.keys().sorted() {
    let item = fig.definitions.at(name)
    let dep-text = item.at("deps", default: ()).map(str).join(", ")
    if include-coordinate {
      rows.push(([#name], [#repr(fig.points.at(name))], [#item.kind], [#dep-text]))
    } else {
      rows.push(([#name], [#item.kind], [#dep-text]))
    }
  }
  table(columns: if include-coordinate { 4 } else { 3 }, ..rows.flatten())
}
