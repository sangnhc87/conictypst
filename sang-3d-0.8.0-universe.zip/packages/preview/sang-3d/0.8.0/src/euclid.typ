#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "solids.typ" as solids
#import "surfaces.typ" as surfaces
#import "definitions.typ" as definitions

// A Euclidean 2D frame embedded in 3D space.
#let frame(origin: (0, 0, 0), normal: (0, 0, 1), x-direction: auto, id: none) = {
  let basis = core.basis-from-normal(normal, preferred-u: x-direction)
  (kind: "euclid-frame3d", id: id, origin: origin, u: basis.u, v: basis.v, normal: basis.normal)
}
#let xy-plane(origin: (0, 0, 0)) = frame(origin: origin, normal: (0, 0, 1), x-direction: (1, 0, 0), id: "xy")
#let yz-plane(origin: (0, 0, 0)) = frame(origin: origin, normal: (1, 0, 0), x-direction: (0, 1, 0), id: "yz")
#let zx-plane(origin: (0, 0, 0)) = frame(origin: origin, normal: (0, 1, 0), x-direction: (0, 0, 1), id: "zx")

#let embed(fr, point) = if point.len() == 3 { point } else {
  core.add3(fr.origin, core.add3(core.mul3(fr.u, point.at(0)), core.mul3(fr.v, point.at(1))))
}
#let local(fr, point) = {
  let q = core.sub3(point, fr.origin)
  (core.dot3(q, fr.u), core.dot3(q, fr.v), core.dot3(q, fr.normal))
}
#let point(fr, x, y) = embed(fr, (x, y))

#let _names(count, prefix, names) = if names == auto {
  range(count).map(index => prefix + str(index + 1))
} else { names }

#let polygon(
  points,
  frame: xy-plane(),
  names: auto,
  prefix: "P",
  close: true,
  fill: auto,
  face: true,
  edges: true,
  labels: false,
  role: "main",
  edge-role: auto,
  face-role: auto,
  cull: false,
  tags: (),
) = {
  if points.len() < 2 { panic("sang-3d.euclid.polygon: at least two points are required") }
  let point-names = _names(points.len(), prefix, names)
  let point-map = point-names.zip(points.map(value => embed(frame, value))).to-dict()
  let er = if edge-role == auto { role } else { edge-role }
  let fr = if face-role == auto { role } else { face-role }
  let items = ()
  if face and points.len() >= 3 {
    items.push(objects.face(point-names, id: prefix + "-face", role: fr, fill: fill, cull: cull, tags: tags + ("euclid-face",)))
  }
  if edges {
    let edge-count = if close { points.len() } else { points.len() - 1 }
    for index in range(edge-count) {
      let next = calc.rem-euclid(index + 1, points.len())
      items.push(objects.segment(point-names.at(index), point-names.at(next), id: prefix + "-edge-" + str(index + 1), role: er, tags: tags + ("euclid-edge",)))
    }
  }
  if labels {
    for name in point-names { items.push(objects.point(name, role: role, tags: tags + ("euclid-point",))) }
  }
  models.model(points: point-map, definitions: definitions.manifest(point-map, kind: "euclid-point", source: "euclid-polygon"), point-order: point-names, objects: items, meta: (kind: "euclid-polygon", frame: frame, edges: items.filter(item => item.kind == "segment").map(item => (item.a, item.b))))
}

#let regular-polygon(
  sides,
  radius: 2,
  center: (0, 0, 0),
  normal: (0, 0, 1),
  x-direction: auto,
  start-angle: 0deg,
  prefix: "A",
  names: auto,
  fill: auto,
  face: true,
  edges: true,
  labels: true,
  role: "main",
  cull: false,
  tags: (),
) = {
  if sides < 3 { panic("sang-3d.euclid.regular-polygon: sides must be at least 3") }
  let fr = frame(origin: center, normal: normal, x-direction: x-direction)
  let points = range(sides).map(index => {
    let angle = start-angle + 360deg * index / sides
    (radius * calc.cos(angle), radius * calc.sin(angle))
  })
  polygon(points, frame: fr, names: names, prefix: prefix, fill: fill, face: face, edges: edges, labels: labels, role: role, cull: cull, tags: tags + ("regular-polygon",))
}

#let triangle(a, b, c, names: ("A", "B", "C"), fill: auto, face: true, edges: true, labels: true, role: "main", tags: ()) = polygon(
  (a, b, c), frame: frame(), names: names, prefix: "T", fill: fill, face: face, edges: edges, labels: labels, role: role, tags: tags + ("triangle",),
)

#let rectangle(
  width: 4,
  height: 3,
  center: (0, 0, 0),
  normal: (0, 0, 1),
  x-direction: auto,
  names: ("A", "B", "C", "D"),
  prefix: "R",
  fill: auto,
  face: true,
  edges: true,
  labels: true,
  role: "main",
  tags: (),
) = polygon(
  ((-width/2, -height/2), (width/2, -height/2), (width/2, height/2), (-width/2, height/2)),
  frame: frame(origin: center, normal: normal, x-direction: x-direction),
  names: names,
  prefix: prefix,
  fill: fill,
  face: face,
  edges: edges,
  labels: labels,
  role: role,
  tags: tags + ("rectangle",),
)
#let square(size: 3, center: (0, 0, 0), normal: (0, 0, 1), x-direction: auto, names: ("A", "B", "C", "D"), prefix: "Q", fill: auto, face: true, edges: true, labels: true, role: "main", tags: ()) = rectangle(
  width: size, height: size, center: center, normal: normal, x-direction: x-direction, names: names, prefix: prefix, fill: fill, face: face, edges: edges, labels: labels, role: role, tags: tags + ("square",),
)

#let ellipse(
  center: (0, 0, 0),
  radii: (2, 1),
  normal: (0, 0, 1),
  x-direction: auto,
  rotation: 0deg,
  segments: 72,
  prefix: "E",
  fill: none,
  role: "main",
  tags: (),
) = {
  let fr = frame(origin: center, normal: normal, x-direction: x-direction)
  let points = (:)
  let names = ()
  for index in range(segments) {
    let angle = 360deg * index / segments
    let x = radii.at(0) * calc.cos(angle)
    let y = radii.at(1) * calc.sin(angle)
    let rotated = (x * calc.cos(rotation) - y * calc.sin(rotation), x * calc.sin(rotation) + y * calc.cos(rotation))
    let name = prefix + str(index)
    points.insert(name, embed(fr, rotated))
    names.push(name)
  }
  models.model(
    points: points,
    definitions: definitions.manifest(points, kind: "ellipse-sample", source: "euclid-ellipse"),
    point-order: names,
    objects: (objects.polyline(names, id: prefix + "-ellipse", role: role, close: true, fill: fill, tags: tags + ("ellipse",), visibility: "always"),),
    meta: (kind: "ellipse3d", frame: fr),
  )
}

#let circle(
  center: (0, 0, 0),
  radius: 1,
  normal: (0, 0, 1),
  x-direction: auto,
  fill: none,
  segments: 72,
  role: "main",
  id: "circle",
  center-name: auto,
  center-label: auto,
  center-label-position: auto,
  tags: (),
) = {
  let name = if center-name == auto { id + "-center" } else { center-name }
  let points = (:)
  points.insert(name, center)
  let registry = (:)
  registry.insert(name, definitions.derived("circle-center", coordinate: center, parameters: (radius: radius, normal: normal, object: id)))
  let options = (:)
  options.insert(name, (label-content: center-label, label-position: center-label-position, show-point: false, show-label: center-label != auto, role: role))
  models.model(
    points: points,
    definitions: registry,
    point-options: options,
    point-order: (name,),
    objects: (objects.circle3d(name, radius, normal: normal, start-direction: x-direction, fill: fill, segments: segments, role: role, id: id, tags: tags + ("euclid-circle",)),),
    meta: (kind: "circle3d", center: center, center-name: name, radius: radius, normal: normal),
  )
}

#let arc(
  center,
  radius,
  start-direction,
  angle,
  normal: (0, 0, 1),
  segments: 32,
  role: "accent",
  mark: none,
  id: "arc",
  center-name: auto,
  center-label: auto,
  center-label-position: auto,
  tags: (),
) = {
  let name = if center-name == auto { id + "-center" } else { center-name }
  let points = (:)
  points.insert(name, center)
  let registry = (:)
  registry.insert(name, definitions.derived("arc-center", coordinate: center, parameters: (radius: radius, angle: angle, normal: normal, object: id)))
  let options = (:)
  options.insert(name, (label-content: center-label, label-position: center-label-position, show-point: false, show-label: center-label != auto, role: role))
  models.model(
    points: points, definitions: registry, point-options: options, point-order: (name,),
    objects: (objects.arc3d(name, radius, start-direction, angle, normal: normal, segments: segments, role: role, mark: mark, id: id, tags: tags + ("euclid-arc",)),),
    meta: (kind: "arc3d", center: center, center-name: name, radius: radius, normal: normal, angle: angle),
  )
}

#let circle-through(a, b, c, tolerance: 1e-8) = {
  let u = core.sub3(b, a)
  let v = core.sub3(c, a)
  let w = core.cross3(u, v)
  let denominator = 2 * core.dot3(w, w)
  if denominator <= tolerance { return none }
  let offset = core.div3(core.add3(
    core.mul3(core.cross3(v, w), core.dot3(u, u)),
    core.mul3(core.cross3(w, u), core.dot3(v, v)),
  ), denominator)
  let center = core.add3(a, offset)
  (kind: "circle3d", center: center, radius: core.distance3(center, a), normal: core.unit3(w), through: (a, b, c))
}

#let circumcircle(a, b, c, role: "accent", segments: 72, id: "circumcircle", tags: ()) = {
  let data = circle-through(a, b, c)
  if data == none { return models.model(meta: (kind: "degenerate-circumcircle")) }
  circle(center: data.center, radius: data.radius, normal: data.normal, segments: segments, role: role, id: id, tags: tags + ("circumcircle",))
}

#let line(a, b, extent: auto, role: "construction", id: "line", names: auto, labels: false, mark: none, tags: ()) = {
  let start = a
  let end = b
  if extent != auto {
    let ln = core.line-through(a, b)
    start = core.line-point(ln, extent.at(0))
    end = core.line-point(ln, extent.at(1))
  }
  let actual-names = if names == auto { (id + "-A", id + "-B") } else { names }
  let points = (:)
  points.insert(actual-names.at(0), start)
  points.insert(actual-names.at(1), end)
  let registry = (:)
  registry.insert(actual-names.at(0), definitions.derived("line-endpoint", coordinate: start, parameters: (object: id, endpoint: "start")))
  registry.insert(actual-names.at(1), definitions.derived("line-endpoint", deps: (actual-names.at(0),), coordinate: end, parameters: (object: id, endpoint: "end")))
  let items = (objects.segment(actual-names.at(0), actual-names.at(1), id: id, role: role, mark: mark, visibility: "always", tags: tags + ("euclid-line",)),)
  if labels { items += actual-names.map(name => objects.point(name, role: role, tags: tags + ("line-point",))) }
  models.model(points: points, definitions: registry, point-order: actual-names, objects: items, meta: (kind: "line3d", line: core.line-through(a, b)))
}

#let ray(origin, through, length: 5, role: "construction", id: "ray", mark: (end: ">"), tags: ()) = {
  let direction = core.unit3(core.sub3(through, origin))
  line(origin, core.add3(origin, core.mul3(direction, length)), role: role, id: id, mark: mark, tags: tags + ("ray",))
}

#let plane(
  center: (0, 0, 0),
  normal: (0, 0, 1),
  width: 4,
  height: 3,
  x-direction: auto,
  grid: none,
  role: "auxiliary",
  id: "plane",
  center-name: auto,
  center-label: auto,
  center-label-position: auto,
  tags: (),
) = {
  let name = if center-name == auto { id + "-center" } else { center-name }
  let points = (:)
  points.insert(name, center)
  let registry = (:)
  registry.insert(name, definitions.derived("plane-center", coordinate: center, parameters: (normal: normal, width: width, height: height, object: id)))
  let options = (:)
  options.insert(name, (label-content: center-label, label-position: center-label-position, show-point: false, show-label: center-label != auto, role: role))
  models.model(
    points: points, definitions: registry, point-options: options, point-order: (name,),
    objects: (objects.plane-patch(name, normal, width: width, height: height, u: x-direction, grid: grid, role: role, id: id, tags: tags + ("euclid-plane",)),),
    meta: (kind: "plane3d", plane: core.plane(normal, point: center), center-name: name),
  )
}

#let sphere(center: (0, 0, 0), radius: 2, latitudes: 10, longitudes: 18, prefix: "S", mesh: true, faces: true, labels: false, role: "surface") = surfaces.sphere(
  center: center, radius: radius, latitudes: latitudes, longitudes: longitudes, prefix: prefix, mesh: mesh, faces: faces, labels: labels, role: role,
)

#let great-circle(sphere, normal: auto, role: "accent", segments: 72, id: "great-circle", tags: ()) = {
  let n = if normal == auto { (0, 0, 1) } else { normal }
  circle(center: sphere.center, radius: sphere.radius, normal: n, segments: segments, role: role, id: id, tags: tags + ("great-circle",))
}

#let tangent-plane(sphere, at) = {
  let normal = core.sub3(at, sphere.center)
  core.plane(normal, point: at, id: "tangent-plane")
}
#let tangent-line(circle, at) = core.line(at, core.cross3(circle.normal, core.sub3(at, circle.center)), id: "tangent-line")

#let radical-plane(a, b, tolerance: 1e-8) = {
  let normal = core.sub3(b.center, a.center)
  let denominator = core.dot3(normal, normal)
  if denominator <= tolerance { return none }
  let rhs = (core.dot3(b.center, b.center) - b.radius*b.radius - core.dot3(a.center, a.center) + a.radius*a.radius) / 2
  core.plane(normal, point: core.mul3(normal, rhs / denominator), id: "radical-plane")
}

#let sphere-intersection-circle(a, b, tolerance: 1e-7) = {
  let centers = core.sub3(b.center, a.center)
  let distance = core.norm3(centers)
  if distance <= tolerance or distance > a.radius + b.radius + tolerance or distance < calc.abs(a.radius - b.radius) - tolerance { return none }
  let direction = core.div3(centers, distance)
  let x = (a.radius*a.radius - b.radius*b.radius + distance*distance) / (2*distance)
  let center = core.add3(a.center, core.mul3(direction, x))
  let radius = calc.sqrt(calc.max(0, a.radius*a.radius - x*x))
  (kind: "circle3d", center: center, radius: radius, normal: direction)
}
