// Implicit surfaces via marching tetrahedra.
#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "definitions.typ" as definitions
#import "points.typ" as point-declarations

#let _offsets = (
  (0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0),
  (0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1),
)
#let _tetrahedra = (
  (0, 5, 1, 6), (0, 1, 2, 6), (0, 2, 3, 6),
  (0, 3, 7, 6), (0, 7, 4, 6), (0, 4, 5, 6),
)
#let _tetra-edges = ((0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3))

#let _lerp-zero(a, b, va, vb, level) = {
  let denominator = vb - va
  let t = if calc.abs(denominator) <= core.epsilon { 0.5 } else { (level - va) / denominator }
  core.lerp3(a, b, core.clamp(t, 0, 1))
}

#let _intersections(points, values, level) = {
  let hits = ()
  for edge in _tetra-edges {
    let ia = edge.at(0)
    let ib = edge.at(1)
    let va = values.at(ia) - level
    let vb = values.at(ib) - level
    if calc.abs(va) <= core.epsilon and calc.abs(vb) <= core.epsilon {
      hits.push(points.at(ia))
      hits.push(points.at(ib))
    } else if calc.abs(va) <= core.epsilon {
      hits.push(points.at(ia))
    } else if calc.abs(vb) <= core.epsilon {
      hits.push(points.at(ib))
    } else if va * vb < 0 {
      hits.push(_lerp-zero(points.at(ia), points.at(ib), values.at(ia), values.at(ib), level))
    }
  }
  core.unique-points3(hits, tolerance: 1e-7)
}

#let gradient(function, point, step: 1e-3) = {
  let x = core.x3(point)
  let y = core.y3(point)
  let z = core.z3(point)
  (
    (function((x + step, y, z)) - function((x - step, y, z))) / (2 * step),
    (function((x, y + step, z)) - function((x, y - step, z))) / (2 * step),
    (function((x, y, z + step)) - function((x, y, z - step))) / (2 * step),
  )
}

#let _ordered(function, points) = {
  if points.len() <= 2 { return points }
  let center = core.centroid3(points)
  let normal = core.unit3(gradient(function, center), fallback: core.polygon-normal(points))
  let ordered = core.sort-points-on-plane(points, core.plane(normal, point: center))
  if core.dot3(core.polygon-normal(ordered), normal) < 0 { ordered.rev() } else { ordered }
}

#let _vertex-key(point, tolerance) = {
  let q(value) = calc.round(value / tolerance)
  str(q(core.x3(point))) + ":" + str(q(core.y3(point))) + ":" + str(q(core.z3(point)))
}

#let _unique-names(names) = {
  let output = ()
  for name in names { if not output.contains(name) { output.push(name) } }
  output
}

#let surface(
  function,
  bounds: ((-2, 2), (-2, 2), (-2, 2)),
  resolution: (12, 12, 12),
  level: 0,
  prefix: "IM",
  role: "surface",
  faces: true,
  mesh: false,
  cull: false,
  tags: (),
  weld: true,
  weld-tolerance: 1e-6,
  control-points: (),
  point-policy: auto,
) = {
  let nx = resolution.at(0)
  let ny = resolution.at(1)
  let nz = resolution.at(2)
  if nx < 1 or ny < 1 or nz < 1 { panic("sang-3d.implicit.surface: every resolution component must be positive") }
  let xr = bounds.at(0)
  let yr = bounds.at(1)
  let zr = bounds.at(2)
  let position(i, j, k) = (
    xr.at(0) + (xr.at(1) - xr.at(0)) * i / nx,
    yr.at(0) + (yr.at(1) - yr.at(0)) * j / ny,
    zr.at(0) + (zr.at(1) - zr.at(0)) * k / nz,
  )
  let controls = point-declarations.declare(control-points)
  let points = (: ..controls.points)
  let point-definitions = (: ..controls.definitions)
  let point-options = (: ..controls.point-options)
  let point-order = controls.order
  let welded = (:)
  let face-objects = ()
  let edge-objects = ()
  let vertex-index = 0
  let face-index = 0
  for i in range(nx) {
    for j in range(ny) {
      for k in range(nz) {
        let cube-points = _offsets.map(offset => position(i + offset.at(0), j + offset.at(1), k + offset.at(2)))
        let cube-values = cube-points.map(function)
        for tetra in _tetrahedra {
          let tetra-points = tetra.map(index => cube-points.at(index))
          let tetra-values = tetra.map(index => cube-values.at(index))
          let hits = _intersections(tetra-points, tetra-values, level)
          if hits.len() >= 3 {
            let ordered = _ordered(function, hits)
            let names = ()
            for (local-index, point) in ordered.enumerate() {
              let key = _vertex-key(point, weld-tolerance)
              let name = if weld and key in welded { welded.at(key) } else {
                let default-name = prefix + "-v-" + str(vertex-index)
                vertex-index += 1
                let declaration = point-declarations.from-policy(
                  default-name,
                  point,
                  "implicit-edge-intersection",
                  deps: controls.order,
                  parameters: (
                    cell: (i, j, k),
                    tetrahedron: tetra,
                    local-index: local-index,
                    level: level,
                    weld-key: key,
                    field: prefix,
                  ),
                  policy: point-policy,
                  context: (vertex-index: vertex-index - 1, cell: (i, j, k), tetrahedron: tetra, local-index: local-index),
                )
                let created = declaration.name
                if created in points { panic("sang-3d.implicit: duplicate generated point name " + created) }
                points.insert(created, point)
                point-definitions.insert(created, declaration.definition)
                point-options.insert(created, declaration.options)
                point-order.push(created)
                if weld { welded.insert(key, created) }
                created
              }
              names.push(name)
            }
            names = _unique-names(names)
            if names.len() >= 3 {
              face-index += 1
              let face-id = prefix + "-face-" + str(face-index)
              if faces { face-objects.push(objects.face(names, id: face-id, role: role, cull: cull, tags: tags + ("implicit-face", "faces"))) }
              if mesh {
                for edge-index in range(names.len()) {
                  edge-objects.push(objects.segment(
                    names.at(edge-index), names.at(calc.rem-euclid(edge-index + 1, names.len())),
                    id: face-id + "-edge-" + str(edge-index), role: role, faces: (face-id,), tags: tags + ("implicit-edge", "edges"),
                  ))
                }
              }
            }
          }
        }
      }
    }
  }
  let point-objects = ()
  for name in point-order {
    let opts = point-options.at(name, default: (:))
    let show-marker = opts.at("show-point", default: false)
    let show-label = opts.at("show-label", default: false)
    if show-marker or show-label {
      point-objects.push(objects.point(name, role: opts.at("role", default: role), point: show-marker, label: if show-label { auto } else { false }, tags: tags + ("implicit-point",)))
    }
  }
  models.model(
    points: points,
    definitions: point-definitions,
    point-options: point-options,
    point-order: point-order,
    objects: face-objects + edge-objects + point-objects,
    meta: (
      kind: "implicit-surface",
      convex: false,
      bounds: bounds,
      resolution: resolution,
      level: level,
      face-ids: face-objects.map(face => face.id),
      edges: edge-objects.map(edge => (edge.a, edge.b)),
      welded: weld,
      weld-tolerance: weld-tolerance,
      vertex-count: points.len(),
    ),
  )
}

#let from-field(field, resolution: (14, 14, 14), level: 0, prefix: "IM", role: "surface", faces: true, mesh: false, cull: false, tags: (), weld: true, weld-tolerance: 1e-6, point-policy: auto) = surface(
  field.function,
  bounds: field.bounds,
  resolution: resolution,
  level: level,
  prefix: prefix,
  role: role,
  faces: faces,
  mesh: mesh,
  cull: cull,
  tags: tags + ("field-surface", field.name),
  weld: weld,
  weld-tolerance: weld-tolerance,
  control-points: field.at("control-points", default: ()),
  point-policy: point-policy,
)
