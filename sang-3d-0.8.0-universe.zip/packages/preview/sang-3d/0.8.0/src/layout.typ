#import "core.typ" as core
#import "camera.typ" as cameras

#let _p2(projected) = (projected.at(0), projected.at(1))
#let _sub2(a, b) = (a.at(0) - b.at(0), a.at(1) - b.at(1))
#let _dot2(a, b) = a.at(0) * b.at(0) + a.at(1) * b.at(1)
#let _norm2(v) = calc.sqrt(_dot2(v, v))
#let _unit2(v, fallback: (1, 0)) = { let length = _norm2(v); if length <= 1e-8 { fallback } else { (v.at(0) / length, v.at(1) / length) } }
#let _distance2(a, b) = _norm2(_sub2(a, b))


#let _position-vector(value) = {
  if value == auto or value == none { none }
  else if type(value) == array { value }
  else if value == "right" { (1, 0) }
  else if value == "left" { (-1, 0) }
  else if value == "top" { (0, 1) }
  else if value == "bottom" { (0, -1) }
  else if value == "top-right" { (1, 1) }
  else if value == "top-left" { (-1, 1) }
  else if value == "bottom-right" { (1, -1) }
  else if value == "bottom-left" { (-1, -1) }
  else { panic("sang-3d: unknown label-position " + str(value)) }
}
#let point-segment-distance(point, a, b) = {
  let ab = _sub2(b, a)
  let denominator = _dot2(ab, ab)
  if denominator <= 1e-10 { return _distance2(point, a) }
  let t = calc.max(0, calc.min(1, _dot2(_sub2(point, a), ab) / denominator))
  let closest = (a.at(0) + ab.at(0) * t, a.at(1) + ab.at(1) * t)
  _distance2(point, closest)
}

#let _label-size(object, options) = {
  let raw = options.at("label-content", default: if object.label == auto { object.name } else { object.label })
  let length = calc.min(12, repr(raw).len())
  (0.12 + length * 0.045, 0.20)
}
#let _box(center, size) = (left: center.at(0) - size.at(0)/2, right: center.at(0) + size.at(0)/2, bottom: center.at(1) - size.at(1)/2, top: center.at(1) + size.at(1)/2)
#let _overlap(a, b) = calc.max(0, calc.min(a.right, b.right) - calc.max(a.left, b.left)) * calc.max(0, calc.min(a.top, b.top) - calc.max(a.bottom, b.bottom))

#let global-label-layout(fig, cam, style, iterations: 4, avoid-edges: true, avoid-points: true) = {
  let label-style = style.label
  let point-objects = fig.objects.filter(object => object.visible and object.kind == "point" and object.label != false and fig.point-options.at(object.name, default: (:)).at("show-label", default: true))
  let projected-points = (:)
  for object in point-objects { projected-points.insert(object.name, _p2(cameras.project(cam, fig.points.at(object.name)))) }
  let values = projected-points.values()
  let center = if values.len() == 0 { (0, 0) } else { (values.map(point => point.at(0)).sum()/values.len(), values.map(point => point.at(1)).sum()/values.len()) }
  let projected-edges = fig.objects.filter(object => object.visible and object.kind == "segment").map(object => {
    let a = if type(object.a) == str { fig.points.at(object.a) } else { object.a }
    let b = if type(object.b) == str { fig.points.at(object.b) } else { object.b }
    (_p2(cameras.project(cam, a)), _p2(cameras.project(cam, b)))
  })
  let ordered = point-objects.sorted(key: object => -fig.point-options.at(object.name, default: (:)).at("label-priority", default: 0))
  let choices = (:)
  let offsets = (:)
  for object in ordered {
    let options = fig.point-options.at(object.name, default: (:))
    let explicit = options.at("label-offset", default: none)
    if explicit != none { offsets.insert(object.name, explicit); choices.insert(object.name, -1) }
    else {
      let outward = _unit2(_sub2(projected-points.at(object.name), center), fallback: (1, 1))
      let requested-position = _position-vector(options.at("label-position", default: auto))
      let candidates = if requested-position == none { options.at("label-candidates", default: label-style.candidates) } else { (requested-position,) }
      let best-index = 0
      let best-dot = -1e20
      for (index, candidate) in candidates.enumerate() {
        let score = _dot2(_unit2(candidate), outward)
        if score > best-dot { best-index = index; best-dot = score }
      }
      choices.insert(object.name, best-index)
      let direction = _unit2(candidates.at(best-index))
      let distance = options.at("label-distance", default: label-style.offset)
      offsets.insert(object.name, (direction.at(0)*distance, direction.at(1)*distance))
    }
  }
  let score-choice(object, candidate) = {
    let point = projected-points.at(object.name)
    let options = fig.point-options.at(object.name, default: (:))
    let direction = _unit2(candidate, fallback: (1, 1))
    let distance = options.at("label-distance", default: label-style.offset)
    let location = (point.at(0) + direction.at(0)*distance, point.at(1) + direction.at(1)*distance)
    let score = _dot2(direction, _unit2(_sub2(point, center), fallback: (1, 1))) * 1.2
    let box = _box(location, _label-size(object, options))
    for other in ordered {
      if other.name != object.name and other.name in offsets {
        let other-point = projected-points.at(other.name)
        let other-offset = offsets.at(other.name)
        let other-options = fig.point-options.at(other.name, default: (:))
        let other-location = (other-point.at(0)+other-offset.at(0), other-point.at(1)+other-offset.at(1))
        score -= _overlap(box, _box(other-location, _label-size(other, other-options))) * 120
      }
    }
    if avoid-points {
      for (name, other) in projected-points.pairs() {
        if name != object.name {
          let gap = _distance2(location, other)
          if gap < label-style.point-clearance { score -= (label-style.point-clearance-gap)*12 }
        }
      }
    }
    if avoid-edges {
      for edge in projected-edges {
        let gap = point-segment-distance(location, edge.at(0), edge.at(1))
        if gap < label-style.edge-clearance { score -= (label-style.edge-clearance-gap)*10 }
      }
    }
    score
  }
  for pass in range(calc.max(1, iterations)) {
    for object in ordered {
      let options = fig.point-options.at(object.name, default: (:))
      if options.at("label-offset", default: none) == none {
        let requested-position = _position-vector(options.at("label-position", default: auto))
        let candidates = if requested-position == none { options.at("label-candidates", default: label-style.candidates) } else { (requested-position,) }
        let best-index = choices.at(object.name)
        let best-score = -1e20
        for (index, candidate) in candidates.enumerate() {
          let score = score-choice(object, candidate)
          if score > best-score { best-index = index; best-score = score }
        }
        choices.insert(object.name, best-index)
        let direction = _unit2(candidates.at(best-index))
        let distance = options.at("label-distance", default: label-style.offset)
        offsets.insert(object.name, (direction.at(0)*distance, direction.at(1)*distance))
      }
    }
  }
  offsets
}

#let auto-label-offsets(fig, cam, style, mode: "global", iterations: 4) = if mode == "greedy" {
  global-label-layout(fig, cam, style, iterations: 1)
} else { global-label-layout(fig, cam, style, iterations: iterations) }

#let leader-records(fig, cam, offsets, threshold: 0.34) = {
  let output = ()
  for (name, offset) in offsets.pairs() {
    if _norm2(offset) >= threshold {
      let point = _p2(cameras.project(cam, fig.points.at(name)))
      output.push((name: name, a: point, b: (point.at(0)+offset.at(0)*0.78, point.at(1)+offset.at(1)*0.78)))
    }
  }
  output
}
