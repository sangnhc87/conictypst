// Publication-oriented materials and face styling.
#import "styles.typ" as styles
#import "model.typ" as models

#let material(
  name: "custom",
  fill: auto,
  edge: auto,
  ambient: auto,
  diffuse: auto,
  contrast: auto,
  specular: auto,
  shininess: auto,
  rim: auto,
  tone-steps: auto,
  opacity: auto,
  shading: auto,
  light-direction: auto,
  double-sided: false,
  hidden-lines: auto,
) = {
  let patch = (face: (:), roles: (:), visibility: (:))
  if ambient != auto { patch.face.insert("ambient", ambient) }
  if diffuse != auto { patch.face.insert("diffuse", diffuse) }
  if contrast != auto { patch.face.insert("contrast", contrast) }
  if specular != auto { patch.face.insert("specular", specular) }
  if shininess != auto { patch.face.insert("shininess", shininess) }
  if rim != auto { patch.face.insert("rim", rim) }
  if tone-steps != auto { patch.face.insert("tone-steps", tone-steps) }
  if opacity != auto { patch.face.insert("opacity", opacity) }
  if shading != auto { patch.face.insert("shading", shading) }
  if light-direction != auto { patch.face.insert("light-direction", light-direction) }
  if hidden-lines != auto { patch.visibility.insert("hidden-lines", hidden-lines) }
  if fill != auto {
    patch.roles.insert("main", (fill: fill))
    patch.roles.insert("surface", (fill: fill))
  }
  if edge != auto {
    let main = patch.roles.at("main", default: (:))
    let surface = patch.roles.at("surface", default: (:))
    patch.roles.insert("main", styles.deep-merge(main, (stroke: edge)))
    patch.roles.insert("surface", styles.deep-merge(surface, (stroke: edge)))
  }
  (kind: "sang-3d-material", name: name, style: patch, double-sided: double-sided)
}

#let preset(name: "textbook", color: styles.palette.blue) = {
  if name == "clay" {
    material(name: name, fill: color.transparentize(18%), ambient: 0.68, diffuse: 0.32, contrast: 1.1, tone-steps: 0)
  } else if name == "matte" {
    material(name: name, fill: color.transparentize(8%), ambient: 0.78, diffuse: 0.22, contrast: 0.9)
  } else if name == "glass" {
    material(name: name, fill: color.transparentize(86%), ambient: 0.82, diffuse: 0.12, specular: 0.55, shininess: 36, rim: 0.16, opacity: 0.45, double-sided: true, hidden-lines: "solid")
  } else if name == "xray" {
    material(name: name, fill: color.transparentize(94%), ambient: 1, diffuse: 0, opacity: 0.28, double-sided: true, hidden-lines: "solid")
  } else if name == "blueprint" {
    material(name: name, fill: rgb("2563EB").transparentize(92%), edge: (paint: rgb("1D4ED8"), thickness: 0.72pt), ambient: 1, diffuse: 0, shading: false)
  } else if name == "technical" {
    material(name: name, fill: none, edge: (paint: styles.palette.ink, thickness: 0.72pt), shading: false, hidden-lines: "dashed")
  } else if name == "metal" {
    material(name: name, fill: color.transparentize(12%), ambient: 0.55, diffuse: 0.25, specular: 0.65, shininess: 48, rim: 0.08, contrast: 1.15)
  } else if name == "toon" {
    material(name: name, fill: color.transparentize(15%), ambient: 0.64, diffuse: 0.36, tone-steps: 4, contrast: 1.25)
  } else if name == "section" {
    material(name: name, fill: color.transparentize(72%), edge: (paint: color, thickness: 1.25pt), ambient: 0.9, diffuse: 0.1)
  } else if name == "wireframe" {
    material(name: name, fill: none, edge: (paint: styles.palette.ink, thickness: 0.65pt), shading: false)
  } else {
    material(name: name, fill: color.transparentize(88%), ambient: 0.84, diffuse: 0.16)
  }
}


#let _matches(object, selector) = {
  if selector == none { return true }
  if type(selector) == function { return selector(object) }
  if type(selector) == str { return object.id == selector or object.tags.contains(selector) }
  if type(selector) != dictionary { return false }
  let ok = true
  if "id" in selector { ok = ok and object.id == selector.id }
  if "kind" in selector { ok = ok and object.kind == selector.kind }
  if "role" in selector { ok = ok and object.role == selector.role }
  if "tag" in selector { ok = ok and object.tags.contains(selector.tag) }
  ok
}

#let apply(fig, value, selector: none) = {
  let actual = if type(value) == str { preset(value) } else { value }
  if selector == none {
    let output = models.with-styles(fig, styles.deep-merge(fig.styles, actual.style))
    if actual.double-sided { output = models.patch-kind(output, "face", (cull: false)) }
    output
  } else {
    let output = (: ..fig, objects: fig.objects.map(object => if _matches(object, selector) {
      let options = object.options
      let previous = options.at("style", default: (:))
      options = (: ..options, style: styles.deep-merge(previous, actual.style))
      if actual.double-sided and object.kind == "face" { (: ..object, options: options, cull: false) }
      else { (: ..object, options: options) }
    } else { object }))
    output
  }
}


#let layered(base, layers) = {
  let actual = if type(base) == str { preset(base) } else { base }
  let style = actual.style
  let double-sided = actual.double-sided
  for layer in layers {
    let value = if type(layer) == str { preset(layer) } else { layer }
    style = styles.deep-merge(style, value.style)
    double-sided = double-sided or value.double-sided
  }
  (kind: "sang-3d-material", name: actual.name + "-layered", style: style, double-sided: double-sided)
}

#let library(color: styles.palette.blue) = (
  textbook: preset("textbook", color: color),
  clay: preset("clay", color: color),
  matte: preset("matte", color: color),
  glass: preset("glass", color: color),
  xray: preset("xray", color: color),
  metal: preset("metal", color: color),
  toon: preset("toon", color: color),
  blueprint: preset("blueprint", color: color),
  technical: preset("technical", color: color),
  wireframe: preset("wireframe", color: color),
  section: preset("section", color: color),
)
