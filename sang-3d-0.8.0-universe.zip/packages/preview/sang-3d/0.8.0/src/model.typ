#import "core.typ" as core
#import "transform.typ" as transforms
#import "definitions.typ" as definitions
#import "points.typ" as point-declarations

#let _materialize-ref(ref, name, points, registry, provenance, strict: true) = {
  if type(ref) == str { return (ref: ref, points: points, definitions: registry) }
  if strict {
    panic("sang-3d: anonymous coordinate in " + str(provenance.at("object", default: "object")) + "." + provenance.at("field", default: "point") + "; declare the point before using it")
  }
  let actual = name
  let suffix = 1
  while actual in points {
    actual = name + "-" + str(suffix)
    suffix += 1
  }
  points.insert(actual, ref)
  registry.insert(actual, definitions.materialized(
    ref,
    object: provenance.at("object", default: none),
    field: provenance.at("field", default: none),
    index: provenance.at("index", default: none),
  ))
  (ref: actual, points: points, definitions: registry)
}

#let _materialize-objects(raw-points, raw-definitions, raw-objects, source: "model", strict: true) = {
  let points = (: ..raw-points)
  let registry = definitions.ensure(points, supplied: raw-definitions, source: source, strict: strict)
  let objects = ()
  for (object-index, raw) in raw-objects.enumerate() {
    let object = raw
    let stem = "__" + object.kind + "-" + str(object-index)
    if object.kind == "segment" {
      let ra = _materialize-ref(object.a, stem + "-a", points, registry, (object: object.id, field: "a"), strict: strict)
      points = ra.points
      registry = ra.definitions
      let rb = _materialize-ref(object.b, stem + "-b", points, registry, (object: object.id, field: "b"), strict: strict)
      points = rb.points
      registry = rb.definitions
      object = (: ..object, a: ra.ref, b: rb.ref)
    } else if object.kind == "polyline" or object.kind == "face" {
      let refs = ()
      for (index, ref) in object.points.enumerate() {
        let result = _materialize-ref(ref, stem + "-point-" + str(index), points, registry, (object: object.id, field: "points", index: index), strict: strict)
        points = result.points
        registry = result.definitions
        refs.push(result.ref)
      }
      object = (: ..object, points: refs)
    } else if object.kind == "label" {
      let result = _materialize-ref(object.at, stem + "-at", points, registry, (object: object.id, field: "at"), strict: strict)
      points = result.points
      registry = result.definitions
      object = (: ..object, at: result.ref)
    } else if object.kind == "circle3d" or object.kind == "arc3d" or object.kind == "plane-patch" {
      let result = _materialize-ref(object.center, stem + "-center", points, registry, (object: object.id, field: "center"), strict: strict)
      points = result.points
      registry = result.definitions
      object = (: ..object, center: result.ref)
    } else if object.kind == "angle3d" or object.kind == "right-angle3d" {
      let ro = _materialize-ref(object.origin, stem + "-origin", points, registry, (object: object.id, field: "origin"), strict: strict)
      points = ro.points
      registry = ro.definitions
      let ra = _materialize-ref(object.a, stem + "-a", points, registry, (object: object.id, field: "a"), strict: strict)
      points = ra.points
      registry = ra.definitions
      let rb = _materialize-ref(object.b, stem + "-b", points, registry, (object: object.id, field: "b"), strict: strict)
      points = rb.points
      registry = rb.definitions
      object = (: ..object, origin: ro.ref, a: ra.ref, b: rb.ref)
    } else if object.kind == "dimension3d" or object.kind == "ticks3d" {
      let ra = _materialize-ref(object.a, stem + "-a", points, registry, (object: object.id, field: "a"), strict: strict)
      points = ra.points
      registry = ra.definitions
      let rb = _materialize-ref(object.b, stem + "-b", points, registry, (object: object.id, field: "b"), strict: strict)
      points = rb.points
      registry = rb.definitions
      object = (: ..object, a: ra.ref, b: rb.ref)
    } else if object.kind == "dihedral3d" {
      let result = _materialize-ref(object.origin, stem + "-origin", points, registry, (object: object.id, field: "origin"), strict: strict)
      points = result.points
      registry = result.definitions
      object = (: ..object, origin: result.ref)
    } else if object.kind == "custom" {
      let refs = ()
      for (index, ref) in object.bounds.enumerate() {
        let result = _materialize-ref(ref, stem + "-bound-" + str(index), points, registry, (object: object.id, field: "bounds", index: index), strict: strict)
        points = result.points
        registry = result.definitions
        refs.push(result.ref)
      }
      object = (: ..object, bounds: refs)
    }
    objects.push(object)
  }
  (points: points, definitions: registry, objects: objects)
}

#let model(
  points: (:),
  definitions: auto,
  objects: (),
  point-options: (:),
  point-order: auto,
  meta: (:),
  styles: (:),
  strict-points: true,
  allow-legacy-materialization: false,
) = {
  let strict = strict-points and not allow-legacy-materialization
  let normalized = _materialize-objects(points, definitions, objects, source: meta.at("kind", default: "model"), strict: strict)
  let order = if point-order == auto { normalized.points.keys() } else { point-order }
  (
    kind: "sang-3d-model",
    schema: "sang-3d/model@4",
    points: normalized.points,
    definitions: normalized.definitions,
    objects: normalized.objects,
    point-options: point-options,
    point-order: order,
    meta: (: ..meta, strict-points: strict-points, allow-legacy-materialization: allow-legacy-materialization),
    styles: styles,
  )
}

// Preferred public constructor: all point declarations are listed first.
#let figure(
  points: (),
  objects: (),
  meta: (:),
  styles: (:),
  strict-order: true,
) = {
  let declared = point-declarations.declare(points, strict-order: strict-order)
  model(
    points: declared.points,
    definitions: declared.definitions,
    point-options: declared.point-options,
    point-order: declared.order,
    objects: objects,
    meta: meta,
    styles: styles,
    strict-points: true,
  )
}

#let point-at(fig, name, default: none) = fig.points.at(name, default: default)
#let definition-at(fig, name, default: none) = fig.definitions.at(name, default: default)
#let point-record(fig, name, default: none) = {
  if name not in fig.points { return default }
  let order = fig.at("point-order", default: fig.points.keys())
  let index = order.position(item => item == name)
  (name: name, coordinate: fig.points.at(name), definition: fig.definitions.at(name), options: fig.point-options.at(name, default: (:)), order: index)
}
#let point-names(fig) = fig.points.keys()
#let points-array(fig) = fig.points.values()
#let object-at(fig, id, default: none) = {
  let found = fig.objects.find(object => object.id == id)
  if found == none { default } else { found }
}
#let objects-with-tag(fig, tag) = fig.objects.filter(object => object.tags.contains(tag))
#let objects-of-kind(fig, kind) = fig.objects.filter(object => object.kind == kind)
#let objects-with-role(fig, role) = fig.objects.filter(object => object.role == role)

#let with-point(fig, name, coordinate, definition: auto) = {
  if fig.meta.at("strict-points", default: true) and definition == auto {
    panic("sang-3d.with-point: point " + name + " needs an explicit definition")
  }
  let points = fig.points
  let registry = fig.definitions
  points.insert(name, coordinate)
  registry.insert(name, if definition == auto { definitions.given(coordinate) } else { (: ..definition, coordinate: coordinate) })
  let order = fig.at("point-order", default: fig.points.keys())
  if not order.contains(name) { order.push(name) }
  (: ..fig, points: points, definitions: registry, point-order: order)
}

#let with-declared-point(fig, declaration) = {
  if type(declaration) != dictionary or declaration.at("kind", default: none) != "sang-3d-point-declaration" {
    panic("sang-3d.with-declared-point: expected a point declaration")
  }
  for dep in declaration.definition.at("deps", default: ()) {
    if type(dep) == str and dep not in fig.points {
      panic("sang-3d.with-declared-point: " + declaration.name + " depends on undeclared point " + dep)
    }
  }
  let output = with-point(fig, declaration.name, declaration.coordinate, definition: declaration.definition)
  with-point-option(output, declaration.name, declaration.options)
}

#let with-points(fig, additions, definitions-map: auto) = {
  let output = fig
  for (name, coordinate) in additions {
    let definition = if definitions-map == auto { auto } else { definitions-map.at(name, default: auto) }
    output = with-point(output, name, coordinate, definition: definition)
  }
  output
}
#let without-point(fig, name) = {
  let points = fig.points
  let registry = fig.definitions
  let options = fig.point-options
  points.remove(name)
  registry.remove(name)
  options.remove(name)
  let order = fig.at("point-order", default: fig.points.keys()).filter(item => item != name)
  (: ..fig, points: points, definitions: registry, point-options: options, point-order: order)
}
#let alias-point(fig, alias, source) = with-point(fig, alias, point-at(fig, source), definition: definitions.alias(source, coordinate: point-at(fig, source)))
#let with-object(fig, object) = {
  let normalized = _materialize-objects(fig.points, fig.definitions, (object,), source: "with-object", strict: fig.meta.at("strict-points", default: true))
  (: ..fig, points: normalized.points, definitions: normalized.definitions, objects: fig.objects + normalized.objects)
}
#let with-objects(fig, additions) = {
  let normalized = _materialize-objects(fig.points, fig.definitions, additions, source: "with-objects", strict: fig.meta.at("strict-points", default: true))
  (: ..fig, points: normalized.points, definitions: normalized.definitions, objects: fig.objects + normalized.objects)
}
#let without-objects(fig, predicate) = (: ..fig, objects: fig.objects.filter(object => not predicate(object)))
#let with-styles(fig, additions) = (: ..fig, styles: (: ..fig.styles, ..additions))
#let with-meta(fig, additions) = (: ..fig, meta: (: ..fig.meta, ..additions))

#let with-point-option(fig, name, options) = {
  let all-options = fig.point-options
  let previous = all-options.at(name, default: (:))
  all-options.insert(name, (: ..previous, ..options))
  (: ..fig, point-options: all-options)
}
#let with-point-options(fig, additions) = {
  let output = fig
  for (name, options) in additions { output = with-point-option(output, name, options) }
  output
}

#let _matches(object, selector) = {
  if selector == none { return true }
  if type(selector) == function { return selector(object) }
  if type(selector) == str { return object.id == selector or object.tags.contains(selector) }
  if type(selector) != dictionary { return false }
  let ok = true
  if "id" in selector { ok = ok and object.id == selector.id }
  if "kind" in selector { ok = ok and object.kind == selector.kind }
  if "role" in selector { ok = ok and object.role == selector.role }
  if "tag" in selector { ok = ok and object.tags.contains(selector.tag) }
  if "visible" in selector { ok = ok and object.visible == selector.visible }
  ok
}

#let select(fig, selector: none) = fig.objects.filter(object => _matches(object, selector))
#let patch(fig, selector, changes) = (: ..fig, objects: fig.objects.map(object => if _matches(object, selector) {
  (: ..object, ..changes)
} else { object }))
#let patch-object(fig, id, changes) = patch(fig, (id: id), changes)
#let patch-tag(fig, tag, changes) = patch(fig, (tag: tag), changes)
#let patch-kind(fig, kind, changes) = patch(fig, (kind: kind), changes)
#let patch-role(fig, role, changes) = patch(fig, (role: role), changes)
#let hide(fig, selector) = patch(fig, selector, (visible: false))
#let show(fig, selector) = patch(fig, selector, (visible: true))
#let remove(fig, selector) = without-objects(fig, object => _matches(object, selector))
#let hide-object(fig, id) = hide(fig, (id: id))
#let show-object(fig, id) = show(fig, (id: id))

#let _transform-ref(ref, operation) = if type(ref) == str { ref } else {
  if type(operation) == function { operation(ref) } else { transforms.apply-point(operation, ref) }
}
#let _transform-vector(vector, operation) = if type(operation) == function { vector } else {
  core.unit3(transforms.apply-vector(operation, vector), fallback: vector)
}
#let _vector-scale(vector, operation) = if type(operation) == function { 1 } else {
  core.norm3(transforms.apply-vector(operation, core.unit3(vector)))
}
#let _average-scale(operation) = if type(operation) == function { 1 } else {
  (_vector-scale((1, 0, 0), operation) + _vector-scale((0, 1, 0), operation) + _vector-scale((0, 0, 1), operation)) / 3
}
#let _plane-transform(normal, preferred-u, operation) = {
  if type(operation) == function {
    return (normal: normal, u: preferred-u, scale-u: 1, scale-v: 1)
  }
  let basis = core.basis-from-normal(normal, preferred-u: preferred-u)
  let transformed-u = transforms.apply-vector(operation, basis.u)
  let transformed-v = transforms.apply-vector(operation, basis.v)
  (
    normal: core.unit3(core.cross3(transformed-u, transformed-v), fallback: normal),
    u: core.unit3(transformed-u, fallback: basis.u),
    scale-u: core.norm3(transformed-u),
    scale-v: core.norm3(transformed-v),
  )
}

#let transform(fig, operation) = {
  let points = (:)
  for (name, point) in fig.points {
    points.insert(name, if type(operation) == function { operation(point) } else { transforms.apply-point(operation, point) })
  }
  let objects = fig.objects.map(object => {
    if object.kind == "segment" {
      (: ..object, a: _transform-ref(object.a, operation), b: _transform-ref(object.b, operation))
    } else if object.kind == "polyline" or object.kind == "face" {
      (: ..object, points: object.points.map(ref => _transform-ref(ref, operation)))
    } else if object.kind == "label" {
      (: ..object, at: _transform-ref(object.at, operation))
    } else if object.kind == "circle3d" or object.kind == "arc3d" {
      let preferred = if object.kind == "arc3d" or object.start-direction != auto { object.start-direction } else { auto }
      let plane-data = _plane-transform(object.normal, preferred, operation)
      (: ..object,
        center: _transform-ref(object.center, operation),
        normal: plane-data.normal,
        radius: object.radius * (plane-data.scale-u + plane-data.scale-v) / 2,
        start-direction: if preferred == auto { auto } else { plane-data.u },
      )
    } else if object.kind == "plane-patch" {
      let plane-data = _plane-transform(object.normal, object.u, operation)
      (: ..object,
        center: _transform-ref(object.center, operation),
        normal: plane-data.normal,
        u: if object.u == auto { auto } else { plane-data.u },
        width: object.width * plane-data.scale-u,
        height: object.height * plane-data.scale-v,
      )
    } else if object.kind == "angle3d" {
      (: ..object,
        origin: _transform-ref(object.origin, operation),
        a: _transform-ref(object.a, operation),
        b: _transform-ref(object.b, operation),
        radius: object.radius * _average-scale(operation),
      )
    } else if object.kind == "right-angle3d" {
      (: ..object,
        origin: _transform-ref(object.origin, operation),
        a: _transform-ref(object.a, operation),
        b: _transform-ref(object.b, operation),
        size: object.size * _average-scale(operation),
      )
    } else if object.kind == "dimension3d" {
      (: ..object,
        a: _transform-ref(object.a, operation),
        b: _transform-ref(object.b, operation),
        offset: _transform-vector(object.offset, operation),
      )
    } else if object.kind == "ticks3d" {
      (: ..object,
        a: _transform-ref(object.a, operation),
        b: _transform-ref(object.b, operation),
        normal: if object.normal == auto { auto } else { _transform-vector(object.normal, operation) },
        size: if object.size == auto { auto } else { object.size * _average-scale(operation) },
        spacing: object.spacing * _average-scale(operation),
      )
    } else if object.kind == "dihedral3d" {
      (: ..object,
        origin: _transform-ref(object.origin, operation),
        edge-direction: _transform-vector(object.edge-direction, operation),
        normal-a: _transform-vector(object.normal-a, operation),
        normal-b: _transform-vector(object.normal-b, operation),
        radius: object.radius * _average-scale(operation),
      )
    } else if object.kind == "custom" {
      (: ..object, bounds: object.bounds.map(point => _transform-ref(point, operation)))
    } else { object }
  })
  let registry = (:)
  for (name, point) in points {
    let previous = fig.definitions.at(name, default: definitions.given(fig.points.at(name)))
    let parameters = previous.at("parameters", default: (:))
    let history = parameters.at("transform-history", default: ()) + ((operation: "model-transform"),)
    parameters.insert("transform-history", history)
    registry.insert(name, (: ..previous, coordinate: point, parameters: parameters))
  }
  (: ..fig, points: points, definitions: registry, objects: objects)
}

#let translate(fig, delta) = transform(fig, transforms.translation(delta))
#let scale(fig, factors, origin: (0, 0, 0)) = transform(fig, transforms.around(transforms.scaling(factors), origin))
#let rotate-x(fig, angle, origin: (0, 0, 0)) = transform(fig, transforms.around(transforms.rotation-x(angle), origin))
#let rotate-y(fig, angle, origin: (0, 0, 0)) = transform(fig, transforms.around(transforms.rotation-y(angle), origin))
#let rotate-z(fig, angle, origin: (0, 0, 0)) = transform(fig, transforms.around(transforms.rotation-z(angle), origin))
#let rotate-axis(fig, axis, angle, origin: (0, 0, 0)) = transform(fig, transforms.around(transforms.rotation-axis(axis, angle), origin))
#let rotate-around(fig, ax, angle) = transform(fig, transforms.rotation-line(ax, angle))
#let rotate-through(fig, a, b, angle) = rotate-around(fig, core.axis-through(a, b), angle)

#let _rename-ref(ref, prefix) = if type(ref) == str { prefix + ref } else { ref }
#let prefixed(fig, prefix) = {
  if prefix == "" { return fig }
  let points = (:)
  for (name, point) in fig.points { points.insert(prefix + name, point) }
  let objects = fig.objects.map(object => {
    let id = if object.id == none { none } else { prefix + object.id }
    if object.kind == "point" {
      (: ..object, id: id, name: prefix + object.name)
    } else if object.kind == "segment" {
      (: ..object,
        id: id,
        a: _rename-ref(object.a, prefix),
        b: _rename-ref(object.b, prefix),
        faces: object.faces.map(face-id => prefix + face-id),
      )
    } else if object.kind == "polyline" or object.kind == "face" {
      (: ..object, id: id, points: object.points.map(ref => _rename-ref(ref, prefix)))
    } else if object.kind == "label" {
      (: ..object, id: id, at: _rename-ref(object.at, prefix))
    } else if object.kind == "circle3d" or object.kind == "arc3d" or object.kind == "plane-patch" {
      (: ..object, id: id, center: _rename-ref(object.center, prefix))
    } else if object.kind == "angle3d" or object.kind == "right-angle3d" {
      (: ..object,
        id: id,
        origin: _rename-ref(object.origin, prefix),
        a: _rename-ref(object.a, prefix),
        b: _rename-ref(object.b, prefix),
      )
    } else if object.kind == "dimension3d" or object.kind == "ticks3d" {
      (: ..object, id: id, a: _rename-ref(object.a, prefix), b: _rename-ref(object.b, prefix))
    } else if object.kind == "dihedral3d" {
      (: ..object, id: id, origin: _rename-ref(object.origin, prefix))
    } else { (: ..object, id: id) }
  })
  let definitions-map = definitions.renamed(fig.definitions, prefix)
  let point-options = (:)
  for (name, options) in fig.point-options { point-options.insert(prefix + name, options) }
  let edges = fig.meta.at("edges", default: ()).map(edge => (_rename-ref(edge.at(0), prefix), _rename-ref(edge.at(1), prefix)))
  let face-ids = fig.meta.at("face-ids", default: ()).map(id => prefix + id)
  (: ..fig, points: points, definitions: definitions-map, objects: objects, point-options: point-options, point-order: fig.at("point-order", default: fig.points.keys()).map(name => prefix + name), meta: (: ..fig.meta, edges: edges, face-ids: face-ids))
}

#let merge(a, b, prefix: "") = {
  let right = prefixed(b, prefix)
  let points = a.points
  for (name, point) in right.points {
    if name in points { panic("sang-3d.merge: duplicate point name " + name) }
    points.insert(name, point)
  }
  let definitions-map = a.definitions
  for (name, item) in right.definitions {
    if name in definitions-map { panic("sang-3d.merge: duplicate point definition " + name) }
    definitions-map.insert(name, item)
  }
  let point-options = a.point-options
  for (name, options) in right.point-options { point-options.insert(name, options) }
  let left-ids = a.objects.filter(object => object.id != none).map(object => object.id)
  for object in right.objects {
    if object.id != none and left-ids.contains(object.id) { panic("sang-3d.merge: duplicate object id " + object.id) }
  }
  let edges = a.meta.at("edges", default: ()) + right.meta.at("edges", default: ())
  model(
    points: points,
    definitions: definitions-map,
    objects: a.objects + right.objects,
    point-options: point-options,
    point-order: a.at("point-order", default: a.points.keys()) + right.at("point-order", default: right.points.keys()),
    meta: (: ..a.meta, edges: edges),
    styles: (: ..a.styles, ..right.styles),
  )
}

#let merge-many(figures, prefixes: auto) = {
  let output = model()
  for (index, fig) in figures.enumerate() {
    let prefix = if prefixes == auto { "" } else { prefixes.at(index) }
    output = merge(output, fig, prefix: prefix)
  }
  output
}

#let bounds(fig) = {
  let extra = ()
  for object in fig.objects {
    if object.kind == "custom" { extra += object.bounds.map(ref => if type(ref) == str { fig.points.at(ref) } else { ref }) }
    if object.kind == "circle3d" or object.kind == "arc3d" {
      let center = if type(object.center) == str { fig.points.at(object.center) } else { object.center }
      let r = object.radius
      extra += ((core.x3(center)-r, core.y3(center)-r, core.z3(center)-r), (core.x3(center)+r, core.y3(center)+r, core.z3(center)+r))
    }
    if object.kind == "dimension3d" or object.kind == "ticks3d" {
      let a = if type(object.a) == str { fig.points.at(object.a) } else { object.a }
      let b = if type(object.b) == str { fig.points.at(object.b) } else { object.b }
      extra += (a, b)
      if object.kind == "dimension3d" { extra += (core.add3(a, object.offset), core.add3(b, object.offset)) }
    }
    if object.kind == "dihedral3d" {
      let origin = if type(object.origin) == str { fig.points.at(object.origin) } else { object.origin }
      let r = object.radius
      extra += ((core.x3(origin)-r, core.y3(origin)-r, core.z3(origin)-r), (core.x3(origin)+r, core.y3(origin)+r, core.z3(origin)+r))
    }
  }
  core.bounds3(fig.points.values() + extra)
}
#let center(fig) = bounds(fig).center

#let _point-refs(object) = {
  if object.kind == "point" { (object.name,) }
  else if object.kind == "segment" { (object.a, object.b) }
  else if object.kind == "face" or object.kind == "polyline" { object.points }
  else if object.kind == "label" { (object.at,) }
  else if object.kind == "circle3d" or object.kind == "arc3d" or object.kind == "plane-patch" { (object.center,) }
  else if object.kind == "angle3d" or object.kind == "right-angle3d" { (object.origin, object.a, object.b) }
  else if object.kind == "dimension3d" or object.kind == "ticks3d" { (object.a, object.b) }
  else if object.kind == "dihedral3d" { (object.origin,) }
  else if object.kind == "custom" { object.bounds }
  else { () }
}

#let validate(
  fig,
  require-defined-points: true,
  reject-anonymous-coordinates: true,
  reject-missing-definitions: true,
  reject-forward-cycles: true,
) = {
  let errors = ()
  let ids = ()
  let face-ids = fig.objects.filter(object => object.kind == "face" and object.id != none).map(object => object.id)
  for name in fig.points.keys() {
    if reject-missing-definitions and name not in fig.definitions { errors.push("point has no definition: " + name) }
  }
  for (name, item) in fig.definitions {
    if name not in fig.points { errors.push("definition has no coordinate: " + name) }
    for dep in item.at("deps", default: ()) {
      if type(dep) == str and dep not in fig.points { errors.push("definition " + name + " references missing dependency: " + dep) }
    }
  }
  let order = fig.at("point-order", default: fig.points.keys())
  let positions = (:)
  for (index, name) in order.enumerate() { positions.insert(name, index) }
  for (name, item) in fig.definitions {
    for dep in item.at("deps", default: ()) {
      if type(dep) == str and dep in positions and name in positions and positions.at(dep) >= positions.at(name) {
        errors.push("point " + name + " uses " + dep + " before " + dep + " is declared")
      }
    }
  }
  if reject-forward-cycles {
    for cycle in definitions.cycles(fig.definitions) { errors.push("point-definition cycle: " + cycle.join(" -> ")) }
  }
  for object in fig.objects {
    if object.id != none {
      if ids.contains(object.id) { errors.push("duplicate object id: " + object.id) } else { ids.push(object.id) }
    }
    for ref in _point-refs(object) {
      if reject-anonymous-coordinates and type(ref) != str { errors.push(object.kind + " contains anonymous coordinate: " + repr(ref)) }
      if type(ref) == str and ref not in fig.points { errors.push(object.kind + " references missing point: " + ref) }
      if require-defined-points and type(ref) == str and ref not in fig.definitions { errors.push(object.kind + " references undefined point: " + ref) }
    }
    if object.kind == "face" and object.points.len() < 3 { errors.push("face has too few points: " + str(object.id)) }
    if object.kind == "polyline" and object.points.len() < 2 { errors.push("polyline has too few points: " + str(object.id)) }
    if object.kind == "segment" {
      for face-id in object.faces { if not face-ids.contains(face-id) { errors.push("segment references missing face: " + face-id) } }
    }
  }
  errors
}

#let assert-valid(fig, ..args) = {
  let errors = validate(fig, ..args)
  if errors.len() > 0 { panic("sang-3d model validation failed: " + errors.join("; ")) }
  fig
}

#let definition-of(fig, name, default: none) = definition-at(fig, name, default: default)
#let provenance(fig, name) = definitions.trace(fig.definitions, name)
#let point-table(fig, include-coordinate: true) = definitions.point-table(fig, include-coordinate: include-coordinate)
#let inspect(fig) = (
  schema: fig.schema,
  point-count: fig.points.len(),
  object-count: fig.objects.len(),
  points: fig.points,
  point-order: fig.at("point-order", default: fig.points.keys()),
  point-options: fig.point-options,
  definitions: fig.definitions,
  dependencies: fig.definitions.map((name, item) => item.at("deps", default: ())),
  validation: validate(fig),
)
