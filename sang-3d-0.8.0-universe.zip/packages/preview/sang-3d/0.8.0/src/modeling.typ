// Sweep, loft, and curve-driven modeling.
#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "definitions.typ" as definitions
#import "points.typ" as point-declarations

#let _edge-key(a, b) = if a < b { a + "|" + b } else { b + "|" + a }
#let _name(prefix, i, j) = prefix + "-" + str(i) + "-" + str(j)
#let _as-local(point) = if point.len() == 2 { (point.at(0), point.at(1), 0) } else { point }

#let _samples(value, steps, closed: false) = {
  if type(value) == function {
    let count = if closed { steps } else { steps + 1 }
    range(count).map(index => value(index / steps))
  } else { value }
}

#let _path-frames(points, up: (0, 0, 1), closed: false) = {
  if points.len() < 2 { panic("sang-3d.sweep: path needs at least two points") }
  let frames = ()
  let previous-u = auto
  for i in range(points.len()) {
    let before = if i == 0 { if closed { points.last() } else { points.first() } } else { points.at(i - 1) }
    let after = if i == points.len() - 1 { if closed { points.first() } else { points.last() } } else { points.at(i + 1) }
    let tangent = core.unit3(core.sub3(after, before), fallback: (0, 0, 1))
    let raw-u = if previous-u == auto {
      core.sub3(up, core.mul3(tangent, core.dot3(up, tangent)))
    } else {
      core.sub3(previous-u, core.mul3(tangent, core.dot3(previous-u, tangent)))
    }
    let u = core.unit3(raw-u, fallback: core.orthogonal3(tangent))
    let v = core.unit3(core.cross3(tangent, u), fallback: core.orthogonal3(tangent))
    frames.push((origin: points.at(i), tangent: tangent, u: u, v: v))
    previous-u = u
  }
  frames
}

#let _mesh(
  rings,
  prefix: "M",
  close-ring: true,
  close-path: false,
  caps: false,
  mesh: true,
  faces: true,
  role: "surface",
  cull: false,
  tags: (),
  point-policy: auto,
  point-kind: "sweep-sample",
  point-source: "modeling",
) = {
  if rings.len() < 2 or rings.first().len() < 2 { panic("sang-3d.modeling: mesh needs at least 2x2 samples") }
  let ring-count = rings.len()
  let side-count = rings.first().len()
  if not rings.all(ring => ring.len() == side-count) { panic("sang-3d.modeling: every profile must use the same point count") }

  // Declare every generated vertex before constructing any face or edge.
  let declarations = ()
  let name-grid = ()
  for i in range(ring-count) {
    let row = ()
    for j in range(side-count) {
      let coordinate = rings.at(i).at(j)
      let declaration = point-declarations.from-policy(
        _name(prefix, i, j),
        coordinate,
        point-kind,
        parameters: (ring: i, profile-index: j, prefix: prefix, source: point-source),
        policy: point-policy,
        context: (ring: i, profile-index: j, ring-count: ring-count, side-count: side-count, prefix: prefix),
      )
      declarations.push(declaration)
      row.push(declaration.name)
    }
    name-grid.push(row)
  }
  let declared = point-declarations.declare(declarations)

  let face-records = ()
  let path-cells = if close-path { ring-count } else { ring-count - 1 }
  let side-cells = if close-ring { side-count } else { side-count - 1 }
  for i in range(path-cells) {
    let ni = calc.rem-euclid(i + 1, ring-count)
    for j in range(side-cells) {
      let nj = calc.rem-euclid(j + 1, side-count)
      face-records.push((
        id: prefix + "-face-" + str(i) + "-" + str(j),
        points: (name-grid.at(i).at(j), name-grid.at(ni).at(j), name-grid.at(ni).at(nj), name-grid.at(i).at(nj)),
      ))
    }
  }
  if caps and close-ring and not close-path {
    face-records.push((id: prefix + "-cap-start", points: range(side-count).rev().map(j => name-grid.at(0).at(j))))
    face-records.push((id: prefix + "-cap-end", points: range(side-count).map(j => name-grid.at(ring-count - 1).at(j))))
  }

  let point-objects = ()
  for declaration in declarations {
    let options = declaration.options
    if options.at("show-point", default: false) or options.at("show-label", default: false) {
      point-objects.push(objects.point(
        declaration.name,
        role: options.at("role", default: "main"),
        point: options.at("show-point", default: false),
        label: if options.at("show-label", default: false) { options.at("label-content", default: auto) } else { none },
        tags: tags + ("generated-point", point-kind),
      ))
    }
  }

  let face-objects = if faces { face-records.map(record => objects.face(record.points, id: record.id, role: role, cull: cull, tags: tags + ("sweep-face", "faces"))) } else { () }
  let edge-map = (:)
  for record in face-records {
    for index in range(record.points.len()) {
      let a = record.points.at(index)
      let b = record.points.at(calc.rem-euclid(index + 1, record.points.len()))
      let key = _edge-key(a, b)
      let previous = edge-map.at(key, default: none)
      if previous == none { edge-map.insert(key, (a: a, b: b, faces: (record.id,))) }
      else { edge-map.insert(key, (: ..previous, faces: previous.faces + (record.id,))) }
    }
  }
  if not faces and mesh {
    for i in range(ring-count) {
      for j in range(side-cells) {
        let nj = calc.rem-euclid(j + 1, side-count)
        let a = name-grid.at(i).at(j)
        let b = name-grid.at(i).at(nj)
        edge-map.insert(_edge-key(a, b), (a: a, b: b, faces: ()))
      }
    }
    for i in range(path-cells) {
      let ni = calc.rem-euclid(i + 1, ring-count)
      for j in range(side-count) {
        let a = name-grid.at(i).at(j)
        let b = name-grid.at(ni).at(j)
        edge-map.insert(_edge-key(a, b), (a: a, b: b, faces: ()))
      }
    }
  }
  let edge-objects = if mesh { edge-map.values().enumerate(start: 1).map(((index, edge)) => objects.segment(
    edge.a, edge.b, id: prefix + "-edge-" + str(index), role: role, faces: edge.faces, tags: tags + ("sweep-edge", "edges"),
  )) } else { () }
  models.model(
    points: declared.points,
    definitions: declared.definitions,
    point-options: declared.point-options,
    point-order: declared.order,
    objects: point-objects + face-objects + edge-objects,
    meta: (kind: "swept-mesh", edges: edge-map.values().map(edge => (edge.a, edge.b)), face-ids: face-objects.map(face => face.id), open: not close-path),
  )
}

#let sweep(
  profile,
  along,
  profile-steps: 24,
  path-steps: 24,
  close-profile: true,
  close-path: false,
  caps: true,
  up: (0, 0, 1),
  scale: 1,
  twist: 0deg,
  prefix: "SW",
  mesh: true,
  faces: true,
  role: "surface",
  cull: false,
  tags: (),
  point-policy: auto,
) = {
  let local-profile = _samples(profile, profile-steps, closed: close-profile).map(_as-local)
  let path = _samples(along, path-steps, closed: close-path)
  let frames = _path-frames(path, up: up, closed: close-path)
  let rings = ()
  for (i, frame) in frames.enumerate() {
    let t = if frames.len() <= 1 { 0 } else { i / (frames.len() - 1) }
    let actual-scale = if type(scale) == function { scale(t) } else { scale }
    let actual-twist = if type(twist) == function { twist(t) } else { twist * t }
    let c = calc.cos(actual-twist)
    let s = calc.sin(actual-twist)
    let ring = local-profile.map(local => {
      let x = core.x3(local) * actual-scale
      let y = core.y3(local) * actual-scale
      let z = core.z3(local) * actual-scale
      let rx = x * c - y * s
      let ry = x * s + y * c
      core.add3(frame.origin, core.add3(core.add3(core.mul3(frame.u, rx), core.mul3(frame.v, ry)), core.mul3(frame.tangent, z)))
    })
    rings.push(ring)
  }
  _mesh(rings, prefix: prefix, close-ring: close-profile, close-path: close-path, caps: caps, mesh: mesh, faces: faces, role: role, cull: cull, tags: tags + ("sweep",), point-policy: point-policy, point-kind: "sweep-sample", point-source: "sweep")
}

#let loft(
  profiles,
  close-profile: true,
  close-path: false,
  caps: true,
  prefix: "LF",
  mesh: true,
  faces: true,
  role: "surface",
  cull: false,
  tags: (),
  point-policy: auto,
) = _mesh(
  profiles,
  prefix: prefix,
  close-ring: close-profile,
  close-path: close-path,
  caps: caps,
  mesh: mesh,
  faces: faces,
  role: role,
  cull: cull,
  tags: tags + ("loft",),
  point-policy: point-policy,
  point-kind: "loft-sample",
  point-source: "loft",
)

#let circle-profile(radius: 1, steps: 24, start: 0deg) = range(steps).map(index => {
  let angle = start + 360deg * index / steps
  (radius * calc.cos(angle), radius * calc.sin(angle))
})

#let tube-along(along, radius: 0.25, sides: 20, path-steps: 32, prefix: "TB", role: "surface", up: (0, 0, 1), caps: true, point-policy: auto) = sweep(
  circle-profile(radius: radius, steps: sides),
  along,
  path-steps: path-steps,
  close-profile: true,
  caps: caps,
  prefix: prefix,
  role: role,
  up: up,
  tags: ("tube-along",),
  point-policy: point-policy,
)

#let ribbon-along(along, width: 0.5, path-steps: 32, prefix: "RB", role: "surface", up: (0, 0, 1), point-policy: auto) = sweep(
  ((-width / 2, 0), (width / 2, 0)),
  along,
  path-steps: path-steps,
  close-profile: false,
  caps: false,
  prefix: prefix,
  role: role,
  up: up,
  tags: ("ribbon-along",),
  point-policy: point-policy,
)

#let helix(radius: 2, pitch: 0.8, turns: 3, center: (0, 0, 0), axis: (0, 0, 1), start: 0deg) = {
  let frame = core.basis-from-normal(axis)
  t => {
    let angle = start + 360deg * turns * t
    core.add3(center, core.add3(
      core.add3(core.mul3(frame.u, radius * calc.cos(angle)), core.mul3(frame.v, radius * calc.sin(angle))),
      core.mul3(frame.normal, pitch * turns * t),
    ))
  }
}
