#let _base(kind, id: none, role: "main", layer: 0, visible: true, tags: (), options: (:)) = (
  kind: kind,
  id: id,
  role: role,
  layer: layer,
  visible: visible,
  tags: tags,
  options: options,
)

#let point(name, id: none, role: "main", layer: 40, visible: true, tags: (), label: auto, point: true, options: (:)) = (
  .._base("point", id: if id == none { "point-" + name } else { id }, role: role, layer: layer, visible: visible, tags: tags, options: options),
  name: name,
  label: label,
  point: point,
)

#let segment(a, b, id: none, role: "main", layer: 20, visible: true, tags: (), stroke: auto, faces: (), mark: none, visibility: auto, options: (:)) = (
  .._base("segment", id: id, role: role, layer: layer, visible: visible, tags: tags, options: options),
  a: a,
  b: b,
  stroke: stroke,
  faces: faces,
  mark: mark,
  visibility: visibility,
)

#let vector(a, b, id: none, role: "accent", layer: 22, visible: true, tags: (), stroke: auto, mark: (end: ">"), visibility: auto, options: (:)) = segment(
  a, b, id: id, role: role, layer: layer, visible: visible, tags: tags + ("vector",), stroke: stroke, mark: mark, visibility: visibility, options: options,
)

#let polyline(points, id: none, role: "main", layer: 20, visible: true, tags: (), stroke: auto, fill: none, close: false, mark: none, visibility: "always", options: (:)) = (
  .._base("polyline", id: id, role: role, layer: layer, visible: visible, tags: tags, options: options),
  points: points,
  stroke: stroke,
  fill: fill,
  close: close,
  mark: mark,
  visibility: visibility,
)

#let face(points, id: none, role: "main", layer: 10, visible: true, tags: (), stroke: auto, fill: auto, cull: true, shade: true, options: (:)) = (
  .._base("face", id: id, role: role, layer: layer, visible: visible, tags: tags, options: options),
  points: points,
  stroke: stroke,
  fill: fill,
  cull: cull,
  shade: shade,
)

#let label(at, body, id: none, role: "main", layer: 50, visible: true, tags: (), offset: (0, 0), anchor: "center", angle: none, options: (:)) = (
  .._base("label", id: id, role: role, layer: layer, visible: visible, tags: tags, options: options),
  at: at,
  body: body,
  offset: offset,
  anchor: anchor,
  angle: angle,
)

#let circle3d(center, radius, normal: (0, 0, 1), id: none, role: "main", layer: 20, visible: true, tags: (), stroke: auto, fill: none, segments: 72, start-direction: auto, options: (:)) = (
  .._base("circle3d", id: id, role: role, layer: layer, visible: visible, tags: tags, options: options),
  center: center,
  radius: radius,
  normal: normal,
  stroke: stroke,
  fill: fill,
  segments: segments,
  start-direction: start-direction,
)

#let arc3d(center, radius, start-direction, sweep, normal: (0, 0, 1), id: none, role: "main", layer: 24, visible: true, tags: (), stroke: auto, mark: none, segments: 32, options: (:)) = (
  .._base("arc3d", id: id, role: role, layer: layer, visible: visible, tags: tags, options: options),
  center: center,
  radius: radius,
  start-direction: start-direction,
  sweep: sweep,
  normal: normal,
  stroke: stroke,
  mark: mark,
  segments: segments,
)

#let plane-patch(center, normal, width: 4, height: 3, u: auto, id: none, role: "auxiliary", layer: 5, visible: true, tags: (), stroke: auto, fill: auto, border: true, grid: none, options: (:)) = (
  .._base("plane-patch", id: id, role: role, layer: layer, visible: visible, tags: tags + ("plane",), options: options),
  center: center,
  normal: normal,
  width: width,
  height: height,
  u: u,
  stroke: stroke,
  fill: fill,
  border: border,
  grid: grid,
)

#let angle3d(origin, a, b, radius: 0.55, id: none, role: "accent", layer: 30, visible: true, tags: (), stroke: auto, label: none, label-radius: 1.35, segments: 24, options: (:)) = (
  .._base("angle3d", id: id, role: role, layer: layer, visible: visible, tags: tags + ("angle",), options: options),
  origin: origin,
  a: a,
  b: b,
  radius: radius,
  stroke: stroke,
  label: label,
  label-radius: label-radius,
  segments: segments,
)

#let right-angle3d(origin, a, b, size: 0.35, id: none, role: "accent", layer: 30, visible: true, tags: (), stroke: auto, options: (:)) = (
  .._base("right-angle3d", id: id, role: role, layer: layer, visible: visible, tags: tags + ("right-angle",), options: options),
  origin: origin,
  a: a,
  b: b,
  size: size,
  stroke: stroke,
)

#let custom(draw, bounds: (), id: none, role: "main", layer: 100, visible: true, tags: (), options: (:)) = (
  .._base("custom", id: id, role: role, layer: layer, visible: visible, tags: tags, options: options),
  draw: draw,
  bounds: bounds,
)

#let dimension3d(a, b, offset: (0, 0, 0), id: none, role: "dimension", layer: 32, visible: true, tags: (), stroke: auto, label: auto, label-offset: (0, 0), mark: auto, extension: true, options: (:)) = (
  .._base("dimension3d", id: id, role: role, layer: layer, visible: visible, tags: tags + ("dimension",), options: options),
  a: a,
  b: b,
  offset: offset,
  stroke: stroke,
  label: label,
  label-offset: label-offset,
  mark: mark,
  extension: extension,
)

#let ticks3d(a, b, count: 1, size: auto, normal: auto, position: 0.5, spacing: 0.12, id: none, role: "annotation", layer: 31, visible: true, tags: (), stroke: auto, options: (:)) = (
  .._base("ticks3d", id: id, role: role, layer: layer, visible: visible, tags: tags + ("ticks",), options: options),
  a: a,
  b: b,
  count: count,
  size: size,
  normal: normal,
  position: position,
  spacing: spacing,
  stroke: stroke,
)

#let dihedral3d(origin, edge-direction, normal-a, normal-b, radius: 0.6, id: none, role: "annotation", layer: 31, visible: true, tags: (), stroke: auto, label: none, label-radius: 1.35, segments: 24, options: (:)) = (
  .._base("dihedral3d", id: id, role: role, layer: layer, visible: visible, tags: tags + ("dihedral",), options: options),
  origin: origin,
  edge-direction: edge-direction,
  normal-a: normal-a,
  normal-b: normal-b,
  radius: radius,
  stroke: stroke,
  label: label,
  label-radius: label-radius,
  segments: segments,
)
