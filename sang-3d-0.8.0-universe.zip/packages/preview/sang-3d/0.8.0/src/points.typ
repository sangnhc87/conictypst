#import "definitions.typ" as definitions

// Explicit point declarations. A declaration is data, not a rendered object.
// It must exist before any object is allowed to reference the point.
#let point(
  name,
  coordinate,
  definition: auto,
  label: auto,
  label-position: auto,
  label-distance: auto,
  show-point: true,
  show-label: true,
  role: "main",
  style: (:),
  metadata: (:),
) = {
  if type(name) != str or name == "" { panic("sang-3d.point: name must be a non-empty string") }
  let actual-definition = if definition == auto {
    definitions.given(coordinate, label: label, meta: metadata)
  } else {
    let item = (: ..definition, coordinate: coordinate)
    if "deps" not in item { item = (: ..item, deps: ()) }
    if "parameters" not in item { item = (: ..item, parameters: (:)) }
    item
  }
  (
    kind: "sang-3d-point-declaration",
    name: name,
    coordinate: coordinate,
    definition: actual-definition,
    options: (
      label-content: label,
      label-position: label-position,
      label-distance: label-distance,
      show-point: show-point,
      show-label: show-label,
      role: role,
      style: style,
    ),
    metadata: metadata,
  )
}

#let given(name, coordinate, ..options) = point(name, coordinate, definition: definitions.given(coordinate), ..options)

#let derived(
  name,
  coordinate,
  kind,
  deps: (),
  parameters: (:),
  formula: none,
  ..options,
) = point(
  name,
  coordinate,
  definition: definitions.derived(kind, deps: deps, coordinate: coordinate, parameters: parameters, formula: formula),
  ..options,
)

#let _resolve(value, context, default: auto) = {
  if value == auto { default }
  else if type(value) == function { value(context) }
  else { value }
}

// Policy for dense constructors. Every generated point still gets a public
// declaration; the policy controls its public name, label and definition.
#let policy(
  name: auto,
  label: auto,
  label-position: auto,
  label-distance: auto,
  show-point: false,
  show-label: false,
  role: "main",
  style: (:),
  definition: auto,
) = (
  name: name,
  label: label,
  label-position: label-position,
  label-distance: label-distance,
  show-point: show-point,
  show-label: show-label,
  role: role,
  style: style,
  definition: definition,
)

#let from-policy(
  default-name,
  coordinate,
  kind,
  deps: (),
  parameters: (:),
  policy: auto,
  context: (:),
) = {
  let actual = if policy == auto { (:) } else { policy }
  let ctx = (: default-name: default-name, coordinate: coordinate, kind: kind, deps: deps, parameters: parameters, ..context)
  let name = _resolve(actual.at("name", default: auto), ctx, default: default-name)
  let definition-value = _resolve(actual.at("definition", default: auto), ctx, default: auto)
  let definition = if definition-value == auto {
    definitions.derived(kind, deps: deps, coordinate: coordinate, parameters: parameters)
  } else {
    (: ..definition-value, coordinate: coordinate, deps: definition-value.at("deps", default: deps))
  }
  point(
    name,
    coordinate,
    definition: definition,
    label: _resolve(actual.at("label", default: auto), ctx, default: auto),
    label-position: _resolve(actual.at("label-position", default: auto), ctx, default: auto),
    label-distance: _resolve(actual.at("label-distance", default: auto), ctx, default: auto),
    show-point: _resolve(actual.at("show-point", default: false), ctx, default: false),
    show-label: _resolve(actual.at("show-label", default: false), ctx, default: false),
    role: _resolve(actual.at("role", default: "main"), ctx, default: "main"),
    style: _resolve(actual.at("style", default: (:)), ctx, default: (:)),
    metadata: (generated: true, context: ctx),
  )
}

// Preserve declaration order and reject dependencies that have not appeared yet.
#let declare(entries, strict-order: true, known: ()) = {
  let coordinates = (:)
  let registry = (:)
  let options = (:)
  let order = ()
  let available = known
  for entry in entries {
    if type(entry) != dictionary or entry.at("kind", default: none) != "sang-3d-point-declaration" {
      panic("sang-3d.declare-points: every entry must be created with sang3d.point/given-point/derived-point")
    }
    let name = entry.name
    if name in coordinates { panic("sang-3d.declare-points: duplicate point name " + name) }
    let deps = entry.definition.at("deps", default: ())
    if strict-order {
      for dep in deps {
        if type(dep) == str and not available.contains(dep) {
          panic("sang-3d.declare-points: " + name + " depends on " + dep + " before " + dep + " is declared")
        }
      }
    }
    coordinates.insert(name, entry.coordinate)
    registry.insert(name, entry.definition)
    options.insert(name, entry.options)
    order.push(name)
    available.push(name)
  }
  (points: coordinates, definitions: registry, point-options: options, order: order)
}

#let declaration-table(entries) = {
  let declared = declare(entries)
  let rows = (([Point], [Coordinate], [Definition], [Dependencies], [Label]),)
  for name in declared.order {
    let item = declared.definitions.at(name)
    let opts = declared.point-options.at(name)
    rows.push((
      [#name],
      [#repr(declared.points.at(name))],
      [#item.kind],
      [#item.at("deps", default: ()).map(str).join(", ")],
      [#repr(opts.at("label-content", default: auto))],
    ))
  }
  table(columns: 5, ..rows.flatten())
}
