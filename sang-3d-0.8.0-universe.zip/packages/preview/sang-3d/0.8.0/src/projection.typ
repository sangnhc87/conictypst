#import "core.typ" as core
#import "camera.typ" as cameras
#import "scene.typ" as scenes

#let _resolve(fig, ref) = if type(ref) == str { fig.points.at(ref) } else { ref }
#let _all-points(fig) = {
  let points = fig.points.values()
  for object in fig.objects {
    if object.kind == "segment" or object.kind == "dimension3d" or object.kind == "ticks3d" {
      points += (_resolve(fig, object.a), _resolve(fig, object.b))
    }
    if object.kind == "polyline" or object.kind == "face" { points += object.points.map(ref => _resolve(fig, ref)) }
    if object.kind == "label" { points.push(_resolve(fig, object.at)) }
    if object.kind == "circle3d" or object.kind == "arc3d" {
      let center = _resolve(fig, object.center)
      let r = object.radius
      points += ((core.x3(center)-r, core.y3(center)-r, core.z3(center)-r), (core.x3(center)+r, core.y3(center)+r, core.z3(center)+r))
    }
    if object.kind == "dihedral3d" { points.push(_resolve(fig, object.origin)) }
    if object.kind == "custom" { points += object.bounds }
  }
  core.unique-points3(points)
}
#let _edges(fig) = {
  let edges = fig.meta.at("edges", default: ())
  if edges.len() == 0 { edges = fig.objects.filter(object => object.kind == "segment").map(object => (object.a, object.b)) }
  edges.map(edge => (_resolve(fig, edge.at(0)), _resolve(fig, edge.at(1))))
}

#let prepare(input, camera: cameras.auto(), width: 8.0, height: 6.2, padding: 0.10) = {
  let fig = if input.kind == "sang-3d-model" { input } else { scenes.flatten(input) }
  let cam = cameras.prepare(camera, _all-points(fig), edges: _edges(fig), width: width, height: height, padding: padding)
  (figure: fig, camera: cam)
}

#let point-map(input, camera: cameras.auto(), width: 8.0, height: 6.2, padding: 0.10) = {
  let prepared = prepare(input, camera: camera, width: width, height: height, padding: padding)
  let output = (:)
  for (name, point) in prepared.figure.points { output.insert(name, cameras.project(prepared.camera, point)) }
  output
}

#let project-model(input, camera: cameras.auto(), width: 8.0, height: 6.2, padding: 0.10) = {
  let prepared = prepare(input, camera: camera, width: width, height: height, padding: padding)
  let fig = prepared.figure
  let cam = prepared.camera
  let project = point => cameras.project(cam, point)
  let points = (:)
  for (name, point) in fig.points { points.insert(name, project(point)) }
  let objects = fig.objects.map(object => {
    if object.kind == "point" { (: ..object, projected: points.at(object.name)) }
    else if object.kind == "segment" or object.kind == "dimension3d" or object.kind == "ticks3d" {
      (: ..object, projected-a: project(_resolve(fig, object.a)), projected-b: project(_resolve(fig, object.b)))
    }
    else if object.kind == "face" or object.kind == "polyline" {
      (: ..object, projected-points: object.points.map(ref => project(_resolve(fig, ref))))
    }
    else if object.kind == "label" { (: ..object, projected: project(_resolve(fig, object.at))) }
    else { object }
  })
  (kind: "sang-3d-projection", camera: cam, points: points, objects: objects, meta: fig.meta)
}
