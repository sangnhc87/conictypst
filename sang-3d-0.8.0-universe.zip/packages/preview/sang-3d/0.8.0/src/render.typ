#import "@preview/cetz:0.5.2" as cetz
#import "core.typ" as core
#import "camera.typ" as cameras
#import "styles.typ" as styles
#import "visibility.typ" as visibility
#import "layout.typ" as layout
#import "scene.typ" as scenes
#import "model.typ" as models
#import "materials.typ" as materials

#let _resolve(fig, ref) = if type(ref) == str { fig.points.at(ref) } else { ref }
#let _p2(projected) = (projected.at(0), projected.at(1))
#let _label-content(raw, size, fill) = text(size: size, fill: fill)[#raw]

#let _actual-style(fig, supplied) = {
  let actual = styles.merge(styles.theme(), fig.styles)
  if supplied == auto { actual } else { styles.merge(actual, supplied) }
}
#let _object-style(base, object, rules: ()) = styles.merge(styles.object-style(base, object, rules: rules), object.options.at("style", default: (:)))

#let _circle-points(center, normal, radius, segments, start-direction: auto, sweep: 360deg) = {
  let basis = core.basis-from-normal(normal, preferred-u: start-direction)
  range(segments + 1).map(index => {
    let angle = sweep * index / segments
    core.add3(center, core.add3(core.mul3(basis.u, radius * calc.cos(angle)), core.mul3(basis.v, radius * calc.sin(angle))))
  })
}

#let _plane-geometry(object, fig) = {
  let center = _resolve(fig, object.center)
  let basis = core.basis-from-normal(object.normal, preferred-u: object.u)
  let half-width = object.width / 2
  let half-height = object.height / 2
  let corner = (su, sv) => core.add3(center, core.add3(core.mul3(basis.u, su * half-width), core.mul3(basis.v, sv * half-height)))
  (center: center, basis: basis, corners: (corner(-1, -1), corner(1, -1), corner(1, 1), corner(-1, 1)))
}

#let _all-camera-points(fig) = {
  let points = fig.points.values()
  for object in fig.objects {
    if object.kind == "segment" { points += (_resolve(fig, object.a), _resolve(fig, object.b)) }
    if object.kind == "polyline" or object.kind == "face" { points += object.points.map(ref => _resolve(fig, ref)) }
    if object.kind == "label" { points.push(_resolve(fig, object.at)) }
    if object.kind == "circle3d" or object.kind == "arc3d" {
      points += _circle-points(_resolve(fig, object.center), object.normal, object.radius, 12, start-direction: object.at("start-direction", default: auto), sweep: if object.kind == "arc3d" { object.sweep } else { 360deg })
    }
    if object.kind == "plane-patch" { points += _plane-geometry(object, fig).corners }
    if object.kind == "angle3d" or object.kind == "right-angle3d" { points += (_resolve(fig, object.origin), _resolve(fig, object.a), _resolve(fig, object.b)) }
    if object.kind == "dimension3d" or object.kind == "ticks3d" {
      let a = _resolve(fig, object.a)
      let b = _resolve(fig, object.b)
      points += (a, b)
      if object.kind == "dimension3d" { points += (core.add3(a, object.offset), core.add3(b, object.offset)) }
    }
    if object.kind == "dihedral3d" { points.push(_resolve(fig, object.origin)) }
    if object.kind == "custom" { points += object.bounds.map(ref => _resolve(fig, ref)) }
  }
  core.unique-points3(points)
}

#let _camera-edges(fig) = {
  let edges = fig.meta.at("edges", default: ())
  if edges.len() == 0 { edges = fig.objects.filter(object => object.kind == "segment").map(object => (object.a, object.b)) }
  edges.map(edge => (_resolve(fig, edge.at(0)), _resolve(fig, edge.at(1))))
}

#let draw-model(
  input,
  camera: cameras.auto(),
  style: auto,
  hidden-lines: auto,
  visibility-mode: auto,
  visibility-samples: auto,
  show-faces: true,
  show-points: true,
  show-labels: true,
  auto-labels: true,
  label-mode: auto,
  leader-lines: auto,
  show-plane-grids: true,
  style-rules: (),
) = {
  import cetz.draw: *
  let fig = if input.kind == "sang-3d-model" { input } else { scenes.flatten(input) }
  let actual-style = _actual-style(fig, style)
  let viewport = actual-style.viewport
  let all-points = _all-camera-points(fig)
  let cam = cameras.prepare(
    camera,
    all-points,
    edges: _camera-edges(fig),
    width: viewport.width,
    height: viewport.height,
    padding: viewport.padding,
  )
  let project = point => cameras.project(cam, point)
  let records = visibility.face-records(fig, cam)
  let visibility-style = actual-style.visibility
  let mode = if visibility-mode == auto { visibility-style.mode } else { visibility-mode }
  let samples = if visibility-samples == auto { visibility-style.samples } else { visibility-samples }
  let hidden-policy = if hidden-lines == auto { visibility-style.hidden-lines } else { hidden-lines }

  // Transparent construction planes are drawn before solid faces.
  for object in fig.objects.filter(object => object.visible and object.kind == "plane-patch").sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, object, rules: style-rules)
    let geometry = _plane-geometry(object, fig)
    let corners = geometry.corners.map(point => _p2(project(point)))
    line(
      ..corners,
      close: true,
      fill: styles.fill-for(object-style, role: object.role, override: object.fill),
      stroke: if object.border { styles.stroke-for(object-style, role: object.role, override: object.stroke) } else { none },
    )
    if show-plane-grids and object.grid != none {
      let counts = if type(object.grid) == int { (object.grid, object.grid) } else { object.grid }
      let u-count = counts.at(0)
      let v-count = counts.at(1)
      for i in range(1, u-count) {
        let t = i / u-count - 0.5
        let a = core.add3(geometry.center, core.add3(core.mul3(geometry.basis.u, object.width * t), core.mul3(geometry.basis.v, -object.height / 2)))
        let b = core.add3(geometry.center, core.add3(core.mul3(geometry.basis.u, object.width * t), core.mul3(geometry.basis.v, object.height / 2)))
        line(_p2(project(a)), _p2(project(b)), stroke: styles.stroke-for(object-style, role: "grid"))
      }
      for i in range(1, v-count) {
        let t = i / v-count - 0.5
        let a = core.add3(geometry.center, core.add3(core.mul3(geometry.basis.v, object.height * t), core.mul3(geometry.basis.u, -object.width / 2)))
        let b = core.add3(geometry.center, core.add3(core.mul3(geometry.basis.v, object.height * t), core.mul3(geometry.basis.u, object.width / 2)))
        line(_p2(project(a)), _p2(project(b)), stroke: styles.stroke-for(object-style, role: "grid"))
      }
    }
  }

  if show-faces {
    for record in records {
      let object = record.object
      let object-style = _object-style(actual-style, object, rules: style-rules)
      if record.front or not object.cull {
        let fill = styles.fill-for(object-style, role: object.role, override: object.fill)
        if object.shade { fill = styles.shade(fill, record.normal, object-style) }
        line(..record.polygon, close: true, fill: fill, stroke: if object.stroke == auto { none } else { styles.stroke-for(object-style, role: object.role, override: object.stroke) })
      }
    }
  }

  // Segments can be split into visible and hidden runs by projected face occlusion.
  for segment in fig.objects.filter(object => object.visible and object.kind == "segment").sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, segment, rules: style-rules)
    let local-mode = if segment.visibility == auto { mode } else { segment.visibility }
    let runs = visibility.segment-runs(
      fig, segment, cam, faces: records, mode: local-mode, samples: samples, refine: visibility-style.at("refine", default: 5), tolerance: visibility-style.tolerance,
    )
    for (run-index, run) in runs.enumerate() {
      if not run.hidden {
        line(
          _p2(project(run.a)), _p2(project(run.b)),
          stroke: styles.stroke-for(object-style, role: segment.role, override: segment.stroke),
          mark: if run-index == runs.len() - 1 { segment.mark } else { none },
        )
      } else if hidden-policy == "dashed" {
        line(_p2(project(run.a)), _p2(project(run.b)), stroke: styles.stroke-for(object-style, role: "hidden"))
      } else if hidden-policy == "solid" {
        line(_p2(project(run.a)), _p2(project(run.b)), stroke: styles.stroke-for(object-style, role: segment.role, override: segment.stroke))
      }
    }
  }

  for object in fig.objects.filter(object => object.visible and object.kind == "polyline").sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, object, rules: style-rules)
    line(
      ..object.points.map(ref => _p2(project(_resolve(fig, ref)))),
      close: object.close,
      stroke: styles.stroke-for(object-style, role: object.role, override: object.stroke),
      fill: object.fill,
      mark: object.mark,
    )
  }

  for object in fig.objects.filter(object => object.visible and (object.kind == "circle3d" or object.kind == "arc3d")).sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, object, rules: style-rules)
    let points = _circle-points(
      _resolve(fig, object.center), object.normal, object.radius, object.segments,
      start-direction: object.start-direction,
      sweep: if object.kind == "arc3d" { object.sweep } else { 360deg },
    )
    if object.kind == "circle3d" and object.fill != none {
      line(..points.map(point => _p2(project(point))), close: true, stroke: none, fill: object.fill)
    }
    for index in range(points.len() - 1) {
      let synthetic = (a: points.at(index), b: points.at(index + 1), faces: (), visibility: object.options.at("visibility", default: auto))
      let runs = visibility.segment-runs(fig, synthetic, cam, faces: records, mode: mode, samples: calc.max(2, calc.floor(samples / 4)), refine: visibility-style.at("refine", default: 5), tolerance: visibility-style.tolerance)
      for (run-index, run) in runs.enumerate() {
        if not run.hidden {
          line(
            _p2(project(run.a)), _p2(project(run.b)),
            stroke: styles.stroke-for(object-style, role: object.role, override: object.stroke),
            mark: if object.kind == "arc3d" and index == points.len() - 2 and run-index == runs.len() - 1 { object.at("mark", default: none) } else { none },
          )
        } else if hidden-policy == "dashed" {
          line(_p2(project(run.a)), _p2(project(run.b)), stroke: styles.stroke-for(object-style, role: "hidden"))
        } else if hidden-policy == "solid" {
          line(_p2(project(run.a)), _p2(project(run.b)), stroke: styles.stroke-for(object-style, role: object.role, override: object.stroke))
        }
      }
    }
  }

  for object in fig.objects.filter(object => object.visible and object.kind == "angle3d").sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, object, rules: style-rules)
    let origin = _resolve(fig, object.origin)
    let ua = core.unit3(core.sub3(_resolve(fig, object.a), origin))
    let ub = core.unit3(core.sub3(_resolve(fig, object.b), origin))
    let normal = core.unit3(core.cross3(ua, ub), fallback: (0, 0, 1))
    let v = core.unit3(core.cross3(normal, ua), fallback: ub)
    let sweep = core.angle-between3(ua, ub)
    let points = range(object.segments + 1).map(index => {
      let angle = sweep * index / object.segments
      core.add3(origin, core.add3(core.mul3(ua, object.radius * calc.cos(angle)), core.mul3(v, object.radius * calc.sin(angle))))
    })
    line(..points.map(point => _p2(project(point))), stroke: styles.stroke-for(object-style, role: object.role, override: object.stroke))
    if object.label != none {
      let middle = sweep / 2
      let at = core.add3(origin, core.add3(
        core.mul3(ua, object.radius * object.label-radius * calc.cos(middle)),
        core.mul3(v, object.radius * object.label-radius * calc.sin(middle)),
      ))
      content(_p2(project(at)), _label-content(object.label, object-style.label.size, object-style.label.fill), anchor: "center")
    }
  }

  for object in fig.objects.filter(object => object.visible and object.kind == "right-angle3d").sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, object, rules: style-rules)
    let origin = _resolve(fig, object.origin)
    let ua = core.unit3(core.sub3(_resolve(fig, object.a), origin))
    let raw-b = core.sub3(_resolve(fig, object.b), origin)
    let ub = core.unit3(core.sub3(raw-b, core.mul3(ua, core.dot3(raw-b, ua))), fallback: core.unit3(raw-b))
    let p1 = core.add3(origin, core.mul3(ua, object.size))
    let p2 = core.add3(p1, core.mul3(ub, object.size))
    let p3 = core.add3(origin, core.mul3(ub, object.size))
    line(_p2(project(p1)), _p2(project(p2)), _p2(project(p3)), stroke: styles.stroke-for(object-style, role: object.role, override: object.stroke))
  }

  for object in fig.objects.filter(object => object.visible and object.kind == "dimension3d").sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, object, rules: style-rules)
    let a = _resolve(fig, object.a)
    let b = _resolve(fig, object.b)
    let da = core.add3(a, object.offset)
    let db = core.add3(b, object.offset)
    let annotation-style = object-style.annotation
    let stroke = styles.stroke-for(object-style, role: object.role, override: object.stroke)
    if object.extension {
      line(_p2(project(a)), _p2(project(da)), stroke: stroke)
      line(_p2(project(b)), _p2(project(db)), stroke: stroke)
    }
    let mark = if object.mark == auto { annotation-style.arrow-mark } else { object.mark }
    line(_p2(project(da)), _p2(project(db)), stroke: stroke, mark: mark)
    if object.label != none {
      let raw = if object.label == auto { str(calc.round(core.distance3(a, b), digits: 2)) } else { object.label }
      let at = _p2(project(core.midpoint3(da, db)))
      content(
        (at.at(0) + object.label-offset.at(0), at.at(1) + object.label-offset.at(1)),
        _label-content(raw, object-style.label.size, object-style.label.fill),
        anchor: "center",
      )
    }
  }

  for object in fig.objects.filter(object => object.visible and object.kind == "ticks3d").sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, object, rules: style-rules)
    let a = _resolve(fig, object.a)
    let b = _resolve(fig, object.b)
    let direction = core.unit3(core.sub3(b, a))
    let normal = if object.normal == auto { cameras.basis(cam).forward } else { core.unit3(object.normal) }
    let perpendicular = core.unit3(core.cross3(direction, normal), fallback: core.orthogonal3(direction))
    let size = if object.size == auto { object-style.annotation.tick-size } else { object.size }
    let center = core.lerp3(a, b, object.position)
    for index in range(object.count) {
      let shift = (index - (object.count - 1) / 2) * object.spacing
      let at = core.add3(center, core.mul3(direction, shift))
      let p1 = core.add3(at, core.mul3(perpendicular, -size / 2))
      let p2 = core.add3(at, core.mul3(perpendicular, size / 2))
      line(_p2(project(p1)), _p2(project(p2)), stroke: styles.stroke-for(object-style, role: object.role, override: object.stroke))
    }
  }

  for object in fig.objects.filter(object => object.visible and object.kind == "dihedral3d").sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, object, rules: style-rules)
    let origin = _resolve(fig, object.origin)
    let edge = core.unit3(object.edge-direction, fallback: (0, 0, 1))
    let ua = core.unit3(core.cross3(edge, object.normal-a), fallback: core.orthogonal3(edge))
    let raw-ub = core.unit3(core.cross3(edge, object.normal-b), fallback: core.orthogonal3(edge))
    let normal = core.unit3(core.cross3(ua, raw-ub), fallback: edge)
    let ub = if core.dot3(normal, edge) < 0 { core.neg3(raw-ub) } else { raw-ub }
    let sweep = core.angle-between3(ua, ub)
    let v = core.unit3(core.cross3(edge, ua), fallback: ub)
    let points = range(object.segments + 1).map(index => {
      let angle = sweep * index / object.segments
      core.add3(origin, core.add3(core.mul3(ua, object.radius * calc.cos(angle)), core.mul3(v, object.radius * calc.sin(angle))))
    })
    line(..points.map(point => _p2(project(point))), stroke: styles.stroke-for(object-style, role: object.role, override: object.stroke))
    if object.label != none {
      let middle = sweep / 2
      let at = core.add3(origin, core.add3(core.mul3(ua, object.radius*object.label-radius*calc.cos(middle)), core.mul3(v, object.radius*object.label-radius*calc.sin(middle))))
      content(_p2(project(at)), _label-content(object.label, object-style.label.size, object-style.label.fill), anchor: "center")
    }
  }

  let actual-label-mode = if label-mode == auto { actual-style.label.at("mode", default: "global") } else { label-mode }
  let label-offsets = if auto-labels {
    layout.auto-label-offsets(fig, cam, actual-style, mode: actual-label-mode, iterations: actual-style.label.at("iterations", default: 4))
  } else { (:) }
  let leader-policy = if leader-lines == auto { actual-style.label.at("leader-lines", default: "auto") } else { leader-lines }
  if show-labels and auto-labels and leader-policy != false and leader-policy != none {
    for leader in layout.leader-records(fig, cam, label-offsets, threshold: actual-style.label.at("leader-threshold", default: 0.34)) {
      line(leader.a, leader.b, stroke: styles.stroke-for(actual-style, role: "construction"))
    }
  }
  for object in fig.objects.filter(object => object.visible and object.kind == "point").sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, object, rules: style-rules)
    let point = _p2(project(_resolve(fig, object.name)))
    let options = fig.point-options.at(object.name, default: (:))
    let point-style = styles.point-style(object-style, (: ..object.options, ..options))
    if show-points and object.point and options.at("show-point", default: true) {
      circle(point, radius: point-style.radius, fill: point-style.fill, stroke: point-style.stroke)
    }
    if show-labels and object.label != false and options.at("show-label", default: true) {
      let raw = options.at("label-content", default: if object.label == auto { object.name } else { object.label })
      let label-style = styles.label-style(object-style, (: ..object.options, ..options))
      let offset = if "label-offset" in options { options.at("label-offset") }
        else { label-offsets.at(object.name, default: (label-style.offset, label-style.offset)) }
      content(
        (point.at(0) + offset.at(0), point.at(1) + offset.at(1)),
        _label-content(raw, label-style.size, label-style.fill),
        anchor: options.at("label-anchor", default: "center"),
      )
    }
  }

  for object in fig.objects.filter(object => object.visible and object.kind == "label").sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, object, rules: style-rules)
    let point = _p2(project(_resolve(fig, object.at)))
    let label-style = styles.label-style(object-style, object.options)
    content(
      (point.at(0) + object.offset.at(0), point.at(1) + object.offset.at(1)),
      _label-content(object.body, label-style.size, label-style.fill),
      anchor: object.anchor,
      angle: object.angle,
    )
  }

  for object in fig.objects.filter(object => object.visible and object.kind == "custom").sorted(key: object => object.layer) {
    let object-style = _object-style(actual-style, object, rules: style-rules)
    object.draw((
      draw: cetz.draw,
      project: point => _p2(project(point)),
      project3: project,
      resolve: ref => _resolve(fig, ref),
      camera: cam,
      style: object-style,
      figure: fig,
      object: object,
    ))
  }
}

#let render-model(
  input,
  camera: cameras.auto(),
  style: auto,
  hidden-lines: auto,
  visibility-mode: auto,
  visibility-samples: auto,
  show-faces: true,
  show-points: true,
  show-labels: true,
  auto-labels: true,
  label-mode: auto,
  leader-lines: auto,
  show-plane-grids: true,
  style-rules: (),
  length: auto,
) = {
  let fig = if input.kind == "sang-3d-model" { input } else { scenes.flatten(input) }
  let actual-style = _actual-style(fig, style)
  let actual-length = if length == auto { actual-style.viewport.canvas-length } else { length }
  cetz.canvas(length: actual-length, {
    draw-model(
      fig,
      camera: camera,
      style: actual-style,
      hidden-lines: hidden-lines,
      visibility-mode: visibility-mode,
      visibility-samples: visibility-samples,
      show-faces: show-faces,
      show-points: show-points,
      show-labels: show-labels,
      auto-labels: auto-labels,
      label-mode: label-mode,
      leader-lines: leader-lines,
      show-plane-grids: show-plane-grids,
      style-rules: style-rules,
    )
  })
}

#let scene3d = render-model

#let render-views(
  input,
  cameras-list,
  columns: auto,
  captions: none,
  style: auto,
  length: 5.2cm,
  gutter: 8pt,
  hidden-lines: auto,
  visibility-mode: auto,
  show-faces: true,
  show-points: true,
  show-labels: true,
) = {
  let cells = ()
  for (index, cam) in cameras-list.enumerate() {
    let caption = if captions == none { none } else { captions.at(index) }
    cells.push([
      #render-model(
        input,
        camera: cam,
        style: style,
        length: length,
        hidden-lines: hidden-lines,
        visibility-mode: visibility-mode,
        show-faces: show-faces,
        show-points: show-points,
        show-labels: show-labels,
      )
      #if caption != none { align(center, text(size: 9pt, caption)) }
    ])
  }
  grid(columns: if columns == auto { cameras-list.len() } else { columns }, gutter: gutter, ..cells)
}

// Smart high-level API. The lower-level render-model remains available when
// every pipeline switch needs to be controlled independently.
#let draw(
  input,
  view: "auto",
  camera: auto,
  theme: "textbook",
  accent: auto,
  quality: "normal",
  focus: auto,
  hidden: auto,
  visibility: auto,
  labels: auto,
  line: auto,
  material: auto,
  strict: true,
  rules: (),
  show: (:),
  length: auto,
) = {
  let focus-normal = if focus == auto { auto }
    else if type(focus) == dictionary and focus.at("normal", default: none) != none { focus.normal }
    else { auto }
  let candidate-count = if quality == "publication" or quality == "ultra" { 48 } else if quality == "print" { 36 } else { 24 }
  let cam = if camera != auto { camera }
    else if view == "auto" or view == "best" {
      cameras.auto(
        view: "best",
        prefer: if focus-normal == auto { "balanced" } else { "show-section" },
        focus-normal: focus-normal,
        candidate-count: candidate-count,
        search: "adaptive",
        avoid-overlap: true,
      )
    } else if view == "cabinet" or view == "cavalier" or view == "perspective" {
      cameras.named(view)
    } else {
      cameras.auto(view: view, prefer: if focus-normal == auto { "balanced" } else { "show-section" }, focus-normal: focus-normal)
    }
  let actual-style = styles.deep-merge(styles.theme(theme, accent: accent), styles.quality(quality))
  let actual-input = input
  if material != auto {
    let actual-material = if type(material) == str { materials.preset(material, color: if accent == auto { styles.palette.blue } else { accent }) } else { material }
    actual-style = styles.deep-merge(actual-style, actual-material.style)
    if actual-material.double-sided {
      let flat = if input.kind == "sang-3d-model" { input } else { scenes.flatten(input) }
      actual-input = models.patch-kind(flat, "face", (cull: false))
    }
  }
  if visibility != auto { actual-style = styles.deep-merge(actual-style, (visibility: (mode: visibility))) }
  if labels != auto {
    let label-patch = if type(labels) == dictionary { labels } else { (mode: labels) }
    actual-style = styles.deep-merge(actual-style, (label: label-patch))
  }
  if line != auto { actual-style = styles.deep-merge(actual-style, styles.role-patch("main", stroke: line)) }
  if strict {
    let flat = if actual-input.kind == "sang-3d-model" { actual-input } else { scenes.flatten(actual-input) }
    actual-input = models.assert-valid(flat)
  }
  render-model(
    actual-input,
    camera: cam,
    style: actual-style,
    hidden-lines: hidden,
    show-faces: show.at("faces", default: true),
    show-points: show.at("points", default: true),
    show-labels: show.at("labels", default: true),
    auto-labels: show.at("auto-labels", default: true),
    label-mode: actual-style.label.at("mode", default: "global"),
    leader-lines: actual-style.label.at("leader-lines", default: "auto"),
    show-plane-grids: show.at("plane-grids", default: true),
    style-rules: rules,
    length: length,
  )
}
