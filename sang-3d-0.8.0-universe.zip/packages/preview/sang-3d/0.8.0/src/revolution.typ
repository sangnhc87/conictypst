#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "definitions.typ" as definitions
#import "surfaces.typ" as surfaces

// High-level rotation and revolution workflows.
#let axis(point: (0, 0, 0), direction: (0, 0, 1), id: none) = core.axis(point: point, direction: direction, id: id)
#let axis-through(a, b, id: none) = core.axis-through(a, b, id: id)
#let rotate-point(point, around, angle) = core.rotate-around-axis(point, around, angle)
#let rotate-vector(vector, around, angle) = core.rotate-vector-axis(vector, around, angle)
#let rotate-model(fig, around, angle) = models.rotate-around(fig, around, angle)

#let _resolve(fig, ref) = if type(ref) == str { fig.points.at(ref) } else { ref }
#let axis-from(fig, a, b, id: none) = core.axis-through(_resolve(fig, a), _resolve(fig, b), id: id)

#let _refs(object) = {
  if object.kind == "point" { (object.name,) }
  else if object.kind == "segment" { (object.a, object.b) }
  else if object.kind == "polyline" or object.kind == "face" { object.points }
  else if object.kind == "label" { (object.at,) }
  else if object.kind == "circle3d" or object.kind == "arc3d" or object.kind == "plane-patch" { (object.center,) }
  else if object.kind == "angle3d" or object.kind == "right-angle3d" { (object.origin, object.a, object.b) }
  else if object.kind == "dimension3d" or object.kind == "ticks3d" { (object.a, object.b) }
  else if object.kind == "dihedral3d" { (object.origin,) }
  else { () }
}

#let selection(fig, selector) = {
  let selected = models.select(fig, selector)
  let selected-face-ids = selected.filter(object => object.kind == "face" and object.id != none).map(object => object.id)
  selected = selected.map(object => if object.kind == "segment" {
    (: ..object, faces: object.faces.filter(id => selected-face-ids.contains(id)))
  } else { object })
  let names = ()
  for object in selected {
    for ref in _refs(object) {
      if type(ref) == str and not names.contains(ref) { names.push(ref) }
    }
  }
  let points = (:)
  let options = (:)
  for name in names {
    points.insert(name, fig.points.at(name))
    if name in fig.point-options { options.insert(name, fig.point-options.at(name)) }
  }
  let edges = selected.filter(object => object.kind == "segment").map(object => (object.a, object.b))
  let registry = (:)
  let order = ()
  for name in fig.at("point-order", default: fig.points.keys()) {
    if name in points { registry.insert(name, fig.definitions.at(name)); order.push(name) }
  }
  models.model(points: points, definitions: registry, point-order: order, objects: selected, point-options: options, styles: fig.styles, meta: (kind: "selection", edges: edges))
}

// Rotate only objects matching a selector. Shared source points are copied and
// prefixed, so unrelated geometry in the original model remains unchanged.
#let rotate-selection(
  fig,
  selector,
  around,
  angle,
  mode: "replace",
  prefix: "rot-",
) = {
  let chosen = selection(fig, selector)
  let rotated = rotate-model(chosen, around, angle)
  if mode == "copy" { models.merge(fig, rotated, prefix: prefix) }
  else if mode == "replace" { models.merge(models.remove(fig, selector), rotated, prefix: prefix) }
  else { panic("sang-3d.revolution.rotate-selection: mode must be replace or copy") }
}

#let rotate-selection-through(fig, selector, a, b, angle, mode: "replace", prefix: "rot-") = rotate-selection(
  fig,
  selector,
  axis-from(fig, a, b),
  angle,
  mode: mode,
  prefix: prefix,
)

// One smart entry point for rotating a model. "move" returns the transformed
// model, "copy" keeps the source and adds one rotated copy, and "copies"
// distributes multiple snapshots over the requested angle.
#let turn(
  fig,
  around,
  angle,
  mode: "move",
  steps: 8,
  prefix: "rot-",
  include-start: true,
  include-end: true,
) = {
  if mode == "move" { return rotate-model(fig, around, angle) }
  if mode == "copy" {
    return models.merge(fig, rotate-model(fig, around, angle), prefix: prefix)
  }
  if mode != "copies" { panic("sang-3d.revolution.turn: mode must be move, copy, or copies") }
  copies(fig, around, angle, steps: steps, prefix: prefix, include-start: include-start, include-end: include-end)
}

#let copies(
  fig,
  around,
  angle,
  steps: 8,
  prefix: "rot-",
  include-start: true,
  include-end: true,
) = {
  if steps < 1 { panic("sang-3d.revolution.copies: steps must be positive") }
  let output = models.model()
  let start-index = if include-start { 0 } else { 1 }
  let end-index = if include-end { steps } else { steps - 1 }
  if end-index < start-index { return output }
  for index in range(start-index, end-index + 1) {
    let current = rotate-model(fig, around, angle * index / steps)
    output = models.merge(output, current, prefix: prefix + str(index) + "-")
  }
  output
}

// Orbit of a point around an arbitrary line. This is useful both as a
// construction and as an annotation of the rotation angle alpha.
#let orbit(
  point,
  around,
  angle: 120deg,
  segments: 48,
  prefix: "O",
  role: "accent",
  show-axis: false,
  axis-extent: (-2, 2),
  show-radius: false,
  show-endpoints: true,
  mark: none,
  label: none,
  source-name: auto,
  center-name: auto,
  label-name: auto,
  tags: (),
) = {
  let source = if source-name == auto { prefix + "P" } else { source-name }
  let center-ref = if center-name == auto { prefix + "C" } else { center-name }
  let label-ref = if label-name == auto { prefix + "L" } else { label-name }
  let center = core.orbit-center(point, around)
  let radius = core.orbit-radius(point, around)
  let points = (:)
  let registry = (:)
  let order = ()
  points.insert(source, point)
  registry.insert(source, definitions.derived("rotation-source-point", coordinate: point, parameters: (axis: around, angle: angle)))
  order.push(source)
  points.insert(center-ref, center)
  registry.insert(center-ref, definitions.derived("rotation-orbit-center", deps: (source,), coordinate: center, parameters: (axis: around, radius: radius)))
  order.push(center-ref)
  let names = ()
  for index in range(segments + 1) {
    let name = prefix + str(index)
    let coordinate = core.rotate-around-axis(point, around, angle * index / segments)
    points.insert(name, coordinate)
    registry.insert(name, definitions.derived("rotation-orbit-sample", deps: (source, center-ref), coordinate: coordinate, parameters: (index: index, parameter-angle: angle * index / segments, total-angle: angle)))
    order.push(name)
    names.push(name)
  }
  let items = (
    objects.polyline(names, id: prefix + "-arc", role: role, tags: tags + ("orbit", "rotation-path"), mark: mark, visibility: "always"),
  )
  if show-endpoints {
    items += (
      objects.point(names.first(), id: prefix + "-start", role: role, tags: tags + ("orbit-endpoint",), label: false),
      objects.point(names.last(), id: prefix + "-end", role: role, tags: tags + ("orbit-endpoint",), label: false),
    )
  }
  if show-radius {
    items += (
      objects.segment(center-ref, names.first(), id: prefix + "-radius-start", role: "construction", tags: tags + ("orbit-radius",), visibility: "always"),
      objects.segment(center-ref, names.last(), id: prefix + "-radius-end", role: "construction", tags: tags + ("orbit-radius",), visibility: "always"),
    )
  }
  if show-axis {
    let line = core.axis-line(around)
    let a0 = prefix + "A0"
    let a1 = prefix + "A1"
    let p0 = core.line-point(line, axis-extent.at(0))
    let p1 = core.line-point(line, axis-extent.at(1))
    points.insert(a0, p0)
    registry.insert(a0, definitions.derived("rotation-axis-endpoint", coordinate: p0, parameters: (axis: around, parameter: axis-extent.at(0))))
    order.push(a0)
    points.insert(a1, p1)
    registry.insert(a1, definitions.derived("rotation-axis-endpoint", deps: (a0,), coordinate: p1, parameters: (axis: around, parameter: axis-extent.at(1))))
    order.push(a1)
    items += (objects.segment(a0, a1, id: prefix + "-axis", role: "axis", tags: tags + ("rotation-axis",), mark: (end: ">"), visibility: "always"),)
  }
  if label != none {
    let middle = core.rotate-around-axis(point, around, angle / 2)
    points.insert(label-ref, middle)
    registry.insert(label-ref, definitions.derived("rotation-label-anchor", deps: (source, center-ref), coordinate: middle, parameters: (angle: angle / 2,)))
    order.push(label-ref)
    items += (objects.label(label-ref, label, id: prefix + "-label", role: role, tags: tags + ("rotation-label",)),)
  }
  models.model(points: points, definitions: registry, point-order: order, objects: items, meta: (kind: "orbit", axis: around, angle: angle, radius: radius, center: center, source-name: source, center-name: center-ref))
}

#let profile(
  function,
  around: core.axis(),
  t: (0, 1, 12),
  angle: 360deg,
  angle-steps: 32,
  profile-mode: "point",
  prefix: "R",
  mesh: true,
  faces: true,
  role: "surface",
  cull: true,
  tags: (),
) = surfaces.surface-of-revolution(
  function,
  t: t,
  angle: angle,
  angle-steps: angle-steps,
  around: around,
  profile-mode: profile-mode,
  prefix: prefix,
  mesh: mesh,
  faces: faces,
  role: role,
  cull: cull,
  tags: tags,
)

#let polyline-profile(
  points,
  around: core.axis(),
  angle: 360deg,
  angle-steps: 32,
  profile-steps: auto,
  prefix: "RP",
  mesh: true,
  faces: true,
  role: "surface",
  cull: true,
  tags: (),
) = surfaces.revolve-points(
  points,
  axis: around,
  angle: angle,
  angle-steps: angle-steps,
  profile-steps: profile-steps,
  prefix: prefix,
  mesh: mesh,
  faces: faces,
  role: role,
  cull: cull,
  tags: tags,
)

// Resolve an axis from an axis value, a pair of point references, an object id,
// or a selector matching a segment. This is the ergonomic bridge for
// "rotate one object around another object" workflows.
#let axis-of(fig, around) = {
  if type(around) == dictionary and around.at("point", default: none) != none and around.at("direction", default: none) != none {
    return around
  }
  if type(around) == array and around.len() == 2 {
    return axis-from(fig, around.at(0), around.at(1))
  }
  let selector = if type(around) == str { (id: around) }
    else if type(around) == dictionary { around }
    else { panic("sang-3d.revolution.axis-of: around must be an axis, a point pair, an object id, or a selector") }
  let candidates = models.select(fig, selector).filter(object => (
    object.kind == "segment" or object.kind == "circle3d" or
    object.kind == "arc3d" or object.kind == "plane-patch"
  ))
  if candidates.len() == 0 {
    panic("sang-3d.revolution.axis-of: selector must match a segment, circle, arc, or plane patch")
  }
  let object = candidates.first()
  if object.kind == "segment" {
    axis-from(fig, object.a, object.b, id: object.id)
  } else {
    core.axis(point: _resolve(fig, object.center), direction: object.normal, id: object.id)
  }
}

// Smart rotation entry point. `target` may be `auto`/"all" or any model
// selector. `around` may be an axis, (A, B), an edge id, or an edge selector.
#let turn-around(
  fig,
  around,
  angle,
  target: auto,
  mode: "move",
  steps: 8,
  prefix: "rot-",
  include-start: true,
  include-end: true,
) = {
  let ax = axis-of(fig, around)
  if target == auto or target == "all" {
    return turn(
      fig,
      ax,
      angle,
      mode: mode,
      steps: steps,
      prefix: prefix,
      include-start: include-start,
      include-end: include-end,
    )
  }
  if mode == "move" {
    return rotate-selection(fig, target, ax, angle, mode: "replace", prefix: prefix)
  }
  if mode == "copy" {
    return rotate-selection(fig, target, ax, angle, mode: "copy", prefix: prefix)
  }
  if mode != "copies" { panic("sang-3d.revolution.turn-around: mode must be move, copy, or copies") }
  let chosen = selection(fig, target)
  let snapshots = copies(
    chosen,
    ax,
    angle,
    steps: steps,
    prefix: prefix + "step-",
    include-start: false,
    include-end: include-end,
  )
  models.merge(fig, snapshots, prefix: prefix)
}
