#import "model.typ" as models
#import "transform.typ" as transforms
#import "styles.typ" as styles

#let node(body, prefix: "", transform: auto, styles: (:), visible: true, tags: (), meta: (:)) = (
  kind: "sang-3d-node",
  body: body,
  prefix: prefix,
  transform: if transform == auto { transforms.identity() } else { transform },
  styles: styles,
  visible: visible,
  tags: tags,
  meta: meta,
)

#let scene(children: (), styles: (:), meta: (:)) = (
  kind: "sang-3d-scene",
  children: children,
  styles: styles,
  meta: meta,
)

#let add(sc, child) = (: ..sc, children: sc.children + (child,))
#let with-styles(sc, patch) = (: ..sc, styles: (: ..sc.styles, ..patch))

#let flatten(value) = {
  if value.kind == "sang-3d-model" { return value }
  if value.kind == "sang-3d-node" {
    if not value.visible { return models.model() }
    let body = flatten(value.body)
    body = models.transform(body, value.transform)
    if value.styles.len() > 0 {
      body = (: ..body, objects: body.objects.map(object => {
        let options = object.options
        let previous = options.at("style", default: (:))
        options = (: ..options, style: styles.deep-merge(previous, value.styles))
        (: ..object, options: options)
      }))
    }
    if value.tags.len() > 0 {
      body = (: ..body, objects: body.objects.map(object => (: ..object, tags: object.tags + value.tags)))
    }
    body = (: ..body, meta: (: ..body.meta, ..value.meta))
    models.prefixed(body, value.prefix)
  } else if value.kind == "sang-3d-scene" {
    let output = models.model(styles: value.styles, meta: value.meta)
    for child in value.children { output = models.merge(output, flatten(child)) }
    output
  } else {
    panic("sang-3d.scene.flatten: expected a model, node, or scene")
  }
}
