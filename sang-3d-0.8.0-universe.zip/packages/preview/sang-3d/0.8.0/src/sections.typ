#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "definitions.typ" as definitions
#import "points.typ" as point-declarations

#let resolve(fig, ref) = if type(ref) == str { fig.points.at(ref) } else { ref }

#let _section-records(fig, pl, tolerance: 1e-6) = {
  let edges = fig.meta.at("edges", default: fig.objects.filter(object => object.kind == "segment").map(object => (object.a, object.b)))
  let records = ()
  for edge in edges {
    let hit = core.segment-plane-intersection(resolve(fig, edge.at(0)), resolve(fig, edge.at(1)), pl, tolerance: tolerance)
    if hit != none {
      let existing = records.find(record => core.distance3(record.coordinate, hit) <= tolerance)
      if existing == none { records.push((coordinate: hit, deps: edge)) }
    }
  }
  let sorted = core.sort-points-on-plane(records.map(record => record.coordinate), pl)
  sorted.map(point => records.find(record => core.distance3(record.coordinate, point) <= tolerance))
}

#let section-points(fig, pl, tolerance: 1e-6) = _section-records(fig, pl, tolerance: tolerance).map(record => record.coordinate)

#let with-section(
  fig,
  pl,
  prefix: "P",
  id: "section",
  labels: true,
  role: "section",
  tolerance: 1e-6,
  show-plane: false,
  plane-width: 5,
  plane-height: 4,
  plane-role: "auxiliary",
  plane-grid: none,
  point-policy: auto,
  plane-center-policy: auto,
) = {
  let records = _section-records(fig, pl, tolerance: tolerance)
  let points = records.map(record => record.coordinate)
  if points.len() < 3 { return (model: fig, points: points, names: (), plane: pl) }
  let actual-policy = if point-policy == auto and labels {
    point-declarations.policy(
      label: context => context.default-name,
      show-point: true,
      show-label: true,
      label-position: context => if calc.rem-euclid(context.index, 2) == 0 { "top-right" } else { "bottom-left" },
    )
  } else { point-policy }
  let declarations = ()
  for i in range(points.len()) {
    declarations.push(point-declarations.from-policy(
      prefix + str(i + 1),
      points.at(i),
      "section-edge-intersection",
      deps: records.at(i).deps,
      parameters: (plane: pl, index: i, section: id),
      policy: actual-policy,
      context: (index: i, section: id, prefix: prefix),
    ))
  }
  let declared = point-declarations.declare(declarations, known: fig.point-order)
  let names = declared.order
  let output = fig
  for declaration in declarations {
    output = models.with-declared-point(output, declaration)
  }
  output = models.with-object(output, objects.face(names, id: id, role: role, layer: 16, tags: ("section",), cull: false))
  output = models.with-object(output, objects.polyline(names, id: id + "-border", role: role, layer: 28, tags: ("section",), close: true))
  for declaration in declarations {
    let options = declaration.options
    if options.at("show-point", default: false) or options.at("show-label", default: false) {
      output = models.with-object(output, objects.point(
        declaration.name,
        role: options.at("role", default: role),
        point: options.at("show-point", default: false),
        label: if options.at("show-label", default: false) { options.at("label-content", default: auto) } else { none },
        tags: ("section", "generated-point"),
      ))
    }
  }
  if show-plane {
    let center-coordinate = core.centroid3(points)
    let center-declaration = point-declarations.from-policy(
      id + "-plane-center",
      center-coordinate,
      "section-plane-center",
      deps: names,
      parameters: (section: id, plane: pl),
      policy: plane-center-policy,
      context: (section: id, prefix: prefix),
    )
    output = models.with-declared-point(output, center-declaration)
    output = models.with-object(output, objects.plane-patch(
      center-declaration.name, pl.normal,
      width: plane-width, height: plane-height, id: id + "-plane", role: plane-role, layer: 4,
      tags: ("section-plane",), grid: plane-grid,
    ))
  }
  (model: output, points: points, names: names, plane: pl)
}

#let through-points(fig, a, b, c, ..options) = {
  let pl = core.plane-through(resolve(fig, a), resolve(fig, b), resolve(fig, c))
  with-section(fig, pl, ..options)
}
