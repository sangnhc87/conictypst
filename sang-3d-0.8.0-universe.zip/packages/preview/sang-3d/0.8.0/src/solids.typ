#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "definitions.typ" as definitions

#let _next(index, count) = calc.rem-euclid(index + 1, count)
#let _prev(index, count) = calc.rem-euclid(index - 1, count)
#let _as3(point) = if point.len() == 2 { (point.at(0), point.at(1), 0) } else { point }

#let _normalize-faces(faces) = {
  if type(faces) == dictionary {
    faces.pairs().map(pair => (id: pair.at(0), points: pair.at(1)))
  } else {
    faces.enumerate(start: 1).map(((index, refs)) => (id: "face-" + str(index), points: refs))
  }
}

#let polyhedron(
  points,
  faces,
  labels: true,
  role: "main",
  face-role: auto,
  edge-role: auto,
  face-fill: auto,
  cull: true,
  orient: true,
  edge-prefix: "edge",
  tags: (),
  point-definitions: auto,
  point-options: (:),
) = {
  let fr = if face-role == auto { role } else { face-role }
  let er = if edge-role == auto { role } else { edge-role }
  let records = _normalize-faces(faces)
  let solid-center = core.centroid3(points.values())
  let face-objects = ()
  let normalized-records = ()
  for record in records {
    let refs = record.points
    if orient {
      let coordinates = refs.map(ref => points.at(ref))
      let normal = core.polygon-normal(coordinates)
      let face-center = core.centroid3(coordinates)
      if core.dot3(normal, core.sub3(face-center, solid-center)) < 0 { refs = refs.rev() }
    }
    normalized-records.push((id: record.id, points: refs))
    face-objects.push(objects.face(refs, id: record.id, role: fr, fill: face-fill, cull: cull, tags: tags + ("faces",)))
  }
  let edge-map = (:)
  for face in normalized-records {
    for i in range(face.points.len()) {
      let a = face.points.at(i)
      let b = face.points.at(_next(i, face.points.len()))
      let key = if a < b { a + "|" + b } else { b + "|" + a }
      let previous = edge-map.at(key, default: none)
      if previous == none {
        edge-map.insert(key, (a: a, b: b, faces: (face.id,)))
      } else {
        edge-map.insert(key, (: ..previous, faces: previous.faces + (face.id,)))
      }
    }
  }
  let edge-objects = ()
  for (index, edge) in edge-map.values().enumerate(start: 1) {
    edge-objects.push(objects.segment(
      edge.a, edge.b, id: edge-prefix + "-" + str(index), role: er, faces: edge.faces, tags: tags + ("edges",),
    ))
  }
  let point-objects = ()
  for name in points.keys() {
    let opts = point-options.at(name, default: (:))
    let show-marker = opts.at("show-point", default: labels)
    let show-label = opts.at("show-label", default: labels)
    if show-marker or show-label {
      point-objects.push(objects.point(
        name,
        role: opts.at("role", default: role),
        point: show-marker,
        label: if show-label { auto } else { false },
        tags: tags + ("vertices",),
      ))
    }
  }
  let registry = if point-definitions == auto {
    definitions.manifest(points, kind: "polyhedron-vertex", source: "polyhedron")
  } else { point-definitions }
  models.model(
    points: points,
    definitions: registry,
    point-options: point-options,
    point-order: points.keys(),
    objects: face-objects + edge-objects + point-objects,
    meta: (
      kind: "polyhedron",
      convex: true,
      edges: edge-objects.map(edge => (edge.a, edge.b)),
      face-ids: face-objects.map(face => face.id),
    ),
  )
}

#let cuboid(width: 4, depth: 3, height: 3, origin: (0, 0, 0), labels: true, role: "main", names: ("A", "B", "C", "D", "A1", "B1", "C1", "D1"), point-options: (:), point-definitions: auto) = {
  let o = origin
  let coordinates = (
    core.add3(o, (0, 0, 0)), core.add3(o, (width, 0, 0)), core.add3(o, (width, depth, 0)), core.add3(o, (0, depth, 0)),
    core.add3(o, (0, 0, height)), core.add3(o, (width, 0, height)), core.add3(o, (width, depth, height)), core.add3(o, (0, depth, height)),
  )
  let points = names.zip(coordinates).to-dict()
  let registry = if point-definitions == auto { (:) } else { (: ..point-definitions) }
  if point-definitions == auto {
    for (index, name) in names.enumerate() {
      registry.insert(name, definitions.derived(
      "cuboid-vertex",
      coordinate: points.at(name),
        parameters: (index: index, origin: origin, width: width, depth: depth, height: height),
      ))
    }
  }
  polyhedron(points, (
    bottom: (names.at(3), names.at(2), names.at(1), names.at(0)),
    top: (names.at(4), names.at(5), names.at(6), names.at(7)),
    front: (names.at(0), names.at(1), names.at(5), names.at(4)),
    right: (names.at(1), names.at(2), names.at(6), names.at(5)),
    back: (names.at(2), names.at(3), names.at(7), names.at(6)),
    left: (names.at(3), names.at(0), names.at(4), names.at(7)),
  ), labels: labels, role: role, point-definitions: registry, point-options: point-options)
}
#let cube(size: 3, origin: (0, 0, 0), labels: true, role: "main", names: ("A", "B", "C", "D", "A1", "B1", "C1", "D1"), point-options: (:), point-definitions: auto) = cuboid(
  width: size, depth: size, height: size, origin: origin, labels: labels, role: role, names: names, point-options: point-options, point-definitions: point-definitions,
)

#let prism(base, height: 3, vector: auto, names: auto, labels: true, role: "main", point-options: (:), point-definitions: auto) = {
  let base3 = base.map(_as3)
  let count = base3.len()
  if count < 3 { panic("sang-3d.prism: base needs at least three points") }
  let lower = if names == auto { range(count).map(index => "A" + str(index + 1)) } else { names }
  let upper = lower.map(name => name + "1")
  let shift = if vector == auto { (0, 0, height) } else { vector }
  let points = (:)
  for i in range(count) {
    points.insert(lower.at(i), base3.at(i))
    points.insert(upper.at(i), core.add3(base3.at(i), shift))
  }
  let registry = if point-definitions == auto { (:) } else { (: ..point-definitions) }
  if point-definitions == auto {
    for i in range(count) {
      registry.insert(lower.at(i), definitions.derived("prism-base-vertex", coordinate: points.at(lower.at(i)), parameters: (index: i,)))
      registry.insert(upper.at(i), definitions.derived("translated-vertex", deps: (lower.at(i),), coordinate: points.at(upper.at(i)), parameters: (vector: shift,)))
    }
  }
  let faces = (base: lower.rev(), top: upper)
  for i in range(count) {
    let j = _next(i, count)
    faces.insert("side-" + str(i + 1), (lower.at(i), lower.at(j), upper.at(j), upper.at(i)))
  }
  polyhedron(points, faces, labels: labels, role: role, point-definitions: registry, point-options: point-options)
}
#let extrude(profile, vector, names: auto, labels: true, role: "main", point-options: (:), point-definitions: auto) = prism(profile, vector: vector, names: names, labels: labels, role: role, point-options: point-options, point-definitions: point-definitions)

#let pyramid(base, apex: auto, height: 4, base-names: auto, apex-name: "S", labels: true, role: "main", point-options: (:), point-definitions: auto) = {
  let base3 = base.map(_as3)
  let count = base3.len()
  if count < 3 { panic("sang-3d.pyramid: base needs at least three points") }
  let names = if base-names == auto { range(count).map(index => "A" + str(index + 1)) } else { base-names }
  let center = core.centroid3(base3)
  let top = if apex == auto { core.add3(center, (0, 0, height)) } else { apex }
  let points = (:)
  for i in range(count) { points.insert(names.at(i), base3.at(i)) }
  points.insert(apex-name, top)
  let registry = if point-definitions == auto { (:) } else { (: ..point-definitions) }
  if point-definitions == auto {
    for i in range(count) {
      registry.insert(names.at(i), definitions.derived("pyramid-base-vertex", coordinate: points.at(names.at(i)), parameters: (index: i,)))
    }
    registry.insert(apex-name, definitions.derived("pyramid-apex", deps: names, coordinate: top, parameters: (height: height, auto-apex: apex == auto)))
  }
  let faces = (base: names.rev())
  for i in range(count) {
    let j = _next(i, count)
    faces.insert("side-" + str(i + 1), (names.at(i), names.at(j), apex-name))
  }
  polyhedron(points, faces, labels: labels, role: role, point-definitions: registry, point-options: point-options)
}

#let frustum(base, height: 3, top-scale: 0.55, center: auto, base-names: auto, labels: true, role: "main", point-options: (:), point-definitions: auto) = {
  let base3 = base.map(_as3)
  let count = base3.len()
  let c = if center == auto { core.centroid3(base3) } else { center }
  let lower = if base-names == auto { range(count).map(index => "A" + str(index + 1)) } else { base-names }
  let upper = lower.map(name => name + "1")
  let points = (:)
  for i in range(count) {
    let p = base3.at(i)
    let q = core.add3(c, core.mul3(core.sub3(p, c), top-scale))
    q = core.add3(q, (0, 0, height))
    points.insert(lower.at(i), p)
    points.insert(upper.at(i), q)
  }
  let registry = if point-definitions == auto { (:) } else { (: ..point-definitions) }
  if point-definitions == auto {
    for i in range(count) {
      registry.insert(lower.at(i), definitions.derived("frustum-base-vertex", coordinate: points.at(lower.at(i)), parameters: (index: i,)))
      registry.insert(upper.at(i), definitions.derived("frustum-top-vertex", deps: (lower.at(i),), coordinate: points.at(upper.at(i)), parameters: (scale: top-scale, height: height)))
    }
  }
  let faces = (base: lower.rev(), top: upper)
  for i in range(count) {
    let j = _next(i, count)
    faces.insert("side-" + str(i + 1), (lower.at(i), lower.at(j), upper.at(j), upper.at(i)))
  }
  polyhedron(points, faces, labels: labels, role: role, point-definitions: registry, point-options: point-options)
}

#let regular-base(n, radius: 2, center: (0, 0), z: 0, rotation: 90deg) = {
  if n < 3 { panic("sang-3d.regular-base: n must be at least three") }
  range(n).map(index => {
    let angle = rotation + 360deg * index / n
    (center.at(0) + radius * calc.cos(angle), center.at(1) + radius * calc.sin(angle), z)
  })
}
#let regular-prism(n, radius: 2, height: 3, labels: true, role: "main", rotation: 90deg) = prism(regular-base(n, radius: radius, rotation: rotation), height: height, labels: labels, role: role)
#let regular-pyramid(n, radius: 2, height: 3, labels: true, role: "main", rotation: 90deg) = pyramid(regular-base(n, radius: radius, rotation: rotation), height: height, labels: labels, role: role)
#let regular-frustum(n, radius: 2, height: 3, top-scale: 0.55, labels: true, role: "main", rotation: 90deg) = frustum(regular-base(n, radius: radius, rotation: rotation), height: height, top-scale: top-scale, labels: labels, role: role)

#let tetrahedron(size: 3, height: auto, labels: true, role: "main") = {
  let h = if height == auto { size * calc.sqrt(2 / 3) } else { height }
  pyramid(
    ((0, 0, 0), (size, 0, 0), (size / 2, size * calc.sqrt(3) / 2, 0)),
    apex: (size / 2, size * calc.sqrt(3) / 6, h),
    base-names: ("A", "B", "C"), apex-name: "S", labels: labels, role: role,
  )
}

#let octahedron(radius: 2, labels: true, role: "main") = polyhedron(
  (
    X: (radius, 0, 0), NX: (-radius, 0, 0), Y: (0, radius, 0), NY: (0, -radius, 0),
    Z: (0, 0, radius), NZ: (0, 0, -radius),
  ),
  (
    f1: ("Z", "X", "Y"), f2: ("Z", "Y", "NX"), f3: ("Z", "NX", "NY"), f4: ("Z", "NY", "X"),
    f5: ("NZ", "Y", "X"), f6: ("NZ", "NX", "Y"), f7: ("NZ", "NY", "NX"), f8: ("NZ", "X", "NY"),
  ),
  labels: labels, role: role,
)

#let icosahedron(radius: 2, labels: false, role: "main") = {
  let phi = (1 + calc.sqrt(5)) / 2
  let raw = (
    (-1, phi, 0), (1, phi, 0), (-1, -phi, 0), (1, -phi, 0),
    (0, -1, phi), (0, 1, phi), (0, -1, -phi), (0, 1, -phi),
    (phi, 0, -1), (phi, 0, 1), (-phi, 0, -1), (-phi, 0, 1),
  )
  let scale = radius / core.norm3(raw.first())
  let names = ("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L")
  let points = names.zip(raw.map(point => core.mul3(point, scale))).to-dict()
  let f = (
    (0,11,5), (0,5,1), (0,1,7), (0,7,10), (0,10,11),
    (1,5,9), (5,11,4), (11,10,2), (10,7,6), (7,1,8),
    (3,9,4), (3,4,2), (3,2,6), (3,6,8), (3,8,9),
    (4,9,5), (2,4,11), (6,2,10), (8,6,7), (9,8,1),
  )
  polyhedron(points, f.map(face => face.map(index => names.at(index))), labels: labels, role: role)
}
