#import "core.typ" as core
// Semantic, deeply customizable styling.

#let palette = (
  ink: rgb("20252B"),
  muted: rgb("667085"),
  blue: rgb("2563EB"),
  green: rgb("15803D"),
  red: rgb("DC2626"),
  amber: rgb("D97706"),
  violet: rgb("7C3AED"),
  cyan: rgb("0891B2"),
)

#let get(value, key, fallback: none) = if type(value) == dictionary {
  value.at(key, default: fallback)
} else { fallback }

#let deep-merge(base, patch) = {
  if type(base) != dictionary or type(patch) != dictionary { return patch }
  let output = (: ..base)
  for (key, value) in patch {
    let previous = output.at(key, default: none)
    output.insert(key, if type(previous) == dictionary and type(value) == dictionary {
      deep-merge(previous, value)
    } else { value })
  }
  output
}

#let _accent(name) = if name == "green" { palette.green }
  else if name == "red" { palette.red }
  else if name == "amber" { palette.amber }
  else if name == "violet" { palette.violet }
  else if name == "cyan" { palette.cyan }
  else { palette.blue }

#let _role-set(accent) = (
  main: (stroke: (paint: palette.ink, thickness: 0.85pt), fill: accent.transparentize(91%)),
  strong: (stroke: (paint: palette.ink, thickness: 1.25pt), fill: accent.transparentize(88%)),
  auxiliary: (stroke: (paint: palette.muted, thickness: 0.6pt), fill: none),
  construction: (stroke: (paint: palette.muted.transparentize(20%), thickness: 0.55pt, dash: "dotted"), fill: none),
  hidden: (stroke: (paint: palette.muted.transparentize(15%), thickness: 0.58pt, dash: "dashed"), fill: none),
  accent: (stroke: (paint: accent, thickness: 1.15pt), fill: accent.transparentize(84%)),
  section: (stroke: (paint: accent, thickness: 1.35pt), fill: accent.transparentize(76%)),
  axis: (stroke: (paint: palette.muted, thickness: 0.65pt), fill: none),
  grid: (stroke: (paint: palette.muted.transparentize(58%), thickness: 0.4pt), fill: none),
  surface: (stroke: (paint: accent.transparentize(20%), thickness: 0.55pt), fill: accent.transparentize(88%)),
  dimension: (stroke: (paint: palette.ink, thickness: 0.65pt), fill: none),
  annotation: (stroke: (paint: accent, thickness: 0.8pt), fill: none),
)

#let _base-theme(accent) = (
  roles: _role-set(accent),
  point: (
    radius: 0.055,
    fill: white,
    stroke: (paint: palette.ink, thickness: 0.75pt),
  ),
  label: (
    size: 9.5pt,
    fill: palette.ink,
    offset: 0.22,
    separation: 0.32,
    edge-clearance: 0.12,
    point-clearance: 0.16,
    candidates: ((1, 1), (1, 0), (0, 1), (-1, 1), (1, -1), (-1, 0), (0, -1), (-1, -1)),
    mode: "global",
    iterations: 4,
    leader-lines: "auto",
    leader-threshold: 0.34,
  ),
  face: (
    shading: true,
    ambient: 0.76,
    diffuse: 0.24,
    contrast: 1.0,
    specular: 0.0,
    shininess: 20,
    rim: 0.0,
    tone-steps: 0,
    opacity: 1.0,
    light-direction: (0.4, -0.6, 1),
    back-fill: none,
  ),
  visibility: (
    mode: "raycast",
    samples: 22,
    refine: 5,
    tolerance: 0.012,
    hidden-lines: "dashed",
  ),
  annotation: (
    dimension-offset: 0.35,
    extension-gap: 0.06,
    extension-overhang: 0.10,
    tick-size: 0.12,
    arrow-mark: (start: "<", end: ">"),
  ),
  viewport: (
    width: 8.0,
    height: 6.2,
    padding: 0.10,
    canvas-length: 9cm,
  ),
)

#let _preset(name, accent) = {
  if name == "wireframe" {
    (face: (shading: false), roles: (main: (fill: none), surface: (fill: none)))
  } else if name == "technical" {
    (
      roles: (
        main: (stroke: (paint: palette.ink, thickness: 0.72pt), fill: none),
        hidden: (stroke: (paint: palette.muted, thickness: 0.48pt, dash: "dashed"), fill: none),
      ),
      face: (shading: false),
      visibility: (mode: "exact", samples: 30),
    )
  } else if name == "transparent" {
    (face: (shading: false), roles: (main: (fill: accent.transparentize(94%)), surface: (fill: accent.transparentize(94%))))
  } else if name == "textbook" {
    (face: (ambient: 0.84, diffuse: 0.16), visibility: (samples: 26))
  } else { (:) }
}

#let theme(name: "default", accent: auto, overrides: (:)) = {
  let actual-accent = if accent == auto { _accent(name) } else { accent }
  let base = _base-theme(actual-accent)
  let preset = _preset(name, actual-accent)
  deep-merge(deep-merge(base, preset), overrides)
}

#let merge(base, patch) = {
  let actual = if base == auto { theme() } else { base }
  if patch == auto { actual } else { deep-merge(actual, patch) }
}

#let role-style(style, role: "main") = style.roles.at(role, default: style.roles.main)
#let stroke-for(style, role: "main", override: auto) = if override != auto { override } else {
  role-style(style, role).at("stroke", default: style.roles.main.stroke)
}
#let fill-for(style, role: "main", override: auto) = if override != auto { override } else {
  role-style(style, role).at("fill", default: none)
}
#let point-style(style, patch: (:)) = deep-merge(style.point, patch)
#let label-style(style, patch: (:)) = deep-merge(style.label, patch)

#let shade(fill, normal, style) = {
  if fill == none or type(fill) != color { return fill }
  let opacity = style.face.at("opacity", default: 1.0)
  let base = if opacity >= 1 { fill } else { fill.transparentize((1 - opacity) * 100%) }
  if not style.face.shading { return base }
  let light = style.face.light-direction
  let n-length = calc.max(1e-8, calc.sqrt(normal.at(0)*normal.at(0) + normal.at(1)*normal.at(1) + normal.at(2)*normal.at(2)))
  let l-length = calc.max(1e-8, calc.sqrt(light.at(0)*light.at(0) + light.at(1)*light.at(1) + light.at(2)*light.at(2)))
  let cosine = calc.max(0, (normal.at(0) * light.at(0) + normal.at(1) * light.at(1) + normal.at(2) * light.at(2)) / (n-length * l-length))
  let view = (0, 0, 1)
  let halfway = core.unit3(core.add3(core.unit3(light), view), fallback: view)
  let specular = style.face.at("specular", default: 0.0) * calc.pow(calc.max(0, core.dot3(core.unit3(normal), halfway)), style.face.at("shininess", default: 20))
  let rim = style.face.at("rim", default: 0.0) * calc.pow(1 - calc.abs(core.dot3(core.unit3(normal), view)), 2)
  let intensity = style.face.ambient + style.face.diffuse * cosine + specular + rim
  let contrast = style.face.at("contrast", default: 1.0)
  intensity = 0.5 + (intensity - 0.5) * contrast
  let steps = style.face.at("tone-steps", default: 0)
  if steps > 1 { intensity = calc.round(core.clamp(intensity, 0, 1) * (steps - 1)) / (steps - 1) }
  if intensity >= 1 { base.lighten(calc.min(100%, (intensity - 1) * 20%)) } else { base.darken(calc.min(100%, (1 - intensity) * 24%)) }
}

// Selector-driven customization. Rules are applied left-to-right.
// A selector may target id, kind, role or tag. Example:
// (selector: (tag: "section"), style: (stroke: ..., fill: ...))
#let matches(object, selector) = {
  let ok = true
  if selector.at("id", default: none) != none { ok = ok and object.id == selector.id }
  if selector.at("kind", default: none) != none { ok = ok and object.kind == selector.kind }
  if selector.at("role", default: none) != none { ok = ok and object.role == selector.role }
  if selector.at("tag", default: none) != none { ok = ok and object.tags.contains(selector.tag) }
  ok
}

#let object-style(base, object, rules: ()) = {
  let out = base
  for rule in rules {
    if matches(object, rule.selector) { out = deep-merge(out, rule.style) }
  }
  out
}

#let rule(selector, style) = (selector: selector, style: style)

// Selector-driven customization. Rules are applied left-to-right.


// Reusable line/stroke vocabulary. These values can be passed directly to
// segment(..., stroke: ...), with-segment(..., stroke: ...), or theme roles.
#let dash-pattern(name) = {
  if name == "solid" or name == none { none }
  else if name == "dashed" or name == "hidden" { "dashed" }
  else if name == "dotted" or name == "construction" { "dotted" }
  else if name == "dash-dot" or name == "center" { (5pt, 2pt, 1pt, 2pt) }
  else if name == "long-dash" { (8pt, 3pt) }
  else if name == "dense-dash" { (3pt, 1.5pt) }
  else if name == "phantom" { (8pt, 2pt, 1pt, 2pt, 1pt, 2pt) }
  else { name }
}

#let stroke(
  pattern: "solid",
  paint: auto,
  thickness: auto,
  dash: auto,
  cap: auto,
  join: auto,
) = {
  let output = (:)
  if paint != auto { output.insert("paint", paint) }
  if thickness != auto { output.insert("thickness", thickness) }
  let actual-dash = if dash == auto { dash-pattern(pattern) } else { dash }
  if actual-dash != none { output.insert("dash", actual-dash) }
  if cap != auto { output.insert("cap", cap) }
  if join != auto { output.insert("join", join) }
  output
}

#let line-preset(name: "main", paint: auto, thickness: auto) = {
  let base = if name == "strong" { stroke(thickness: 1.25pt) }
  else if name == "thin" { stroke(thickness: 0.5pt) }
  else if name == "hidden" { stroke(pattern: "dashed", paint: palette.muted, thickness: 0.58pt) }
  else if name == "construction" { stroke(pattern: "dotted", paint: palette.muted, thickness: 0.55pt) }
  else if name == "center" { stroke(pattern: "dash-dot", paint: palette.muted, thickness: 0.55pt) }
  else if name == "axis" { stroke(pattern: "dash-dot", paint: palette.muted, thickness: 0.65pt) }
  else if name == "accent" { stroke(paint: palette.blue, thickness: 1.1pt) }
  else { stroke(thickness: 0.85pt) }
  let patch = (:)
  if paint != auto { patch.insert("paint", paint) }
  if thickness != auto { patch.insert("thickness", thickness) }
  deep-merge(base, patch)
}

#let role-patch(role, stroke: auto, fill: auto) = {
  let value = (:)
  if stroke != auto { value.insert("stroke", stroke) }
  if fill != auto { value.insert("fill", fill) }
  let roles = (:)
  roles.insert(role, value)
  (roles: roles)
}

#let line-rule(selector, pattern: "solid", role: "main", paint: auto, thickness: auto, dash: auto, cap: auto, join: auto) = rule(
  selector,
  role-patch(role, stroke: stroke(pattern: pattern, paint: paint, thickness: thickness, dash: dash, cap: cap, join: join)),
)

#let quality(name: "normal") = {
  if name == "draft" { (visibility: (mode: "convex", samples: 8, refine: 0), face: (shading: false), label: (iterations: 1)) }
  else if name == "print" { (visibility: (mode: "exact", samples: 36, refine: 7, tolerance: 0.008), label: (iterations: 5)) }
  else if name == "ultra" or name == "publication" { (visibility: (mode: "publication", samples: 64, refine: 9, tolerance: 0.004), label: (iterations: 7)) }
  else { (visibility: (mode: "raycast", samples: 22, refine: 5, tolerance: 0.012), label: (iterations: 4)) }
}
