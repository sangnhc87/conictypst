#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "solids.typ" as solids
#import "definitions.typ" as definitions
#import "points.typ" as point-declarations

#let _range-spec(spec) = {
  if spec.len() != 3 { panic("sang-3d.surface: range must be (start, end, steps)") }
  if spec.at(2) < 1 { panic("sang-3d.surface: steps must be positive") }
  (start: spec.at(0), end: spec.at(1), steps: spec.at(2))
}
#let _sample(spec, index) = spec.start + (spec.end - spec.start) * index / spec.steps
#let _name(prefix, i, j) = prefix + "-" + str(i) + "-" + str(j)
#let _edge-key(a, b) = if a < b { a + "|" + b } else { b + "|" + a }

#let parametric(
  function,
  u: (0, 1, 12),
  v: (0, 1, 12),
  prefix: "P",
  mesh: true,
  faces: true,
  role: "surface",
  mesh-role: auto,
  face-role: auto,
  cull: false,
  labels: false,
  close-u: false,
  close-v: false,
  flip: false,
  tags: (),
  point-policy: auto,
  control-points: (),
) = {
  let us = _range-spec(u)
  let vs = _range-spec(v)
  let mr = if mesh-role == auto { role } else { mesh-role }
  let fr = if face-role == auto { role } else { face-role }
  let u-count = if close-u { us.steps } else { us.steps + 1 }
  let v-count = if close-v { vs.steps } else { vs.steps + 1 }

  // Control points are public declarations and always precede samples.
  let declarations = control-points
  let control-names = control-points.map(item => item.name)
  let grid-names = (:)
  for i in range(u-count) {
    for j in range(v-count) {
      let default-name = _name(prefix, i, j)
      let u-value = _sample(us, i)
      let v-value = _sample(vs, j)
      let coordinate = function(u-value, v-value)
      let declaration = point-declarations.from-policy(
        default-name,
        coordinate,
        "parametric-surface-sample",
        deps: control-names,
        parameters: (u: u-value, v: v-value, u-index: i, v-index: j, prefix: prefix),
        policy: point-policy,
        context: (u: u-value, v: v-value, u-index: i, v-index: j, prefix: prefix),
      )
      declarations.push(declaration)
      grid-names.insert(default-name, declaration.name)
    }
  }
  let declared = point-declarations.declare(declarations)
  let ref(i, j) = grid-names.at(_name(prefix, i, j))

  let face-objects = ()
  let face-records = ()
  if faces {
    for i in range(us.steps) {
      for j in range(vs.steps) {
        let ni = if close-u { calc.rem-euclid(i + 1, u-count) } else { i + 1 }
        let nj = if close-v { calc.rem-euclid(j + 1, v-count) } else { j + 1 }
        let refs = (ref(i, j), ref(ni, j), ref(ni, nj), ref(i, nj))
        if flip { refs = refs.rev() }
        let id = prefix + "-face-" + str(i) + "-" + str(j)
        face-records.push((id: id, points: refs))
        face-objects.push(objects.face(
          refs, id: id, role: fr, cull: cull, tags: tags + ("surface-face", "faces"),
        ))
      }
    }
  }

  let edge-map = (:)
  for face in face-records {
    for index in range(face.points.len()) {
      let a = face.points.at(index)
      let b = face.points.at(calc.rem-euclid(index + 1, face.points.len()))
      let key = _edge-key(a, b)
      let previous = edge-map.at(key, default: none)
      if previous == none {
        edge-map.insert(key, (a: a, b: b, faces: (face.id,)))
      } else {
        edge-map.insert(key, (: ..previous, faces: previous.faces + (face.id,)))
      }
    }
  }

  if not faces and mesh {
    for i in range(u-count) {
      for j in range(vs.steps) {
        let nj = if close-v { calc.rem-euclid(j + 1, v-count) } else { j + 1 }
        let a = ref(i, j)
        let b = ref(i, nj)
        edge-map.insert(_edge-key(a, b), (a: a, b: b, faces: ()))
      }
    }
    for j in range(v-count) {
      for i in range(us.steps) {
        let ni = if close-u { calc.rem-euclid(i + 1, u-count) } else { i + 1 }
        let a = ref(i, j)
        let b = ref(ni, j)
        edge-map.insert(_edge-key(a, b), (a: a, b: b, faces: ()))
      }
    }
  }

  let mesh-objects = if mesh {
    edge-map.values().enumerate(start: 1).map(((index, edge)) => objects.segment(
      edge.a, edge.b,
      id: prefix + "-edge-" + str(index),
      role: mr,
      faces: edge.faces,
      tags: tags + ("surface-mesh", "edges"),
    ))
  } else { () }
  let point-objects = ()
  for declaration in declarations {
    let opts = declaration.options
    let is-control = control-names.contains(declaration.name)
    let show-marker = opts.at("show-point", default: if is-control { false } else { labels })
    let show-label = opts.at("show-label", default: if is-control { false } else { labels })
    if show-marker or show-label {
      point-objects.push(objects.point(
        declaration.name,
        role: opts.at("role", default: if is-control { "construction" } else { role }),
        point: show-marker,
        label: if show-label { opts.at("label-content", default: auto) } else { none },
        tags: tags + (if is-control { "surface-control-point" } else { "surface-point" },),
      ))
    }
  }
  let edges = edge-map.values().map(edge => (edge.a, edge.b))
  models.model(
    points: declared.points,
    definitions: declared.definitions,
    point-options: declared.point-options,
    point-order: declared.order,
    objects: face-objects + mesh-objects + point-objects,
    meta: (kind: "parametric-surface", edges: edges, face-ids: face-objects.map(face => face.id), open: not close-u or not close-v, controls: control-names),
  )
}

#let graph(function, x: (-2, 2, 12), y: (-2, 2, 12), prefix: "G", mesh: true, faces: true, role: "surface", cull: false, point-policy: auto) = parametric(
  (u, v) => (u, v, function(u, v)), u: x, v: y, prefix: prefix, mesh: mesh, faces: faces, role: role, cull: cull, point-policy: point-policy,
)

#let sphere(
  radius: 2,
  center: (0, 0, 0),
  latitudes: 10,
  longitudes: 18,
  prefix: "S",
  mesh: true,
  faces: true,
  labels: false,
  role: "surface",
  point-policy: auto,
  control-point-policy: auto,
) = {
  if latitudes < 2 or longitudes < 3 { panic("sang-3d.sphere: use at least 2 latitudes and 3 longitudes") }
  let actual-policy = if point-policy == auto and labels {
    point-declarations.policy(label: ctx => ctx.default-name, show-point: true, show-label: true)
  } else { point-policy }
  let center-declaration = point-declarations.from-policy(
    prefix + "-O", center, "sphere-center",
    parameters: (radius: radius),
    policy: control-point-policy,
    context: (control: "center", prefix: prefix),
  )
  let declarations = (center-declaration,)
  let north-declaration = point-declarations.from-policy(
    prefix + "-N", core.add3(center, (0, 0, radius)), "sphere-pole",
    deps: (center-declaration.name,),
    parameters: (pole: "north", radius: radius),
    policy: actual-policy,
    context: (kind: "pole", pole: "north", prefix: prefix),
  )
  let south-declaration = point-declarations.from-policy(
    prefix + "-S", core.add3(center, (0, 0, -radius)), "sphere-pole",
    deps: (center-declaration.name,),
    parameters: (pole: "south", radius: radius),
    policy: actual-policy,
    context: (kind: "pole", pole: "south", prefix: prefix),
  )
  declarations += (north-declaration, south-declaration)
  let ring-names = (:)
  for i in range(1, latitudes) {
    let latitude = 90deg - 180deg * i / latitudes
    for j in range(longitudes) {
      let longitude = 360deg * j / longitudes
      let default-name = prefix + "-r-" + str(i) + "-" + str(j)
      let coordinate = core.add3(center, (
        radius * calc.cos(latitude) * calc.cos(longitude),
        radius * calc.cos(latitude) * calc.sin(longitude),
        radius * calc.sin(latitude),
      ))
      let declaration = point-declarations.from-policy(
        default-name, coordinate, "sphere-latitude-longitude-point",
        deps: (center-declaration.name,),
        parameters: (latitude: latitude, longitude: longitude, latitude-index: i, longitude-index: j, radius: radius),
        policy: actual-policy,
        context: (kind: "ring", latitude: latitude, longitude: longitude, latitude-index: i, longitude-index: j, prefix: prefix),
      )
      declarations.push(declaration)
      ring-names.insert(default-name, declaration.name)
    }
  }
  let declared = point-declarations.declare(declarations)
  let ring-name(i, j) = ring-names.at(prefix + "-r-" + str(i) + "-" + str(j))
  let north = north-declaration.name
  let south = south-declaration.name
  let face-map = (:)
  for j in range(longitudes) {
    let next = calc.rem-euclid(j + 1, longitudes)
    face-map.insert(prefix + "-top-" + str(j), (north, ring-name(1, j), ring-name(1, next)))
    face-map.insert(prefix + "-bottom-" + str(j), (south, ring-name(latitudes - 1, next), ring-name(latitudes - 1, j)))
  }
  for i in range(1, latitudes - 1) {
    for j in range(longitudes) {
      let next = calc.rem-euclid(j + 1, longitudes)
      face-map.insert(prefix + "-side-" + str(i) + "-" + str(j), (
        ring-name(i, j), ring-name(i + 1, j), ring-name(i + 1, next), ring-name(i, next),
      ))
    }
  }
  let result = solids.polyhedron(
    declared.points, face-map,
    labels: labels, role: role, edge-role: role, face-role: role, cull: true,
    edge-prefix: prefix + "-edge", tags: ("sphere",),
    point-definitions: declared.definitions,
    point-options: declared.point-options,
  )
  if mesh and faces { result }
  else if mesh { models.hide(result, (kind: "face")) }
  else if faces { models.hide(result, (kind: "segment")) }
  else { models.model(points: declared.points, definitions: declared.definitions, point-options: declared.point-options, point-order: declared.order) }
}

#let torus(
  major-radius: 2.4,
  minor-radius: 0.65,
  center: (0, 0, 0),
  major-steps: 24,
  minor-steps: 10,
  prefix: "T",
  mesh: true,
  faces: true,
  role: "surface",
  point-policy: auto,
  control-point-policy: auto,
) = {
  let center-declaration = point-declarations.from-policy(
    prefix + "-O",
    center,
    "torus-center",
    parameters: (major-radius: major-radius, minor-radius: minor-radius),
    policy: control-point-policy,
    context: (control: "center", prefix: prefix),
  )
  let axis-coordinate = core.add3(center, (0, 0, 1))
  let axis-declaration = point-declarations.from-policy(
    prefix + "-Z",
    axis-coordinate,
    "torus-axis-point",
    deps: (center-declaration.name,),
    parameters: (direction: (0, 0, 1)),
    policy: control-point-policy,
    context: (control: "axis", prefix: prefix),
  )
  parametric(
    (u, v) => core.add3(center, (
      (major-radius + minor-radius * calc.cos(v)) * calc.cos(u),
      (major-radius + minor-radius * calc.cos(v)) * calc.sin(u),
      minor-radius * calc.sin(v),
    )),
    u: (0deg, 360deg, major-steps),
    v: (0deg, 360deg, minor-steps),
    prefix: prefix,
    mesh: mesh,
    faces: faces,
    role: role,
    cull: true,
    close-u: true,
    close-v: true,
    point-policy: point-policy,
    control-points: (center-declaration, axis-declaration),
  )
}

#let _axis-value(axis, center: (0, 0, 0)) = {
  if type(axis) == str {
    if axis == "x" { core.axis(point: center, direction: (1, 0, 0)) }
    else if axis == "y" { core.axis(point: center, direction: (0, 1, 0)) }
    else { core.axis(point: center, direction: (0, 0, 1)) }
  } else { axis }
}

// Rotate a profile around any oriented 3D axis. The legacy profile form
// profile(t) -> (radius, height) remains supported. Use profile-mode: "point"
// when profile(t) already returns a world-space 3D point.
#let surface-of-revolution(
  profile,
  t: (0, 1, 12),
  angle: 360deg,
  angle-steps: 24,
  axis: "z",
  around: auto,
  center: (0, 0, 0),
  profile-mode: "radius-height",
  prefix: "R",
  mesh: true,
  faces: true,
  role: "surface",
  mesh-role: auto,
  face-role: auto,
  cull: true,
  flip: false,
  tags: (),
  point-policy: auto,
  control-point-policy: auto,
) = {
  let ax = if around == auto { _axis-value(axis, center: center) } else { around }
  let axis-origin = point-declarations.from-policy(
    prefix + "-axis-O",
    core.axis-point(ax),
    "revolution-axis-origin",
    parameters: (axis: ax, angle: angle),
    policy: control-point-policy,
    context: (control: "axis-origin", prefix: prefix),
  )
  let axis-direction-point = point-declarations.from-policy(
    prefix + "-axis-D",
    core.add3(core.axis-point(ax), core.axis-direction(ax)),
    "revolution-axis-direction-point",
    deps: (axis-origin.name,),
    parameters: (direction: core.axis-direction(ax), angle: angle),
    policy: control-point-policy,
    context: (control: "axis-direction", prefix: prefix),
  )
  let basis = core.basis-from-normal(core.axis-direction(ax))
  let point-at(parameter) = {
    let sample = profile(parameter)
    if profile-mode == "point" { sample } else {
      let radius = sample.at(0)
      let height = sample.at(1)
      core.add3(core.axis-point(ax), core.add3(
        core.mul3(core.axis-direction(ax), height),
        core.mul3(basis.u, radius),
      ))
    }
  }
  let closed = calc.abs(angle) >= 359.999deg
  parametric(
    (parameter, theta) => core.rotate-around-axis(point-at(parameter), ax, theta),
    u: t,
    v: (0deg, angle, angle-steps),
    prefix: prefix,
    mesh: mesh,
    faces: faces,
    role: role,
    mesh-role: mesh-role,
    face-role: face-role,
    cull: cull,
    close-v: closed,
    flip: flip,
    tags: tags + ("revolution",),
  )
}

#let _polyline-sampler(points) = parameter => {
  if points.len() == 1 { return points.first() }
  let scaled = core.clamp(parameter, 0, 1) * (points.len() - 1)
  let index = calc.min(points.len() - 2, calc.floor(scaled))
  core.lerp3(points.at(index), points.at(index + 1), scaled - index)
}

#let revolve-points(
  points,
  angle: 360deg,
  angle-steps: 24,
  axis: core.axis(),
  profile-steps: auto,
  prefix: "RP",
  mesh: true,
  faces: true,
  role: "surface",
  cull: true,
  tags: (),
  point-policy: auto,
  control-point-policy: auto,
) = surface-of-revolution(
  _polyline-sampler(points),
  t: (0, 1, if profile-steps == auto { calc.max(1, points.len() - 1) } else { profile-steps }),
  angle: angle,
  angle-steps: angle-steps,
  around: axis,
  profile-mode: "point",
  prefix: prefix,
  mesh: mesh,
  faces: faces,
  role: role,
  cull: cull,
  tags: tags,
  point-policy: point-policy,
  control-point-policy: control-point-policy,
)

#let _radius-pair(value) = if type(value) == int or type(value) == float { (value, value) } else { value }
#let _valid-radii(value) = { let pair = _radius-pair(value); pair.at(0) > 0 and pair.at(1) > 0 }

#let _ring(center-declaration, direction, radius, sides, prefix, start-angle: 0deg, point-policy: auto, ring: "ring") = {
  let basis = core.basis-from-normal(direction)
  let radii = _radius-pair(radius)
  let declarations = ()
  let names = ()
  for index in range(sides) {
    let default-name = prefix + str(index + 1)
    let angle = start-angle + 360deg * index / sides
    let coordinate = core.add3(center-declaration.coordinate, core.add3(
      core.mul3(basis.u, radii.at(0) * calc.cos(angle)),
      core.mul3(basis.v, radii.at(1) * calc.sin(angle)),
    ))
    let declaration = point-declarations.from-policy(
      default-name,
      coordinate,
      "round-solid-ring-point",
      deps: (center-declaration.name,),
      parameters: (angle: angle, radii: radii, ring: ring, index: index),
      policy: point-policy,
      context: (angle: angle, radii: radii, ring: ring, index: index, prefix: prefix),
    )
    declarations.push(declaration)
    names.push(declaration.name)
  }
  (declarations: declarations, names: names)
}

#let _round-control(default-name, coordinate, kind, parameters: (:), policy: auto, context: (:), deps: ()) = point-declarations.from-policy(
  default-name, coordinate, kind,
  deps: deps,
  parameters: parameters,
  policy: policy,
  context: context,
)

#let frustum-between(
  base-center,
  top-center,
  radius: 2,
  top-radius: 1,
  sides: 32,
  caps: true,
  labels: false,
  role: "surface",
  edge-role: auto,
  face-role: auto,
  prefix: "F",
  start-angle: 0deg,
  twist: 0deg,
  tags: (),
  point-policy: auto,
  control-point-policy: auto,
) = {
  if sides < 3 { panic("sang-3d.frustum-between: sides must be at least 3") }
  if not _valid-radii(radius) or not _valid-radii(top-radius) { panic("sang-3d.frustum-between: radii must be positive; use cone-between for an apex") }
  let direction = core.sub3(top-center, base-center)
  if core.norm3(direction) <= core.epsilon { panic("sang-3d.frustum-between: centers must be different") }
  let actual-policy = if point-policy == auto and labels { point-declarations.policy(label: ctx => ctx.default-name, show-point: true, show-label: true) } else { point-policy }
  let base-control = _round-control(prefix + "-O1", base-center, "round-solid-base-center", parameters: (radius: radius), policy: control-point-policy, context: (control: "base-center", prefix: prefix))
  let top-control = _round-control(prefix + "-O2", top-center, "round-solid-top-center", deps: (base-control.name,), parameters: (top-radius: top-radius), policy: control-point-policy, context: (control: "top-center", prefix: prefix))
  let base = _ring(base-control, direction, radius, sides, prefix + "B", start-angle: start-angle, point-policy: actual-policy, ring: "base")
  let top = _ring(top-control, direction, top-radius, sides, prefix + "T", start-angle: start-angle + twist, point-policy: actual-policy, ring: "top")
  let declared = point-declarations.declare((base-control, top-control) + base.declarations + top.declarations)
  let faces-map = (:)
  for index in range(sides) {
    let next = calc.rem-euclid(index + 1, sides)
    faces-map.insert(prefix + "-side-" + str(index + 1), (
      base.names.at(index), base.names.at(next), top.names.at(next), top.names.at(index),
    ))
  }
  if caps {
    faces-map.insert(prefix + "-base", base.names.rev())
    faces-map.insert(prefix + "-top", top.names)
  }
  solids.polyhedron(
    declared.points, faces-map,
    labels: labels, role: role, edge-role: edge-role, face-role: face-role,
    cull: true, edge-prefix: prefix + "-edge", tags: tags + ("frustum", "round-solid"),
    point-definitions: declared.definitions, point-options: declared.point-options,
  )
}

#let cylinder-between(
  a,
  b,
  radius: 2,
  sides: 32,
  caps: true,
  labels: false,
  role: "surface",
  edge-role: auto,
  face-role: auto,
  prefix: "C",
  start-angle: 0deg,
  twist: 0deg,
  tags: (),
  point-policy: auto,
  control-point-policy: auto,
) = frustum-between(
  a, b,
  radius: radius, top-radius: radius, sides: sides, caps: caps, labels: labels,
  role: role, edge-role: edge-role, face-role: face-role, prefix: prefix,
  start-angle: start-angle, twist: twist, tags: tags + ("cylinder",),
  point-policy: point-policy, control-point-policy: control-point-policy,
)

#let cone-between(
  base-center,
  apex,
  radius: 2,
  sides: 32,
  cap: true,
  labels: false,
  role: "surface",
  edge-role: auto,
  face-role: auto,
  prefix: "N",
  start-angle: 0deg,
  tags: (),
  point-policy: auto,
  control-point-policy: auto,
) = {
  if sides < 3 { panic("sang-3d.cone-between: sides must be at least 3") }
  let direction = core.sub3(apex, base-center)
  if core.norm3(direction) <= core.epsilon { panic("sang-3d.cone-between: apex and base center must be different") }
  if not _valid-radii(radius) { panic("sang-3d.cone-between: radius/radii must be positive") }
  let actual-policy = if point-policy == auto and labels { point-declarations.policy(label: ctx => ctx.default-name, show-point: true, show-label: true) } else { point-policy }
  let base-control = _round-control(prefix + "-O", base-center, "cone-base-center", parameters: (radius: radius), policy: control-point-policy, context: (control: "base-center", prefix: prefix))
  let apex-control = _round-control(prefix + "-S", apex, "cone-apex", deps: (base-control.name,), parameters: (radius: radius), policy: control-point-policy, context: (control: "apex", prefix: prefix))
  let base = _ring(base-control, direction, radius, sides, prefix + "B", start-angle: start-angle, point-policy: actual-policy, ring: "base")
  let declared = point-declarations.declare((base-control, apex-control) + base.declarations)
  let faces-map = (:)
  for index in range(sides) {
    let next = calc.rem-euclid(index + 1, sides)
    faces-map.insert(prefix + "-side-" + str(index + 1), (base.names.at(index), base.names.at(next), apex-control.name))
  }
  if cap { faces-map.insert(prefix + "-base", base.names.rev()) }
  solids.polyhedron(
    declared.points, faces-map,
    labels: labels, role: role, edge-role: edge-role, face-role: face-role,
    cull: true, edge-prefix: prefix + "-edge", tags: tags + ("cone", "round-solid"),
    point-definitions: declared.definitions, point-options: declared.point-options,
  )
}

#let tube-between(
  a,
  b,
  outer-radius: 2,
  inner-radius: 1.2,
  sides: 32,
  caps: true,
  labels: false,
  role: "surface",
  prefix: "U",
  start-angle: 0deg,
  tags: (),
  point-policy: auto,
  control-point-policy: auto,
) = {
  if inner-radius <= 0 or inner-radius >= outer-radius { panic("sang-3d.tube-between: require 0 < inner-radius < outer-radius") }
  let direction = core.sub3(b, a)
  let actual-policy = if point-policy == auto and labels { point-declarations.policy(label: ctx => ctx.default-name, show-point: true, show-label: true) } else { point-policy }
  let bottom-control = _round-control(prefix + "-O1", a, "tube-bottom-center", parameters: (outer-radius: outer-radius, inner-radius: inner-radius), policy: control-point-policy, context: (control: "bottom-center", prefix: prefix))
  let top-control = _round-control(prefix + "-O2", b, "tube-top-center", deps: (bottom-control.name,), parameters: (outer-radius: outer-radius, inner-radius: inner-radius), policy: control-point-policy, context: (control: "top-center", prefix: prefix))
  let ob = _ring(bottom-control, direction, outer-radius, sides, prefix + "OB", start-angle: start-angle, point-policy: actual-policy, ring: "outer-bottom")
  let ot = _ring(top-control, direction, outer-radius, sides, prefix + "OT", start-angle: start-angle, point-policy: actual-policy, ring: "outer-top")
  let ib = _ring(bottom-control, direction, inner-radius, sides, prefix + "IB", start-angle: start-angle, point-policy: actual-policy, ring: "inner-bottom")
  let it = _ring(top-control, direction, inner-radius, sides, prefix + "IT", start-angle: start-angle, point-policy: actual-policy, ring: "inner-top")
  let declared = point-declarations.declare((bottom-control, top-control) + ob.declarations + ot.declarations + ib.declarations + it.declarations)
  let faces-map = (:)
  for index in range(sides) {
    let next = calc.rem-euclid(index + 1, sides)
    faces-map.insert(prefix + "-outer-" + str(index + 1), (ob.names.at(index), ob.names.at(next), ot.names.at(next), ot.names.at(index)))
    faces-map.insert(prefix + "-inner-" + str(index + 1), (ib.names.at(next), ib.names.at(index), it.names.at(index), it.names.at(next)))
    if caps {
      faces-map.insert(prefix + "-bottom-" + str(index + 1), (ob.names.at(next), ob.names.at(index), ib.names.at(index), ib.names.at(next)))
      faces-map.insert(prefix + "-top-" + str(index + 1), (ot.names.at(index), ot.names.at(next), it.names.at(next), it.names.at(index)))
    }
  }
  solids.polyhedron(
    declared.points, faces-map,
    labels: labels, role: role, cull: true, orient: false,
    edge-prefix: prefix + "-edge", tags: tags + ("tube", "round-solid"),
    point-definitions: declared.definitions, point-options: declared.point-options,
  )
}

#let cylinder(
  radius: 2,
  height: 3,
  sides: 32,
  center: (0, 0, 0),
  direction: (0, 0, 1),
  top-center: auto,
  caps: true,
  labels: false,
  role: "surface",
  prefix: "C",
  point-policy: auto,
  control-point-policy: auto,
) = {
  let top = if top-center == auto { core.add3(center, core.mul3(core.unit3(direction, fallback: (0, 0, 1)), height)) } else { top-center }
  cylinder-between(center, top, radius: radius, sides: sides, caps: caps, labels: labels, role: role, prefix: prefix, point-policy: point-policy, control-point-policy: control-point-policy)
}
#let cone(
  radius: 2,
  height: 3,
  sides: 32,
  center: (0, 0, 0),
  direction: (0, 0, 1),
  apex: auto,
  cap: true,
  labels: false,
  role: "surface",
  prefix: "N",
  point-policy: auto,
  control-point-policy: auto,
) = {
  let top = if apex == auto { core.add3(center, core.mul3(core.unit3(direction, fallback: (0, 0, 1)), height)) } else { apex }
  cone-between(center, top, radius: radius, sides: sides, cap: cap, labels: labels, role: role, prefix: prefix, point-policy: point-policy, control-point-policy: control-point-policy)
}
#let truncated-cone(
  radius: 2,
  top-radius: 1,
  height: 3,
  sides: 32,
  center: (0, 0, 0),
  direction: (0, 0, 1),
  top-center: auto,
  caps: true,
  labels: false,
  role: "surface",
  prefix: "F",
  point-policy: auto,
  control-point-policy: auto,
) = {
  let top = if top-center == auto { core.add3(center, core.mul3(core.unit3(direction, fallback: (0, 0, 1)), height)) } else { top-center }
  frustum-between(center, top, radius: radius, top-radius: top-radius, sides: sides, caps: caps, labels: labels, role: role, prefix: prefix, point-policy: point-policy, control-point-policy: control-point-policy)
}

#let spherical-zone(
  radius: 2,
  center: (0, 0, 0),
  axis: (0, 0, 1),
  polar: (0deg, 180deg),
  latitudes: 10,
  longitudes: 24,
  caps: false,
  prefix: "Z",
  mesh: true,
  faces: true,
  labels: false,
  role: "surface",
  tags: (),
  point-policy: auto,
  control-point-policy: auto,
) = {
  if latitudes < 1 or longitudes < 3 { panic("sang-3d.spherical-zone: invalid resolution") }
  let direction = core.unit3(axis, fallback: (0, 0, 1))
  let basis = core.basis-from-normal(direction)
  let start = polar.at(0)
  let end = polar.at(1)
  let actual-policy = if point-policy == auto and labels { point-declarations.policy(label: ctx => ctx.default-name, show-point: true, show-label: true) } else { point-policy }
  let center-control = point-declarations.from-policy(
    prefix + "-O", center, "spherical-zone-center",
    parameters: (radius: radius, polar: polar), policy: control-point-policy,
    context: (control: "center", prefix: prefix),
  )
  let axis-control = point-declarations.from-policy(
    prefix + "-D", core.add3(center, direction), "spherical-zone-axis-point",
    deps: (center-control.name,), parameters: (direction: direction), policy: control-point-policy,
    context: (control: "axis", prefix: prefix),
  )
  let at(phi, theta) = core.add3(center, core.add3(
    core.mul3(direction, radius * calc.cos(phi)),
    core.add3(core.mul3(basis.u, radius * calc.sin(phi) * calc.cos(theta)), core.mul3(basis.v, radius * calc.sin(phi) * calc.sin(theta))),
  ))
  let declarations = (center-control, axis-control)
  let ring-names = ()
  let add-ring(index, phi, pole: false) = {
    let names = ()
    let count = if pole { 1 } else { longitudes }
    for j in range(count) {
      let theta = if pole { 0deg } else { 360deg * j / longitudes }
      let default-name = if pole { prefix + "-P" + str(index) } else { prefix + "-R" + str(index) + "-" + str(j) }
      let declaration = point-declarations.from-policy(
        default-name, at(phi, theta), if pole { "spherical-zone-pole" } else { "spherical-zone-ring-point" },
        deps: (center-control.name, axis-control.name),
        parameters: (polar: phi, azimuth: theta, ring-index: index, longitude-index: j, radius: radius),
        policy: actual-policy,
        context: (polar: phi, azimuth: theta, ring-index: index, longitude-index: j, pole: pole, prefix: prefix),
      )
      declarations.push(declaration)
      names.push(declaration.name)
    }
    names
  }
  let start-pole = calc.abs(calc.sin(start)) <= 1e-7
  let end-pole = calc.abs(calc.sin(end)) <= 1e-7
  ring-names.push(add-ring(0, start, pole: start-pole))
  for i in range(1, latitudes) {
    let phi = start + (end - start) * i / latitudes
    ring-names.push(add-ring(i, phi))
  }
  ring-names.push(add-ring(latitudes, end, pole: end-pole))
  let declared = point-declarations.declare(declarations)
  let face-map = (:)
  for i in range(ring-names.len() - 1) {
    let lower = ring-names.at(i)
    let upper = ring-names.at(i + 1)
    if lower.len() == 1 {
      for j in range(longitudes) {
        let next = calc.rem-euclid(j + 1, longitudes)
        face-map.insert(prefix + "-face-" + str(i) + "-" + str(j), (lower.first(), upper.at(j), upper.at(next)))
      }
    } else if upper.len() == 1 {
      for j in range(longitudes) {
        let next = calc.rem-euclid(j + 1, longitudes)
        face-map.insert(prefix + "-face-" + str(i) + "-" + str(j), (lower.at(j), upper.first(), lower.at(next)))
      }
    } else {
      for j in range(longitudes) {
        let next = calc.rem-euclid(j + 1, longitudes)
        face-map.insert(prefix + "-face-" + str(i) + "-" + str(j), (lower.at(j), upper.at(j), upper.at(next), lower.at(next)))
      }
    }
  }
  if caps and ring-names.first().len() > 1 { face-map.insert(prefix + "-cap-start", ring-names.first().rev()) }
  if caps and ring-names.last().len() > 1 { face-map.insert(prefix + "-cap-end", ring-names.last()) }
  let result = solids.polyhedron(
    declared.points, face-map,
    labels: labels, role: role, cull: true, edge-prefix: prefix + "-edge", tags: tags + ("sphere", "spherical-zone"),
    point-definitions: declared.definitions, point-options: declared.point-options,
  )
  if mesh and faces { result }
  else if mesh { models.hide(result, (kind: "face")) }
  else if faces { models.hide(result, (kind: "segment")) }
  else { models.model(points: declared.points, definitions: declared.definitions, point-options: declared.point-options, point-order: declared.order) }
}

#let hemisphere(
  radius: 2,
  center: (0, 0, 0),
  axis: (0, 0, 1),
  side: "positive",
  caps: true,
  latitudes: 7,
  longitudes: 24,
  prefix: "H",
  mesh: true,
  faces: true,
  labels: false,
  role: "surface",
  point-policy: auto,
  control-point-policy: auto,
) = spherical-zone(
  radius: radius,
  center: center,
  axis: axis,
  polar: if side == "negative" { (90deg, 180deg) } else { (0deg, 90deg) },
  caps: caps,
  latitudes: latitudes,
  longitudes: longitudes,
  prefix: prefix,
  mesh: mesh,
  faces: faces,
  labels: labels,
  role: role,
  point-policy: point-policy,
  control-point-policy: control-point-policy,
)

#let spherical-cap(
  radius: 2,
  height: 0.8,
  center: (0, 0, 0),
  axis: (0, 0, 1),
  caps: true,
  latitudes: 6,
  longitudes: 24,
  prefix: "K",
  mesh: true,
  faces: true,
  role: "surface",
  point-policy: auto,
  control-point-policy: auto,
) = {
  if height <= 0 or height > 2 * radius { panic("sang-3d.spherical-cap: require 0 < height <= 2*radius") }
  let end = calc.acos(core.clamp((radius - height) / radius, -1, 1))
  spherical-zone(radius: radius, center: center, axis: axis, polar: (0deg, end), caps: caps, latitudes: latitudes, longitudes: longitudes, prefix: prefix, mesh: mesh, faces: faces, role: role, point-policy: point-policy, control-point-policy: control-point-policy)
}

#let capsule(
  a,
  b,
  radius: 1,
  sides: 24,
  hemisphere-steps: 6,
  role: "surface",
  prefix: "Q",
  point-policy: auto,
  control-point-policy: auto,
) = {
  let direction = core.unit3(core.sub3(b, a), fallback: (0, 0, 1))
  let body = cylinder-between(a, b, radius: radius, sides: sides, caps: false, role: role, prefix: prefix + "B", point-policy: point-policy, control-point-policy: control-point-policy)
  let bottom = spherical-zone(radius: radius, center: a, axis: direction, polar: (90deg, 180deg), latitudes: hemisphere-steps, longitudes: sides, caps: false, prefix: prefix + "L", role: role, point-policy: point-policy, control-point-policy: control-point-policy)
  let top = spherical-zone(radius: radius, center: b, axis: direction, polar: (0deg, 90deg), latitudes: hemisphere-steps, longitudes: sides, caps: false, prefix: prefix + "T", role: role, point-policy: point-policy, control-point-policy: control-point-policy)
  models.merge-many((body, bottom, top), prefixes: ("", "", ""))
}


#let elliptic-cylinder-between(
  a,
  b,
  radii: (2, 1),
  sides: 40,
  caps: true,
  twist: 0deg,
  labels: false,
  role: "surface",
  prefix: "EC",
  tags: (),
  point-policy: auto,
  control-point-policy: auto,
) = cylinder-between(a, b, radius: radii, sides: sides, caps: caps, twist: twist, labels: labels, role: role, prefix: prefix, tags: tags + ("elliptic-cylinder",), point-policy: point-policy, control-point-policy: control-point-policy)

#let elliptic-cone-between(
  base-center,
  apex,
  radii: (2, 1),
  sides: 40,
  cap: true,
  labels: false,
  role: "surface",
  prefix: "EN",
  tags: (),
  point-policy: auto,
  control-point-policy: auto,
) = cone-between(base-center, apex, radius: radii, sides: sides, cap: cap, labels: labels, role: role, prefix: prefix, tags: tags + ("elliptic-cone",), point-policy: point-policy, control-point-policy: control-point-policy)

#let ellipsoid(radii: (2, 1.5, 1), center: (0, 0, 0), latitudes: 10, longitudes: 18, prefix: "E", mesh: true, faces: true, labels: false, role: "surface", point-policy: auto, control-point-policy: auto) = {
  let unit = sphere(radius: 1, center: center, latitudes: latitudes, longitudes: longitudes, prefix: prefix, mesh: mesh, faces: faces, labels: labels, role: role, point-policy: point-policy, control-point-policy: control-point-policy)
  models.scale(unit, radii, origin: center)
}
