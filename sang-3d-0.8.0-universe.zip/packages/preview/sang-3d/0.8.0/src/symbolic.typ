// Numeric geometry paired with reusable symbolic labels and measurements.
#import "core.typ" as core
#import "model.typ" as models
#import "solids.typ" as solids
#import "surfaces.typ" as surfaces

#let scalar(symbol, value, unit: none) = (
  kind: "sang-3d-symbolic-scalar",
  symbol: symbol,
  value: value,
  unit: unit,
)

#let is-symbolic(value) = type(value) == dictionary and value.at("kind", default: none) == "sang-3d-symbolic-scalar"
#let numeric(value) = if is-symbolic(value) { value.value } else { value }
#let expression(value) = if is-symbolic(value) { value.symbol } else { [#value] }
#let _unit(value) = if is-symbolic(value) { value.unit } else { none }

#let _binary(a, b, op, calculate, unit: none) = scalar(
  [#expression(a) #op #expression(b)],
  calculate(numeric(a), numeric(b)),
  unit: unit,
)

#let add(a, b) = _binary(a, b, [+], (x, y) => x + y, unit: if _unit(a) == _unit(b) { _unit(a) } else { none })
#let subtract(a, b) = _binary(a, b, [−], (x, y) => x - y, unit: if _unit(a) == _unit(b) { _unit(a) } else { none })
#let multiply(a, b) = _binary(a, b, [·], (x, y) => x * y)
#let divide(a, b) = _binary(a, b, [/], (x, y) => x / y)
#let power(a, exponent) = scalar([(#expression(a))^#exponent], calc.pow(numeric(a), exponent))
#let root(a, degree: 2) = scalar([root(#degree, #expression(a))], calc.pow(numeric(a), 1 / degree))
#let constant(symbol, value) = scalar(symbol, value)
#let pi = constant([$pi$], calc.pi)

#let formula(value, name: none, approximate: false, digits: 3) = {
  let lhs = if name == none { [] } else { [#name = ] }
  let rhs = expression(value)
  let approximation = if approximate { [ $approx$ #calc.round(numeric(value), digits: digits)] } else { [] }
  let unit = if _unit(value) == none { [] } else { [ #_unit(value)] }
  [#lhs#rhs#approximation#unit]
}

#let attach(fig, kind, parameters, measures: (:)) = models.with-meta(fig, (
  symbolic: (
    kind: kind,
    parameters: parameters,
    measures: measures,
  ),
))

#let cuboid(width: scalar([a], 4), depth: scalar([b], 3), height: scalar([h], 3), origin: (0, 0, 0), labels: true, role: "main") = attach(
  solids.cuboid(width: numeric(width), depth: numeric(depth), height: numeric(height), origin: origin, labels: labels, role: role),
  "cuboid",
  (width: width, depth: depth, height: height),
)

#let cube(size: scalar([a], 3), origin: (0, 0, 0), labels: true, role: "main") = attach(
  solids.cube(size: numeric(size), origin: origin, labels: labels, role: role),
  "cube",
  (size: size,),
)

#let cylinder(radius: scalar([R], 2), height: scalar([h], 3), sides: 32, center: (0, 0, 0), direction: (0, 0, 1), labels: false, role: "surface") = attach(
  surfaces.cylinder(radius: numeric(radius), height: numeric(height), sides: sides, center: center, direction: direction, labels: labels, role: role),
  "cylinder",
  (radius: radius, height: height),
)

#let cone(radius: scalar([R], 2), height: scalar([h], 3), sides: 32, center: (0, 0, 0), direction: (0, 0, 1), labels: false, role: "surface") = attach(
  surfaces.cone(radius: numeric(radius), height: numeric(height), sides: sides, center: center, direction: direction, labels: labels, role: role),
  "cone",
  (radius: radius, height: height),
)

#let sphere(radius: scalar([R], 2), center: (0, 0, 0), latitudes: 10, longitudes: 18, labels: false, role: "surface") = attach(
  surfaces.sphere(radius: numeric(radius), center: center, latitudes: latitudes, longitudes: longitudes, labels: labels, role: role),
  "sphere",
  (radius: radius,),
)

#let frustum(radius: scalar([R], 2), top-radius: scalar([r], 1), height: scalar([h], 3), sides: 32, center: (0, 0, 0), direction: (0, 0, 1), labels: false, role: "surface") = attach(
  surfaces.truncated-cone(radius: numeric(radius), top-radius: numeric(top-radius), height: numeric(height), sides: sides, center: center, direction: direction, labels: labels, role: role),
  "frustum",
  (radius: radius, top-radius: top-radius, height: height),
)

#let _data(fig) = fig.meta.at("symbolic", default: none)
#let _need(fig) = {
  let data = _data(fig)
  if data == none { panic("sang-3d.symbolic: model has no symbolic metadata; use symbolic constructors or symbolic.attach") }
  data
}

#let volume(fig) = {
  let data = _need(fig)
  let p = data.parameters
  if data.kind == "cuboid" { multiply(multiply(p.width, p.depth), p.height) }
  else if data.kind == "cube" { power(p.size, 3) }
  else if data.kind == "cylinder" { multiply(multiply(pi, power(p.radius, 2)), p.height) }
  else if data.kind == "cone" { divide(multiply(multiply(pi, power(p.radius, 2)), p.height), 3) }
  else if data.kind == "sphere" { multiply(divide(4, 3), multiply(pi, power(p.radius, 3))) }
  else if data.kind == "frustum" {
    multiply(divide(multiply(pi, p.height), 3), add(add(power(p.radius, 2), multiply(p.radius, p.top-radius)), power(p.top-radius, 2)))
  } else if data.kind == "prism" { multiply(p.base-area, p.height) }
  else if data.kind == "pyramid" { divide(multiply(p.base-area, p.height), 3) }
  else if data.kind == "torus" { multiply(multiply(2, power(pi, 2)), multiply(p.major-radius, power(p.minor-radius, 2))) }
  else if data.kind == "ellipsoid" { multiply(divide(4, 3), multiply(pi, product((p.rx, p.ry, p.rz)))) }
  else { data.measures.at("volume", default: panic("sang-3d.symbolic.volume: unsupported kind " + data.kind)) }
}

#let surface-area(fig) = {
  let data = _need(fig)
  let p = data.parameters
  if data.kind == "cuboid" { multiply(2, add(add(multiply(p.width, p.depth), multiply(p.width, p.height)), multiply(p.depth, p.height))) }
  else if data.kind == "cube" { multiply(6, power(p.size, 2)) }
  else if data.kind == "sphere" { multiply(4, multiply(pi, power(p.radius, 2))) }
  else if data.kind == "cylinder" { multiply(multiply(2, pi), multiply(p.radius, add(p.radius, p.height))) }
  else if data.kind == "cone" {
    let slant = root(add(power(p.radius, 2), power(p.height, 2)))
    multiply(pi, multiply(p.radius, add(p.radius, slant)))
  } else { data.measures.at("surface-area", default: panic("sang-3d.symbolic.surface-area: unsupported kind " + data.kind)) }
}

#let diagonal(fig) = {
  let data = _need(fig)
  let p = data.parameters
  if data.kind == "cuboid" { root(add(add(power(p.width, 2), power(p.depth, 2)), power(p.height, 2))) }
  else if data.kind == "cube" { multiply(p.size, root(3)) }
  else { data.measures.at("diagonal", default: panic("sang-3d.symbolic.diagonal: unsupported kind " + data.kind)) }
}

#let slant-height(fig) = {
  let data = _need(fig)
  let p = data.parameters
  if data.kind == "cone" { root(add(power(p.radius, 2), power(p.height, 2))) }
  else if data.kind == "frustum" { root(add(power(subtract(p.radius, p.top-radius), 2), power(p.height, 2))) }
  else { data.measures.at("slant-height", default: panic("sang-3d.symbolic.slant-height: unsupported kind " + data.kind)) }
}

// Complete symbolic-numeric layer ---------------------------------------------
#let parameter(name, symbol, value, unit: none, assumptions: ()) = (
  ..scalar(symbol, value, unit: unit),
  name: name,
  assumptions: assumptions,
)

#let with-value(value, numeric-value) = if is-symbolic(value) { (: ..value, value: numeric-value) } else { numeric-value }
#let negate(value) = scalar([−#expression(value)], -numeric(value), unit: _unit(value))
#let square(value) = power(value, 2)
#let sum(values) = {
  if values.len() == 0 { return scalar([0], 0) }
  let result = values.first()
  for value in values.slice(1) { result = add(result, value) }
  result
}
#let product(values) = {
  if values.len() == 0 { return scalar([1], 1) }
  let result = values.first()
  for value in values.slice(1) { result = multiply(result, value) }
  result
}

#let prism(base-area: scalar([B], 6), height: scalar([h], 4), model: none, measures: (:)) = {
  let fig = if model == none { solids.regular-prism(4, radius: 2, height: numeric(height), labels: true) } else { model }
  attach(fig, "prism", (base-area: base-area, height: height), measures: measures)
}

#let pyramid(base-area: scalar([B], 6), height: scalar([h], 4), model: none, measures: (:)) = {
  let fig = if model == none { solids.regular-pyramid(4, radius: 2, height: numeric(height), labels: true) } else { model }
  attach(fig, "pyramid", (base-area: base-area, height: height), measures: measures)
}

#let torus(major-radius: scalar([R], 2), minor-radius: scalar([r], 0.6), center: (0, 0, 0), labels: false, role: "surface") = attach(
  surfaces.torus(major-radius: numeric(major-radius), minor-radius: numeric(minor-radius), center: center, role: role),
  "torus",
  (major-radius: major-radius, minor-radius: minor-radius),
)

#let ellipsoid(rx: scalar([a], 2), ry: scalar([b], 1.5), rz: scalar([c], 1), center: (0, 0, 0), labels: false, role: "surface") = attach(
  surfaces.ellipsoid(radii: (numeric(rx), numeric(ry), numeric(rz)), center: center, labels: labels, role: role),
  "ellipsoid",
  (rx: rx, ry: ry, rz: rz),
)

#let base-area(fig) = {
  let data = _need(fig)
  let p = data.parameters
  if data.kind == "cylinder" or data.kind == "cone" { multiply(pi, square(p.radius)) }
  else if data.kind == "frustum" { multiply(pi, square(p.radius)) }
  else if data.kind == "prism" or data.kind == "pyramid" { p.base-area }
  else { data.measures.at("base-area", default: panic("sang-3d.symbolic.base-area: unsupported kind " + data.kind)) }
}

#let lateral-area(fig) = {
  let data = _need(fig)
  let p = data.parameters
  if data.kind == "cylinder" { multiply(multiply(2, pi), multiply(p.radius, p.height)) }
  else if data.kind == "cone" { multiply(pi, multiply(p.radius, slant-height(fig))) }
  else if data.kind == "frustum" { multiply(pi, multiply(add(p.radius, p.top-radius), slant-height(fig))) }
  else { data.measures.at("lateral-area", default: panic("sang-3d.symbolic.lateral-area: unsupported kind " + data.kind)) }
}

#let total-area = surface-area

#let measure(fig, name) = {
  if name == "volume" { volume(fig) }
  else if name == "surface-area" or name == "total-area" { surface-area(fig) }
  else if name == "base-area" { base-area(fig) }
  else if name == "lateral-area" { lateral-area(fig) }
  else if name == "diagonal" { diagonal(fig) }
  else if name == "slant-height" { slant-height(fig) }
  else { _need(fig).measures.at(name, default: panic("sang-3d.symbolic.measure: unknown measure " + name)) }
}

#let link-point(fig, name, coordinates) = {
  if name not in fig.points { panic("sang-3d.symbolic.link-point: missing point " + name) }
  let links = fig.meta.at("symbolic-points", default: (:))
  links.insert(name, coordinates)
  models.with-meta(fig, (symbolic-points: links))
}

#let point-coordinate(fig, name) = fig.meta.at("symbolic-points", default: (:)).at(name, default: fig.points.at(name))

#let parameter-table(fig) = {
  let data = _need(fig)
  let rows = (([Parameter], [Symbol], [Numeric value], [Unit]),)
  for (name, value) in data.parameters {
    rows.push((
      [#name],
      [#expression(value)],
      [#numeric(value)],
      [#if _unit(value) == none { [] } else { _unit(value) }],
    ))
  }
  table(columns: 4, ..rows.flatten())
}

// Extend the original measurement dispatches.
#let volume-complete(fig) = {
  let data = _need(fig)
  let p = data.parameters
  if data.kind == "prism" { multiply(p.base-area, p.height) }
  else if data.kind == "pyramid" { divide(multiply(p.base-area, p.height), 3) }
  else if data.kind == "torus" { multiply(multiply(2, square(pi)), multiply(p.major-radius, square(p.minor-radius))) }
  else if data.kind == "ellipsoid" { multiply(divide(4, 3), multiply(pi, product((p.rx, p.ry, p.rz)))) }
  else { volume(fig) }
}
