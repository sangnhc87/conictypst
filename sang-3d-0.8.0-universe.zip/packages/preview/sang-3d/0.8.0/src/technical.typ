// Technical drawing helpers: orthographic sheets, cutaways, and exploded views.
#import "core.typ" as core
#import "model.typ" as models
#import "camera.typ" as cameras
#import "render.typ" as render
#import "styles.typ" as styles
#import "revolution.typ" as revolution
#import "constructions.typ" as constructions
#import "sections.typ" as sections
#import "objects.typ" as objects
#import "definitions.typ" as definitions

#let _resolve(fig, ref) = if type(ref) == str { fig.points.at(ref) } else { ref }

#let _object-point-refs(object) = {
  if object.kind == "point" { (object.name,) }
  else if object.kind == "segment" { (object.a, object.b) }
  else if object.kind in ("face", "polyline") { object.points }
  else if object.kind == "label" { (object.at,) }
  else if object.kind in ("circle3d", "arc3d", "plane-patch") { (object.center,) }
  else if object.kind in ("angle3d", "right-angle3d") { (object.origin, object.a, object.b) }
  else if object.kind in ("dimension3d", "ticks3d") { (object.a, object.b) }
  else if object.kind == "dihedral3d" { (object.origin,) }
  else if object.kind == "custom" { object.bounds }
  else { () }
}

#let sheet(
  fig,
  views: ("front", "top", "right", "isometric"),
  columns: 2,
  captions: auto,
  length: 5.2cm,
  theme: "technical",
  hidden-lines: "dashed",
  show-faces: false,
  show-points: false,
  show-labels: false,
) = {
  let camera-list = views.map(name => cameras.named(name))
  let actual-captions = if captions == auto { views.map(name => name) } else { captions }
  render.render-views(
    fig,
    camera-list,
    columns: columns,
    captions: actual-captions,
    style: styles.theme(theme),
    length: length,
    hidden-lines: hidden-lines,
    visibility-mode: "exact",
    show-faces: show-faces,
    show-points: show-points,
    show-labels: show-labels,
  )
}

#let cutaway(fig, plane, keep: "negative", include-crossing: true) = {
  let keep-point(point) = {
    let value = core.plane-value(plane, point)
    if keep == "positive" { value >= -core.epsilon } else { value <= core.epsilon }
  }
  (: ..fig, objects: fig.objects.map(object => {
    if object.kind == "face" {
      let coordinates = object.points.map(ref => _resolve(fig, ref))
      let inside = coordinates.filter(keep-point).len()
      let visible = if include-crossing { inside > 0 } else { inside == coordinates.len() }
      (: ..object, visible: object.visible and visible)
    } else if object.kind == "segment" {
      let a = keep-point(_resolve(fig, object.a))
      let b = keep-point(_resolve(fig, object.b))
      (: ..object, visible: object.visible and (if include-crossing { a or b } else { a and b }))
    } else { object }
  }))
}

#let explode(fig, groups, distance: 1, center: auto, prefix: "part-") = {
  let actual-center = if center == auto { core.centroid3(fig.points.values()) } else { center }
  let output = fig
  for (index, group) in groups.enumerate() {
    let selector = if type(group) == dictionary and "selector" in group { group.selector } else { group }
    let chosen = revolution.selection(output, selector)
    if chosen.points.len() > 0 {
      let part-center = core.centroid3(chosen.points.values())
      let direction = if type(group) == dictionary and group.at("direction", default: none) != none { core.unit3(group.direction) }
        else { core.unit3(core.sub3(part-center, actual-center), fallback: (1, 0, 0)) }
      let amount = if type(group) == dictionary { group.at("distance", default: distance) } else { distance }
      let moved = models.translate(chosen, core.mul3(direction, amount))
      output = models.remove(output, selector)
      output = models.merge(output, moved, prefix: prefix + str(index) + "-")
    }
  }
  models.with-meta(output, (technical: (kind: "exploded-view", groups: groups.len())))
}

#let auto-dimensions(fig, labels: ([W], [D], [H]), offset: 0.45) = {
  let bounds = core.bounds3(fig.points.values())
  let min = bounds.min
  let max = bounds.max
  let output = fig
  let additions = (:)
  additions.insert("__dim-x0", (core.x3(min), core.y3(min), core.z3(min)))
  additions.insert("__dim-x1", (core.x3(max), core.y3(min), core.z3(min)))
  additions.insert("__dim-y0", (core.x3(max), core.y3(min), core.z3(min)))
  additions.insert("__dim-y1", (core.x3(max), core.y3(max), core.z3(min)))
  additions.insert("__dim-z0", (core.x3(max), core.y3(max), core.z3(min)))
  additions.insert("__dim-z1", (core.x3(max), core.y3(max), core.z3(max)))
  let dimension-definitions = (:)
  for (name, coordinate) in additions {
    dimension-definitions.insert(name, definitions.derived(
      "bounding-box-dimension-point",
      deps: fig.points.keys(),
      coordinate: coordinate,
      parameters: (bounds: bounds, name: name),
      meta: (source: "technical.auto-dimensions"),
    ))
  }
  output = models.with-points(output, additions, definitions-map: dimension-definitions)
  output = constructions.with-dimension(output, "__dim-x0", "__dim-x1", offset: (0, -offset, 0), label: labels.at(0), id: "width-dimension")
  output = constructions.with-dimension(output, "__dim-y0", "__dim-y1", offset: (offset, 0, 0), label: labels.at(1), id: "depth-dimension")
  output = constructions.with-dimension(output, "__dim-z0", "__dim-z1", offset: (offset, offset, 0), label: labels.at(2), id: "height-dimension")
  output
}


// Publication-grade sections, hatching, assemblies, and BOM ------------------
#let _plane-coordinates(point, plane, basis) = {
  let q = core.sub3(point, plane.point)
  (core.dot3(q, basis.u), core.dot3(q, basis.v))
}
#let _from-plane-coordinates(point, plane, basis) = core.add3(plane.point, core.add3(core.mul3(basis.u, point.at(0)), core.mul3(basis.v, point.at(1))))
#let _dot2(a, b) = a.at(0) * b.at(0) + a.at(1) * b.at(1)
#let _sub2(a, b) = (a.at(0) - b.at(0), a.at(1) - b.at(1))
#let _lerp2(a, b, t) = (a.at(0) + (b.at(0) - a.at(0)) * t, a.at(1) + (b.at(1) - a.at(1)) * t)

#let hatch(
  fig,
  names,
  plane,
  spacing: 0.28,
  angle: 45deg,
  prefix: "HATCH",
  role: "construction",
  tags: ("hatch",),
) = {
  if names.len() < 3 { return fig }
  let basis = core.basis-from-normal(plane.normal)
  let polygon = names.map(name => _plane-coordinates(fig.points.at(name), plane, basis))
  let direction = (calc.cos(angle), calc.sin(angle))
  let normal = (-direction.at(1), direction.at(0))
  let projections = polygon.map(point => _dot2(point, normal))
  let minimum = projections.first()
  let maximum = projections.first()
  for value in projections.slice(1) {
    minimum = calc.min(minimum, value)
    maximum = calc.max(maximum, value)
  }
  let output = fig
  let line-index = 0
  let offset = minimum - spacing
  while offset <= maximum + spacing {
    let hits = ()
    for index in range(polygon.len()) {
      let a = polygon.at(index)
      let b = polygon.at(calc.rem-euclid(index + 1, polygon.len()))
      let da = _dot2(a, normal) - offset
      let db = _dot2(b, normal) - offset
      if calc.abs(da) <= core.epsilon { hits.push(a) }
      if da * db < 0 {
        let t = da / (da - db)
        hits.push(_lerp2(a, b, t))
      }
    }
    let unique = ()
    for point in hits {
      if not unique.any(other => calc.sqrt(calc.pow(point.at(0) - other.at(0), 2) + calc.pow(point.at(1) - other.at(1), 2)) <= 1e-6) { unique.push(point) }
    }
    if unique.len() >= 2 {
      unique = unique.sorted(key: point => _dot2(point, direction))
      let a2 = unique.first()
      let b2 = unique.last()
      let a3 = _from-plane-coordinates(a2, plane, basis)
      let b3 = _from-plane-coordinates(b2, plane, basis)
      let an = prefix + "-" + str(line-index) + "-A"
      let bn = prefix + "-" + str(line-index) + "-B"
      output = models.with-point(output, an, a3, definition: definitions.derived("hatch-endpoint", deps: names, coordinate: a3, parameters: (line: line-index, side: "A", angle: angle, spacing: spacing)))
      output = models.with-point(output, bn, b3, definition: definitions.derived("hatch-endpoint", deps: names, coordinate: b3, parameters: (line: line-index, side: "B", angle: angle, spacing: spacing)))
      output = models.with-object(output, objects.segment(an, bn, id: prefix + "-" + str(line-index), role: role, layer: 18, tags: tags))
      line-index += 1
    }
    offset += spacing
  }
  models.with-meta(output, (hatch: (lines: line-index, spacing: spacing, angle: angle)))
}

#let section-view(
  fig,
  plane,
  keep: "negative",
  cap: true,
  hatch-lines: true,
  hatch-spacing: 0.28,
  hatch-angle: 45deg,
  prefix: "SEC",
  role: "section",
  show-plane: false,
) = {
  let clipped = cutaway(fig, plane, keep: keep, include-crossing: true)
  if not cap { return models.with-meta(clipped, (technical: (kind: "section-view", capped: false))) }
  let result = sections.with-section(
    clipped,
    plane,
    prefix: prefix + "P",
    id: prefix + "-cap",
    labels: false,
    role: role,
    show-plane: show-plane,
  )
  let output = result.model
  if hatch-lines and result.names.len() >= 3 {
    output = hatch(output, result.names, plane, spacing: hatch-spacing, angle: hatch-angle, prefix: prefix + "-hatch")
  }
  models.with-meta(output, (technical: (kind: "section-view", capped: true, section-points: result.names, keep: keep)))
}

#let assembly(parts, prefixes: auto, names: auto, meta: (:)) = {
  let actual-prefixes = if prefixes == auto { range(parts.len()).map(index => "PART" + str(index + 1) + "-") } else { prefixes }
  let output = models.merge-many(parts, prefixes: actual-prefixes)
  let actual-names = if names == auto { range(parts.len()).map(index => "Part " + str(index + 1)) } else { names }
  let records = range(parts.len()).map(index => (
    index: index + 1,
    name: actual-names.at(index),
    prefix: actual-prefixes.at(index),
    points: parts.at(index).points.len(),
    objects: parts.at(index).objects.len(),
  ))
  models.with-meta(output, (: ..meta, assembly: (parts: records, count: parts.len())))
}

#let bom-data(fig) = fig.meta.at("assembly", default: (parts: (), count: 0)).parts
#let bom(fig, title: [Bill of Materials]) = {
  let rows = (([#], [Part], [Prefix], [Points], [Objects]),)
  for item in bom-data(fig) {
    rows.push(([#item.index], [#item.name], [#item.prefix], [#item.points], [#item.objects]))
  }
  block[
    *#title*
    #table(columns: 5, ..rows.flatten())
  ]
}

#let callouts(fig, groups: auto, prefix: "CALL", offset: (0.6, 0.6, 0.6)) = {
  let records = if groups == auto { bom-data(fig) } else { groups }
  let output = fig
  for (index, item) in records.enumerate() {
    let selector = if "selector" in item { item.selector } else { (id: none) }
    let selected = models.select(output, selector: selector)
    if selected.len() > 0 {
      let refs = ()
      for object in selected { refs += _object-point-refs(object) }
      refs = refs.filter(ref => type(ref) == str and ref in output.points)
      if refs.len() > 0 {
        let at = core.centroid3(refs.map(ref => output.points.at(ref)))
        let anchor = prefix + "-" + str(index + 1)
        output = models.with-point(output, anchor, core.add3(at, offset), definition: definitions.derived("assembly-callout", deps: refs, coordinate: core.add3(at, offset), parameters: (index: index + 1)))
        output = models.with-object(output, objects.label(anchor, [#(index + 1)], id: anchor + "-label", role: "annotation", tags: ("callout",)))
      }
    }
  }
  output
}

#let drawing-package(
  fig,
  include-sheet: true,
  include-bom: true,
  views: ("front", "top", "right", "isometric"),
  columns: 2,
  title: [Technical drawing],
) = block[
  = #title
  #if include-sheet { sheet(fig, views: views, columns: columns) }
  #if include-bom and "assembly" in fig.meta { bom(fig) }
]
