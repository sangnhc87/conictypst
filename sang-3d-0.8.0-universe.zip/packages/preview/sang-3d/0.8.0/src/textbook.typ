// High-level constructions for school and university geometry diagrams.
#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "solids.typ" as solids
#import "surfaces.typ" as surfaces
#import "constructions.typ" as constructions
#import "definitions.typ" as definitions

#let regular-pyramid(
  n: 4,
  radius: 2.2,
  height: 3.5,
  apex-name: "S",
  center-name: "H",
  base-names: auto,
  show-altitude: true,
  show-right-angle: true,
  show-base-center: true,
  labels: true,
  role: "main",
  rotation: 45deg,
) = {
  let alphabet = ("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L")
  if n > alphabet.len() and base-names == auto { panic("sang-3d.textbook.regular-pyramid: provide base-names when n > 12") }
  let names = if base-names == auto { alphabet.slice(0, n) } else { base-names }
  if names.contains(center-name) { panic("sang-3d.textbook.regular-pyramid: center-name must differ from base vertex names") }
  let base = solids.regular-base(n, radius: radius, rotation: rotation)
  let apex = (0, 0, height)
  let fig = solids.pyramid(base, apex: apex, base-names: names, apex-name: apex-name, labels: labels, role: role)
  fig = models.with-point(fig, center-name, (0, 0, 0), definition: definitions.derived("base-center", deps: names, coordinate: (0, 0, 0), parameters: (polygon: names,)))
  if show-base-center {
    fig = models.with-object(fig, objects.point(center-name, role: "auxiliary", tags: ("base-center",), label: labels))
  }
  if show-altitude {
    fig = constructions.with-segment(fig, apex-name, center-name, id: "altitude", role: "accent", tags: ("altitude",))
  }
  if show-right-angle and show-altitude and n >= 3 {
    fig = constructions.with-right-angle(fig, center-name, names.first(), apex-name, size: 0.28, id: "altitude-right-angle", tags: ("right-angle",))
  }
  models.with-meta(fig, (textbook: (kind: "regular-pyramid", apex: apex-name, base-center: center-name, base: names)))
}

#let prism(
  n: 4,
  radius: 2.2,
  height: 3,
  labels: true,
  role: "main",
  rotation: 45deg,
  show-height: false,
) = {
  let fig = solids.regular-prism(n, radius: radius, height: height, labels: labels, role: role, rotation: rotation)
  if show-height {
    fig = constructions.with-dimension(fig, "A1", "A11", offset: (-0.4, 0, 0), label: [h], id: "height-dimension")
  }
  models.with-meta(fig, (textbook: (kind: "regular-prism", sides: n)))
}

#let cylinder(
  radius: 2,
  height: 3.5,
  center: (0, 0, 0),
  axis: (0, 0, 1),
  sides: 36,
  show-axis: true,
  show-radii: true,
  show-generators: true,
  labels: true,
  prefix: "CY",
) = {
  let direction = core.unit3(axis, fallback: (0, 0, 1))
  let top = core.add3(center, core.mul3(direction, height))
  let fig = surfaces.cylinder-between(center, top, radius: radius, sides: sides, labels: false, prefix: prefix, role: "surface")
  let basis = core.basis-from-normal(direction)
  let base-radius = core.add3(center, core.mul3(basis.u, radius))
  let top-radius = core.add3(top, core.mul3(basis.u, radius))
  let additions = (:)
  additions.insert(prefix + "O", center)
  additions.insert(prefix + "O1", top)
  additions.insert(prefix + "R", base-radius)
  additions.insert(prefix + "R1", top-radius)
  fig = models.with-points(fig, additions)
  if show-axis { fig = constructions.with-segment(fig, prefix + "O", prefix + "O1", id: prefix + "-axis", role: "axis", tags: ("axis",)) }
  if show-radii {
    fig = constructions.with-segment(fig, prefix + "O", prefix + "R", id: prefix + "-radius", role: "accent", tags: ("radius",))
    fig = constructions.with-segment(fig, prefix + "O1", prefix + "R1", id: prefix + "-top-radius", role: "auxiliary", tags: ("radius",))
  }
  if show-generators { fig = constructions.with-segment(fig, prefix + "R", prefix + "R1", id: prefix + "-generator", role: "strong", tags: ("generator",)) }
  if labels {
    for name in (prefix + "O", prefix + "O1") { fig = models.with-object(fig, objects.point(name, role: "auxiliary")) }
  }
  models.with-meta(fig, (textbook: (kind: "cylinder", base-center: prefix + "O", top-center: prefix + "O1", radius-point: prefix + "R")))
}

#let cone(
  radius: 2,
  height: 3.5,
  center: (0, 0, 0),
  axis: (0, 0, 1),
  sides: 36,
  apex-name: "S",
  center-name: "O",
  show-axis: true,
  show-radius: true,
  show-generator: true,
  labels: true,
  prefix: "CN",
) = {
  let direction = core.unit3(axis, fallback: (0, 0, 1))
  let apex = core.add3(center, core.mul3(direction, height))
  let basis = core.basis-from-normal(direction)
  let radius-point = core.add3(center, core.mul3(basis.u, radius))
  let fig = surfaces.cone-between(center, apex, radius: radius, sides: sides, labels: false, prefix: prefix, role: "surface")
  let additions = (:)
  additions.insert(center-name, center)
  additions.insert(apex-name, apex)
  additions.insert(prefix + "R", radius-point)
  fig = models.with-points(fig, additions)
  if show-axis { fig = constructions.with-segment(fig, center-name, apex-name, id: prefix + "-axis", role: "axis", tags: ("axis", "height")) }
  if show-radius { fig = constructions.with-segment(fig, center-name, prefix + "R", id: prefix + "-radius", role: "accent", tags: ("radius",)) }
  if show-generator { fig = constructions.with-segment(fig, apex-name, prefix + "R", id: prefix + "-generator", role: "strong", tags: ("generator",)) }
  if labels {
    fig = models.with-object(fig, objects.point(center-name, role: "auxiliary"))
    fig = models.with-object(fig, objects.point(apex-name, role: "main"))
  }
  models.with-meta(fig, (textbook: (kind: "cone", apex: apex-name, base-center: center-name, radius-point: prefix + "R")))
}

#let sphere(
  radius: 2,
  center: (0, 0, 0),
  center-name: "O",
  radius-name: "A",
  show-radius: true,
  show-great-circle: true,
  labels: true,
  prefix: "SP",
) = {
  let fig = surfaces.sphere(radius: radius, center: center, latitudes: 10, longitudes: 24, prefix: prefix, labels: false, role: "surface")
  let radius-point = core.add3(center, (radius, 0, 0))
  let additions = (:)
  additions.insert(center-name, center)
  additions.insert(radius-name, radius-point)
  fig = models.with-points(fig, additions)
  if show-radius { fig = constructions.with-segment(fig, center-name, radius-name, id: prefix + "-radius", role: "accent", tags: ("radius",)) }
  if show-great-circle { fig = constructions.with-circle(fig, center-name, radius, normal: (0, 0, 1), id: prefix + "-great-circle", role: "strong", tags: ("great-circle",)) }
  if labels {
    fig = models.with-object(fig, objects.point(center-name, role: "auxiliary"))
    fig = models.with-object(fig, objects.point(radius-name, role: "main"))
  }
  models.with-meta(fig, (textbook: (kind: "sphere", center: center-name, radius-point: radius-name)))
}

// Extended textbook DSL --------------------------------------------------------
#let cuboid(
  width: 4,
  depth: 3,
  height: 3,
  names: ("A", "B", "C", "D", "A1", "B1", "C1", "D1"),
  show-diagonal: false,
  show-space-diagonal: false,
  labels: true,
  role: "main",
) = {
  let fig = solids.cuboid(width: width, depth: depth, height: height, names: names, labels: labels, role: role)
  if show-diagonal { fig = constructions.with-segment(fig, names.at(0), names.at(2), id: "base-diagonal", role: "auxiliary", tags: ("diagonal", "base-diagonal")) }
  if show-space-diagonal { fig = constructions.with-segment(fig, names.at(0), names.at(6), id: "space-diagonal", role: "accent", tags: ("diagonal", "space-diagonal")) }
  models.with-meta(fig, (textbook: (kind: "cuboid", names: names, width: width, depth: depth, height: height)))
}

#let regular-tetrahedron(size: 3, names: ("A", "B", "C", "D"), labels: true, show-altitude: true) = {
  let h = size * calc.sqrt(2 / 3)
  let coordinates = (
    (0, 0, 0),
    (size, 0, 0),
    (size / 2, size * calc.sqrt(3) / 2, 0),
    (size / 2, size * calc.sqrt(3) / 6, h),
  )
  let points = names.zip(coordinates).to-dict()
  let fig = solids.polyhedron(points, (
    base: (names.at(2), names.at(1), names.at(0)),
    f1: (names.at(0), names.at(1), names.at(3)),
    f2: (names.at(1), names.at(2), names.at(3)),
    f3: (names.at(2), names.at(0), names.at(3)),
  ), labels: labels)
  let base-center = "H"
  let center-coordinate = core.centroid3((fig.points.at(names.at(0)), fig.points.at(names.at(1)), fig.points.at(names.at(2))))
  fig = models.with-point(fig, base-center, center-coordinate, definition: definitions.centroid(names.slice(0, 3), coordinate: center-coordinate))
  if show-altitude {
    fig = constructions.with-segment(fig, names.at(3), base-center, id: "tetrahedron-altitude", role: "accent", tags: ("altitude",))
    fig = constructions.with-right-angle(fig, base-center, names.at(0), names.at(3), id: "tetrahedron-altitude-right-angle")
  }
  models.with-meta(fig, (textbook: (kind: "regular-tetrahedron", apex: names.at(3), base: names.slice(0, 3), base-center: base-center)))
}

#let regular-frustum(
  n: 4,
  radius: 2.4,
  top-radius: 1.3,
  height: 3,
  labels: true,
  show-axis: true,
  rotation: 45deg,
) = {
  let fig = solids.regular-frustum(n, radius: radius, top-scale: top-radius / radius, height: height, labels: labels, rotation: rotation)
  let bottom-center = "O"
  let top-center = "O1"
  fig = models.with-point(fig, bottom-center, (0, 0, 0), definition: definitions.derived("regular-polygon-center", coordinate: (0, 0, 0), parameters: (sides: n, radius: radius)))
  fig = models.with-point(fig, top-center, (0, 0, height), definition: definitions.derived("translated-center", deps: (bottom-center,), coordinate: (0, 0, height), parameters: (vector: (0, 0, height))))
  if show-axis { fig = constructions.with-segment(fig, bottom-center, top-center, id: "frustum-axis", role: "axis", tags: ("axis", "height")) }
  models.with-meta(fig, (textbook: (kind: "regular-frustum", base-center: bottom-center, top-center: top-center)))
}

#let hemisphere(radius: 2, center: (0, 0, 0), axis: (0, 0, 1), show-radius: true, labels: true, prefix: "HS") = {
  let fig = surfaces.hemisphere(radius: radius, center: center, axis: axis, prefix: prefix, labels: false)
  let center-name = prefix + "O"
  let edge-name = prefix + "A"
  let basis = core.basis-from-normal(axis)
  let edge = core.add3(center, core.mul3(basis.u, radius))
  fig = models.with-point(fig, center-name, center, definition: definitions.given(center, meta: (role: "hemisphere-center")))
  fig = models.with-point(fig, edge-name, edge, definition: definitions.derived("radius-point", deps: (center-name,), coordinate: edge, parameters: (radius: radius, direction: basis.u)))
  if show-radius { fig = constructions.with-segment(fig, center-name, edge-name, id: prefix + "-radius", role: "accent", tags: ("radius",)) }
  if labels {
    fig = models.with-object(fig, objects.point(center-name, role: "auxiliary"))
    fig = models.with-object(fig, objects.point(edge-name, role: "main"))
  }
  models.with-meta(fig, (textbook: (kind: "hemisphere", center: center-name, radius-point: edge-name)))
}

#let cone-inscribed-sphere(
  sphere-radius: 3,
  cone-height: 4.5,
  axis: (0, 0, 1),
  center: (0, 0, 0),
  sides: 40,
  labels: true,
) = {
  let direction = core.unit3(axis, fallback: (0, 0, 1))
  let half = cone-height / 2
  let base-center = core.sub3(center, core.mul3(direction, half))
  let base-radius = calc.sqrt(calc.max(0, sphere-radius * sphere-radius - half * half))
  let sphere-model = sphere(radius: sphere-radius, center: center, center-name: "O", radius-name: "R", labels: labels, prefix: "SP")
  let cone-model = cone(radius: base-radius, height: cone-height, center: base-center, axis: direction, apex-name: "S", center-name: "H", labels: labels, prefix: "CN")
  let fig = models.merge(sphere-model, cone-model, prefix: "IN-")
  models.with-meta(fig, (textbook: (kind: "cone-inscribed-sphere", sphere-radius: sphere-radius, cone-height: cone-height, base-radius: base-radius)))
}

#let common-perpendicular(fig, line-a, line-b, names: ("M", "N"), role: "accent") = {
  let first = core.line-through(fig.points.at(line-a.at(0)), fig.points.at(line-a.at(1)))
  let second = core.line-through(fig.points.at(line-b.at(0)), fig.points.at(line-b.at(1)))
  let closest = core.line-line-closest(first, second)
  let output = models.with-point(fig, names.at(0), closest.point-a, definition: definitions.derived("closest-point-on-line", deps: line-a + line-b, coordinate: closest.point-a, parameters: (line: line-a,)))
  output = models.with-point(output, names.at(1), closest.point-b, definition: definitions.derived("closest-point-on-line", deps: line-a + line-b, coordinate: closest.point-b, parameters: (line: line-b,)))
  output = constructions.with-segment(output, names.at(0), names.at(1), id: "common-perpendicular", role: role, tags: ("common-perpendicular", "distance"))
  models.with-meta(output, (textbook-construction: (kind: "common-perpendicular", lines: (line-a, line-b), feet: names, distance: closest.distance)))
}

#let angle-line-plane(fig, line, plane-points, origin-name: "H", radius: 0.55, label: $alpha$) = {
  let a = line.at(0)
  let b = line.at(1)
  let pl = core.plane-through(..plane-points.map(name => fig.points.at(name)))
  let foot-coordinate = core.project-point-plane(fig.points.at(b), pl)
  let output = models.with-point(fig, origin-name, foot-coordinate, definition: definitions.projection(b, plane-points, coordinate: foot-coordinate, kind: "projection-on-plane"))
  constructions.with-angle(output, b, a, origin-name, radius: radius, label: label, id: "line-plane-angle")
}

#let dihedral-angle(fig, edge, face-a, face-b, origin: auto, radius: 0.6, label: $alpha$) = {
  let origin-name = if origin == auto { edge.at(0) } else { origin }
  let normal-a = core.polygon-normal(face-a.map(name => fig.points.at(name)))
  let normal-b = core.polygon-normal(face-b.map(name => fig.points.at(name)))
  constructions.with-dihedral(fig, origin-name, core.sub3(fig.points.at(edge.at(1)), fig.points.at(edge.at(0))), normal-a, normal-b, radius: radius, label: label, id: "dihedral-angle")
}
