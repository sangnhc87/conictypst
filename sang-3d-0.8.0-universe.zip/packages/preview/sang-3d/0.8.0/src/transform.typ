#import "core.typ" as core

// Homogeneous 4x4 affine transformations.
#let identity() = (
  (1, 0, 0, 0),
  (0, 1, 0, 0),
  (0, 0, 1, 0),
  (0, 0, 0, 1),
)

#let multiply(a, b) = {
  let output = ()
  for row in range(4) {
    let values = ()
    for column in range(4) {
      let value = 0
      for k in range(4) { value += a.at(row).at(k) * b.at(k).at(column) }
      values.push(value)
    }
    output.push(values)
  }
  output
}

#let compose(matrices) = {
  let result = identity()
  for matrix in matrices { result = multiply(result, matrix) }
  result
}

#let translation(delta) = (
  (1, 0, 0, core.x3(delta)),
  (0, 1, 0, core.y3(delta)),
  (0, 0, 1, core.z3(delta)),
  (0, 0, 0, 1),
)

#let scaling(factors) = {
  let actual = if type(factors) == int or type(factors) == float {
    (factors, factors, factors)
  } else { factors }
  (
    (actual.at(0), 0, 0, 0),
    (0, actual.at(1), 0, 0),
    (0, 0, actual.at(2), 0),
    (0, 0, 0, 1),
  )
}

#let rotation-x(angle) = {
  let c = calc.cos(angle)
  let s = calc.sin(angle)
  ((1, 0, 0, 0), (0, c, -s, 0), (0, s, c, 0), (0, 0, 0, 1))
}
#let rotation-y(angle) = {
  let c = calc.cos(angle)
  let s = calc.sin(angle)
  ((c, 0, s, 0), (0, 1, 0, 0), (-s, 0, c, 0), (0, 0, 0, 1))
}
#let rotation-z(angle) = {
  let c = calc.cos(angle)
  let s = calc.sin(angle)
  ((c, -s, 0, 0), (s, c, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1))
}

#let rotation-axis(axis, angle) = {
  let n = core.unit3(axis, fallback: (0, 0, 1))
  let x = core.x3(n)
  let y = core.y3(n)
  let z = core.z3(n)
  let c = calc.cos(angle)
  let s = calc.sin(angle)
  let t = 1 - c
  (
    (t*x*x + c, t*x*y - s*z, t*x*z + s*y, 0),
    (t*x*y + s*z, t*y*y + c, t*y*z - s*x, 0),
    (t*x*z - s*y, t*y*z + s*x, t*z*z + c, 0),
    (0, 0, 0, 1),
  )
}

#let around(matrix, origin) = compose((translation(origin), matrix, translation(core.neg3(origin))))

#let apply-point(matrix, point) = {
  let v = (core.x3(point), core.y3(point), core.z3(point), 1)
  let out = range(4).map(row => range(4).map(k => matrix.at(row).at(k) * v.at(k)).sum())
  let w = out.at(3)
  if calc.abs(w) <= core.epsilon { (out.at(0), out.at(1), out.at(2)) } else {
    (out.at(0) / w, out.at(1) / w, out.at(2) / w)
  }
}

#let apply-vector(matrix, vector) = {
  let v = (core.x3(vector), core.y3(vector), core.z3(vector), 0)
  let out = range(3).map(row => range(4).map(k => matrix.at(row).at(k) * v.at(k)).sum())
  (out.at(0), out.at(1), out.at(2))
}

// Rotation around an arbitrary line, not just an axis through the origin.
#let rotation-line(ax, angle) = around(rotation-axis(core.axis-direction(ax), angle), core.axis-point(ax))
#let rotation-through(a, b, angle) = rotation-line(core.axis-through(a, b), angle)
