// Polyhedral face unfolding into the z=0 plane.
#import "core.typ" as core
#import "model.typ" as models
#import "objects.typ" as objects
#import "definitions.typ" as definitions
#import "points.typ" as point-declarations

#let _edge-key(a, b) = if a < b { a + "|" + b } else { b + "|" + a }
#let _sub2(a, b) = (a.at(0) - b.at(0), a.at(1) - b.at(1))
#let _add2(a, b) = (a.at(0) + b.at(0), a.at(1) + b.at(1))
#let _mul2(v, scalar) = (v.at(0) * scalar, v.at(1) * scalar)
#let _dot2(a, b) = a.at(0) * b.at(0) + a.at(1) * b.at(1)
#let _cross2(a, b) = a.at(0) * b.at(1) - a.at(1) * b.at(0)
#let _norm2(v) = calc.sqrt(_dot2(v, v))
#let _unit2(v, fallback: (1, 0)) = { let length = _norm2(v); if length <= 1e-8 { fallback } else { _mul2(v, 1 / length) } }
#let _sign(value) = if value < 0 { -1 } else { 1 }
#let _safe-id(value) = value.replace(" ", "-").replace("/", "-")

#let _faces(fig) = fig.objects.filter(object => object.visible and object.kind == "face" and object.id != none)

#let adjacency(fig) = {
  let edge-map = (:)
  for face in _faces(fig) {
    for index in range(face.points.len()) {
      let a = face.points.at(index)
      let b = face.points.at(calc.rem-euclid(index + 1, face.points.len()))
      let key = _edge-key(a, b)
      let previous = edge-map.at(key, default: none)
      if previous == none { edge-map.insert(key, (a: a, b: b, faces: (face.id,))) }
      else { edge-map.insert(key, (: ..previous, faces: previous.faces + (face.id,))) }
    }
  }
  edge-map
}

#let _root-placement(fig, face) = {
  let p0 = fig.points.at(face.points.at(0))
  let p1 = fig.points.at(face.points.at(1))
  let coordinates = face.points.map(ref => fig.points.at(ref))
  let normal = core.polygon-normal(coordinates)
  let e = core.unit3(core.sub3(p1, p0), fallback: (1, 0, 0))
  let m = core.unit3(core.cross3(normal, e), fallback: core.orthogonal3(e))
  let output = (:)
  for ref in face.points {
    let q = core.sub3(fig.points.at(ref), p0)
    output.insert(ref, (core.dot3(q, e), core.dot3(q, m)))
  }
  output
}

#let _centroid2(points) = {
  if points.len() == 0 { return (0, 0) }
  (points.map(point => point.at(0)).sum() / points.len(), points.map(point => point.at(1)).sum() / points.len())
}

#let _neighbor-placement(fig, parent-face, child-face, parent-map, shared) = {
  let a = shared.a
  let b = shared.b
  let pa = fig.points.at(a)
  let pb = fig.points.at(b)
  let a2 = parent-map.at(a)
  let b2 = parent-map.at(b)
  let edge2 = _unit2(_sub2(b2, a2))
  let perp2 = (-edge2.at(1), edge2.at(0))
  let parent-center = _centroid2(parent-face.points.map(ref => parent-map.at(ref)))
  let parent-side = _sign(_cross2(edge2, _sub2(parent-center, a2)))

  let child-coordinates = child-face.points.map(ref => fig.points.at(ref))
  let child-normal = core.polygon-normal(child-coordinates)
  let edge3 = core.unit3(core.sub3(pb, pa), fallback: (1, 0, 0))
  let across3 = core.unit3(core.cross3(child-normal, edge3), fallback: core.orthogonal3(edge3))
  let local = (:)
  for ref in child-face.points {
    let q = core.sub3(fig.points.at(ref), pa)
    local.insert(ref, (core.dot3(q, edge3), core.dot3(q, across3)))
  }
  let local-center = _centroid2(local.values())
  let orientation = -parent-side * _sign(local-center.at(1))
  let output = (:)
  for ref in child-face.points {
    let q = local.at(ref)
    output.insert(ref, _add2(a2, _add2(_mul2(edge2, q.at(0)), _mul2(perp2, q.at(1) * orientation))))
  }
  output
}

#let net(
  fig,
  root-face: auto,
  prefix: "NET",
  face-role: "surface",
  cut-role: "main",
  fold-role: "construction",
  labels: false,
  strict: true,
  point-policy: auto,
  source-point-policy: auto,
) = {
  let faces = _faces(fig)
  if faces.len() == 0 { panic("sang-3d.unfold: model has no named face objects") }
  let face-map = (:)
  for face in faces { face-map.insert(face.id, face) }
  let root = if root-face == auto { faces.first().id } else { root-face }
  if root not in face-map { panic("sang-3d.unfold: unknown root face " + str(root)) }
  let edges = adjacency(fig)
  let neighbors = (:)
  for face in faces { neighbors.insert(face.id, ()) }
  for edge in edges.values() {
    if edge.faces.len() == 2 {
      let a = edge.faces.at(0)
      let b = edge.faces.at(1)
      neighbors.insert(a, neighbors.at(a) + ((face: b, edge: edge),))
      neighbors.insert(b, neighbors.at(b) + ((face: a, edge: edge),))
    }
  }

  let placements = (:)
  placements.insert(root, _root-placement(fig, face-map.at(root)))
  let parents = (:)
  let queue = (root,)
  let visited = (root,)
  while queue.len() > 0 {
    let current = queue.first()
    queue = queue.slice(1)
    for link in neighbors.at(current, default: ()) {
      if not visited.contains(link.face) {
        let child = face-map.at(link.face)
        let parent = face-map.at(current)
        placements.insert(link.face, _neighbor-placement(fig, parent, child, placements.at(current), link.edge))
        parents.insert(link.face, (face: current, edge: link.edge))
        visited.push(link.face)
        queue.push(link.face)
      }
    }
  }
  if strict and visited.len() != faces.len() { panic("sang-3d.unfold: disconnected face graph") }

  // Phase 1a: declare source-reference points first. These public control
  // points keep the unfolded net self-contained and make every dependency
  // inspectable inside the output model.
  let declarations = ()
  let source-names = (:)
  let source-refs = ()
  for face-id in visited {
    for ref in face-map.at(face-id).points {
      if not source-refs.contains(ref) { source-refs.push(ref) }
    }
  }
  for (index, ref) in source-refs.enumerate() {
    let source-definition = fig.definitions.at(ref)
    let declaration = point-declarations.from-policy(
      prefix + "-source-" + ref,
      fig.points.at(ref),
      "unfold-source-reference",
      parameters: (source-point: ref, source-definition: source-definition, index: index),
      policy: source-point-policy,
      context: (source-point: ref, index: index, prefix: prefix),
    )
    declarations.push(declaration)
    source-names.insert(ref, declaration.name)
  }

  // Phase 1b: calculate and declare every unfolded point after its source.
  let face-records = ()
  for face-id in visited {
    let face = face-map.at(face-id)
    let placement = placements.at(face-id)
    let refs = ()
    let safe = _safe-id(face-id)
    for (index, ref) in face.points.enumerate() {
      let default-name = prefix + "-" + safe + "-" + ref
      let p = placement.at(ref)
      let coordinate = (p.at(0), p.at(1), 0)
      let declaration = point-declarations.from-policy(
        default-name,
        coordinate,
        "unfolded-vertex",
        deps: (source-names.at(ref),),
        parameters: (root-face: root, source-point: ref, source-reference: source-names.at(ref), source-face: face-id, vertex-index: index),
        policy: point-policy,
        context: (face: face-id, source-point: ref, vertex-index: index, prefix: prefix),
      )
      declarations.push(declaration)
      refs.push(declaration.name)
    }
    face-records.push((face-id: face-id, safe: safe, source: face, refs: refs))
  }
  let declared = point-declarations.declare(declarations)

  // Phase 2: objects may now reference the complete, validated point table.
  let output-objects = ()
  let tree-edges = parents.values().map(parent => _edge-key(parent.edge.a, parent.edge.b))
  for record in face-records {
    let face = record.source
    let refs = record.refs
    let face-id = record.face-id
    let safe = record.safe
    if labels {
      for (index, name) in refs.enumerate() {
        output-objects.push(objects.point(name, label: face.points.at(index), tags: ("net-vertex",)))
      }
    }
    output-objects.push(objects.face(refs, id: prefix + "-face-" + safe, role: face-role, cull: false, tags: ("net-face", face-id)))
    for index in range(refs.len()) {
      let original-a = face.points.at(index)
      let original-b = face.points.at(calc.rem-euclid(index + 1, face.points.len()))
      let edge-role = if tree-edges.contains(_edge-key(original-a, original-b)) { fold-role } else { cut-role }
      output-objects.push(objects.segment(
        refs.at(index), refs.at(calc.rem-euclid(index + 1, refs.len())),
        id: prefix + "-edge-" + safe + "-" + str(index + 1),
        role: edge-role,
        visibility: "always",
        tags: (if edge-role == fold-role { "fold" } else { "cut" }, "net-edge"),
      ))
    }
  }
  models.model(
    points: declared.points,
    definitions: declared.definitions,
    point-options: declared.point-options,
    point-order: declared.order,
    objects: output-objects,
    meta: (kind: "unfolded-net", root-face: root, face-count: visited.len(), parent-map: parents, source-kind: fig.meta.at("kind", default: none)),
  )
}

#let unfold = net
