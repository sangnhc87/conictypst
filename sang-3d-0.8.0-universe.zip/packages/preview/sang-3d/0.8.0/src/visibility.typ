#import "core.typ" as core
#import "camera.typ" as cameras

#let resolve-point(fig, ref) = if type(ref) == str { fig.points.at(ref) } else { ref }
#let _p2(projected) = (projected.at(0), projected.at(1))
#let _cross2(a, b) = a.at(0) * b.at(1) - a.at(1) * b.at(0)
#let _sub2(a, b) = (a.at(0) - b.at(0), a.at(1) - b.at(1))

#let face-info(fig, face, cam) = {
  let points = face.points.map(ref => resolve-point(fig, ref))
  let normal = core.polygon-normal(points)
  let center = core.centroid3(points)
  let toward-camera = cameras.to-camera-direction(cam, center)
  let front = core.dot3(normal, toward-camera) > 0
  let projected = points.map(point => cameras.project(cam, point))
  let raw-projected = points.map(point => cameras.project-raw(cam, point))
  let depth = projected.map(point => point.at(2)).sum() / projected.len()
  (
    id: face.id,
    object: face,
    front: front,
    normal: normal,
    center: center,
    plane: core.plane(normal, point: center),
    points: points,
    polygon: projected.map(_p2),
    raw-polygon: raw-projected.map(point => (point.x, point.y)),
    depth: depth,
  )
}

#let face-records(fig, cam) = fig.objects
  .filter(object => object.visible and object.kind == "face")
  .map(face => face-info(fig, face, cam))
  .sorted(key: record => -record.depth)

#let face-map(fig, cam) = {
  let output = (:)
  for record in face-records(fig, cam) {
    if record.id != none { output.insert(record.id, record) }
  }
  output
}

#let segment-hidden-convex(segment, faces) = {
  if segment.faces.len() == 0 { return false }
  not segment.faces.any(id => faces.at(id, default: (front: true)).front)
}

#let point-in-polygon(point, polygon) = {
  if polygon.len() < 3 { return false }
  let x = point.at(0)
  let y = point.at(1)
  let inside = false
  let previous = polygon.len() - 1
  for current in range(polygon.len()) {
    let a = polygon.at(current)
    let b = polygon.at(previous)
    let crosses = (a.at(1) > y) != (b.at(1) > y)
    if crosses {
      let denominator = b.at(1) - a.at(1)
      let x-cross = (b.at(0) - a.at(0)) * (y - a.at(1)) / denominator + a.at(0)
      if x < x-cross { inside = not inside }
    }
    previous = current
  }
  inside
}

#let face-between-point-and-camera(point3, face, cam, tolerance: 0.012) = {
  let direction = cameras.to-camera-direction(cam, point3)
  let hit = core.line-plane-intersection(core.line(point3, direction), face.plane, tolerance: tolerance / 10)
  if hit == none or hit.parameter <= tolerance { return false }
  if cam.kind == "perspective" {
    hit.parameter < core.distance3(point3, cam.position) - tolerance
  } else { true }
}

#let point-occluded(point3, projected3, faces, cam, excluded-face-ids: (), tolerance: 0.012) = {
  let point2 = _p2(projected3)
  faces.any(face => {
    if face.id != none and excluded-face-ids.contains(face.id) { return false }
    point-in-polygon(point2, face.polygon) and face-between-point-and-camera(point3, face, cam, tolerance: tolerance)
  })
}

// Returns the screen-space parameter s where segments p->q and a->b meet.
#let _segment-intersection-parameter(p, q, a, b, tolerance: 1e-9) = {
  let r = _sub2(q, p)
  let svec = _sub2(b, a)
  let denominator = _cross2(r, svec)
  if calc.abs(denominator) <= tolerance { return none }
  let offset = _sub2(a, p)
  let t = _cross2(offset, svec) / denominator
  let u = _cross2(offset, r) / denominator
  if t < -tolerance or t > 1 + tolerance or u < -tolerance or u > 1 + tolerance { none } else { core.clamp(t, 0, 1) }
}

#let _screen-to-world-parameter(cam, a, b, screen-s) = {
  if cam.kind != "perspective" { return screen-s }
  let pa = cameras.project-raw(cam, a)
  let pb = cameras.project-raw(cam, b)
  let target-x = pa.x + (pb.x - pa.x) * screen-s
  let target-y = pa.y + (pb.y - pa.y) * screen-s
  let scale = cam.focal-length * cam.zoom
  let ca = pa.camera
  let cb = pb.camera
  let dx = ca.at(0) - cb.at(0)
  let dy = ca.at(1) - cb.at(1)
  let dz = cb.at(2) - ca.at(2)
  let qx = target-x / scale
  let qy = target-y / scale
  let denominator-x = qx * dz - (cb.at(0) - ca.at(0))
  let denominator-y = qy * dz - (cb.at(1) - ca.at(1))
  let tx = if calc.abs(denominator-x) <= 1e-10 { none } else { (ca.at(0) - qx * ca.at(2)) / denominator-x }
  let ty = if calc.abs(denominator-y) <= 1e-10 { none } else { (ca.at(1) - qy * ca.at(2)) / denominator-y }
  let value = if tx != none and tx >= -0.01 and tx <= 1.01 { tx } else if ty != none { ty } else { screen-s }
  core.clamp(value, 0, 1)
}

#let _unique-sorted(values, tolerance: 1e-7) = {
  let output = ()
  for value in values.sorted() {
    if output.len() == 0 or calc.abs(value - output.last()) > tolerance { output.push(value) }
  }
  output
}

#let _exact-boundaries(a, b, records, cam, excluded-face-ids: (), tolerance: 0.012) = {
  let pa = cameras.project-raw(cam, a)
  let pb = cameras.project-raw(cam, b)
  let segment2 = ((pa.x, pa.y), (pb.x, pb.y))
  let candidates = (0, 1)
  for face in records {
    if face.id != none and excluded-face-ids.contains(face.id) { continue }
    for index in range(face.raw-polygon.len()) {
      let q0 = face.raw-polygon.at(index)
      let q1 = face.raw-polygon.at(calc.rem-euclid(index + 1, face.raw-polygon.len()))
      let screen-s = _segment-intersection-parameter(segment2.at(0), segment2.at(1), q0, q1, tolerance: tolerance / 100)
      if screen-s != none { candidates.push(_screen-to-world-parameter(cam, a, b, screen-s)) }
    }
    // Visibility can also change when the 3D edge crosses a face plane while
    // remaining inside the projected polygon.
    let da = core.plane-value(face.plane, a)
    let db = core.plane-value(face.plane, b)
    let denominator = da - db
    if calc.abs(denominator) > tolerance / 100 {
      let t = da / denominator
      if t > tolerance and t < 1 - tolerance {
        let point = core.lerp3(a, b, t)
        if point-in-polygon(_p2(cameras.project(cam, point)), face.polygon) { candidates.push(t) }
      }
    }
  }
  _unique-sorted(candidates, tolerance: tolerance / 20)
}

#let _runs-from-boundaries(a, b, boundaries, hidden-at) = {
  let runs = ()
  for index in range(boundaries.len() - 1) {
    let start = boundaries.at(index)
    let finish = boundaries.at(index + 1)
    if finish - start > 1e-8 {
      let hidden = hidden-at((start + finish) / 2)
      if runs.len() > 0 and runs.last().hidden == hidden {
        let previous = runs.last()
        runs = runs.slice(0, runs.len() - 1) + ((a: previous.a, b: core.lerp3(a, b, finish), hidden: hidden),)
      } else {
        runs.push((a: core.lerp3(a, b, start), b: core.lerp3(a, b, finish), hidden: hidden))
      }
    }
  }
  runs
}

#let segment-runs(fig, segment, cam, faces: auto, mode: "raycast", samples: 22, refine: 5, tolerance: 0.012) = {
  let a = resolve-point(fig, segment.a)
  let b = resolve-point(fig, segment.b)
  if segment.visibility == "always" { return ((a: a, b: b, hidden: false),) }
  let records = if faces == auto { face-records(fig, cam) } else { faces }
  if mode == "none" { return ((a: a, b: b, hidden: false),) }
  if mode == "convex" {
    let fmap = (:)
    for face in records { if face.id != none { fmap.insert(face.id, face) } }
    return ((a: a, b: b, hidden: segment-hidden-convex(segment, fmap)),)
  }
  let hidden-at(t) = {
    let point = core.lerp3(a, b, t)
    point-occluded(point, cameras.project(cam, point), records, cam, excluded-face-ids: segment.faces, tolerance: tolerance)
  }
  if mode == "exact" or mode == "publication" {
    let boundaries = _exact-boundaries(a, b, records, cam, excluded-face-ids: segment.faces, tolerance: tolerance)
    return _runs-from-boundaries(a, b, boundaries, hidden-at)
  }
  let count = calc.max(2, samples)
  let samples-data = range(count + 1).map(index => {
    let t = index / count
    (t: t, hidden: hidden-at(t))
  })
  let boundaries = (0,)
  let states = (samples-data.first().hidden,)
  for index in range(count) {
    let left = samples-data.at(index)
    let right = samples-data.at(index + 1)
    if left.hidden != right.hidden {
      let low = left.t
      let high = right.t
      let low-state = left.hidden
      for step in range(calc.max(0, refine)) {
        let middle = (low + high) / 2
        if hidden-at(middle) == low-state { low = middle } else { high = middle }
      }
      boundaries.push((low + high) / 2)
      states.push(right.hidden)
    }
  }
  boundaries.push(1)
  let runs = ()
  for index in range(states.len()) {
    let start = boundaries.at(index)
    let finish = boundaries.at(index + 1)
    if finish - start > 1e-8 {
      runs.push((a: core.lerp3(a, b, start), b: core.lerp3(a, b, finish), hidden: states.at(index)))
    }
  }
  runs
}
