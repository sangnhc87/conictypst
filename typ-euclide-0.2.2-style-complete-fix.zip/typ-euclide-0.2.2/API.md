# API overview — typ-euclide 0.2.1

Package có hai lớp API:

1. **API cũ** trả về canvas/hình dựng sẵn và được giữ tương thích.
2. **API `euclid` mới** trả về model có điểm đặt tên, dùng để xây hình lớn và tiếp tục vẽ.

---

# 1. Advanced API: `euclid`

```typ
#import "lib.typ": euclid
```

## 1.1. `euclid.model`

### Tạo và đọc model

- `model(points:, objects:, point-options:, meta:, styles:)`
- `empty-model()`
- `point-at(model, name, default: none)`
- `has-point(model, name)`
- `point-names(model)`
- `point-pairs(model)`
- `object-list(model)`
- `object-at(model, id, default: none)`
- `objects-with-tag(model, tag)`
- `objects-of-kind(model, kind)`
- `metadata(model, key, default: none)`
- `resolve(model, value)` — nếu `value` là chuỗi thì tra tọa độ điểm có tên.
- `resolve-many(model, values)`

### Mở rộng và chỉnh sửa

- `extend(model, points:, objects:, point-options:, meta:, styles:)`
- `with-point(model, name, at, options: (:))`
- `with-points(model, points, point-options: (:))`
- `alias-point(model, alias, source, options: (:))`
- `with-point-option(model, name, options)`
- `with-meta(model, meta)`
- `with-style(model, styles)`
- `with-object(model, object)`
- `with-objects(model, objects)`
- `without-object(model, id)`
- `map-objects(model, transform)`
- `patch-object(model, id, patch)`
- `patch-objects(model, ids, patch)`
- `patch-kind(model, kind, patch)`
- `patch-tag(model, tag, patch)`
- `hide-object(model, id)`
- `show-object(model, id)`

### Biến đổi toàn model

- `map-points(model, transform)`
- `translate(model, by:)`
- `rotate(model, angle, center:)`
- `scale(model, ratio, center:)`
- `reflect(model, a, b)`
- `bounds(model, padding:)`
- `validate(model)` — trả về mảng lỗi tham chiếu điểm.

## 1.2. `euclid.objects`

Các hàm này tạo object dictionary. Tọa độ có thể là tuple `(x, y)` hoặc tên điểm dạng chuỗi.

- `point(name, label:, role:, layer:, offset:, anchor:, radius:, fill:, stroke:, tags:)`
- `label(at, body, id:, role:, layer:, offset:, anchor:, angle:, padding:, tags:)`
- `segment(a, b, id:, role:, layer:, stroke:, mark:, tags:)`
- `line(a, b, id:, role:, layer:, extend:, stroke:, tags:)`
- `ray(a, b, id:, role:, layer:, extend:, stroke:, mark:, tags:)`
- `vector(a, b, id:, role:, layer:, stroke:, label:, tags:)`
- `polyline(points, id:, role:, layer:, close:, stroke:, fill:, fill-role:, tags:)`
- `polygon(points, id:, role:, layer:, stroke:, fill:, fill-role:, tags:)`
- `circle(center, radius, id:, role:, layer:, stroke:, fill:, fill-role:, tags:)`
- `circle-through(center, through, ...)`
- `arc(center, radius, start, stop, mode:, ...)`
- `ellipse(center, rx, ry, ...)`
- `angle(vertex, a, b, radius:, label:, reflex:, ...)`
- `right-angle(vertex, a, b, size:, ...)`
- `ticks(a, b, count:, size:, gap:, ...)`
- `parallel(a, b, count:, size:, gap:, ...)`
- `grid(x-range:, y-range:, step:, ...)`
- `axes(x-range:, y-range:, ticks:, tick-step:, x-label:, y-label:, ...)`
- `function-curve(f, domain:, samples:, ...)`
- `parametric-curve(f, domain:, samples:, close:, ...)`

### Thuộc tính chung của object

- `kind`: loại object.
- `id`: tên duy nhất để `patch-object` hoặc `hide-object`.
- `role`: `main`, `strong`, `auxiliary`, `construction`, `hidden`, `accent`, `secondary`, `tertiary`.
- `layer`: số thứ tự lớp vẽ.
- `visible`: bật/tắt.
- `tags`: nhóm logic để `patch-tag`.
- `stroke`, `fill`, `fill-role`: ghi đè style.

## 1.3. `euclid.style`

- `euclid-theme(name: none, overrides: (:))`
- `role-strokes(style)`
- `role-fills(style)`
- `stroke-for(style, role:, override:)`
- `fill-for(style, role:, override:)`
- `point-style(style, override:)`
- `label-style(style, override:)`
- `angle-style(style, override:)`

Theme nâng cao có các nhóm:

```typ
(
  strokes: (...),
  fills: (...),
  point: (...),
  label: (...),
  angle: (...),
  layer-order: (...),
)
```

## 1.4. `euclid.render`

- `draw-object(model, object, style:)` — gọi bên trong CeTZ canvas.
- `draw-model(model, style:, extra-objects:, overlay:)` — gọi bên trong CeTZ canvas.
- `render-model(model, style:, length:, extra-objects:, overlay:)` — trả về canvas độc lập.

`overlay` là hàm nhận model và có thể gọi trực tiếp CeTZ để vẽ bổ sung.

## 1.5. `euclid.analytic`

### Vector và điểm

`point`, `add`, `sub`, `mul`, `div`, `dot`, `cross`, `norm`, `norm2`, `distance`, `unit`, `perp`, `midpoint`, `lerp`, `direction`, `rotate-point`, `translate-point`, `homothety`, `projection`, `reflection`, `is-collinear`.

### Đường và đường tròn dạng dữ liệu

- `line(p, q, name:)`
- `line-point-direction(p, d, name:)`
- `line-equation(a, b, c, name:)`
- `segment(p, q, name:)`
- `ray(p, q, name:)`
- `circle(center, radius, name:)`
- `line-to-equation(line)`
- `equation-to-line(line)`
- `parallel-line(p, through-line)`
- `perpendicular-line(p, to-line)`
- `perpendicular-bisector(a, b)`

### Giao điểm

- `line-intersection-points(a, b, c, d)`
- `segment-intersection(a, b, c, d)`
- `circle-line-intersections-points(center, radius, a, b)`
- `circle-circle-intersections-points(c1, r1, c2, r2)`
- `intersect-lines(line1, line2)`
- `intersect-line-circle(line, circle)`
- `intersect-circles(circle1, circle2)`

### Góc, chia đoạn và phép biến hình

- `signed-angle(a, vertex, b)`
- `angle(a, vertex, b)`
- `angle-bisector-direction(a, vertex, b, internal:)`
- `angle-bisector-line(...)`
- `divide-segment(a, b, ratio:, internal:)`
- `point-on-line(a, b, t)`
- `rotate`, `translate`, `scale-from`, `reflect`
- `affine-point(p, matrix:, shift:)`
- `invert-point(p, center:, radius:)`

### Đường tròn nâng cao

- `tangent-points(circle, p)`
- `circle-through-three(a, b, c)`
- `radical-axis(circle1, circle2)`
- `power-of-point(p, circle)`

### Tam giác

- `triangle-data(A, B, C)`
- `triangle-excircle(data, which:)`

`triangle-data` trả về:

```text
A B C
a b c perimeter semiperimeter area
G O I H N
M_a M_b M_c
H_a H_b H_c
T_a T_b T_c
I_a I_b I_c
K Ge Na S Be L
incircle circumcircle
```

### Đa giác

- `polygon-signed-area(points)`
- `polygon-area(points)`
- `polygon-centroid(points)`
- `regular-polygon(n, center:, radius:, start-angle:)`

## 1.6. `euclid.construct`

Các hàm nhận model và thêm điểm có tên:

- `define-point(model, name, at, ...)`
- `midpoint(model, name, a, b, ...)`
- `division-point(model, name, a, b, ratio:, internal:, ...)`
- `point-on-segment(model, name, a, b, t:, ...)`
- `barycentric-point(model, name, a, b, c, weights, ...)`
- `centroid(model, name, a, b, c, ...)`
- `incenter(model, name, a, b, c, ...)`
- `circumcenter(model, name, a, b, c, ...)`
- `orthocenter(model, name, a, b, c, ...)`
- `angle-bisector-foot(model, name, vertex, a, b, ...)`
- `projection(model, name, p, a, b, ...)`
- `reflection(model, name, p, a, b, ...)`
- `rotation(model, name, p, center, angle, ...)`
- `translation(model, name, p, by:, ...)`
- `homothety(model, name, p, center, ratio, ...)`
- `line-intersection(model, name, a, b, c, d, ...)`
- `circle-line-intersections(model, names, center, radius, a, b, ...)`
- `circle-circle-intersections(model, names, c1, r1, c2, r2, ...)`
- `tangent-points(model, names, center, radius, p, ...)`
- `circumcircle(model, center-name, a, b, c, ...)`
- `incircle(model, center-name, a, b, c, ...)`
- `excenter(model, name, a, b, c, which:, ...)`
- `inversion(model, name, p, center, radius, ...)`
- `radical-axis(model, center-one, radius-one, center-two, radius-two, ...)`
- `perpendicular-line(model, through, a, b, ...)`
- `parallel-line(model, through, a, b, ...)`

## 1.7. `euclid.figures`

- `triangle(A:, B:, C:, features:, fill-role:, point-options:, meta:)`
- `right-triangle(A:, B:, C:, features:, ...)`
- `equilateral-triangle(side:, center:, rotation:, features:, ...)`
- `isosceles-triangle(base:, height:, center:, features:, ...)`
- `quadrilateral(A:, B:, C:, D:, features:, ...)`
- `rectangle(width:, height:, center:, features:, ...)`
- `square(side:, center:, features:, ...)`
- `parallelogram(base:, side-vector:, center:, features:, ...)`
- `rhombus(diagonal-x:, diagonal-y:, center:, features:, ...)`
- `trapezoid(bottom:, top:, height:, offset:, center:, features:, ...)`
- `kite(width:, upper:, lower:, center:, features:, ...)`
- `regular-polygon(n:, center:, radius:, start-angle:, features:, ...)`
- `circle(O:, radius:, angles:, features:, point-prefix:)`
- `coordinate-plane(x-range:, y-range:, grid-step:, axes:, grid:)`

### Feature tam giác

```text
vertices, midpoints, feet, contact-points, centers,
medians, altitudes, angle-bisectors, perpendicular-bisectors,
incircle, circumcircle, nine-point-circle, excircles,
euler-line, medial-triangle, orthic-triangle, contact-triangle,
excentral-triangle, advanced-centers, gergonne-cevians, all
```

### Feature tứ giác

```text
vertices, diagonals, midpoints, diagonal-intersection, all
```

### Feature đa giác đều

```text
vertices, center, radii, circumcircle, all
```

### Feature đường tròn

```text
center, points, radii, polygon, all
```

## 1.8. `euclid.templates`

- `triangle-centers`
- `euler-triangle`
- `derived-triangles`
- `thales`
- `ceva`
- `menelaus`
- `perpendicular-bisector`
- `angle-bisector`
- `tangent-from-point`
- `intersecting-chords`
- `cyclic-quadrilateral`
- `reflection`
- `homothety`

Mọi template trả về model mở và có thể tiếp tục dùng `with-object`, `construct`, `patch-object` hoặc `patch-tag`.

## 1.9. `euclid.theorems`

- `pedal-triangle`
- `simson-line`
- `gergonne`
- `nagel`
- `symmedians`
- `radical-axis`
- `power-of-point`
- `inversion`
- `ptolemy`
- `inscribed-angle`

Mỗi hàm trả về model mở, có điểm đặc biệt được đặt tên và metadata chứa đại lượng liên quan khi thích hợp.

## 1.10. `euclid.conics`

- `parabola(vertex:, p:, rotation:, domain:, features:)`
- `ellipse(center:, a:, b:, rotation:, features:)` — tự xác định trục lớn theo `a` hoặc `b`.
- `hyperbola(center:, a:, b:, rotation:, t-max:, features:)`

Các điểm đặc biệt như `V`, `F`, `F_1`, `F_2`, `A_1`, `A_2`, `B_1`, `B_2`, `O` được lưu trong model.

---

# 2. API cũ được giữ tương thích

## 2.1. Foundation

### `core`

`point`, `add`, `sub`, `mul`, `div`, `dot`, `cross`, `norm`, `distance`, `unit`, `perp`, `midpoint`, `lerp`, `direction`, `rotate-point`, `project-point-line`, `reflect-point-line`, `line-intersection`, `segment-intersection`, `circle-line-intersections`, `circle-circle-intersections`, `triangle-centroid`, `triangle-incenter`, `triangle-circumcenter`, `triangle-orthocenter`, `triangle-incircle`, `triangle-circumcircle`, `regular-polygon-points`, `sample-function`.

### `styles`

`theme`, `palette`, `get`, `stroke-with`.

### `primitives`

`draw-point`, `draw-points`, `draw-segment`, `draw-polyline`, `draw-line`, `draw-ray`, `draw-vector`, `draw-circle`, `draw-ellipse`, `draw-arc`, `draw-polygon`, `draw-regular-polygon`, `draw-label`, `draw-grid`, `draw-axes`.

### `marks`

`right-angle`, `angle-mark`, `segment-ticks`, `parallel-marks`, `perpendicular-foot`.

## 2.2. Plane geometry

- `triangles`: `triangle`, `right-triangle`, `isosceles-triangle`, `equilateral-triangle`.
- `quadrilaterals`: `rectangle`, `square`, `parallelogram`, `rhombus`, `trapezoid`, `cyclic-quadrilateral`, `quadrilateral`.
- `circles`: `circle-basic`, `tangent-from-point`, `intersecting-chords`, `inscribed-angle`.
- `polygons`: `regular-polygon`, `star-polygon`, `polygon-angle-sum`.
- `constructions`: `perpendicular-bisector`, `angle-bisector`, `reflection-across-line`, `homothety-figure`, `circle-through-three-points`.
- `theorems`: `thales-parallel`, `pythagorean-squares`, `ceva-configuration`, `menelaus-configuration`, `power-of-point`, `tangent-secant-theorem`.
- `trigonometry`: `unit-circle`, `right-triangle-trig`, `sine-rule-triangle`, `vector-components`.

## 2.3. Analytic geometry

- `conics`: `draw-curve`, `parabola`, `ellipse`, `hyperbola`.
- `contacts`: `tangent-parabola`, `tangent-ellipse`, `tangent-hyperbola`, cùng các bản `draw-*` dùng trong canvas.
- `regions`: `find-roots`, `integral-regions`, `feasible-polygon`, `lp-region`, `draw-integral-region`, `draw-lp-region`.
- `linear-programming`: namespace của `lp-region.typ` đầy đủ do tác giả cung cấp.

## 2.4. Space geometry

- `solids`: `cube`, `prism`, `pyramid`, `cylinder`, `cone`, `frustum`, `sphere`.
- `nets`: `cube-net`, `prism-net`, `cylinder-net`, `cone-net`.
- `unfold`: `wrapped-cylinder`, `wrapped-cone`, `wrapped-frustum`, `wrapped-prism`, `wrapped-cube`, `wrapped-pyramid`.
- `sections`: `solid-section`, `draw-solid-section`.

## 2.5. Probability and diagrams

- `probability-tree`, `prob-tree`
- `venn`, `venn-diagram`

---

# 3. Validation rule

Trước khi render một model lớn:

```typ
#let errors = euclid.validate(fig)
#assert(errors.len() == 0, message: errors.join("; "))
```

Điều này phát hiện object đang tham chiếu tới điểm chưa được định nghĩa.
