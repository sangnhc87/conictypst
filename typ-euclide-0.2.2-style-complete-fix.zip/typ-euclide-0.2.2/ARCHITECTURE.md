# Architecture of typ-euclide 0.2.1

## 1. Design objective

The advanced Euclidean API deliberately separates **geometry data**, **drawable objects**, and **rendering**. A preset must never be the only place where its coordinates exist. Every reusable figure returns a model whose points can be addressed by stable names and whose visual objects can be queried or patched before rendering.

```text
analytic geometry ──> named model ──> declarative objects ──> CeTZ renderer
                           │                    │
                           ├─ constructions     ├─ id / tag / role / layer
                           ├─ figures           └─ per-object overrides
                           ├─ templates
                           └─ theorem models
```

## 2. Model schema

```typ
(
  points: (:),          // name -> coordinate
  objects: (),          // declarative drawable dictionaries
  point-options: (:),   // per-point marker and label options
  meta: (:),            // computed geometry and semantic information
  styles: (:),          // optional model-local style data
)
```

Coordinates are unitless CeTZ coordinates. Object references may be either a coordinate tuple or a point name. This permits a template to expose all its geometry while still allowing direct ad-hoc coordinates.

## 3. Dependency direction

```text
src/core.typ                        pure numeric geometry
       │
src/euclid/analytic.typ             analytic objects and named data
       │
       ├─ model.typ                 persistent model editing
       ├─ objects.typ               declarative drawing records
       ├─ construct.typ             add named constructions to a model
       ├─ figures.typ               reusable figure builders
       ├─ templates.typ             standard school constructions
       ├─ theorems.typ              advanced theorem configurations
       └─ conics.typ                open analytic conic models
                    │
style.typ + primitives + marks ──> render.typ ──> CeTZ
```

`core.typ` stays independent of CeTZ. Geometry algorithms return coordinates or data dictionaries. Rendering consumes those values but does not own them.

## 4. Object contract

Every object has common fields:

```text
kind, id, role, layer, visible, tags
```

Most objects may additionally define `stroke`, `fill`, and `fill-role`. Point objects merge theme settings, model `point-options`, and object-level overrides in that order.

Stable `id` values support one-object edits. Semantic `tags` support group edits. `role` selects a theme channel. `layer` controls draw order.

## 5. Open-template workflow

```typ
#let fig = euclid.templates.euler-triangle()
#let fig = euclid.construct.midpoint(fig, "D", "B", "C")
#let fig = euclid.with-object(fig, euclid.segment("A", "D"))
#let fig = euclid.patch-tag(fig, "altitudes", (role: "accent"))
#euclid.render-model(fig)
```

The same model can also be drawn inside an existing CeTZ canvas with `euclid.draw-model`, after which ordinary CeTZ commands can continue using coordinates returned by `euclid.point-at`.

## 6. Style hierarchy

```text
base theme
  ├─ role strokes: main / strong / auxiliary / construction / hidden / accents
  ├─ role fills
  ├─ default point marker
  ├─ default point label
  ├─ angle settings
  └─ object-level overrides
```

Point options can override label content, offset, anchor, size, fill, point radius, point fill, and point stroke without changing the rest of the model.

## 7. Compatibility layer

The 0.1.x namespaces and root shim modules remain available. The new `euclid` namespace is additive. `linear-programming` exposes the complete supplemental `lp-region.typ` while legacy `regions` and root imports remain intact.

## 8. Test layers

- Static structure: delimiters, import paths, duplicate library definitions, explicit local imports.
- Analytic assertions: distances, angles, triangle centers, tangent geometry, vertical-major ellipse behavior.
- Model assertions: named points, object queries, validation, extension and point options.
- Smoke compilation targets: old API, demo compatibility, advanced examples, and `hdsd-euclide.typ`.
- Visual review: compile the guide/gallery and compare its pages; reference PNGs are supplied only as independent composition previews.
