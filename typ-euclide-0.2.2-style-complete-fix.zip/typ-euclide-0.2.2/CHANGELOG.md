# Changelog

## 0.2.1

- Fixed the Tinymist diagnostic on `base.theme(name)` in `src/euclid/style.typ`.
- Theme selection now resolves `none`, named themes, and custom dictionaries locally before applying overrides.
- Preserved the public `euclid-theme(name: none, overrides: (:))` API.

## 0.2.0

### Named Euclidean model API

- Added `euclid`, a new namespace whose figures return open data models instead of closed, hard-coded canvas output.
- Added stable named-point lookup through `point-at`, `point-names`, `alias-point`, `with-point`, `with-points`, and `with-point-option`.
- Added object querying and editing through `object-at`, `objects-with-tag`, `objects-of-kind`, `map-objects`, `patch-object`, `patch-objects`, `patch-kind`, `patch-tag`, `hide-object`, and `show-object`.
- Added object constructors for points, labels, segments, infinite lines, rays, vectors, polylines, polygons, circles, circle-through-point, arcs, ellipses, angles, right-angle marks, equal-length ticks, parallel marks, grids, axes, function curves, and parametric curves.
- Added named construction workflows for midpoint, division point, point-on-segment, projection, reflection, rotation, translation, homothety, barycentric point, triangle centers, line/circle intersections, tangent points, angle-bisector foot, incircle, circumcircle, excenter, inversion, parallel/perpendicular lines, and radical axis.
- Added layered theme roles and per-point label/marker customization.

### Figures and theorem models

- Added open models for general/right/equilateral/isosceles triangles, quadrilaterals, rectangles, squares, parallelograms, rhombi, trapezoids, kites, regular polygons, circles, and coordinate planes.
- Added triangle features for medians, altitudes, angle bisectors, perpendicular bisectors, midpoints, feet, contact points, incircle, circumcircle, nine-point circle, excircles, Euler line, medial/orthic/contact/excentral triangles, advanced centers, and Gergonne cevians.
- Added named triangle data for `G`, `O`, `I`, `H`, `N`, excenters, Lemoine, Gergonne, Nagel, Spieker, Bevan, and de Longchamps points.
- Added extensible theorem models for Thales, Ceva, Menelaus, tangent constructions, intersecting chords, cyclic quadrilaterals, pedal triangle, Simson line, Gergonne, Nagel, symmedians, radical axis, power of a point, inversion, Ptolemy, and inscribed angles.
- Added open conic models for parabola, ellipse, and hyperbola with named foci, vertices, axes, center, focus/directrix, and asymptotes.

### Supplemental module integration

- Replaced the generated fallback with the complete author-supplied `lp-region.typ` implementation.
- Preserved input labels and stroke fields during inequality normalization.
- Added equality support as paired inequalities.
- Added a standalone `linear-programming.lp-region` canvas wrapper while keeping `draw-lp-region` available inside CeTZ canvases.

### Correctness and documentation

- Corrected the signed-angle argument order for Typst's `(x, y)` form of `calc.atan2`.
- Made ellipse foci and major/minor vertices correct when the vertical semiaxis is larger than the horizontal semiaxis.
- Applied nested per-point label size and fill during rendering.
- Added `hdsd-euclide.typ`, a code-and-result gallery, plus Markdown API and architecture documentation.
- Added analytic and named-model smoke tests and independent reference previews.

## 0.1.1

- Integrated the six source modules supplied with `demo.typ`.
- Added the previously missing `lp-region.typ` compatibility file.
- Removed duplicate prism definitions in `unfold.typ`.
- Fixed dictionary stroke handling in the 3D conic mode.
- Removed a repeated CeTZ import in `solid-section.typ`.
- Fixed the `theme("blue")` diagnostic in `src/presets.typ`.
- Added `demo.typ` and `examples/demo-full.typ`.

## 0.1.0

- Introduced the modular geometry core, shared styles, plane figures, conics, graphs, space geometry, unfoldings, probability trees, and Venn diagrams.
