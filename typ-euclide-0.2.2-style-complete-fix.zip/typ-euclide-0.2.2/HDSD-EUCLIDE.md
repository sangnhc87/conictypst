# Hướng dẫn sử dụng typ-euclide 0.2.1

Tài liệu chạy trực tiếp, có code và hình kết quả nằm trong [`hdsd-euclide.typ`](hdsd-euclide.typ).
File Markdown này giải thích ngắn gọn quy trình mới.

## 1. Nguyên tắc model mở

```typ
#import "lib.typ": euclid

#let fig = euclid.triangle(
  A: (-2.4, -1.1),
  B: (2.5, -1.1),
  C: (0.4, 2.5),
  features: ("vertices", "circumcircle", "centers"),
)
```

`fig` không phải ảnh hardcode. Nó là dictionary:

```text
points         tọa độ theo tên
objects        danh sách đối tượng cần vẽ
point-options  style/nhãn riêng từng điểm
meta           dữ liệu hình học dẫn xuất
styles         style phụ của model
```

## 2. Lấy điểm

```typ
#let H = euclid.point-at(fig, "H")
#let O = euclid.point-at(fig, "O")
#let names = euclid.point-names(fig)
```

Với tam giác, package tính sẵn nhiều điểm:

```text
A B C
M_a M_b M_c
H_a H_b H_c
T_a T_b T_c
G O I H N
I_a I_b I_c
K Ge Na S Be L
```

## 3. Dựng thêm điểm

```typ
#let fig = euclid.construct.midpoint(fig, "D", "B", "C")
#let fig = euclid.construct.projection(fig, "E", "D", "A", "B")
#let fig = euclid.construct.reflection(fig, "P", "E", "A", "C")
#let fig = euclid.construct.rotation(fig, "Q", "P", "A", 60deg)
```

## 4. Thêm đối tượng

```typ
#let fig = euclid.with-objects(fig, (
  euclid.segment("A", "D", id: "ad", role: "accent"),
  euclid.line("H", "O", id: "euler-extension", role: "tertiary"),
  euclid.circle-through("D", "E", id: "circle-de", role: "secondary"),
  euclid.angle("A", "B", "C", label: $alpha$),
))
```

Mọi tham chiếu có thể dùng tên điểm hoặc tọa độ trực tiếp.

## 5. Sửa theo id/tag

```typ
#let fig = euclid.hide-object(fig, "circumcircle")
#let fig = euclid.patch-object(fig, "ad", (
  stroke: (paint: purple, thickness: 1.4pt),
))
#let fig = euclid.patch-tag(fig, "altitudes", (role: "accent"))
```

## 6. Render

```typ
#euclid.render-model(fig)
```

Trong một CeTZ canvas đang có:

```typ
#cetz.canvas({
  euclid.draw-model(fig)
  // Có thể tiếp tục gọi cetz.draw tại đây.
})
```

Hoặc dùng overlay:

```typ
#euclid.render-model(fig, overlay: model => {
  import cetz.draw: line
  line(
    euclid.point-at(model, "A"),
    euclid.point-at(model, "G"),
    stroke: red,
  )
})
```

## 7. Theme

```typ
#let style = euclid.euclid-theme("blue", overrides: (
  accent: rgb("0057B8"),
  secondary: rgb("C62828"),
  point: (radius: 0.07, fill: white),
  label: (size: 10pt, offset: (0.15, 0.15)),
  strokes: (
    accent: (paint: rgb("0057B8"), thickness: 1.3pt),
    construction: (paint: gray, thickness: 0.5pt, dash: "dotted"),
  ),
  fills: (
    accent: rgb("DDEBFF").transparentize(25%),
  ),
))
```

## 8. Hình dựng sẵn

### Figures

```typ
#euclid.triangle(...)
#euclid.right-triangle(...)
#euclid.equilateral-triangle(...)
#euclid.isosceles-triangle(...)
#euclid.quadrilateral(...)
#euclid.rectangle(...)
#euclid.square(...)
#euclid.parallelogram(...)
#euclid.rhombus(...)
#euclid.trapezoid(...)
#euclid.kite(...)
#euclid.regular-polygon(...)
```

### Templates

```typ
#euclid.templates.triangle-centers()
#euclid.templates.euler-triangle()
#euclid.templates.derived-triangles()
#euclid.templates.thales()
#euclid.templates.ceva()
#euclid.templates.menelaus()
#euclid.templates.perpendicular-bisector()
#euclid.templates.angle-bisector()
#euclid.templates.tangent-from-point()
#euclid.templates.intersecting-chords()
#euclid.templates.cyclic-quadrilateral()
#euclid.templates.reflection()
#euclid.templates.homothety()
```

### Advanced theorems

```typ
#euclid.theorems.pedal-triangle()
#euclid.theorems.simson-line()
#euclid.theorems.gergonne()
#euclid.theorems.nagel()
#euclid.theorems.symmedians()
#euclid.theorems.radical-axis()
#euclid.theorems.power-of-point()
#euclid.theorems.inversion()
#euclid.theorems.ptolemy()
#euclid.theorems.inscribed-angle()
```

### Conics

```typ
#euclid.conics.parabola(...)
#euclid.conics.ellipse(...)
#euclid.conics.hyperbola(...)
```

## 9. Kiểm tra tham chiếu

```typ
#let errors = euclid.validate(fig)
#assert(errors.len() == 0, message: errors.join("; "))
```

`validate` kiểm tra object dùng tên điểm chưa tồn tại.

## 10. File mẫu đầy đủ

Mở và compile:

```text
hdsd-euclide.typ
```

File này gồm code hiển thị và hình được render ngay bên dưới từng đoạn code, phù hợp dùng như gallery và smoke test trực quan.

## 11. Tra cứu object và tùy biến sau khi dựng

```typ
#let triangle-object = euclid.object-at(fig, "triangle")
#let centers = euclid.objects-with-tag(fig, "centers")
#let points = euclid.objects-of-kind(fig, "point")

#let fig = euclid.alias-point(fig, "X", "G")
#let fig = euclid.with-point-option(fig, "X", (
  label-content: $X_0$,
  label: (offset: (0.18, 0.18), size: 10pt),
  point: (fill: red, radius: 0.08),
))
#let fig = euclid.with-object(fig, euclid.point("X", role: "accent"))
```

## 12. Dựng tâm và đường tròn vào model bất kỳ

```typ
#let fig = euclid.triangle(features: ("vertices",))
#let fig = euclid.construct.centroid(fig, "G_1", "A", "B", "C")
#let fig = euclid.construct.incenter(fig, "I_1", "A", "B", "C")
#let fig = euclid.construct.circumcenter(fig, "O_1", "A", "B", "C")
#let fig = euclid.construct.orthocenter(fig, "H_1", "A", "B", "C")
#let fig = euclid.construct.circumcircle(fig, "O_c", "A", "B", "C")
#let fig = euclid.construct.incircle(fig, "I_c", "A", "B", "C")
```

## 13. Vẽ tiếp bằng CeTZ mà không mất tọa độ

```typ
#import "@preview/cetz:0.5.2" as cetz

#cetz.canvas({
  import cetz.draw: *
  euclid.draw-model(fig)
  line(
    euclid.point-at(fig, "A"),
    euclid.point-at(fig, "G"),
    stroke: red,
  )
})
```

## 14. Quy hoạch tuyến tính bổ sung

```typ
#import "lib.typ": linear-programming

#linear-programming.lp-region(
  (
    (a: 1, b: 2, c: 10, label: $d_1$),
    (a: 2, b: 1, c: 8, label: $d_2$),
    (a: -1, b: 0, c: 0),
    (a: 0, b: -1, c: 0),
  ),
  bounds: (x: (-1, 8), y: (-1, 8)),
  format-vertex: "auto",
)
```

## 15. Hình tham chiếu

Các hình dưới đây mô tả bố cục mong đợi. Chúng được tạo độc lập để xem nhanh, không phải ảnh chụp đầu ra Typst/CeTZ. Kết quả thật nằm trong `hdsd-euclide.typ` sau khi compile.

![Tam giác và các tâm](docs/previews/triangle-centers.png)

![Dựng hình theo tên](docs/previews/named-construction.png)

![Tiếp tuyến từ điểm ngoài](docs/previews/tangent-from-point.png)

![Mô hình elip mở](docs/previews/ellipse-model.png)

## 16. Trạng thái kiểm tra

- Kiểm tra tĩnh đã đạt cho 50 file Typst ngoài `legacy/`.
- Có test số học hình học và test model mở.
- Môi trường tạo bản này không có Typst CLI, nên cần compile `hdsd-euclide.typ` trên máy của bạn để xác nhận hình thực tế trước khi phát hành.
