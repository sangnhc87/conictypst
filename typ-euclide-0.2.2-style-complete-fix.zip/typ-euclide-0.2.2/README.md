# typ-euclide 0.2.1

`typ-euclide` là package Typst/CeTZ cho hình học Euclid và hình minh họa Toán phổ thông. Bản 0.2.1 bổ sung một API mới theo **mô hình điểm có tên**: hình mẫu trả về dữ liệu có thể tra cứu, mở rộng, sửa từng đối tượng và render lại, thay vì chỉ trả về một hình hardcode đóng kín.

## Điểm nổi bật của 0.2.1

- Model chứa `points`, `objects`, `point-options`, `meta`, `styles`.
- Mọi điểm quan trọng có tên ổn định: `A`, `B`, `C`, `G`, `H`, `O`, `I`, `N`, `M_a`, `H_a`, `T_a`, `I_a`, `K`, `Ge`, `Na`, ...
- Object khai báo: điểm, nhãn, đoạn, đường thẳng, tia, vector, đa giác, đường tròn, cung, elip, góc, dấu vuông, dấu bằng nhau, dấu song song, trục, lưới và đường cong.
- Dựng hình tuần tự theo tên điểm: trung điểm, chia đoạn, điểm theo tham số, barycentric, trọng tâm/nội tâm/ngoại tâm/trực tâm, hình chiếu, đối xứng, quay, tịnh tiến, vị tự, giao đường, giao đường tròn, tiếp tuyến, đường tròn nội/ngoại tiếp, nghịch đảo và trục đẳng phương.
- Sửa hình theo `id` hoặc `tag`: ẩn, hiện, đổi role, đổi màu/nét riêng, thay đổi theo nhóm.
- Theme phân cấp: nét theo role, fill theo role, style điểm, nhãn, góc và lớp vẽ.
- Hình tam giác mở rộng: trung tuyến, đường cao, phân giác, trung trực, các tâm, đường tròn nội/ngoại tiếp, Euler, chín điểm, tam giác trung bình/trực tâm/tiếp xúc/ngoại tâm và các tâm nâng cao.
- Hình mẫu định lý: Thales, Ceva, Menelaus, trung trực, phân giác, tiếp tuyến từ điểm ngoài, dây cung cắt nhau, tứ giác nội tiếp và phép biến hình.
- Conic ở dạng model mở: parabol, elip, hypebol; có thể lấy lại tiêu điểm/đỉnh/tâm và tiếp tục vẽ.
- Giữ toàn bộ API cũ: hình không gian, khai triển, thiết diện, xác suất, Venn, đồ thị, tích phân và miền nghiệm tuyến tính.
- Tích hợp bản `lp-region.typ` đầy đủ do tác giả bổ sung.

## Cài đặt

Sau khi package được phát hành:

```typ
#import "@preview/typ-euclide:0.2.1": euclid
```

Dùng local:

```typ
#import "lib.typ": euclid
```

Package dùng CeTZ `0.5.2` và khai báo compiler Typst tối thiểu `0.14.0`.

## Khởi động nhanh

```typ
#import "lib.typ": euclid

#let fig = euclid.triangle(
  A: (-2.3, -1.2),
  B: (2.4, -1.2),
  C: (0.4, 2.3),
  features: (
    "vertices", "medians", "altitudes",
    "circumcircle", "incircle", "centers",
  ),
)

#euclid.render-model(fig)
```

## Lấy điểm và tiếp tục vẽ

```typ
#let fig = euclid.templates.euler-triangle()

#let H = euclid.point-at(fig, "H")
#let O = euclid.point-at(fig, "O")

#let fig = euclid.construct.midpoint(fig, "D", "B", "C")
#let fig = euclid.with-objects(fig, (
  euclid.segment("A", "D", id: "median-ad", role: "accent"),
  euclid.line("H", "O", id: "line-ho", role: "tertiary", extend: 1.2),
))

#euclid.render-model(fig)
```

## Tùy biến từng điểm

```typ
#let fig = euclid.triangle(
  features: ("vertices", "centers"),
  point-options: (
    A: (
      label-content: $A_0$,
      label: (offset: (-0.25, -0.18), anchor: "north-east"),
      point: (radius: 0.08, fill: red),
    ),
    H: (
      label: (offset: (0.18, 0.18)),
      point: (radius: 0.07, fill: green),
    ),
  ),
)
```

## Tùy biến theme phân cấp

```typ
#let exam-theme = euclid.euclid-theme("blue", overrides: (
  accent: rgb("0057B8"),
  secondary: rgb("C62828"),
  tertiary: rgb("2E7D32"),
  strong-stroke: (paint: rgb("202124"), thickness: 1.35pt),
  auxiliary-stroke: (paint: rgb("5F6368"), thickness: 0.65pt, dash: "dashed"),
  point: (
    radius: 0.07,
    fill: white,
    stroke: (paint: rgb("202124"), thickness: 0.9pt),
  ),
  label: (size: 10pt, offset: (0.15, 0.15)),
  strokes: (
    accent: (paint: rgb("0057B8"), thickness: 1.25pt),
  ),
))

#euclid.render-model(euclid.templates.tangent-from-point(), style: exam-theme)
```

## Sửa theo id và tag

```typ
#let fig = euclid.templates.euler-triangle()
#let fig = euclid.hide-object(fig, "circumcircle")
#let fig = euclid.patch-tag(fig, "altitudes", (role: "accent"))
#let fig = euclid.patch-object(fig, "euler-line", (
  stroke: (paint: purple, thickness: 1.4pt),
))
#euclid.render-model(fig)
```

## Tra cứu và chỉnh sửa model

```typ
#let triangle-object = euclid.object-at(fig, "triangle")
#let center-objects = euclid.objects-with-tag(fig, "centers")
#let point-objects = euclid.objects-of-kind(fig, "point")

// Tạo tên khác cho cùng một điểm và tùy chỉnh sau khi dựng.
#let fig = euclid.alias-point(fig, "X", "G")
#let fig = euclid.with-point-option(fig, "X", (
  label-content: $X_0$,
  point: (fill: red, radius: 0.08),
))
#let fig = euclid.with-object(fig, euclid.point("X", role: "accent"))

// Sửa nhiều object theo id, kind hoặc tag.
#let fig = euclid.patch-objects(fig, ("median-a", "median-b"), (role: "accent"))
#let fig = euclid.patch-kind(fig, "point", (layer: 60))
```

## Dựng các tâm và đường tròn vào một hình đang có

```typ
#let fig = euclid.triangle(features: ("vertices",))
#let fig = euclid.construct.centroid(fig, "G_1", "A", "B", "C")
#let fig = euclid.construct.circumcenter(fig, "O_1", "A", "B", "C")
#let fig = euclid.construct.incenter(fig, "I_1", "A", "B", "C")
#let fig = euclid.construct.orthocenter(fig, "H_1", "A", "B", "C")
#let fig = euclid.construct.circumcircle(fig, "O_c", "A", "B", "C")
#let fig = euclid.construct.incircle(fig, "I_c", "A", "B", "C")
```

## Namespace mới `euclid`

| Namespace | Nội dung |
|---|---|
| `euclid.model` | Model, tra cứu điểm, thêm/sửa/xóa object, biến đổi toàn hình, kiểm tra tham chiếu |
| `euclid.objects` | Các object khai báo để render |
| `euclid.analytic` | Đại số vector, đường, đường tròn, giao điểm, tâm tam giác, nghịch đảo, trục đẳng phương |
| `euclid.construct` | Dựng điểm có tên theo từng bước |
| `euclid.figures` | Tam giác, tứ giác, hình đặc biệt, đa giác đều, đường tròn, mặt phẳng tọa độ |
| `euclid.templates` | Hình định lý và phép dựng thông dụng |
| `euclid.theorems` | Pedal, Simson, Gergonne, Nagel, symmedian, trục đẳng phương, phương tích, nghịch đảo, Ptolemy |
| `euclid.conics` | Parabol, elip, hypebol dạng model mở |
| `euclid.style` | Theme phân cấp |
| `euclid.render` | Render model hoặc vẽ vào CeTZ canvas hiện có |

## Các feature tam giác

```text
vertices, midpoints, feet, contact-points, centers,
medians, altitudes, angle-bisectors, perpendicular-bisectors,
incircle, circumcircle, nine-point-circle, excircles,
euler-line, medial-triangle, orthic-triangle, contact-triangle,
excentral-triangle, advanced-centers, gergonne-cevians, all
```

Các điểm dẫn xuất có thể truy cập gồm:

```text
A B C
M_a M_b M_c
H_a H_b H_c
T_a T_b T_c
G O I H N
I_a I_b I_c
K Ge Na S Be L
```

Trong đó `K` là điểm symmedian/Lemoine, `Ge` là Gergonne, `Na` là Nagel, `S` là Spieker, `Be` là Bevan và `L` là de Longchamps.

## API cũ vẫn còn

Bản 0.2.1 giữ các namespace cũ:

```typ
#import "lib.typ": triangles, circles, theorems, trigonometry
#import "lib.typ": solids, nets, unfold, sections
#import "lib.typ": probability, regions, contacts, graphs
```

Các file tương thích demo cũ vẫn được giữ:

```text
unfold.typ
tree.typ
venn.typ
solid-section.typ
conic-tangent.typ
integral-region.typ
lp-region.typ
```

## Tài liệu và gallery

- `hdsd-euclide.typ`: tài liệu Typst có cả code và hình kết quả trong cùng một file.
- `HDSD-EUCLIDE.md`: hướng dẫn API dạng Markdown.
- `API.md`: danh mục API toàn package.
- `examples/advanced-model.typ`: ví dụ xây hình theo model.
- `tests/euclid-model-smoke.typ`: kiểm tra model, điểm và tham chiếu.
- `tests/euclid-analytic.typ`: kiểm tra số học hình học, tâm tam giác, tiếp tuyến và conic.
- `docs/previews/`: hình tham chiếu về bố cục; không phải ảnh chụp từ Typst vì môi trường tạo package chưa có compiler.
- `demo.typ`: demo lớn tương thích bộ file ban đầu.

## Kiểm tra

```bash
python scripts/check_package.py
```

Script kiểm tra đường dẫn import, ngoặc, định nghĩa trùng, symbol import nội bộ và sẽ compile toàn bộ smoke test cùng `hdsd-euclide.typ` nếu tìm thấy Typst CLI. Bản build này đã vượt qua kiểm tra tĩnh cho 50 file Typst; biên dịch thực tế vẫn cần chạy trên máy có Typst.
