# typ-euclide 0.2.1 release summary

This release introduces the open named-model Euclidean API and integrates the complete supplemental LP region module.

## Core promise

A standard figure is not a closed picture. It is a model containing named coordinates and declarative objects. Users can:

1. retrieve any exposed point by name;
2. construct additional named points;
3. append new objects referencing those names;
4. query, hide, show, or patch objects by id, kind, or semantic tag;
5. apply global or per-point styles;
6. draw the model inside an existing CeTZ canvas and continue with ordinary CeTZ commands.

## Main entry points

```typ
#import "lib.typ": euclid, linear-programming
```

- `euclid`: open Euclidean geometry models.
- `linear-programming`: the full supplied `lp-region.typ` implementation.
- Existing 0.1.x namespaces remain available.

## Guide

Compile `hdsd-euclide.typ`. It contains displayed source code followed by the corresponding rendered package result for each section.

## Validation limitation

Static validation succeeded. The release environment did not contain Typst CLI, so local compilation of the guide and tests is still required before publishing.
