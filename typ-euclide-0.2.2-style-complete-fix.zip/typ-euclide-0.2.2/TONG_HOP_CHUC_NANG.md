# Tổng hợp toàn bộ chức năng đã có trong `typ-euclide` 0.1.0

Tài liệu này mô tả **toàn bộ nội dung hiện có trong file `typ-euclide-0.1.0.zip`**: mục tiêu package, kiến trúc, các nhóm hình đã triển khai, API công khai, lớp tương thích với `demo.typ`, ví dụ, kiểm thử và các giới hạn hiện tại.

> Trạng thái kỹ thuật của bản ZIP hiện tại:
>
> - 40 file tổng cộng.
> - 31 file `.typ`, trong đó script kiểm tra 30 file ngoài thư mục `legacy/`.
> - 6 file Markdown sau khi bổ sung tài liệu này thành 7 file Markdown.
> - Package dùng CeTZ `0.5.2`.
> - Yêu cầu Typst `0.14.0` trở lên.
> - Kiểm tra tĩnh đã đạt; chưa biên dịch thật trong môi trường tạo package vì không có Typst CLI.

---

## 1. Mục tiêu của package

`typ-euclide` là một package Typst xây trên CeTZ, hướng tới việc tạo một bộ công cụ vẽ hình Toán phổ thông có cấu trúc phân cấp, gồm:

- Hình học Euclid phẳng.
- Các phép dựng hình cơ bản.
- Hình minh họa định lý phổ thông.
- Lượng giác và vector.
- Đường tròn và các đường conic.
- Đồ thị hàm số, miền tích phân và miền nghiệm tuyến tính.
- Hình học không gian, hình khai triển và đường quấn trên mặt khối.
- Khối có thiết diện biến thiên theo hàm.
- Cây xác suất và biểu đồ Venn.
- Hệ theme dùng chung để tùy chỉnh màu, nét, nhãn, điểm và vùng tô.
- Lớp tương thích với các lời gọi đã xuất hiện trong `demo.typ` ban đầu.

Package được thiết kế theo hướng:

1. **Tách tính toán và hiển thị**: thuật toán hình học số nằm trong `core.typ`, phần vẽ dùng CeTZ nằm ở các module còn lại.
2. **Phân cấp namespace**: mỗi nhóm chức năng có namespace riêng.
3. **Tùy chỉnh tập trung**: các hình cấp cao nhận đối số `style:`.
4. **Giữ API cũ**: các file shim ở thư mục gốc chuyển lời gọi cũ sang API mới.
5. **Dễ mở rộng**: chức năng mới nên thêm trong module riêng rồi mới re-export ở `lib.typ` khi đủ ổn định.

---

## 2. Cấu trúc package

```text
typ-euclide/
├── typst.toml
├── lib.typ
├── README.md
├── API.md
├── ARCHITECTURE.md
├── CHANGELOG.md
├── VALIDATION.md
├── TONG_HOP_CHUC_NANG.md
├── LICENSE
│
├── src/
│   ├── core.typ
│   ├── styles.typ
│   ├── primitives.typ
│   ├── marks.typ
│   ├── triangles.typ
│   ├── quadrilaterals.typ
│   ├── circles.typ
│   ├── conics.typ
│   ├── graphs.typ
│   ├── solids.typ
│   ├── nets.typ
│   ├── probability.typ
│   ├── presets.typ
│   │
│   ├── geometry/
│   │   ├── polygons.typ
│   │   ├── constructions.typ
│   │   ├── theorems.typ
│   │   └── trigonometry.typ
│   │
│   ├── analysis/
│   │   ├── regions.typ
│   │   └── conic-contact.typ
│   │
│   └── space/
│       ├── unfold.typ
│       └── sections.typ
│
├── examples/
│   ├── gallery.typ
│   └── legacy-compat.typ
│
├── tests/
│   └── smoke.typ
│
├── scripts/
│   └── check_package.py
│
├── unfold.typ
├── tree.typ
├── venn.typ
├── solid-section.typ
├── conic-tangent.typ
│
└── legacy/
    ├── README.md
    └── demo-original.typ
```

---

## 3. Cách import

### 3.1. Dùng package local

```typ
#import "lib.typ": *
```

### 3.2. Dùng namespace

```typ
#import "lib.typ": triangles, circles, theorems, unfold, regions

#triangles.right-triangle(legs: (4, 3))
#circles.tangent-from-point(radius: 2, p: (4.5, 1))
#theorems.pythagorean-squares(adjacent: 4, opposite: 3)
#unfold.wrapped-cylinder(r: 1, h: 4, wrap: 2)
#regions.integral-regions(x => x * x - 2, g: x => x)
```

### 3.3. Khi phát hành lên Typst Universe

```typ
#import "@preview/typ-euclide:0.1.0": *
```

---

# PHẦN I — LÕI HÌNH HỌC VÀ HỆ STYLE

## 4. `core` — lõi tính toán hình học

File: `src/core.typ`

Module này không phụ thuộc CeTZ. Nó cung cấp các phép toán số và hình học thuần túy để các module vẽ sử dụng.

### 4.1. Điểm và vector

- `point(x, y)` — tạo điểm hai chiều.
- `x(p)`, `y(p)` — lấy tọa độ.
- `add(a, b)` — cộng hai vector/điểm.
- `sub(a, b)` — trừ hai vector/điểm.
- `mul(k, a)` — nhân vector với số.
- `div(a, k)` — chia vector cho số.
- `dot(a, b)` — tích vô hướng.
- `cross(a, b)` — tích có hướng hai chiều.
- `norm2(a)` — bình phương độ dài.
- `norm(a)` — độ dài vector.
- `distance(a, b)` — khoảng cách hai điểm.
- `unit(a)` — vector đơn vị.
- `perp(a)` — vector vuông góc.
- `midpoint(a, b)` — trung điểm.
- `lerp(a, b, t)` — nội suy tuyến tính.
- `direction(a, b)` — vector đơn vị từ `a` đến `b`.
- `angle-of(v)` — góc phương của vector.
- `clamp(v, lo, hi)` — chặn giá trị vào đoạn.
- `almost-equal(a, b, tolerance:)` — so sánh gần đúng.

### 4.2. Phép biến hình

- `rotate-vector(v, angle)` — quay vector.
- `rotate-point(p, angle, center:)` — quay điểm quanh tâm.
- `translate-point(p, by:)` — tịnh tiến điểm.
- `homothety(p, center:, ratio:)` — vị tự.
- `project-point-line(p, a, b)` — hình chiếu vuông góc của điểm lên đường thẳng.
- `reflect-point-line(p, a, b)` — đối xứng điểm qua đường thẳng.

### 4.3. Diện tích và quan hệ thẳng hàng

- `signed-area2(a, b, c)` — hai lần diện tích đại số tam giác.
- `triangle-area(a, b, c)` — diện tích tam giác.
- `is-collinear(a, b, c, tolerance:)` — kiểm tra ba điểm thẳng hàng.
- `distance-point-line(p, a, b)` — khoảng cách từ điểm đến đường thẳng.

### 4.4. Giao điểm

- `line-intersection(a, b, c, d, tolerance:)` — giao hai đường thẳng.
- `segment-intersection(a, b, c, d, tolerance:)` — giao hai đoạn thẳng.
- `circle-line-intersections(center, radius, a, b, tolerance:)` — giao đường tròn và đường thẳng.
- `circle-circle-intersections(c1, r1, c2, r2, tolerance:)` — giao hai đường tròn.

### 4.5. Tâm và đường tròn của tam giác

- `triangle-centroid(a, b, c)` — trọng tâm.
- `triangle-circumcenter(a, b, c)` — tâm ngoại tiếp.
- `triangle-incenter(a, b, c)` — tâm nội tiếp.
- `triangle-orthocenter(a, b, c)` — trực tâm.
- `triangle-incircle(a, b, c)` — dữ liệu đường tròn nội tiếp.
- `triangle-circumcircle(a, b, c)` — dữ liệu đường tròn ngoại tiếp.
- `barycentric(a, b, c, weights)` — điểm theo tọa độ barycentric.

### 4.6. Đa giác và lấy mẫu hàm

- `regular-polygon-points(n, center:, radius:, start-angle:)` — danh sách đỉnh đa giác đều.
- `polygon-centroid(points)` — trọng tâm đa giác.
- `sample-function(f, domain:, samples:)` — lấy mẫu đồ thị hàm.
- `arc-start(center, radius, angle)` — chuyển tâm, bán kính, góc thành điểm đầu cung theo quy tắc CeTZ.

---

## 5. `styles` — hệ theme và tùy chỉnh tập trung

File: `src/styles.typ`

### 5.1. Palette có sẵn

- `ink`
- `muted`
- `blue`
- `red`
- `green`
- `orange`
- `violet`
- `cyan`
- `yellow`
- `paper`
- `grid`

### 5.2. Theme có sẵn

```typ
#theme()
#theme("blue")
#theme("red")
#theme("green")
#theme("orange")
#theme("minimal")
```

### 5.3. Các khóa style có thể ghi đè

- `stroke`
- `strong-stroke`
- `auxiliary-stroke`
- `hidden-stroke`
- `construction-stroke`
- `point-radius`
- `point-fill`
- `point-stroke`
- `label-fill`
- `label-size`
- `angle-radius`
- `mark-size`
- `fill`
- `accent`
- `secondary`
- `tertiary`
- `axis-stroke`
- `grid-stroke`
- `edge-stroke`
- `node-shape`
- `node-fill`
- `node-stroke`
- `node-padding`

### 5.4. API style

- `theme(name: "default", overrides: (:))`
- `get(style, key, fallback: none)`
- `stroke-with(style, paint:, thickness:, dash:)`

### 5.5. Ví dụ theme riêng

```typ
#let exam-style = theme("green", overrides: (
  stroke: (paint: rgb("20252B"), thickness: 1pt),
  strong-stroke: (paint: rgb("111111"), thickness: 1.35pt),
  auxiliary-stroke: (
    paint: rgb("667085"),
    thickness: 0.6pt,
    dash: "dashed",
  ),
  point-radius: 0.065,
  point-fill: white,
  label-size: 10pt,
  fill: rgb("D1FADF").transparentize(35%),
))
```

---

## 6. `primitives` — các primitive vẽ cơ bản

File: `src/primitives.typ`

Các hàm này được dùng bên trong `cetz.canvas`:

- `draw-point` — vẽ điểm và nhãn.
- `draw-points` — vẽ nhiều điểm.
- `draw-segment` — vẽ đoạn thẳng.
- `draw-polyline` — vẽ đường gấp khúc.
- `draw-line` — vẽ đường thẳng kéo dài.
- `draw-ray` — vẽ tia có mũi tên.
- `draw-vector` — vẽ vector có nhãn.
- `draw-circle` — vẽ đường tròn.
- `draw-ellipse` — vẽ elip.
- `draw-arc` — vẽ cung tròn theo tâm, bán kính và hai góc.
- `draw-polygon` — vẽ đa giác.
- `draw-regular-polygon` — vẽ đa giác đều.
- `draw-label` — đặt nhãn tại tọa độ.
- `draw-grid` — vẽ lưới tọa độ.
- `draw-axes` — vẽ trục tọa độ có mũi tên, nhãn và vạch chia.

---

## 7. `marks` — dấu hiệu hình học

File: `src/marks.typ`

- `right-angle` — dấu góc vuông.
- `angle-mark` — cung góc thường hoặc góc phản.
- `segment-ticks` — dấu bằng nhau trên đoạn thẳng.
- `parallel-marks` — dấu song song.
- `perpendicular-foot` — chân đường vuông góc, đoạn phụ và dấu góc vuông.

---

# PHẦN II — HÌNH HỌC PHẲNG

## 8. `triangles` — tam giác và các tâm đặc biệt

File: `src/triangles.typ`

### 8.1. Các loại tam giác

- `triangle` — tam giác tổng quát từ ba tọa độ.
- `right-triangle` — tam giác vuông theo hai cạnh góc vuông.
- `equilateral-triangle` — tam giác đều.
- `isosceles-triangle` — tam giác cân.
- `draw-triangle` — hàm vẽ trong canvas hiện tại.

### 8.2. Các tính năng bật bằng `features`

- `"medians"` — ba đường trung tuyến và trọng tâm `G`.
- `"altitudes"` — ba đường cao, chân đường cao, dấu góc vuông và trực tâm `H`.
- `"angle-bisectors"` — ba đường phân giác và tâm nội tiếp `I`.
- `"perpendicular-bisectors"` — ba đường trung trực.
- `"incircle"` — đường tròn nội tiếp.
- `"circumcircle"` — đường tròn ngoại tiếp và tâm `O`.
- `"euler-line"` — đường thẳng Euler qua `O`, `G`, `H`.
- `"nine-point-circle"` — đường tròn chín điểm và tâm `N`.
- `"all"` — bật toàn bộ các nhóm trên.

### 8.3. Ví dụ

```typ
#triangle(
  features: (
    "medians",
    "altitudes",
    "circumcircle",
    "euler-line",
    "nine-point-circle",
  ),
  style: theme("blue"),
)
```

---

## 9. `quadrilaterals` — tứ giác phổ thông

File: `src/quadrilaterals.typ`

- `rectangle` — hình chữ nhật.
- `square` — hình vuông.
- `parallelogram` — hình bình hành.
- `rhombus` — hình thoi.
- `trapezoid` — hình thang.
- `cyclic-quadrilateral` — tứ giác nội tiếp đường tròn.
- `draw-quadrilateral` — vẽ tứ giác từ bốn điểm.

Các hình hỗ trợ tùy trường hợp:

- Nhãn đỉnh.
- Đường chéo.
- Màu tô.
- Theme chung.
- Kích thước bằng `length:`.

---

## 10. `circles` — các cấu hình đường tròn

File: `src/circles.typ`

- `circle-basic` — đường tròn cơ bản, tâm, bán kính và các điểm trên đường tròn.
- `tangent-from-point` — hai tiếp tuyến từ một điểm ngoài đến đường tròn.
- `intersecting-chords` — hai dây cung cắt nhau.
- `inscribed-angle` — góc nội tiếp và cung liên quan.

---

## 11. `polygons` — đa giác đều và đa giác sao

File: `src/geometry/polygons.typ`

- `regular-polygon` — đa giác đều `n` cạnh.
- `star-polygon` — đa giác sao theo bước `step`.
- `polygon-angle-sum` — chia đa giác thành tam giác để minh họa tổng góc trong.

`regular-polygon` hỗ trợ các chế độ đường chéo:

- `"none"`
- `"all"`
- `"from-first"`
- `"star"`

Ngoài ra còn có:

- Dấu bằng nhau trên các cạnh.
- Tâm `O`.
- Nhãn đỉnh.
- Màu tô.
- Tâm, bán kính và góc bắt đầu tùy chỉnh.

---

## 12. `constructions` — phép dựng hình và phép biến hình

File: `src/geometry/constructions.typ`

- `perpendicular-bisector` — dựng đường trung trực bằng hai cung tròn.
- `angle-bisector` — dựng đường phân giác của một góc.
- `reflection-across-line` — minh họa đối xứng điểm qua đường thẳng.
- `homothety-figure` — minh họa phép vị tự.
- `circle-through-three-points` — dựng đường tròn đi qua ba điểm.

Các hình dựng có thể hiển thị:

- Đường dựng phụ.
- Giao điểm cung.
- Trung điểm.
- Chân vuông góc.
- Điểm ảnh qua phép biến hình.
- Tâm và bán kính đường tròn ngoại tiếp ba điểm.

---

## 13. `theorems` — hình minh họa định lý phổ thông

File: `src/geometry/theorems.typ`

- `thales-parallel` — cấu hình định lý Thales với đoạn song song.
- `pythagorean-squares` — tam giác vuông và ba hình vuông trên ba cạnh.
- `ceva-configuration` — cấu hình ba đường cevian cho định lý Ceva.
- `menelaus-configuration` — cấu hình đường cắt ba cạnh hoặc phần kéo dài cho định lý Menelaus.
- `power-of-point` — phương tích của điểm với đường tròn.
- `tangent-secant-theorem` — định lý tiếp tuyến–cát tuyến.

---

## 14. `trigonometry` — lượng giác và vector

File: `src/geometry/trigonometry.typ`

- `unit-circle` — đường tròn lượng giác, bán kính quay, hình chiếu lên trục, giá trị sin/cos trực quan.
- `right-triangle-trig` — tam giác vuông và các tỉ số lượng giác.
- `sine-rule-triangle` — tam giác minh họa định lý sin.
- `vector-components` — phân tích vector thành thành phần ngang và dọc.

---

## 15. `conics` — các đường conic

File: `src/conics.typ`

- `draw-curve` — vẽ đường cong theo hàm lấy mẫu.
- `parabola` — parabol có thể bật/tắt trục và lưới.
- `ellipse` — elip có thể hiển thị trục và tiêu điểm.
- `hyperbola` — hypebol có thể hiển thị trục và tiệm cận.

---

# PHẦN III — GIẢI TÍCH, TỌA ĐỘ VÀ MIỀN NGHIỆM

## 16. `graphs` — đồ thị và vùng thủ công

File: `src/graphs.typ`

- `function-plot` — vẽ đồ thị một hàm trên miền xác định.
- `integral-region` — tô miền giữa hai đồ thị trên một khoảng được chỉ định thủ công.
- `linear-programming-region` — minh họa miền quy hoạch tuyến tính theo dữ liệu biên được cung cấp.

Module này phù hợp khi người dùng đã biết sẵn khoảng hoặc đa giác cần tô.

---

## 17. `regions` — tự động tìm giao điểm và cắt nửa mặt phẳng

File: `src/analysis/regions.typ`

### 17.1. Tìm nghiệm số

- `find-roots(f, g:, domain:, samples:, tolerance:)`

Chức năng:

- Lấy mẫu hiệu `f(x) - g(x)`.
- Phát hiện đổi dấu.
- Dùng chia đôi để xấp xỉ nghiệm.
- Loại nghiệm trùng gần nhau.

### 17.2. Miền giữa hai đồ thị

- `integral-regions(...)` — tự tìm giao điểm rồi tô các miền giữa hai đồ thị.
- `draw-integral-region(...)` — phiên bản gọi bên trong `cetz.canvas` để tương thích demo cũ.

### 17.3. Miền nghiệm bất phương trình tuyến tính

- `feasible-polygon(inequalities, x-range:, y-range:)` — cắt một hình chữ nhật ban đầu bằng từng nửa mặt phẳng.
- `lp-region(...)` — vẽ hệ đường biên và tô miền nghiệm.
- `draw-lp-region(...)` — phiên bản gọi bên trong canvas hiện tại.

Định dạng một bất phương trình:

```typ
(a: 1, b: 2, op: "<=", c: 10, stroke: red)
```

Biểu diễn:

```text
a·x + b·y <= c
```

Nếu không ghi `op`, module dùng quy ước nửa mặt phẳng `<=`.

---

## 18. `contacts` — đường tròn tiếp xúc với conic

File: `src/analysis/conic-contact.typ`

### 18.1. Canvas độc lập

- `tangent-parabola`
- `tangent-ellipse`
- `tangent-hyperbola`

### 18.2. Gọi bên trong canvas hiện tại

- `draw-tangent-parabola`
- `draw-tangent-ellipse`
- `draw-tangent-hyperbola`

Module hỗ trợ dữ liệu nhiều đường tròn tiếp xúc, tùy bán kính, vị trí hoặc giá trị tự động theo cấu hình hàm.

---

# PHẦN IV — HÌNH HỌC KHÔNG GIAN

## 19. `solids` — các khối không gian cơ bản

File: `src/solids.typ`

- `cube` — hình lập phương.
- `prism` — lăng trụ đều `n` cạnh.
- `pyramid` — hình chóp đều `n` cạnh đáy.
- `cylinder` — hình trụ.
- `cone` — hình nón.
- `frustum` — hình nón cụt.
- `sphere` — hình cầu.

Các khả năng đã có:

- Chiếu tọa độ 3D xuống mặt phẳng bằng góc `yaw` và `pitch` đối với khối đa diện.
- Nét liền cho cạnh thấy.
- Nét đứt cho cạnh khuất theo cấu hình hiện có.
- Nhãn đỉnh cho lập phương, lăng trụ và hình chóp.
- Đường chéo chọn lọc ở hình lập phương.
- Theme và tỉ lệ chung.

---

## 20. `nets` — hình khai triển cơ bản

File: `src/nets.typ`

- `cube-net` — hình khai triển lập phương.
- `prism-net` — hình khai triển lăng trụ.
- `cylinder-net` — hình khai triển hình trụ.
- `cone-net` — hình khai triển hình nón.

Các hình thể hiện mặt bên và đáy bằng nét, màu tô và kích thước tùy chỉnh.

---

## 21. `unfold` — đường quấn và hình khai triển nâng cao

File: `src/space/unfold.typ`

- `wrapped-cylinder`
- `wrapped-cone`
- `wrapped-frustum`
- `wrapped-prism`
- `wrapped-cube`
- `wrapped-pyramid`

Mỗi hàm có thể hiển thị:

```typ
display: "3d"
display: "2d"
display: "both"
```

### 21.1. Hình trụ

`wrapped-cylinder` có thể:

- Vẽ đường xoắn/quấn quanh mặt trụ.
- Điều chỉnh bán kính, chiều cao, số vòng quấn.
- Hiển thị mặt trụ 3D giả lập.
- Trải mặt bên thành hình chữ nhật.
- Biến đường quấn thành đoạn thẳng trên hình khai triển.

### 21.2. Hình nón

`wrapped-cone` có thể:

- Vẽ đường quấn quanh mặt nón.
- Điều chỉnh bán kính, đường sinh và số vòng.
- Hiển thị mặt nón và hình quạt tròn khi khai triển.
- Chọn vị trí đích trên đường sinh bằng tham số liên quan.

### 21.3. Hình nón cụt

`wrapped-frustum` có thể:

- Vẽ đường quấn trên mặt nón cụt.
- Điều chỉnh hai bán kính và đường sinh.
- Hiển thị hình vành khăn quạt khi khai triển.
- Hỗ trợ kiểu đường đi theo tham số `path-style`.

### 21.4. Lăng trụ

`wrapped-prism` có thể:

- Chọn số mặt bên.
- Điều chỉnh cạnh đáy và chiều cao.
- Điều chỉnh số vòng quấn.
- Chọn cao độ bắt đầu và kết thúc.
- Trải mặt bên thành dải các hình chữ nhật.

### 21.5. Lập phương

`wrapped-cube` là trường hợp chuyên biệt của lăng trụ vuông, có thêm các tham số tương thích với demo cũ như:

- `m-at-bottom`
- `path-type`
- `z-start`
- `z-end`

### 21.6. Hình chóp

`wrapped-pyramid` có thể:

- Chọn số cạnh đáy.
- Điều chỉnh cạnh đáy và cạnh bên.
- Điều chỉnh đường đi trên các mặt tam giác.
- Hiển thị hình chóp 3D và dải mặt bên khai triển.

### 21.7. Ví dụ

```typ
#wrapped-cylinder(
  r: 1,
  h: 4,
  wrap: 2,
  display: "both",
  style: theme("red"),
)
```

---

## 22. `sections` — khối có thiết diện biến thiên theo hàm

File: `src/space/sections.typ`

### 22.1. API chính

```typ
#solid-section(
  kind: "circle",
  axis: "y",
  f: y => 1 + y / 4,
  domain: (0, 4),
)
```

### 22.2. Loại thiết diện hỗ trợ

- `"circle"`
- `"semi-circle"`
- `"triangle"`
- `"square"`
- `"pentagon"`
- `"hexagon"`

### 22.3. Khả năng tùy chỉnh

- `axis:` — trục biến thiên `"x"` hoặc `"y"`.
- `f:` — hàm kích thước ngoài.
- `f2:` — hàm kích thước trong để tạo dạng rỗng.
- `domain:` — miền biến thiên.
- `slices:` — vị trí các lát cắt cần nhấn mạnh.
- `value-type:` — diễn giải giá trị là bán kính hoặc loại kích thước khác theo module.
- `anchor:` — cách neo thiết diện.
- `rotation:` — quay đa giác thiết diện.
- `depth:` — độ dẹt giả lập chiều sâu.
- `caps:` — bật/tắt hai mặt đầu.
- `style:` — theme.
- `length:` — tỉ lệ.

### 22.4. Wrapper tương thích

- `draw-solid-section(type:, ..., theme:, size-scale:)`

Wrapper này chuyển tên đối số kiểu cũ sang API mới.

---

# PHẦN V — XÁC SUẤT VÀ SƠ ĐỒ

## 23. `probability` — cây xác suất

File: `src/probability.typ`

### 23.1. Hàm chính

- `probability-tree`
- `prob-tree` — wrapper tương thích demo cũ.

### 23.2. Hai dạng dữ liệu đầu vào

#### Dạng dictionary

```typ
(
  label: [A],
  edge: $0.4$,
  style: (:),
  children: (...),
)
```

#### Dạng tuple rút gọn

```typ
(
  [Gốc],
  ([A], "0.4", ([A_1], "0.3"), ([A_2], "0.7")),
  ([B], "0.6", ([B_1], "0.2"), ([B_2], "0.8")),
)
```

### 23.3. Khả năng tùy chỉnh

- `dir: "right"` — cây ngang.
- `dir: "down"` — cây dọc.
- `level-step` — khoảng cách tầng.
- `node-step` — khoảng cách lá.
- `path-type: "straight"` — cạnh thẳng.
- `path-type: "orthogonal"` — cạnh gấp vuông góc.
- `angled-labels` — xoay nhãn cạnh theo góc cạnh.
- Style riêng từng node.
- Style riêng từng cạnh.
- Hình node: chữ nhật, tròn, hoặc không khung theo cấu hình style.
- Mũi tên ở cuối cạnh.

---

## 24. `probability` — biểu đồ Venn

Các hàm:

- `venn`
- `venn-diagram` — wrapper tương thích.

Hỗ trợ:

- Venn 2 tập.
- Venn 3 tập.
- Venn 4 tập bằng bốn elip xoay.
- Nhãn tên tập.
- Điền giá trị vào các vùng giao.
- Khung tập vũ trụ bằng `universe:`.
- Theme và kích thước.

Ví dụ 3 tập:

```typ
#venn-diagram(
  n: 3,
  labels: ("A", "B", "C"),
  values: (
    "A": 4,
    "B": 5,
    "C": 6,
    "AB": 2,
    "AC": 1,
    "BC": 3,
    "ABC": 1,
  ),
  theme: "green",
)
```

---

# PHẦN VI — PRESET VÀ API GỌI NHANH

## 25. `presets` — các hình mẫu dựng sẵn

File: `src/presets.typ`

- `triangle-centers`
- `triangle-euler`
- `right-triangle-basic`
- `right-triangle-trig`
- `square-diagonals`
- `circle-tangents`
- `circle-inscribed-angle`
- `cube-space-diagonal`
- `pyramid-regular`
- `cone-and-net`
- `area-between-curves`
- `auto-area-between-curves`
- `pythagoras`
- `thales`
- `circumcircle-construction`
- `cylinder-shortest-path`

Các preset giúp tạo nhanh một hình hoàn chỉnh mà không cần nhớ nhiều tham số.

---

## 26. Các namespace được export từ `lib.typ`

- `core`
- `styles`
- `primitives`
- `marks`
- `triangles`
- `quadrilaterals`
- `circles`
- `conics`
- `polygons`
- `constructions`
- `trigonometry`
- `theorems`
- `graphs`
- `regions`
- `contacts`
- `probability`
- `solids`
- `nets`
- `unfold`
- `sections`
- `presets`
- `cetz`

Ngoài ra còn export:

```typ
#let version = "0.1.0"
#let name = "typ-euclide"
#let canvas = cetz.canvas
#let draw = cetz.draw
```

---

## 27. Các hàm tiện ích được re-export trực tiếp

### Style

- `theme`
- `palette`

### Tam giác

- `triangle`
- `right-triangle`
- `equilateral-triangle`
- `isosceles-triangle`

### Tứ giác

- `rectangle`
- `square`
- `parallelogram`
- `rhombus`
- `trapezoid`
- `cyclic-quadrilateral`

### Đường tròn và conic

- `circle-basic`
- `tangent-from-point`
- `intersecting-chords`
- `inscribed-angle`
- `parabola`
- `ellipse`
- `hyperbola`

### Đa giác và dựng hình

- `regular-polygon`
- `star-polygon`
- `polygon-angle-sum`
- `perpendicular-bisector`
- `angle-bisector`
- `reflection-across-line`
- `homothety-figure`
- `circle-through-three-points`

### Lượng giác và định lý

- `unit-circle`
- `right-triangle-trig`
- `sine-rule-triangle`
- `vector-components`
- `thales-parallel`
- `pythagorean-squares`
- `ceva-configuration`
- `menelaus-configuration`
- `power-of-point`
- `tangent-secant-theorem`

### Đồ thị, miền nghiệm và tiếp xúc conic

- `function-plot`
- `integral-region`
- `linear-programming-region`
- `find-roots`
- `integral-regions`
- `feasible-polygon`
- `lp-region`
- `draw-integral-region`
- `draw-lp-region`
- `tangent-parabola`
- `tangent-ellipse`
- `tangent-hyperbola`
- `draw-tangent-parabola`
- `draw-tangent-ellipse`
- `draw-tangent-hyperbola`

### Xác suất

- `probability-tree`
- `prob-tree`
- `venn`
- `venn-diagram`

### Hình không gian

- `cube`
- `prism`
- `pyramid`
- `cylinder`
- `cone`
- `frustum`
- `sphere`
- `cube-net`
- `prism-net`
- `cylinder-net`
- `cone-net`
- `wrapped-cone`
- `wrapped-frustum`
- `wrapped-cylinder`
- `wrapped-prism`
- `wrapped-cube`
- `wrapped-pyramid`
- `solid-section`
- `draw-solid-section`

---

# PHẦN VII — TƯƠNG THÍCH VỚI `demo.typ`

## 28. Các file shim ở thư mục gốc

### `unfold.typ`

Cung cấp API tên ngắn theo demo cũ:

- `cone`
- `frustum`
- `cylinder`
- `prism`
- `cube`
- `pyramid`

Wrapper này chuyển các đối số có dấu gạch dưới như:

- `vis_r`
- `vis_h`
- `z_start`
- `z_end`
- `m_at_bottom`
- `path_type`

sang API namespace mới dùng dấu gạch nối.

### `tree.typ`

Export:

- `probability-tree`
- `prob-tree`

### `venn.typ`

Export:

- `venn`
- `venn-diagram`

### `solid-section.typ`

Export:

- `solid-section`
- `draw-solid-section`

### `conic-tangent.typ`

Export:

- `tangent-parabola`
- `tangent-ellipse`
- `tangent-hyperbola`
- `draw-tangent-parabola`
- `draw-tangent-ellipse`
- `draw-tangent-hyperbola`

### `legacy/demo-original.typ`

Lưu lại nguyên file demo ban đầu để đối chiếu và phát triển tương thích về sau.

---

# PHẦN VIII — VÍ DỤ VÀ KIỂM THỬ

## 29. `examples/gallery.typ`

Gallery hiện minh họa các nhóm:

1. Tam giác và tâm đặc biệt.
2. Pythagore, Thales, Ceva, tiếp tuyến–cát tuyến.
3. Đa giác, trung trực, đối xứng, vị tự.
4. Đường tròn lượng giác, tam giác lượng giác, định lý sin, vector.
5. Tiếp tuyến đường tròn, góc nội tiếp, parabol, tiếp xúc parabol.
6. Lập phương, chóp, trụ, nón, nón cụt, cầu.
7. Khai triển và đường quấn trên trụ, nón, chóp.
8. Thiết diện tròn và lục giác biến thiên.
9. Cây xác suất và Venn 4 tập.
10. Miền tích phân và miền nghiệm tuyến tính.

---

## 30. `examples/legacy-compat.typ`

File này kiểm tra kiểu gọi cũ:

- Hình trụ và hình nón bằng `unfold.typ`.
- Cây xác suất bằng `tree.typ`.
- Venn bằng `venn.typ`.
- Thiết diện bằng `solid-section.typ`.
- Tiếp xúc parabol trong một canvas CeTZ.
- Miền tích phân trong một canvas CeTZ.
- Miền nghiệm tuyến tính trong một canvas CeTZ.

---

## 31. `tests/smoke.typ`

Smoke test khởi tạo ít nhất một hình thuộc các nhóm chính:

- Tam giác vuông.
- Hình vuông.
- Tiếp tuyến đường tròn.
- Đa giác đều.
- Thales.
- Pythagore.
- Đường tròn lượng giác.
- Trung trực.
- Parabol.
- Tiếp xúc parabol.
- Lập phương.
- Hình khai triển nón.
- Đường quấn trên trụ.
- Thiết diện.
- Venn 3 tập.
- Miền giữa hai đồ thị.
- Miền nghiệm tuyến tính.

---

## 32. `scripts/check_package.py`

Script kiểm tra:

1. Cân bằng các dấu `()`, `[]`, `{}` trong file Typst.
2. Bỏ qua ký tự trong chuỗi và comment khi kiểm tra ngoặc.
3. Kiểm tra mọi đường dẫn `#import "..."` cục bộ có tồn tại.
4. Bỏ qua thư mục `legacy/` trong kiểm tra package chính.
5. Khi có Typst CLI, tự biên dịch:
   - `tests/smoke.typ`
   - `examples/legacy-compat.typ`

Lệnh chạy:

```bash
python scripts/check_package.py
```

Kết quả trong môi trường hiện tại:

```text
Static checks passed for 30 Typst files.
Typst CLI not found; skipped compilation.
```

---

# PHẦN IX — CÁC FILE TÀI LIỆU ĐÃ CÓ

## 33. `README.md`

- Giới thiệu nhanh package.
- Cách cài và import.
- Ví dụ bắt đầu nhanh.
- Bảng namespace.
- Ví dụ theme.
- API tương thích demo cũ.
- Trạng thái 0.1.0.

## 34. `API.md`

- Danh mục API cô đọng theo namespace.
- Tên các hàm public chính.
- Các dạng tham số quan trọng.

## 35. `ARCHITECTURE.md`

- Hướng phụ thuộc module.
- Chính sách API public.
- Quy ước style.
- Các lớp kiểm thử nên có.

## 36. `CHANGELOG.md`

- Ghi nhận toàn bộ nhóm chức năng được thêm trong 0.1.0.

## 37. `VALIDATION.md`

- Mô tả script kiểm tra.
- Ghi rõ kiểm tra tĩnh đã đạt.
- Ghi rõ Typst CLI chưa có trong môi trường tạo package.

## 38. `LICENSE`

- Giấy phép MIT.

---

# PHẦN X — NHỮNG GÌ ĐÃ HOÀN THÀNH VÀ NHỮNG GÌ CHƯA XÁC NHẬN

## 39. Đã hoàn thành trong mã nguồn

- Kiến trúc package phân module.
- Lõi toán hình học 2D.
- Giao điểm đường–đường, đoạn–đoạn, đường–tròn, tròn–tròn.
- Tâm tam giác và các đường tròn liên quan.
- Hệ theme chung.
- Primitive và dấu hình học.
- Nhiều hình tam giác, tứ giác, đường tròn, đa giác và conic.
- Phép dựng và phép biến hình cơ bản.
- Sáu hình định lý phổ thông.
- Lượng giác và vector.
- Đồ thị và miền giữa hai đồ thị.
- Tìm nghiệm số bằng lấy mẫu và chia đôi.
- Miền nghiệm tuyến tính bằng cắt đa giác.
- Tiếp xúc đường tròn với parabol, elip, hypebol theo API hiện có.
- Bảy loại khối cơ bản.
- Bốn loại hình khai triển cơ bản.
- Sáu nhóm đường quấn và khai triển nâng cao.
- Sáu loại thiết diện biến thiên.
- Cây xác suất đệ quy.
- Venn 2, 3, 4 tập.
- Preset gọi nhanh.
- Lớp tương thích với demo ban đầu.
- Gallery, smoke test và script kiểm tra tĩnh.

## 40. Đã xác nhận bằng kiểm tra tĩnh

- 30 file Typst ngoài `legacy/` có ngoặc cân bằng theo script.
- Các import cục bộ được script kiểm tra đều tồn tại.
- Cấu trúc ZIP và đường dẫn file đầy đủ.
- Các helper cung tròn đã dùng quy tắc điểm bắt đầu của CeTZ 0.5.2.

## 41. Chưa được xác nhận trong môi trường tạo package

- Chưa chạy `typst compile` thật vì không có Typst CLI.
- Chưa có visual regression bằng ảnh/PDF chuẩn.
- Chưa kiểm tra chống va chạm nhãn tự động.
- Chưa có solver hình học ký hiệu tổng quát kiểu TikZ-Euclide đầy đủ.
- Chưa có phân loại cạnh khuất tự động tổng quát cho mọi góc nhìn 3D.
- Chưa có kiểm thử số riêng cho từng trường hợp suy biến.
- Chưa đảm bảo mọi cấu hình tham số cực trị đều render đẹp.

Do đó, trước khi gửi lên Typst Universe, cần chạy:

```bash
python scripts/check_package.py
typst compile tests/smoke.typ build/smoke.pdf
typst compile examples/gallery.typ build/gallery.pdf
typst compile examples/legacy-compat.typ build/legacy-compat.pdf
```

Sau đó phải xem trực tiếp PDF của gallery để phát hiện lỗi bố cục, nhãn chồng nhau hoặc nét khuất chưa hợp lý.

---

# PHẦN XI — VÍ DỤ TỔNG HỢP

```typ
#import "lib.typ": *

#set page(paper: "a4", margin: 1.2cm)
#set text(size: 10pt)

#let my-style = theme("blue", overrides: (
  label-size: 10pt,
  point-radius: 0.065,
  fill: rgb("DDEBFF").transparentize(30%),
))

= Tam giác và đường Euler

#triangle(
  features: (
    "medians",
    "altitudes",
    "circumcircle",
    "euler-line",
    "nine-point-circle",
  ),
  style: my-style,
)

= Định lý Pythagore

#pythagorean-squares(
  adjacent: 4,
  opposite: 3,
  style: theme("green"),
)

= Đường quấn trên hình trụ

#wrapped-cylinder(
  r: 1,
  h: 4,
  wrap: 2,
  display: "both",
  style: theme("red"),
)

= Miền giữa hai đồ thị

#integral-regions(
  x => x * x - 2,
  g: x => x,
  domain: (-2.5, 3),
  y-range: (-3, 7),
  style: theme("orange"),
)

= Cây xác suất

#prob-tree(
  (
    [Gốc],
    ([A], "0.4", ([A_1], "0.3"), ([A_2], "0.7")),
    ([B], "0.6", ([B_1], "0.2"), ([B_2], "0.8")),
  ),
  theme: "blue",
  angled-labels: true,
)
```

---

# Kết luận

Bản `typ-euclide` 0.1.0 trong ZIP hiện tại đã là một **khung package lớn và phân cấp**, không chỉ là một file demo. Nó đã bao phủ nhiều nhóm hình Toán phổ thông, có lõi tính toán, hệ theme, API cấp thấp và cấp cao, module hình phẳng, không gian, giải tích, xác suất, lớp tương thích, gallery và kiểm thử tĩnh.

Tuy vậy, đây vẫn là bản nền 0.1.0. Bước quan trọng tiếp theo là biên dịch toàn bộ bằng Typst CLI, xem gallery thực tế, sửa lỗi render, bổ sung kiểm thử hình học và chỉ sau đó mới mở rộng tiếp thành một thư viện có độ tin cậy gần với TikZ-Euclide.
