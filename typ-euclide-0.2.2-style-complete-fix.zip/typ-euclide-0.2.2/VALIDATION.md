# Validation report — typ-euclide 0.2.1

## Static validation performed

Run:

```bash
python scripts/check_package.py
```

The generated release passed static checks for **50 Typst files outside `legacy/`**. The checker verifies:

- balanced parentheses, brackets, and braces;
- existence of every local import target;
- repeated top-level library definitions;
- simple explicit local-import symbol existence.

The supplied `lp-region(1).typ` was compared with the integrated `lp-region.typ`; the integrated copy preserves the full implementation and adds metadata-preserving normalization, equality support, safer stroke-paint extraction, and the standalone wrapper.

## Numeric/code audit performed

- Corrected signed-angle calculation to respect Typst's `calc.atan2(x, y)` parameter order.
- Reviewed line, circle-line, circle-circle, tangent, triangle-center, radical-axis, inversion, and polygon-centroid formulas.
- Added `tests/euclid-analytic.typ` for distances, signed angles, right-triangle centers, tangent orthogonality, model querying, aliases, point options, and vertical-major ellipses.
- Added `tests/euclid-model-smoke.typ` for extensible figures and renderer usage.

## Compilation status

A Typst executable was not available in the build environment, and the environment could not download one. Therefore no claim is made that the final package or gallery was compiled here.

When Typst CLI is available, the validation script compiles:

```text
tests/smoke.typ
examples/legacy-compat.typ
tests/demo-modules-smoke.typ
examples/demo-full.typ
tests/euclid-model-smoke.typ
tests/euclid-analytic.typ
examples/advanced-model.typ
hdsd-euclide.typ
```

The files under `docs/previews/` are independent reference compositions, not Typst/CeTZ screenshots. Compile `hdsd-euclide.typ` to obtain the real package-rendered code-and-result gallery.
