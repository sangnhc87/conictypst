# Reference previews

These PNG files are geometry previews generated independently to show the intended composition of the named-model API. They are **not claimed to be Typst/CeTZ render captures** because a Typst compiler was unavailable in the build environment.

Compile `../../hdsd-euclide.typ` to obtain the actual package-rendered gallery.
