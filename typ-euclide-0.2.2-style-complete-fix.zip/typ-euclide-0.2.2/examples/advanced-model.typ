#import "../lib.typ": euclid

#set page(width: 18cm, height: auto, margin: 1cm)
#set text(size: 10pt)

= Named model and extension

#let fig = euclid.triangle(
  A: (-2.6, -1.2),
  B: (2.6, -1.2),
  C: (0.5, 2.6),
  features: ("vertices", "circumcircle", "incircle", "centers"),
)

#let fig = euclid.construct.midpoint(fig, "D", "B", "C")
#let fig = euclid.construct.projection(fig, "E", "D", "A", "B")
#let fig = euclid.with-objects(fig, (
  euclid.segment("A", "D", id: "ad", role: "accent"),
  euclid.segment("D", "E", id: "de", role: "secondary"),
  euclid.circle-through("D", "E", id: "circle-de", role: "tertiary"),
))

#assert(euclid.validate(fig).len() == 0)
#euclid.render-model(fig, style: euclid.euclid-theme("blue"), length: 1cm)

= Patch by id and tag

#let euler = euclid.templates.euler-triangle()
#let euler = euclid.hide-object(euler, "circumcircle")
#let euler = euclid.patch-tag(euler, "altitudes", (role: "accent"))
#euclid.render-model(euler, style: euclid.euclid-theme("green"), length: 0.9cm)
