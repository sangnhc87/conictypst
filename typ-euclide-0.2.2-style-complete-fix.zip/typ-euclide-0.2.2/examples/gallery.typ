#import "../lib.typ": *

#set page(paper: "a4", margin: 1.3cm)
#set text(font: "New Computer Modern", size: 9.5pt, lang: "vi")
#set heading(numbering: "1.1")

= typ-euclide — Gallery 0.2.1

== Tam giác và tâm đặc biệt
#grid(columns: (1fr, 1fr), gutter: 0.8cm,
  triangle(features: ("medians", "circumcircle"), style: theme("blue"), length: 0.78cm),
  triangle(features: ("all",), style: theme("green"), length: 0.68cm),
)

== Định lý phổ thông
#grid(columns: (1fr, 1fr), gutter: 0.8cm,
  pythagorean-squares(style: theme("blue"), length: 0.55cm),
  thales-parallel(style: theme("green"), length: 0.75cm),
  ceva-configuration(style: theme("orange"), length: 0.72cm),
  tangent-secant-theorem(style: theme("red"), length: 0.72cm),
)

== Đa giác, dựng hình và phép biến hình
#grid(columns: (1fr, 1fr), gutter: 0.8cm,
  regular-polygon(n: 6, diagonals: "from-first", style: theme("orange"), length: 0.7cm),
  perpendicular-bisector(style: theme("blue"), length: 0.7cm),
  reflection-across-line(style: theme("green"), length: 0.7cm),
  homothety-figure(style: theme("red"), length: 0.7cm),
)

== Lượng giác và vector
#grid(columns: (1fr, 1fr), gutter: 0.8cm,
  unit-circle(angle: 35deg, style: theme("blue"), length: 0.65cm),
  right-triangle-trig(adjacent: 4, opposite: 3, style: theme("green"), length: 0.68cm),
  sine-rule-triangle(style: theme("orange"), length: 0.7cm),
  vector-components(vector: (3.5, 2.2), style: theme("red"), length: 0.65cm),
)

== Đường tròn và conic
#grid(columns: (1fr, 1fr), gutter: 0.8cm,
  tangent-from-point(style: theme("orange"), length: 0.72cm),
  inscribed-angle(style: theme("green"), length: 0.72cm),
  parabola(style: theme("blue"), length: 0.55cm),
  tangent-parabola(
    circles: ((R: 1, y: "auto", name: $O$),),
    style: theme("red"), length: 0.55cm,
  ),
)

== Hình không gian cơ bản
#grid(columns: (1fr, 1fr, 1fr), gutter: 0.55cm,
  cube(diagonals: ((0, 6),), style: theme("blue"), length: 0.55cm),
  pyramid(n: 4, style: theme("orange"), length: 0.55cm),
  cylinder(style: theme("green"), length: 0.55cm),
  cone(style: theme("red"), length: 0.55cm),
  frustum(style: theme("blue"), length: 0.55cm),
  sphere(style: theme("orange"), length: 0.55cm),
)

== Khai triển và đường quấn
#wrapped-cylinder(r: 1, h: 4, wrap: 2, style: theme("red"), scale: 0.42cm, gap: 0.8cm)
#v(0.8cm)
#wrapped-cone(r: 1, l: 5, wrap: 2, to: 2, style: theme("blue"), scale: 0.42cm, gap: 0.8cm)
#v(0.8cm)
#wrapped-pyramid(n: 4, a: 1.8, e: 3, wrap: 1, sm: 2.4, sm2: 2.4, style: theme("green"), scale: 0.48cm, gap: 0.8cm)

== Thiết diện biến thiên
#grid(columns: (1fr, 1fr), gutter: 0.8cm,
  solid-section(
    kind: "circle", axis: "y",
    f: y => 1.2 + 0.25 * y,
    f2: y => 0.7 + 0.18 * y,
    domain: (0, 5), slices: (1, 2.5, 4),
    style: theme("blue"), length: 0.55cm,
  ),
  solid-section(
    kind: "hexagon", axis: "y",
    f: y => 2.2 * calc.sin(y * 45deg),
    domain: (0, 4), slices: (1, 2, 3), caps: false,
    style: theme("orange"), length: 0.62cm,
  ),
)

== Cây xác suất và Venn
#let data = (
  [Khởi đầu],
  ([A], "0.4", ([A_1], "0.3"), ([A_2], "0.7")),
  ([B], "0.6", ([B_1], "0.2"), ([B_2], "0.8")),
)
#grid(columns: (1fr, 1fr), gutter: 0.8cm,
  prob-tree(data, theme: "blue", angled-labels: true, scale: 0.75cm),
  venn-diagram(n: 4, labels: ("A", "B", "C", "D"), values: ("ABCD": [all]), theme: "green", size-scale: 0.9),
)

== Miền tích phân và miền nghiệm
#grid(columns: (1fr, 1fr), gutter: 0.8cm,
  integral-regions(
    x => x * x - 2,
    g: x => x,
    domain: (-2.5, 3), y-range: (-3, 7),
    style: theme("blue"), length: 0.48cm,
  ),
  lp-region(
    (
      (a: 1, b: 2, c: 10),
      (a: 2, b: 1, c: 8),
      (a: -1, b: 0, c: 0),
      (a: 0, b: -1, c: 0),
    ),
    x-range: (-1, 7), y-range: (-1, 7),
    style: theme("green"), length: 0.48cm,
  ),
)
