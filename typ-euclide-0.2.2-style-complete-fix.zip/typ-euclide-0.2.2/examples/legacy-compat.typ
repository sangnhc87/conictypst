#import "@preview/cetz:0.5.2" as cetz
#import "../unfold.typ": *
#import "../tree.typ": *
#import "../venn.typ": *
#import "../solid-section.typ": *
#import "../conic-tangent.typ": *
#import "../src/analysis/regions.typ": draw-integral-region, draw-lp-region

#set page(width: auto, height: auto, margin: 8pt)

#grid(columns: (1fr, 1fr), gutter: 1cm,
  cylinder(r: 1, h: 4, vis_r: 1.5, vis_h: 4, wrap: 2, display: "both", scale: 0.45cm),
  cone(r: 1, l: 5, vis_r: 2, vis_h: 4.5, wrap: 2, display: "both", scale: 0.42cm),
)

#let tree-data = ([Gốc], ([A], "0.4", ([A1], "0.3")), ([B], "0.6", ([B1], "0.7")))
#prob-tree(tree-data, theme: "blue", scale: 0.75cm)
#venn-diagram(n: 3, labels: ("A", "B", "C"), values: ("ABC": 1), theme: "green")

#draw-solid-section(
  type: "circle", axis: "y",
  f: y => 1 + 0.3 * y,
  f2: y => 0.55 + 0.18 * y,
  domain: (0, 4), slices: (1, 2, 3), theme: "orange", size-scale: 0.6,
)

#cetz.canvas({
  import cetz.draw: *
  draw-tangent-parabola(
    a: 1, domain: (-1.8, 1.8), axes-range: ((-2, 2), (-0.5, 3.5)),
    circles: ((R: 1, y: "auto", name: $O$),),
  )
})

#cetz.canvas({
  import cetz.draw: *
  draw-integral-region(x => x * x - 2, x => x, domain: (-2.5, 3))
})

#cetz.canvas({
  import cetz.draw: *
  draw-lp-region((
    (a: 1, b: 2, c: 10),
    (a: 2, b: 1, c: 8),
    (a: -1, b: 0, c: 0),
    (a: 0, b: -1, c: 0),
  ))
})
