#import "lib.typ": euclid, linear-programming
#import "@preview/cetz:0.5.2" as cetz

#set page(
  paper: "a4",
  margin: (x: 1.6cm, y: 1.4cm),
  numbering: "1",
)
#set text(font: "New Computer Modern", size: 10pt, lang: "vi")
#set heading(numbering: "1.1")
#set par(justify: true, leading: 0.65em)

#let title-color = rgb("174EA6")
#let note-color = rgb("E8F0FE")
#let demo-card(body) = block(
  width: 100%,
  inset: 10pt,
  radius: 5pt,
  fill: rgb("F8FAFD"),
  stroke: (paint: rgb("D0D7E2"), thickness: 0.6pt),
  body,
)
#let result-card(body) = align(center, block(
  inset: 12pt,
  radius: 5pt,
  fill: white,
  stroke: (paint: rgb("D0D7E2"), thickness: 0.6pt),
  body,
))

#align(center)[
  #text(size: 23pt, weight: "bold", fill: title-color)[HƯỚNG DẪN `typ-euclide` 0.2.1]
  #v(4pt)
  #text(size: 12pt)[Hình học Euclid theo mô hình điểm có tên — dễ mở rộng, tái sử dụng và tùy biến]
]

#v(10pt)
#block(fill: note-color, inset: 10pt, radius: 5pt)[
  *Ý tưởng chính:* mỗi hình là một _model_ chứa `points`, `objects`, `point-options` và `meta`.
  Hình mẫu không bị đóng cứng. Có thể lấy lại điểm bằng tên, dựng thêm điểm mới, thêm đường,
  đổi kiểu nét hoặc ẩn từng đối tượng rồi mới render.
]

= 1. Khởi động nhanh

```typ
#import "@preview/typ-euclide:0.2.1": euclid

#let fig = euclid.triangle(
  A: (-2.3, -1.2),
  B: (2.4, -1.2),
  C: (0.4, 2.3),
  features: (
    "vertices", "medians", "altitudes",
    "circumcircle", "incircle", "centers",
  ),
)

#euclid.render-model(fig)
```

#let quick = euclid.triangle(
  A: (-2.3, -1.2), B: (2.4, -1.2), C: (0.4, 2.3),
  features: ("vertices", "medians", "altitudes", "circumcircle", "incircle", "centers"),
)
#result-card(euclid.render-model(quick, style: euclid.euclid-theme("blue"), length: 0.82cm))

= 2. Lấy điểm theo tên và tiếp tục vẽ

Các điểm dẫn xuất như `G`, `H`, `O`, `I`, `M_a`, `H_a`, `T_a` đã nằm trong model.
Không cần đoán tọa độ từ một hình hardcode.

```typ
#let base = euclid.triangle(
  features: ("vertices", "circumcircle", "centers"),
)

// Lấy tọa độ đã tính sẵn.
#let H = euclid.point-at(base, "H")
#let O = euclid.point-at(base, "O")

// Dựng thêm D là trung điểm BC.
#let extended = euclid.construct.midpoint(
  base, "D", "B", "C",
  show: true,
)

// Thêm đường AD và đường HO.
#let extended = euclid.with-objects(extended, (
  euclid.segment("A", "D", role: "accent"),
  euclid.line("H", "O", role: "tertiary", extend: 1.2),
))

#euclid.render-model(extended)
```

#let extend-demo = euclid.triangle(features: ("vertices", "circumcircle", "centers"))
#let extend-demo = euclid.construct.midpoint(extend-demo, "D", "B", "C", show: true)
#let extend-demo = euclid.with-objects(extend-demo, (
  euclid.segment("A", "D", id: "new-median", role: "accent"),
  euclid.line("H", "O", id: "new-ho", role: "tertiary", extend: 1.2),
))
#result-card(euclid.render-model(extend-demo, style: euclid.euclid-theme("green"), length: 0.9cm))

= 3. Hệ thống feature của tam giác

Các feature chính:

- `vertices`, `midpoints`, `feet`, `contact-points`, `centers`
- `medians`, `altitudes`, `angle-bisectors`, `perpendicular-bisectors`
- `incircle`, `circumcircle`, `nine-point-circle`, `excircles`
- `euler-line`, `medial-triangle`, `orthic-triangle`, `contact-triangle`, `excentral-triangle`
- `all` để bật toàn bộ tính năng

```typ
#let fig = euclid.triangle(
  A: (-2.7, -1.2),
  B: (2.5, -1.1),
  C: (0.7, 2.6),
  features: (
    "vertices", "midpoints", "feet",
    "medial-triangle", "orthic-triangle",
    "contact-triangle", "incircle",
    "circumcircle", "nine-point-circle",
    "euler-line", "centers",
  ),
)
#euclid.render-model(fig)
```

#let tri-rich = euclid.triangle(
  A: (-2.7, -1.2), B: (2.5, -1.1), C: (0.7, 2.6),
  features: ("vertices", "midpoints", "feet", "medial-triangle", "orthic-triangle", "contact-triangle", "incircle", "circumcircle", "nine-point-circle", "euler-line", "centers"),
)
#result-card(euclid.render-model(tri-rich, style: euclid.euclid-theme("orange"), length: 0.73cm))

= 4. Dựng hình tuần tự bằng tên điểm

```typ
#let fig = euclid.right-triangle(
  A: (0, 0), B: (4.5, 0), C: (0, 3.2),
  features: ("vertices", "right-angle"),
)

// H_a là hình chiếu của A lên BC.
#let fig = euclid.construct.projection(
  fig, "H_a", "A", "B", "C",
)

// M là trung điểm AH_a.
#let fig = euclid.construct.midpoint(
  fig, "M", "A", "H_a",
)

// P là ảnh của M qua đường AC.
#let fig = euclid.construct.reflection(
  fig, "P", "M", "A", "C",
)

#let fig = euclid.with-objects(fig, (
  euclid.segment("M", "P", role: "accent"),
  euclid.circle-through("M", "P", role: "secondary"),
))
#euclid.render-model(fig)
```

#let build = euclid.right-triangle(A: (0, 0), B: (4.5, 0), C: (0, 3.2), features: ("vertices", "right-angle"))
#let build = euclid.construct.projection(build, "H_a", "A", "B", "C")
#let build = euclid.construct.midpoint(build, "M", "A", "H_a")
#let build = euclid.construct.reflection(build, "P", "M", "A", "C")
#let build = euclid.with-objects(build, (
  euclid.segment("M", "P", role: "accent"),
  euclid.circle-through("M", "P", role: "secondary"),
))
#result-card(euclid.render-model(build, style: euclid.euclid-theme("red"), length: 0.88cm))

= 5. Sửa từng đối tượng theo `id` hoặc `tag`

```typ
#let fig = euclid.templates.euler-triangle()

// Ẩn đường tròn ngoại tiếp.
#let fig = euclid.hide-object(fig, "circumcircle")

// Đổi toàn bộ đối tượng có tag "altitudes" sang vai trò accent.
#let fig = euclid.patch-tag(fig, "altitudes", (role: "accent"))

// Đổi riêng đường Euler.
#let fig = euclid.patch-object(
  fig, "euler-line",
  (stroke: (paint: purple, thickness: 1.4pt)),
)

#euclid.render-model(fig)
```

#let patch-demo = euclid.templates.euler-triangle()
#let patch-demo = euclid.hide-object(patch-demo, "circumcircle")
#let patch-demo = euclid.patch-tag(patch-demo, "altitudes", (role: "accent"))
#let patch-demo = euclid.patch-object(patch-demo, "euler-line", (stroke: (paint: purple, thickness: 1.4pt)))
#result-card(euclid.render-model(patch-demo, style: euclid.euclid-theme("blue"), length: 0.83cm))

= 6. Tùy biến theme phân cấp

```typ
#let exam-theme = euclid.euclid-theme("blue", overrides: (
  accent: rgb("0057B8"),
  secondary: rgb("C62828"),
  tertiary: rgb("2E7D32"),
  strong-stroke: (paint: rgb("202124"), thickness: 1.35pt),
  auxiliary-stroke: (paint: rgb("5F6368"), thickness: 0.65pt, dash: "dashed"),
  point: (
    radius: 0.07,
    fill: white,
    stroke: (paint: rgb("202124"), thickness: 0.9pt),
  ),
  label: (
    size: 10pt,
    offset: (0.15, 0.15),
  ),
  strokes: (
    accent: (paint: rgb("0057B8"), thickness: 1.25pt),
  ),
))

#euclid.render-model(
  euclid.templates.tangent-from-point(),
  style: exam-theme,
)
```

#let exam-theme = euclid.euclid-theme("blue", overrides: (
  accent: rgb("0057B8"), secondary: rgb("C62828"), tertiary: rgb("2E7D32"),
  strong-stroke: (paint: rgb("202124"), thickness: 1.35pt),
  auxiliary-stroke: (paint: rgb("5F6368"), thickness: 0.65pt, dash: "dashed"),
  point: (radius: 0.07, fill: white, stroke: (paint: rgb("202124"), thickness: 0.9pt)),
  label: (size: 10pt, offset: (0.15, 0.15)),
  strokes: (accent: (paint: rgb("0057B8"), thickness: 1.25pt)),
))
#result-card(euclid.render-model(euclid.templates.tangent-from-point(), style: exam-theme, length: 0.84cm))

= 7. Hình tứ giác, đa giác và đường tròn

```typ
#let q = euclid.trapezoid(
  bottom: 5.4,
  top: 2.8,
  height: 2.7,
  offset: 0.6,
  features: ("vertices", "diagonals", "midpoints", "diagonal-intersection"),
  fill-role: "main",
)

#let p = euclid.regular-polygon(
  n: 7,
  radius: 2.4,
  features: ("vertices", "center", "radii", "circumcircle"),
)
```

#grid(columns: (1fr, 1fr), gutter: 12pt,
  result-card(euclid.render-model(
    euclid.trapezoid(bottom: 5.4, top: 2.8, height: 2.7, offset: 0.6, features: ("vertices", "diagonals", "midpoints", "diagonal-intersection"), fill-role: "main"),
    style: euclid.euclid-theme("green"), length: 0.72cm,
  )),
  result-card(euclid.render-model(
    euclid.regular-polygon(n: 7, radius: 2.4, features: ("vertices", "center", "radii", "circumcircle")),
    style: euclid.euclid-theme("orange"), length: 0.72cm,
  )),
)

= 8. Các hình định lý dựng sẵn nhưng vẫn mở rộng được

```typ
#let fig = euclid.templates.thales()
#let fig = euclid.with-object(
  fig,
  euclid.segment("B", "E", role: "tertiary"),
)
#euclid.render-model(fig)
```

#grid(columns: (1fr, 1fr), gutter: 12pt,
  result-card(euclid.render-model(euclid.templates.thales(), style: euclid.euclid-theme("green"), length: 0.72cm)),
  result-card(euclid.render-model(euclid.templates.ceva(), style: euclid.euclid-theme("red"), length: 0.72cm)),
  result-card(euclid.render-model(euclid.templates.perpendicular-bisector(), style: euclid.euclid-theme("blue"), length: 0.72cm)),
  result-card(euclid.render-model(euclid.templates.angle-bisector(), style: euclid.euclid-theme("orange"), length: 0.72cm)),
)

= 9. Phép biến hình

```typ
#let reflected = euclid.templates.reflection()
#let scaled = euclid.templates.homothety(ratio: 1.8)

#euclid.render-model(reflected)
#euclid.render-model(scaled)
```

#grid(columns: (1fr, 1fr), gutter: 12pt,
  result-card(euclid.render-model(euclid.templates.reflection(), style: euclid.euclid-theme("blue"), length: 0.78cm)),
  result-card(euclid.render-model(euclid.templates.homothety(ratio: 1.8), style: euclid.euclid-theme("red"), length: 0.78cm)),
)

= 10. Conic dưới dạng model tái sử dụng

```typ
#let e = euclid.conics.ellipse(
  center: (0, 0),
  a: 3,
  b: 1.8,
  rotation: 15deg,
  features: ("center", "foci", "axes", "vertices"),
)

#let e = euclid.with-object(
  e,
  euclid.segment("F_1", "F_2", role: "accent"),
)
#euclid.render-model(e)
```

#grid(columns: (1fr, 1fr), gutter: 12pt,
  result-card(euclid.render-model(euclid.conics.parabola(p: 0.8, rotation: -12deg), style: euclid.euclid-theme("green"), length: 0.66cm)),
  result-card(euclid.render-model(euclid.conics.ellipse(a: 3, b: 1.8, rotation: 15deg), style: euclid.euclid-theme("blue"), length: 0.66cm)),
  result-card(euclid.render-model(euclid.conics.hyperbola(a: 1.6, b: 1.1, rotation: 8deg), style: euclid.euclid-theme("red"), length: 0.66cm)),
)

= 11. Vẽ tự do bằng object khai báo

```typ
#let free = euclid.empty-model()
#let free = euclid.with-points(free, (
  A: (-2, -1),
  B: (2, -1),
  C: (1.2, 2),
  D: (-1.4, 1.5),
  O: (0, 0),
))
#let free = euclid.with-objects(free, (
  euclid.polygon(("A", "B", "C", "D"), fill-role: "accent"),
  euclid.circle("O", 1.2, role: "secondary"),
  euclid.vector("A", "C", label: $vec(v)$),
  euclid.angle("B", "A", "C", label: $alpha$),
  euclid.point("A"), euclid.point("B"), euclid.point("C"),
  euclid.point("D"), euclid.point("O", role: "accent"),
))
#euclid.render-model(free)
```

#let free = euclid.empty-model()
#let free = euclid.with-points(free, (A: (-2, -1), B: (2, -1), C: (1.2, 2), D: (-1.4, 1.5), O: (0, 0)))
#let free = euclid.with-objects(free, (
  euclid.polygon(("A", "B", "C", "D"), fill-role: "accent"),
  euclid.circle("O", 1.2, role: "secondary"),
  euclid.vector("A", "C", label: $vec(v)$),
  euclid.angle("B", "A", "C", label: $alpha$),
  euclid.point("A"), euclid.point("B"), euclid.point("C"), euclid.point("D"), euclid.point("O", role: "accent"),
))
#result-card(euclid.render-model(free, style: euclid.euclid-theme("orange"), length: 0.9cm))

= 12. Kiểm tra model trước khi render

```typ
#let errors = euclid.validate(fig)
#assert(errors.len() == 0, message: errors.join("; "))
```

`validate` phát hiện object tham chiếu đến tên điểm chưa tồn tại. Đây là lớp kiểm tra quan trọng khi hình lớn được xây qua nhiều bước.

= 13. Danh mục namespace

- `euclid.model`: model, tra cứu điểm, thêm/xóa/sửa object, biến đổi toàn hình.
- `euclid.objects`: point, segment, line, ray, vector, polygon, circle, arc, ellipse, angle, marks, axes, curve.
- `euclid.analytic`: phép toán vector, giao điểm, đường tròn, tiếp tuyến, tâm tam giác, nghịch đảo, trục đẳng phương.
- `euclid.construct`: dựng điểm theo tên và nối tiếp quy trình.
- `euclid.figures`: tam giác, tứ giác, đa giác đều, đường tròn, mặt phẳng tọa độ.
- `euclid.templates`: Thales, Ceva, Menelaus, trung trực, phân giác, tiếp tuyến, phép biến hình.
- `euclid.conics`: parabol, elip, hypebol dưới dạng model mở.
- `euclid.render`: render toàn model hoặc vẽ bên trong một CeTZ canvas đang có.

#pagebreak()
= 14. Mẫu khung dùng cho bài toán mới

```typ
#import "@preview/typ-euclide:0.2.1": euclid

#let s = euclid.euclid-theme("blue")

#let fig = euclid.triangle(
  A: (-2, 0),
  B: (3, 0),
  C: (0.5, 3),
  features: ("vertices",),
)

// 1. Dựng điểm theo tên.
#let fig = euclid.construct.midpoint(fig, "M", "B", "C")
#let fig = euclid.construct.projection(fig, "H", "A", "B", "C")

// 2. Thêm các đối tượng cần thiết.
#let fig = euclid.with-objects(fig, (
  euclid.segment("A", "M", role: "accent"),
  euclid.segment("A", "H", role: "secondary"),
  euclid.circle-through("M", "H", role: "tertiary"),
))

// 3. Sửa theo id/tag nếu cần.
#let fig = euclid.patch-tag(fig, "constructed", (role: "accent"))

// 4. Kiểm tra và render.
#assert(euclid.validate(fig).len() == 0)
#euclid.render-model(fig, style: s)
```


= 15. Tùy biến riêng từng điểm và nhãn

```typ
#let fig = euclid.triangle(
  features: ("vertices", "centers"),
  point-options: (
    A: (
      label-content: $A_0$,
      label: (offset: (-0.22, -0.16), anchor: "north-east", size: 11pt),
      point: (radius: 0.085, fill: red),
    ),
    H: (
      label: (offset: (0.18, 0.16), size: 10pt),
      point: (radius: 0.075, fill: green),
    ),
  ),
)

// Có thể bổ sung hoặc sửa options sau khi model đã được tạo.
#let fig = euclid.with-point-option(fig, "O", (
  label: (offset: (-0.2, 0.16), anchor: "south-east"),
  point: (fill: blue),
))
#euclid.render-model(fig)
```

#let point-style-demo = euclid.triangle(
  features: ("vertices", "centers"),
  point-options: (
    A: (label-content: $A_0$, label: (offset: (-0.22, -0.16), anchor: "north-east", size: 11pt), point: (radius: 0.085, fill: red)),
    H: (label: (offset: (0.18, 0.16), size: 10pt), point: (radius: 0.075, fill: green)),
  ),
)
#let point-style-demo = euclid.with-point-option(point-style-demo, "O", (label: (offset: (-0.2, 0.16), anchor: "south-east"), point: (fill: blue)))
#result-card(euclid.render-model(point-style-demo, style: euclid.euclid-theme("blue"), length: 0.86cm))

= 16. Gallery định lý nâng cao

Các model dưới đây vẫn chứa toàn bộ điểm có tên và object có `id`/`tag`, nên có thể lấy điểm rồi vẽ tiếp.

#grid(columns: (1fr, 1fr), gutter: 12pt,
  result-card(euclid.render-model(euclid.theorems.simson-line(), style: euclid.euclid-theme("blue"), length: 0.68cm)),
  result-card(euclid.render-model(euclid.theorems.gergonne(), style: euclid.euclid-theme("green"), length: 0.68cm)),
  result-card(euclid.render-model(euclid.theorems.radical-axis(), style: euclid.euclid-theme("red"), length: 0.68cm)),
  result-card(euclid.render-model(euclid.theorems.inversion(), style: euclid.euclid-theme("orange"), length: 0.68cm)),
)

= 17. Tiếp tục vẽ trực tiếp bằng CeTZ

```typ
#let fig = euclid.templates.euler-triangle()

#cetz.canvas(length: 0.8cm, {
  import cetz.draw: *
  euclid.draw-model(fig)

  // Vẽ thêm bằng CeTZ, nhưng vẫn dùng tọa độ từ model.
  line(
    euclid.point-at(fig, "A"),
    euclid.point-at(fig, "N"),
    stroke: (paint: purple, thickness: 1.2pt),
  )
})
```

#let cetz-demo = euclid.templates.euler-triangle()
#result-card(cetz.canvas(length: 0.76cm, {
  import cetz.draw: *
  euclid.draw-model(cetz-demo, style: euclid.euclid-theme("blue"))
  line(euclid.point-at(cetz-demo, "A"), euclid.point-at(cetz-demo, "N"), stroke: (paint: purple, thickness: 1.2pt))
}))

= 18. Mô-đun quy hoạch tuyến tính được bổ sung

```typ
#import "@preview/typ-euclide:0.2.1": linear-programming

#linear-programming.lp-region(
  (
    (a: 1, b: 2, c: 10, label: $d_1$),
    (a: 2, b: 1, c: 8, label: $d_2$),
    (a: -1, b: 0, c: 0),
    (a: 0, b: -1, c: 0),
  ),
  bounds: (x: (-1, 8), y: (-1, 8)),
  format-vertex: "auto",
)
```

#result-card(linear-programming.lp-region(
  (
    (a: 1, b: 2, c: 10, label: $d_1$),
    (a: 2, b: 1, c: 8, label: $d_2$),
    (a: -1, b: 0, c: 0),
    (a: 0, b: -1, c: 0),
  ),
  bounds: (x: (-1, 8), y: (-1, 8)),
  format-vertex: "auto",
  length: 0.58cm,
))

#align(center)[#text(fill: rgb("5F6368"), size: 9pt)[Hết tài liệu — file này vừa là hướng dẫn, vừa là gallery kiểm thử trực quan.]]
