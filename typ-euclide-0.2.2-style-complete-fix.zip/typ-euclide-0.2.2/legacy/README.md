# Archived input

`demo-original.typ` is the uploaded source preserved for reference. It imported five local implementation files that were not included with the upload, so those original algorithms could not be ported byte-for-byte. The package therefore contains a clean modular reimplementation and root-level compatibility shims.

Use `../examples/legacy-compat.typ` as the maintained compatibility example.
