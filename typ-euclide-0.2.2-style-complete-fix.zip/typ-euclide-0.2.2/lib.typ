// typ-euclide 0.2.1 — reusable named Euclidean geometry, diagrams, solids and analysis.
#import "@preview/cetz:0.5.2" as cetz

// Foundation.
#import "src/core.typ" as core
#import "src/styles.typ" as styles
#import "src/primitives.typ" as primitives
#import "src/marks.typ" as marks

// Plane geometry.
#import "src/triangles.typ" as triangles
#import "src/quadrilaterals.typ" as quadrilaterals
#import "src/circles.typ" as circles
#import "src/conics.typ" as conics
#import "src/geometry/polygons.typ" as polygons
#import "src/geometry/constructions.typ" as constructions
#import "src/geometry/trigonometry.typ" as trigonometry
#import "src/geometry/theorems.typ" as theorems

// Analytic geometry and diagrams.
#import "src/graphs.typ" as graphs
#import "src/analysis/regions.typ" as regions
#import "src/analysis/conic-contact.typ" as contacts
#import "src/probability.typ" as probability

// Space geometry.
#import "src/solids.typ" as solids
#import "src/nets.typ" as nets
#import "src/space/unfold.typ" as unfold
#import "src/space/sections.typ" as sections

#import "src/presets.typ" as presets

// Advanced named-model Euclidean API.
#import "src/euclid/api.typ" as euclid
#import "lp-region.typ" as linear-programming

// Convenience exports: common styles and plane figures.
#import "src/styles.typ": theme, palette
#import "src/triangles.typ": triangle, right-triangle, equilateral-triangle, isosceles-triangle
#import "src/quadrilaterals.typ": rectangle, square, parallelogram, rhombus, trapezoid, cyclic-quadrilateral
#import "src/circles.typ": circle-basic, tangent-from-point, intersecting-chords, inscribed-angle
#import "src/conics.typ": parabola, ellipse, hyperbola
#import "src/geometry/polygons.typ": regular-polygon, star-polygon, polygon-angle-sum
#import "src/geometry/constructions.typ": perpendicular-bisector, angle-bisector, reflection-across-line, homothety-figure, circle-through-three-points
#import "src/geometry/trigonometry.typ": unit-circle, right-triangle-trig, sine-rule-triangle, vector-components
#import "src/geometry/theorems.typ": thales-parallel, pythagorean-squares, ceva-configuration, menelaus-configuration, power-of-point, tangent-secant-theorem

// Convenience exports: graphs, regions and diagramming.
#import "src/graphs.typ": function-plot, integral-region, linear-programming-region
#import "src/analysis/regions.typ": find-roots, integral-regions, feasible-polygon, lp-region, draw-integral-region, draw-lp-region
#import "src/analysis/conic-contact.typ": tangent-parabola, tangent-ellipse, tangent-hyperbola, draw-tangent-parabola, draw-tangent-ellipse, draw-tangent-hyperbola
#import "src/probability.typ": probability-tree, prob-tree, venn, venn-diagram

// Convenience exports: ordinary solids, nets, unfoldings and cross-sections.
#import "src/solids.typ": cube, prism, pyramid, cylinder, cone, frustum, sphere
#import "src/nets.typ": cube-net, prism-net, cylinder-net, cone-net
#import "src/space/unfold.typ": wrapped-cone, wrapped-frustum, wrapped-cylinder, wrapped-prism, wrapped-cube, wrapped-pyramid
#import "src/space/sections.typ": solid-section, draw-solid-section

#let version = "0.2.1"
#let name = "typ-euclide"
#let canvas = cetz.canvas
#let draw = cetz.draw
