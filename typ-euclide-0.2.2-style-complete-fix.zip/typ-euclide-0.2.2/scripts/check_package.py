#!/usr/bin/env python3
"""Static checks and optional Typst compilation for typ-euclide."""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def balanced(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    stack: list[tuple[str, int, int]] = []
    pairs = {")": "(", "]": "[", "}": "{"}
    errors: list[str] = []
    line = 1
    column = 0
    index = 0
    in_string = False
    escaped = False
    in_comment = False

    while index < len(text):
        char = text[index]
        column += 1
        if char == "\n":
            line += 1
            column = 0
            in_comment = False
            index += 1
            continue
        if in_comment:
            index += 1
            continue
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            index += 1
            continue
        if char == "/" and index + 1 < len(text) and text[index + 1] == "/":
            in_comment = True
            index += 2
            column += 1
            continue
        if char == '"':
            in_string = True
        elif char in "([{":
            stack.append((char, line, column))
        elif char in ")]}":
            if not stack or stack[-1][0] != pairs[char]:
                errors.append(f"{path}:{line}:{column}: unexpected {char}")
            else:
                stack.pop()
        index += 1

    for char, open_line, open_column in stack:
        errors.append(f"{path}:{open_line}:{open_column}: unclosed {char}")
    return errors


def _without_raw(text: str) -> str:
    return re.sub(r"```.*?```", "", text, flags=re.DOTALL)


def duplicate_definition_errors(path: Path) -> list[str]:
    # Rebinding is useful in examples and documents. This check is intended for
    # library modules where a repeated top-level API definition is usually accidental.
    relative = path.relative_to(ROOT)
    if relative.parts[0] in {"examples", "tests"} or relative.name in {"demo.typ", "hdsd-euclide.typ"}:
        return []
    text = _without_raw(path.read_text(encoding="utf-8"))
    names = re.findall(r"^#let\s+([\w-]+)", text, flags=re.MULTILINE)
    errors: list[str] = []
    for name in sorted(set(names)):
        count = names.count(name)
        if count > 1:
            errors.append(f"{path}: duplicate top-level definition {name!r} ({count} times)")
    return errors



def duplicate_binding_errors(path: Path) -> list[str]:
    """Find repeated top-level names introduced by imports or #let in library modules."""
    relative = path.relative_to(ROOT)
    if relative.parts[0] in {"examples", "tests"} or relative.name in {"demo.typ", "hdsd-euclide.typ"}:
        return []
    text = _without_raw(path.read_text(encoding="utf-8"))
    names: list[str] = []
    names.extend(re.findall(r'^#let\s+([\w-]+)', text, flags=re.MULTILINE))
    names.extend(re.findall(r'^#import\s+"[^"]+"\s+as\s+([\w-]+)', text, flags=re.MULTILINE))
    for imported in re.findall(r'^#import\s+"[^"]+"\s*:\s*([^\n]+)', text, flags=re.MULTILINE):
        for item in imported.split(","):
            item = item.strip()
            if not item or item == "*":
                continue
            candidate = item.split(" as ")[-1].strip()
            if re.fullmatch(r"[\w-]+", candidate):
                names.append(candidate)
    return [f"{path}: duplicate top-level binding {name!r}" for name in sorted(set(names)) if names.count(name) > 1]

def local_import_errors(path: Path) -> list[str]:
    errors: list[str] = []
    text = path.read_text(encoding="utf-8")
    for match in re.finditer(r'#import\s+"([^"]+)"', text):
        target = match.group(1)
        if target.startswith("@"):
            continue
        resolved = (path.parent / target).resolve()
        if not resolved.exists():
            errors.append(f"{path}: missing local import {target}")
    return errors



def explicit_import_symbol_errors(path: Path) -> list[str]:
    """Check simple local `#import "x.typ": a, b` imports against top-level #let exports."""
    errors: list[str] = []
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(r'#import\s+"([^"]+)"\s*:\s*([^\n]+)')
    for match in pattern.finditer(text):
        target = match.group(1)
        if target.startswith("@"):
            continue
        symbols_text = match.group(2).strip()
        if symbols_text == "*" or symbols_text.startswith("*"):
            continue
        resolved = (path.parent / target).resolve()
        if not resolved.exists() or resolved.suffix != ".typ":
            continue
        target_text = _without_raw(resolved.read_text(encoding="utf-8"))
        exports = set(re.findall(r"^#let\s+([\w-]+)", target_text, flags=re.MULTILINE))
        exports.update(re.findall(r'^#import\s+"[^"]+"\s+as\s+([\w-]+)', target_text, flags=re.MULTILINE))
        for imported in re.findall(r'^#import\s+"[^"]+"\s*:\s*([^\n]+)', target_text, flags=re.MULTILINE):
            for item in imported.split(","):
                item = item.strip()
                if item == "*":
                    continue
                alias_parts = item.split(" as ")
                candidate = alias_parts[-1].strip()
                if re.fullmatch(r"[\w-]+", candidate):
                    exports.add(candidate)
        for part in symbols_text.split(","):
            part = part.strip()
            if not part or part.startswith("//"):
                continue
            name = part.split(" as ", 1)[0].strip()
            if re.fullmatch(r"[\w-]+", name) and name not in exports:
                errors.append(f"{path}: {name!r} is not exported by {target}")
    return errors

def main() -> int:
    typ_files = [p for p in ROOT.rglob("*.typ") if "legacy" not in p.parts]
    errors: list[str] = []
    for path in typ_files:
        errors.extend(balanced(path))
        errors.extend(local_import_errors(path))
        errors.extend(duplicate_definition_errors(path))
        errors.extend(duplicate_binding_errors(path))
        errors.extend(explicit_import_symbol_errors(path))

    if errors:
        print("Static checks failed:")
        print("\n".join(errors))
        return 1

    print(f"Static checks passed for {len(typ_files)} Typst files.")
    typst = shutil.which("typst")
    if typst is None:
        print("Typst CLI not found; skipped compilation.")
        return 0

    targets = [
        ROOT / "tests/smoke.typ",
        ROOT / "examples/legacy-compat.typ",
        ROOT / "tests/demo-modules-smoke.typ",
        ROOT / "examples/demo-full.typ",
        ROOT / "tests/euclid-model-smoke.typ",
        ROOT / "tests/euclid-analytic.typ",
        ROOT / "examples/advanced-model.typ",
        ROOT / "hdsd-euclide.typ",
    ]
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    for target in targets:
        output = build / f"{target.stem}.pdf"
        print(f"Compiling {target.relative_to(ROOT)} ...")
        subprocess.run([typst, "compile", str(target), str(output)], check=True, cwd=ROOT)
    print("Compilation checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
