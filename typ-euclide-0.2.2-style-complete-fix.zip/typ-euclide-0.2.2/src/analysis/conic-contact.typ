#import "@preview/cetz:0.5.2": canvas, draw
#import "../core.typ" as geo
#import "../styles.typ" as styles
#import "../primitives.typ" as primitive
#import "../conics.typ": draw-curve

#let circle-style(item, style) = (
  stroke: item.at("stroke", default: (paint: styles.get(style, "secondary"), thickness: 1pt)),
  fill: item.at("fill", default: styles.get(style, "secondary").transparentize(86%)),
)

#let paint-of(stroke, fallback) = if type(stroke) == dictionary { stroke.at("paint", default: fallback) } else { stroke }

#let render-tangent-parabola(
  a: 1,
  domain: (-2, 2),
  axes-range: ((-3, 3), (-1, 5)),
  circles: (),
  mode: "flat",
  grid: true,
  axes: true,
  style: styles.theme(),
) = {
  if grid { primitive.draw-grid(x-range: axes-range.at(0), y-range: axes-range.at(1), style: style) }
  if axes { primitive.draw-axes(x-range: axes-range.at(0), y-range: axes-range.at(1), style: style) }
  draw-curve(x => a * x * x, domain: domain, style: style, stroke: (paint: styles.get(style, "accent"), thickness: 1.2pt))
  for item in circles {
    let r = item.at("R")
    let automatic = item.at("y", default: "auto") == "auto"
    let threshold = 1 / (2 * calc.abs(a))
    let cy = if automatic {
      if r <= threshold { r } else { calc.abs(a) * r * r + 1 / (4 * calc.abs(a)) }
    } else { item.at("y") }
    let cx = item.at("x", default: 0)
    let cs = circle-style(item, style)
    draw.circle((cx, cy), radius: r, stroke: cs.stroke, fill: cs.fill)
    let t2 = r * r - threshold * threshold
    if automatic and t2 > geo.eps {
      let t = calc.sqrt(t2)
      let p1 = (t, a * t * t)
      let p2 = (-t, a * t * t)
      draw.line((cx, cy), p1, stroke: styles.get(style, "auxiliary-stroke"))
      draw.line((cx, cy), p2, stroke: styles.get(style, "auxiliary-stroke"))
      primitive.draw-points((p1, p2), style: style, labels: ($T_1$, $T_2$))
    }
    primitive.draw-point((cx, cy), label: item.at("name", default: none), style: style, fill: paint-of(cs.stroke, styles.get(style, "secondary")))
  }
}

#let tangent-parabola(
  a: 1, domain: (-2, 2), axes-range: ((-3, 3), (-1, 5)), circles: (),
  mode: "flat", grid: true, axes: true, style: styles.theme(), length: 1cm,
) = canvas(length: length, {
  render-tangent-parabola(a: a, domain: domain, axes-range: axes-range, circles: circles, mode: mode, grid: grid, axes: axes, style: style)
})

#let ellipse-contact(a, b, radius, samples: 720) = {
  let best-error = 1e9
  let best-point = (-a, 0)
  let best-center = (0, 0)
  for i in range(samples + 1) {
    let angle = 180deg + i / samples * 90deg
    let p = (a * calc.cos(angle), b * calc.sin(angle))
    let normal = geo.unit((-p.at(0) / (a * a), -p.at(1) / (b * b)))
    let center = geo.add(p, geo.mul(radius, normal))
    let error = calc.abs(center.at(0))
    if error < best-error {
      best-error = error
      best-point = p
      best-center = center
    }
  }
  (center: (0, best-center.at(1)), left: best-point, right: (-best-point.at(0), best-point.at(1)), error: best-error)
}

#let render-tangent-ellipse(
  a: 2,
  b: 4,
  axes-range: ((-4, 4), (-5, 5)),
  circles: (),
  mode: "flat",
  grid: true,
  axes: true,
  style: styles.theme(),
) = {
  if grid { primitive.draw-grid(x-range: axes-range.at(0), y-range: axes-range.at(1), style: style) }
  if axes { primitive.draw-axes(x-range: axes-range.at(0), y-range: axes-range.at(1), style: style) }
  draw.circle((0, 0), radius: (a, b), stroke: (paint: styles.get(style, "accent"), thickness: 1.2pt), fill: none)
  for item in circles {
    let r = item.at("R")
    let automatic = item.at("y", default: "auto") == "auto"
    let contact = ellipse-contact(a, b, r)
    let center = if automatic { contact.center } else { (item.at("x", default: 0), item.at("y")) }
    let cs = circle-style(item, style)
    draw.circle(center, radius: r, stroke: cs.stroke, fill: cs.fill)
    if automatic {
      draw.line(center, contact.left, stroke: styles.get(style, "auxiliary-stroke"))
      draw.line(center, contact.right, stroke: styles.get(style, "auxiliary-stroke"))
      primitive.draw-points((contact.left, contact.right), labels: ($T_1$, $T_2$), style: style)
    }
    primitive.draw-point(center, label: item.at("name", default: none), style: style, fill: paint-of(cs.stroke, styles.get(style, "secondary")))
  }
}

#let tangent-ellipse(
  a: 2, b: 4, axes-range: ((-4, 4), (-5, 5)), circles: (),
  mode: "flat", grid: true, axes: true, style: styles.theme(), length: 1cm,
) = canvas(length: length, {
  render-tangent-ellipse(a: a, b: b, axes-range: axes-range, circles: circles, mode: mode, grid: grid, axes: axes, style: style)
})

#let render-tangent-hyperbola(
  a: 3,
  b: 4,
  domain: (-2, 2),
  axes-range: ((-7, 7), (-5, 5)),
  circles: (),
  mode: "flat",
  grid: true,
  axes: true,
  style: styles.theme(),
) = {
  if grid { primitive.draw-grid(x-range: axes-range.at(0), y-range: axes-range.at(1), style: style) }
  if axes { primitive.draw-axes(x-range: axes-range.at(0), y-range: axes-range.at(1), style: style) }
  let branch = range(241).map(i => {
    let t = domain.at(0) + i / 240 * (domain.at(1) - domain.at(0))
    (a * calc.cosh(t), b * calc.sinh(t))
  })
  draw.line(..branch, stroke: (paint: styles.get(style, "accent"), thickness: 1.2pt))
  draw.line(..branch.map(p => (-p.at(0), p.at(1))), stroke: (paint: styles.get(style, "accent"), thickness: 1.2pt))
  for item in circles {
    let r = item.at("R")
    let center = (item.at("x", default: 0), item.at("y", default: 0))
    let cs = circle-style(item, style)
    draw.circle(center, radius: r, stroke: cs.stroke, fill: cs.fill)
    primitive.draw-point(center, label: item.at("name", default: none), style: style, fill: paint-of(cs.stroke, styles.get(style, "secondary")))
  }
}

#let tangent-hyperbola(
  a: 3, b: 4, domain: (-2, 2), axes-range: ((-7, 7), (-5, 5)), circles: (),
  mode: "flat", grid: true, axes: true, style: styles.theme(), length: 1cm,
) = canvas(length: length, {
  render-tangent-hyperbola(a: a, b: b, domain: domain, axes-range: axes-range, circles: circles, mode: mode, grid: grid, axes: axes, style: style)
})

// Compatibility functions intended for use inside an existing cetz.canvas.
#let draw-tangent-parabola(
  a: 1, domain: (-2, 2), axes-range: ((-3, 3), (-1, 5)), circles: (),
  mode: "flat", grid: true, axes: true, style: styles.theme(),
) = render-tangent-parabola(a: a, domain: domain, axes-range: axes-range, circles: circles, mode: mode, grid: grid, axes: axes, style: style)

#let draw-tangent-ellipse(
  a: 2, b: 4, axes-range: ((-4, 4), (-5, 5)), circles: (),
  mode: "flat", grid: true, axes: true, style: styles.theme(),
) = render-tangent-ellipse(a: a, b: b, axes-range: axes-range, circles: circles, mode: mode, grid: grid, axes: axes, style: style)

#let draw-tangent-hyperbola(
  a: 3, b: 4, domain: (-2, 2), axes-range: ((-7, 7), (-5, 5)), circles: (),
  mode: "flat", grid: true, axes: true, style: styles.theme(),
) = render-tangent-hyperbola(a: a, b: b, domain: domain, axes-range: axes-range, circles: circles, mode: mode, grid: grid, axes: axes, style: style)
