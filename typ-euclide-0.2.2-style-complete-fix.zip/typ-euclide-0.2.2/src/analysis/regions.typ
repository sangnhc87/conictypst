#import "@preview/cetz:0.5.2": canvas, draw
#import "../core.typ" as geo
#import "../styles.typ" as styles
#import "../primitives.typ" as primitive
#import "../conics.typ": draw-curve

#let bisect-root(h, left, right, iterations: 45) = {
  let a = left
  let b = right
  let fa = h(a)
  for _ in range(iterations) {
    let m = (a + b) / 2
    let fm = h(m)
    if fa * fm <= 0 {
      b = m
    } else {
      a = m
      fa = fm
    }
  }
  (a + b) / 2
}

#let find-roots(f, g: x => 0, domain: (-5, 5), samples: 400, tolerance: 1e-6) = {
  let roots = ()
  let h(x) = f(x) - g(x)
  let x0 = domain.at(0)
  let y0 = h(x0)
  for i in range(samples) {
    let x1 = domain.at(0) + (i + 1) / samples * (domain.at(1) - domain.at(0))
    let y1 = h(x1)
    if calc.abs(y0) <= tolerance {
      if roots.len() == 0 or calc.abs(x0 - roots.last()) > tolerance * 10 { roots += (x0,) }
    }
    if y0 * y1 < 0 {
      let root = bisect-root(h, x0, x1)
      if roots.len() == 0 or calc.abs(root - roots.last()) > tolerance * 10 { roots += (root,) }
    }
    x0 = x1
    y0 = y1
  }
  if calc.abs(y0) <= tolerance and (roots.len() == 0 or calc.abs(x0 - roots.last()) > tolerance * 10) { roots += (x0,) }
  roots
}

#let render-integral-regions(
  f,
  g: x => 0,
  domain: (-5, 5),
  y-range: (-5, 5),
  roots: auto,
  samples: 240,
  fill: none,
  grid: true,
  axes: true,
  x-tick-step: 1,
  y-tick-step: 1,
  f-label: none,
  g-label: none,
  style: styles.theme(),
) = {
  if grid { primitive.draw-grid(x-range: domain, y-range: y-range, step: (x-tick-step, y-tick-step), style: style) }
  if axes { primitive.draw-axes(x-range: domain, y-range: y-range, x-tick-step: x-tick-step, y-tick-step: y-tick-step, style: style) }
  let intersections = if roots == auto { find-roots(f, g, domain: domain) } else { roots }
  let intervals = ()
  if intersections.len() >= 2 {
    for i in range(intersections.len() - 1) { intervals += ((intersections.at(i), intersections.at(i + 1)),) }
  } else { intervals = (domain,) }
  let default-fills = (
    styles.get(style, "accent").transparentize(82%),
    styles.get(style, "secondary").transparentize(84%),
  )
  let fills = if fill == none { default-fills } else if type(fill) == array { fill } else { (fill,) }
  for (index, interval) in intervals.enumerate() {
    let xs = range(samples + 1).map(i => interval.at(0) + i / samples * (interval.at(1) - interval.at(0)))
    let upper = xs.map(x => (x, f(x)))
    let lower = xs.rev().map(x => (x, g(x)))
    draw.line(..(upper + lower), close: true, stroke: none, fill: fills.at(calc.rem(index, fills.len())))
  }
  draw-curve(f, domain: domain, samples: samples, style: style, stroke: (paint: styles.get(style, "accent"), thickness: 1pt), name: "f-curve")
  draw-curve(g, domain: domain, samples: samples, style: style, stroke: (paint: styles.get(style, "secondary"), thickness: 1pt), name: "g-curve")
  if f-label != none { draw.content(("f-curve.start", 86%, "f-curve.end"), f-label, anchor: "south", padding: 2pt, fill: white) }
  if g-label != none { draw.content(("g-curve.start", 78%, "g-curve.end"), g-label, anchor: "north", padding: 2pt, fill: white) }
  for root in intersections { primitive.draw-point((root, f(root)), style: style, fill: styles.get(style, "accent"), radius: 0.045) }
}

#let integral-regions(
  f,
  g: x => 0,
  domain: (-5, 5),
  y-range: (-5, 5),
  roots: auto,
  samples: 240,
  fill: none,
  grid: true,
  axes: true,
  x-tick-step: 1,
  y-tick-step: 1,
  f-label: none,
  g-label: none,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  render-integral-regions(
    f, g: g, domain: domain, y-range: y-range, roots: roots, samples: samples,
    fill: fill, grid: grid, axes: axes, x-tick-step: x-tick-step,
    y-tick-step: y-tick-step, f-label: f-label, g-label: g-label, style: style,
  )
})

#let normalize-inequality(ineq) = {
  let op = ineq.at("op", default: "<=")
  let factor = if op == ">=" or op == ">" { -1 } else { 1 }
  ineq + (a: factor * ineq.at("a"), b: factor * ineq.at("b"), c: factor * ineq.at("c"), op: "<=")
}

#let inequality-value(ineq, p) = ineq.a * p.at(0) + ineq.b * p.at(1) - ineq.c
#let satisfies(ineq, p, tolerance: 1e-7) = inequality-value(ineq, p) <= tolerance

#let boundary-intersection(ineq, p, q) = {
  let vp = inequality-value(ineq, p)
  let vq = inequality-value(ineq, q)
  let denom = vp - vq
  if calc.abs(denom) < geo.eps { p } else { geo.lerp(p, q, vp / denom) }
}

#let clip-polygon(polygon, ineq) = {
  let output = ()
  if polygon.len() > 0 {
    for i in range(polygon.len()) {
      let p = polygon.at(i)
      let q = polygon.at(calc.rem(i + 1, polygon.len()))
      let pin = satisfies(ineq, p)
      let qin = satisfies(ineq, q)
      if pin and qin { output += (q,) }
      else if pin and not qin { output += (boundary-intersection(ineq, p, q),) }
      else if not pin and qin { output += (boundary-intersection(ineq, p, q), q) }
    }
  }
  output
}

#let feasible-polygon(inequalities, x-range: (-1, 8), y-range: (-1, 8)) = {
  let polygon = (
    (x-range.at(0), y-range.at(0)),
    (x-range.at(1), y-range.at(0)),
    (x-range.at(1), y-range.at(1)),
    (x-range.at(0), y-range.at(1)),
  )
  for raw in inequalities { polygon = clip-polygon(polygon, normalize-inequality(raw)) }
  polygon
}

#let line-in-box(ineq, x-range, y-range, tolerance: 1e-7) = {
  let a = ineq.a
  let b = ineq.b
  let c = ineq.c
  let pts = ()
  if calc.abs(b) > tolerance {
    for x in x-range {
      let y = (c - a * x) / b
      if y >= y-range.at(0) - tolerance and y <= y-range.at(1) + tolerance { pts += ((x, y),) }
    }
  }
  if calc.abs(a) > tolerance {
    for y in y-range {
      let x = (c - b * y) / a
      if x >= x-range.at(0) - tolerance and x <= x-range.at(1) + tolerance {
        let duplicate = false
        for p in pts { if geo.distance(p, (x, y)) <= tolerance { duplicate = true } }
        if not duplicate { pts += ((x, y),) }
      }
    }
  }
  pts
}

#let number-label(value, digits: 2) = str(calc.round(value * calc.pow(10, digits)) / calc.pow(10, digits))

#let render-lp-region(
  inequalities,
  x-range: (-1, 8),
  y-range: (-1, 8),
  fill: none,
  format-vertex: "auto",
  grid: true,
  axes: true,
  x-tick-step: 1,
  y-tick-step: 1,
  style: styles.theme(),
) = {
  if grid { primitive.draw-grid(x-range: x-range, y-range: y-range, step: (x-tick-step, y-tick-step), style: style) }
  if axes { primitive.draw-axes(x-range: x-range, y-range: y-range, x-tick-step: x-tick-step, y-tick-step: y-tick-step, style: style) }
  for raw in inequalities {
    let ineq = normalize-inequality(raw)
    let pts = line-in-box(ineq, x-range, y-range)
    if pts.len() >= 2 { draw.line(pts.at(0), pts.at(1), stroke: raw.at("stroke", default: styles.get(style, "auxiliary-stroke"))) }
  }
  let polygon = feasible-polygon(inequalities, x-range: x-range, y-range: y-range)
  let area-fill = if fill == none { styles.get(style, "fill") } else { fill }
  if polygon.len() >= 3 {
    draw.line(..polygon, close: true, stroke: styles.get(style, "strong-stroke"), fill: area-fill)
    for (i, p) in polygon.enumerate() {
      let label = if type(format-vertex) == function { format-vertex(p, i) }
        else if format-vertex == "none" { none }
        else { "(" + number-label(p.at(0)) + ", " + number-label(p.at(1)) + ")" }
      primitive.draw-point(p, label: label, style: style, fill: styles.get(style, "accent"))
    }
  }
}

#let lp-region(
  inequalities,
  x-range: (-1, 8),
  y-range: (-1, 8),
  fill: none,
  format-vertex: "auto",
  grid: true,
  axes: true,
  x-tick-step: 1,
  y-tick-step: 1,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  render-lp-region(
    inequalities, x-range: x-range, y-range: y-range, fill: fill,
    format-vertex: format-vertex, grid: grid, axes: axes,
    x-tick-step: x-tick-step, y-tick-step: y-tick-step, style: style,
  )
})

// Compatibility functions intended for use inside an existing cetz.canvas.
#let draw-integral-region(
  f,
  g: x => 0,
  domain: (-5, 5),
  y-range: (-5, 5),
  p-fill: none,
  x-tick-step: 1,
  y-tick-step: 1,
  f-label: none,
  g-label: none,
  style: styles.theme(),
) = render-integral-regions(
  f, g: g, domain: domain, y-range: y-range, fill: p-fill,
  x-tick-step: x-tick-step, y-tick-step: y-tick-step,
  f-label: f-label, g-label: g-label, style: style,
)

#let draw-lp-region(
  inequalities,
  p-fill: none,
  format-vertex: "auto",
  x-range: (-1, 8),
  y-range: (-1, 8),
  x-tick-step: 1,
  y-tick-step: 1,
  style: styles.theme(),
) = render-lp-region(
  inequalities, x-range: x-range, y-range: y-range, fill: p-fill,
  format-vertex: format-vertex, x-tick-step: x-tick-step, y-tick-step: y-tick-step,
  style: style,
)
