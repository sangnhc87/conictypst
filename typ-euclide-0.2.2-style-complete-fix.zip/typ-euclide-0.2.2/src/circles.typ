#import "@preview/cetz:0.5.2": canvas, draw
#import "core.typ" as geo
#import "styles.typ": theme, get
#import "primitives.typ" as primitive
#import "marks.typ" as mark

#let circle-basic(center: (0, 0), radius: 2.5, radii: (20deg, 135deg), labels: ($O$, $A$, $B$), style: theme(), length: 1cm) = canvas(length: length, {
  let a = geo.add(center, (radius * calc.cos(radii.at(0)), radius * calc.sin(radii.at(0))))
  let b = geo.add(center, (radius * calc.cos(radii.at(1)), radius * calc.sin(radii.at(1))))
  draw.circle(center, radius: radius, stroke: get(style, "stroke"))
  draw.line(center, a, stroke: get(style, "stroke"))
  draw.line(center, b, stroke: get(style, "stroke"))
  primitive.draw-points((center, a, b), labels: labels, style: style)
})

#let tangent-from-point(center: (0, 0), radius: 2, p: (4.2, 1), style: theme(), length: 1cm) = canvas(length: length, {
  let op = geo.distance(center, p)
  draw.circle(center, radius: radius, stroke: get(style, "stroke"))
  if op > radius {
    let alpha = geo.angle-of(geo.sub(p, center))
    let beta = calc.acos(radius / op)
    let t1 = geo.add(center, (radius * calc.cos(alpha + beta), radius * calc.sin(alpha + beta)))
    let t2 = geo.add(center, (radius * calc.cos(alpha - beta), radius * calc.sin(alpha - beta)))
    draw.line(p, t1, stroke: get(style, "strong-stroke"))
    draw.line(p, t2, stroke: get(style, "strong-stroke"))
    draw.line(center, t1, stroke: get(style, "auxiliary-stroke"))
    draw.line(center, t2, stroke: get(style, "auxiliary-stroke"))
    mark.right-angle(t1, center, p, style: style)
    mark.right-angle(t2, center, p, style: style)
    primitive.draw-points((center, p, t1, t2), labels: ($O$, $P$, $A$, $B$), style: style)
  }
})

#let intersecting-chords(center: (0, 0), radius: 2.6, angles: (25deg, 155deg, 225deg, 315deg), style: theme(), length: 1cm) = canvas(length: length, {
  let pts = angles.map(a => geo.add(center, (radius * calc.cos(a), radius * calc.sin(a))))
  let e = geo.line-intersection(pts.at(0), pts.at(2), pts.at(1), pts.at(3))
  draw.circle(center, radius: radius, stroke: get(style, "stroke"))
  draw.line(pts.at(0), pts.at(2), stroke: get(style, "strong-stroke"))
  draw.line(pts.at(1), pts.at(3), stroke: get(style, "strong-stroke"))
  primitive.draw-points(pts, labels: ($A$, $B$, $C$, $D$), style: style)
  if e != none { primitive.draw-point(e, label: $E$, style: style, fill: get(style, "accent")) }
})

#let inscribed-angle(center: (0, 0), radius: 2.6, angles: (205deg, 330deg, 85deg), style: theme(), length: 1cm) = canvas(length: length, {
  let a = geo.add(center, (radius * calc.cos(angles.at(0)), radius * calc.sin(angles.at(0))))
  let b = geo.add(center, (radius * calc.cos(angles.at(1)), radius * calc.sin(angles.at(1))))
  let c = geo.add(center, (radius * calc.cos(angles.at(2)), radius * calc.sin(angles.at(2))))
  draw.circle(center, radius: radius, stroke: get(style, "stroke"))
  draw.line(a, c, stroke: get(style, "stroke"))
  draw.line(b, c, stroke: get(style, "stroke"))
  draw.line(center, a, stroke: get(style, "stroke"))
  draw.line(center, b, stroke: get(style, "stroke"))
  mark.angle-mark(c, a, b, label: $alpha$, style: style)
  mark.angle-mark(center, a, b, radius: 0.55, label: $2 alpha$, style: style, stroke: (paint: get(style, "accent"), thickness: 0.9pt))
  primitive.draw-points((center, a, b, c), labels: ($O$, $A$, $B$, $C$), style: style)
})
