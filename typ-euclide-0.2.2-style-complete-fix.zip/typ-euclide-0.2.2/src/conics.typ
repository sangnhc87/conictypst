#import "@preview/cetz:0.5.2": canvas, draw
#import "core.typ" as geo
#import "styles.typ": theme, get
#import "primitives.typ" as primitive

#let draw-curve(f, domain: (-5, 5), samples: 180, style: theme(), stroke: none, name: none) = {
  let pts = geo.sample-function(f, domain: domain, samples: samples)
  let s = if stroke == none { (paint: get(style, "accent"), thickness: 1pt) } else { stroke }
  draw.line(..pts, stroke: s, name: name)
}

#let parabola(a: 1, vertex: (0, 0), domain: (-3, 3), axes: true, grid: false, style: theme(), length: 1cm) = canvas(length: length, {
  if grid { primitive.draw-grid(x-range: domain, y-range: (-1, 6), style: style) }
  if axes { primitive.draw-axes(x-range: domain, y-range: (-1, 6), style: style) }
  draw-curve(x => vertex.at(1) + a * calc.pow(x - vertex.at(0), 2), domain: domain, style: style)
  primitive.draw-point(vertex, label: $I$, style: style)
})

#let ellipse(a: 3, b: 2, center: (0, 0), axes: true, foci: true, style: theme(), length: 1cm) = canvas(length: length, {
  if axes { primitive.draw-axes(x-range: (-a - 1, a + 1), y-range: (-b - 1, b + 1), style: style) }
  draw.circle(center, radius: (a, b), stroke: (paint: get(style, "accent"), thickness: 1pt))
  if foci {
    let c = calc.sqrt(calc.abs(a * a - b * b))
    let f1 = if a >= b { geo.add(center, (-c, 0)) } else { geo.add(center, (0, -c)) }
    let f2 = if a >= b { geo.add(center, (c, 0)) } else { geo.add(center, (0, c)) }
    primitive.draw-points((f1, f2), labels: ($F_1$, $F_2$), style: style)
  }
})

#let hyperbola(a: 2, b: 1.5, domain: (-3, 3), axes: true, asymptotes: true, style: theme(), length: 1cm) = canvas(length: length, {
  let xmax = a * calc.cosh(domain.at(1))
  if axes { primitive.draw-axes(x-range: (-xmax - 1, xmax + 1), y-range: (-b * calc.sinh(domain.at(1)) - 1, b * calc.sinh(domain.at(1)) + 1), style: style) }
  let right = range(181).map(i => {
    let t = domain.at(0) + i / 180 * (domain.at(1) - domain.at(0))
    (a * calc.cosh(t), b * calc.sinh(t))
  })
  let left = right.map(p => (-p.at(0), p.at(1)))
  draw.line(..right, stroke: (paint: get(style, "accent"), thickness: 1pt))
  draw.line(..left, stroke: (paint: get(style, "accent"), thickness: 1pt))
  if asymptotes {
    draw.line((-xmax, -b / a * xmax), (xmax, b / a * xmax), stroke: get(style, "auxiliary-stroke"))
    draw.line((-xmax, b / a * xmax), (xmax, -b / a * xmax), stroke: get(style, "auxiliary-stroke"))
  }
})
