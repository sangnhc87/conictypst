// Pure Euclidean geometry helpers. Coordinates are (x, y) tuples.

#let eps = 1e-8
#let x(p) = p.at(0)
#let y(p) = p.at(1)
#let point(x, y) = (x, y)
#let add(a, b) = (x(a) + x(b), y(a) + y(b))
#let sub(a, b) = (x(a) - x(b), y(a) - y(b))
#let mul(k, a) = (k * x(a), k * y(a))
#let div(a, k) = (x(a) / k, y(a) / k)
#let dot(a, b) = x(a) * x(b) + y(a) * y(b)
#let cross(a, b) = x(a) * y(b) - y(a) * x(b)
#let norm2(a) = dot(a, a)
#let norm(a) = calc.sqrt(norm2(a))
#let distance(a, b) = norm(sub(a, b))
#let unit(a) = if norm(a) < eps { (0, 0) } else { div(a, norm(a)) }
#let perp(a) = (-y(a), x(a))
#let midpoint(a, b) = mul(0.5, add(a, b))
#let lerp(a, b, t) = add(mul(1 - t, a), mul(t, b))
#let direction(a, b) = unit(sub(b, a))
#let angle-of(v) = calc.atan2(x(v), y(v))

// CeTZ draw.arc positions an arc at its start point, not at its center.
// This helper converts a center/radius/angle description into that start point.
#let arc-start(center, radius, angle) = {
  let rx = if type(radius) == array { radius.at(0) } else { radius }
  let ry = if type(radius) == array { radius.at(1) } else { radius }
  add(center, (rx * calc.cos(angle), ry * calc.sin(angle)))
}
#let clamp(v, lo, hi) = calc.max(lo, calc.min(hi, v))
#let almost-equal(a, b, tolerance: eps) = calc.abs(a - b) <= tolerance

#let rotate-vector(v, angle) = (
  x(v) * calc.cos(angle) - y(v) * calc.sin(angle),
  x(v) * calc.sin(angle) + y(v) * calc.cos(angle),
)

#let rotate-point(p, angle, center: (0, 0)) = add(center, rotate-vector(sub(p, center), angle))
#let translate-point(p, by: (0, 0)) = add(p, by)
#let homothety(p, center: (0, 0), ratio: 1) = add(center, mul(ratio, sub(p, center)))

#let project-point-line(p, a, b) = {
  let ab = sub(b, a)
  let denom = norm2(ab)
  if denom < eps { a } else { add(a, mul(dot(sub(p, a), ab) / denom, ab)) }
}

#let reflect-point-line(p, a, b) = {
  let h = project-point-line(p, a, b)
  sub(mul(2, h), p)
}

#let signed-area2(a, b, c) = cross(sub(b, a), sub(c, a))
#let triangle-area(a, b, c) = calc.abs(signed-area2(a, b, c)) / 2
#let is-collinear(a, b, c, tolerance: eps) = calc.abs(signed-area2(a, b, c)) <= tolerance

#let line-intersection(a, b, c, d, tolerance: eps) = {
  let r = sub(b, a)
  let s = sub(d, c)
  let den = cross(r, s)
  if calc.abs(den) <= tolerance {
    none
  } else {
    add(a, mul(cross(sub(c, a), s) / den, r))
  }
}

#let segment-intersection(a, b, c, d, tolerance: eps) = {
  let r = sub(b, a)
  let s = sub(d, c)
  let den = cross(r, s)
  if calc.abs(den) <= tolerance {
    none
  } else {
    let t = cross(sub(c, a), s) / den
    let u = cross(sub(c, a), r) / den
    if t >= -tolerance and t <= 1 + tolerance and u >= -tolerance and u <= 1 + tolerance {
      add(a, mul(t, r))
    } else {
      none
    }
  }
}

#let distance-point-line(p, a, b) = {
  let ab = sub(b, a)
  if norm(ab) < eps { distance(p, a) } else { calc.abs(cross(ab, sub(p, a))) / norm(ab) }
}

#let circle-line-intersections(center, radius, a, b, tolerance: eps) = {
  let d = sub(b, a)
  let f = sub(a, center)
  let aa = dot(d, d)
  let bb = 2 * dot(f, d)
  let cc = dot(f, f) - radius * radius
  let disc = bb * bb - 4 * aa * cc
  if aa < tolerance or disc < -tolerance {
    ()
  } else if calc.abs(disc) <= tolerance {
    (add(a, mul(-bb / (2 * aa), d)),)
  } else {
    let root = calc.sqrt(disc)
    (
      add(a, mul((-bb - root) / (2 * aa), d)),
      add(a, mul((-bb + root) / (2 * aa), d)),
    )
  }
}

#let circle-circle-intersections(c1, r1, c2, r2, tolerance: eps) = {
  let delta = sub(c2, c1)
  let d = norm(delta)
  if d < tolerance or d > r1 + r2 + tolerance or d < calc.abs(r1 - r2) - tolerance {
    ()
  } else {
    let a = (r1 * r1 - r2 * r2 + d * d) / (2 * d)
    let h2 = r1 * r1 - a * a
    let p = add(c1, mul(a / d, delta))
    if calc.abs(h2) <= tolerance {
      (p,)
    } else {
      let h = calc.sqrt(calc.max(0, h2))
      let off = mul(h / d, perp(delta))
      (add(p, off), sub(p, off))
    }
  }
}

#let triangle-centroid(a, b, c) = div(add(add(a, b), c), 3)

#let triangle-circumcenter(a, b, c) = {
  let d = 2 * (x(a) * (y(b) - y(c)) + x(b) * (y(c) - y(a)) + x(c) * (y(a) - y(b)))
  if calc.abs(d) < eps {
    none
  } else {
    let aa = norm2(a)
    let bb = norm2(b)
    let cc = norm2(c)
    (
      (aa * (y(b) - y(c)) + bb * (y(c) - y(a)) + cc * (y(a) - y(b))) / d,
      (aa * (x(c) - x(b)) + bb * (x(a) - x(c)) + cc * (x(b) - x(a))) / d,
    )
  }
}

#let triangle-incenter(a, b, c) = {
  let la = distance(b, c)
  let lb = distance(c, a)
  let lc = distance(a, b)
  div(add(add(mul(la, a), mul(lb, b)), mul(lc, c)), la + lb + lc)
}

#let triangle-orthocenter(a, b, c) = {
  let o = triangle-circumcenter(a, b, c)
  if o == none { none } else { sub(add(add(a, b), c), mul(2, o)) }
}

#let triangle-incircle(a, b, c) = {
  let center = triangle-incenter(a, b, c)
  (center: center, radius: distance-point-line(center, a, b))
}

#let triangle-circumcircle(a, b, c) = {
  let center = triangle-circumcenter(a, b, c)
  if center == none { none } else { (center: center, radius: distance(center, a)) }
}

#let barycentric(a, b, c, weights) = {
  let wa = weights.at(0)
  let wb = weights.at(1)
  let wc = weights.at(2)
  div(add(add(mul(wa, a), mul(wb, b)), mul(wc, c)), wa + wb + wc)
}

#let regular-polygon-points(n, center: (0, 0), radius: 1, start-angle: 90deg) = range(n).map(i => (
  x(center) + radius * calc.cos(start-angle + i * 360deg / n),
  y(center) + radius * calc.sin(start-angle + i * 360deg / n),
))

#let polygon-centroid(points) = {
  let n = points.len()
  if n == 0 {
    (0, 0)
  } else {
    let sx = 0.0
    let sy = 0.0
    for p in points {
      sx += x(p)
      sy += y(p)
    }
    (sx / n, sy / n)
  }
}

#let sample-function(f, domain: (-5, 5), samples: 160) = range(samples + 1).map(i => {
  let t = i / samples
  let xx = domain.at(0) + t * (domain.at(1) - domain.at(0))
  (xx, f(xx))
})
