// Analytic Euclidean geometry: reusable data, constructions and intersections.
#import "../core.typ" as g

#let eps = g.eps
#let point = g.point
#let add = g.add
#let sub = g.sub
#let mul = g.mul
#let div = g.div
#let dot = g.dot
#let cross = g.cross
#let norm = g.norm
#let norm2 = g.norm2
#let distance = g.distance
#let unit = g.unit
#let perp = g.perp
#let midpoint = g.midpoint
#let lerp = g.lerp
#let direction = g.direction
#let rotate-point = g.rotate-point
#let translate-point = g.translate-point
#let homothety = g.homothety
#let projection = g.project-point-line
#let reflection = g.reflect-point-line
#let is-collinear = g.is-collinear
#let line-intersection-points = g.line-intersection
#let segment-intersection = g.segment-intersection
#let circle-line-intersections-points = g.circle-line-intersections
#let circle-circle-intersections-points = g.circle-circle-intersections

#let line(p, q, name: none) = (kind: "line", p: p, q: q, direction: direction(p, q), name: name)
#let line-point-direction(p, d, name: none) = (kind: "line", p: p, q: add(p, d), direction: unit(d), name: name)
#let line-equation(a, b, c, name: none) = (kind: "line-equation", a: a, b: b, c: c, name: name)
#let segment(p, q, name: none) = (kind: "segment", p: p, q: q, name: name)
#let ray(p, q, name: none) = (kind: "ray", p: p, q: q, direction: direction(p, q), name: name)
#let circle(center, radius, name: none) = (kind: "circle", center: center, radius: radius, name: name)

#let line-to-equation(l) = {
  if l.kind == "line-equation" { l }
  else {
    let p = l.p
    let q = l.q
    let a = q.at(1) - p.at(1)
    let b = p.at(0) - q.at(0)
    let c = a * p.at(0) + b * p.at(1)
    line-equation(a, b, c, name: l.at("name", default: none))
  }
}

#let equation-to-line(l) = {
  if l.kind != "line-equation" { l }
  else if calc.abs(l.b) > eps {
    line((0, l.c / l.b), (1, (l.c - l.a) / l.b), name: l.at("name", default: none))
  } else {
    line((l.c / l.a, 0), (l.c / l.a, 1), name: l.at("name", default: none))
  }
}

#let parallel-line(p, through-line, name: none) = {
  let l = equation-to-line(through-line)
  line-point-direction(p, sub(l.q, l.p), name: name)
}

#let perpendicular-line(p, to-line, name: none) = {
  let l = equation-to-line(to-line)
  line-point-direction(p, perp(sub(l.q, l.p)), name: name)
}

#let perpendicular-bisector(a, b, name: none) = line-point-direction(midpoint(a, b), perp(sub(b, a)), name: name)

#let intersect-lines(l1, l2, tolerance: eps) = {
  let a = equation-to-line(l1)
  let b = equation-to-line(l2)
  g.line-intersection(a.p, a.q, b.p, b.q, tolerance: tolerance)
}

#let intersect-line-circle(l, c, tolerance: eps) = {
  let q = equation-to-line(l)
  g.circle-line-intersections(c.center, c.radius, q.p, q.q, tolerance: tolerance)
}

#let intersect-circles(c1, c2, tolerance: eps) = g.circle-circle-intersections(c1.center, c1.radius, c2.center, c2.radius, tolerance: tolerance)

#let signed-angle(a, vertex, b) = {
  let u = sub(a, vertex)
  let v = sub(b, vertex)
  calc.atan2(dot(u, v), cross(u, v))
}

#let angle(a, vertex, b) = calc.abs(signed-angle(a, vertex, b))
#let angle-bisector-direction(a, vertex, b, internal: true) = {
  let u = direction(vertex, a)
  let v = direction(vertex, b)
  unit(if internal { add(u, v) } else { sub(u, v) })
}
#let angle-bisector-line(a, vertex, b, internal: true, name: none) = line-point-direction(vertex, angle-bisector-direction(a, vertex, b, internal: internal), name: name)

#let divide-segment(a, b, ratio: 1, internal: true) = {
  if internal { div(add(a, mul(ratio, b)), 1 + ratio) }
  else { div(sub(mul(ratio, b), a), ratio - 1) }
}

#let point-on-line(a, b, t) = lerp(a, b, t)
#let rotate(p, center: (0, 0), angle: 0deg) = g.rotate-point(p, angle, center: center)
#let translate(p, by: (0, 0)) = g.translate-point(p, by: by)
#let scale-from(p, center: (0, 0), ratio: 1) = g.homothety(p, center: center, ratio: ratio)
#let reflect(p, a, b) = g.reflect-point-line(p, a, b)

#let invert-point(p, center: (0, 0), radius: 1) = {
  let v = sub(p, center)
  let d2 = norm2(v)
  if d2 <= eps { none } else { add(center, mul(radius * radius / d2, v)) }
}

#let tangent-points(c, p, tolerance: eps) = {
  let d = distance(c.center, p)
  if d < c.radius - tolerance { () }
  else if calc.abs(d - c.radius) <= tolerance { (p,) }
  else {
    let u = direction(c.center, p)
    let base = add(c.center, mul(c.radius * c.radius / d, u))
    let h = c.radius * calc.sqrt(calc.max(0, 1 - c.radius * c.radius / (d * d)))
    let v = perp(u)
    (add(base, mul(h, v)), sub(base, mul(h, v)))
  }
}

#let circle-through-three(a, b, c, name: none) = {
  let center = g.triangle-circumcenter(a, b, c)
  if center == none { none } else { circle(center, distance(center, a), name: name) }
}

#let radical-axis(c1, c2, name: none) = {
  let x1 = c1.center.at(0)
  let y1 = c1.center.at(1)
  let x2 = c2.center.at(0)
  let y2 = c2.center.at(1)
  let a = 2 * (x2 - x1)
  let b = 2 * (y2 - y1)
  let cc = x2 * x2 + y2 * y2 - c2.radius * c2.radius - x1 * x1 - y1 * y1 + c1.radius * c1.radius
  line-equation(a, b, cc, name: name)
}

#let power-of-point(p, c) = norm2(sub(p, c.center)) - c.radius * c.radius

#let triangle-data(a, b, c) = {
  let side-a = distance(b, c)
  let side-b = distance(c, a)
  let side-c = distance(a, b)
  let perimeter = side-a + side-b + side-c
  let s = perimeter / 2
  let area = g.triangle-area(a, b, c)
  let centroid = g.triangle-centroid(a, b, c)
  let circumcenter = g.triangle-circumcenter(a, b, c)
  let incenter = g.triangle-incenter(a, b, c)
  let orthocenter = g.triangle-orthocenter(a, b, c)
  let incircle = g.triangle-incircle(a, b, c)
  let circumcircle = g.triangle-circumcircle(a, b, c)
  let ma = midpoint(b, c)
  let mb = midpoint(c, a)
  let mc = midpoint(a, b)
  let ha = projection(a, b, c)
  let hb = projection(b, c, a)
  let hc = projection(c, a, b)
  let ta = projection(incenter, b, c)
  let tb = projection(incenter, c, a)
  let tc = projection(incenter, a, b)
  let ex-a = div(add(add(mul(-side-a, a), mul(side-b, b)), mul(side-c, c)), -side-a + side-b + side-c)
  let ex-b = div(add(add(mul(side-a, a), mul(-side-b, b)), mul(side-c, c)), side-a - side-b + side-c)
  let ex-c = div(add(add(mul(side-a, a), mul(side-b, b)), mul(-side-c, c)), side-a + side-b - side-c)
  let nine-center = if circumcenter == none or orthocenter == none { none } else { midpoint(circumcenter, orthocenter) }
  let symmedian = g.barycentric(a, b, c, (side-a * side-a, side-b * side-b, side-c * side-c))
  let gergonne = g.barycentric(a, b, c, (1 / (s - side-a), 1 / (s - side-b), 1 / (s - side-c)))
  let nagel = g.barycentric(a, b, c, (s - side-a, s - side-b, s - side-c))
  let spieker = g.barycentric(a, b, c, (side-b + side-c, side-c + side-a, side-a + side-b))
  let bevan = if circumcenter == none { none } else { sub(mul(2, circumcenter), incenter) }
  let de-longchamps = if circumcenter == none or orthocenter == none { none } else { sub(mul(2, circumcenter), orthocenter) }
  (
    A: a, B: b, C: c,
    a: side-a, b: side-b, c: side-c,
    perimeter: perimeter,
    semiperimeter: s,
    area: area,
    G: centroid,
    O: circumcenter,
    I: incenter,
    H: orthocenter,
    N: nine-center,
    incircle: incircle,
    circumcircle: circumcircle,
    M_a: ma, M_b: mb, M_c: mc,
    H_a: ha, H_b: hb, H_c: hc,
    T_a: ta, T_b: tb, T_c: tc,
    I_a: ex-a, I_b: ex-b, I_c: ex-c,
    K: symmedian, Ge: gergonne, Na: nagel, S: spieker, Be: bevan, L: de-longchamps,
  )
}

#let triangle-excircle(data, which: "a") = {
  let center = if which == "a" { data.I_a } else if which == "b" { data.I_b } else { data.I_c }
  let p = if which == "a" { data.B } else { data.C }
  let q = if which == "a" { data.C } else { data.A }
  circle(center, g.distance-point-line(center, p, q))
}

#let polygon-signed-area(points) = {
  let total = 0.0
  for i in range(points.len()) {
    let p = points.at(i)
    let q = points.at(calc.rem(i + 1, points.len()))
    total += cross(p, q)
  }
  total / 2
}

#let polygon-area(points) = calc.abs(polygon-signed-area(points))

#let polygon-centroid(points) = {
  let a = polygon-signed-area(points)
  if calc.abs(a) <= eps { g.polygon-centroid(points) }
  else {
    let cx = 0.0
    let cy = 0.0
    for i in range(points.len()) {
      let p = points.at(i)
      let q = points.at(calc.rem(i + 1, points.len()))
      let k = cross(p, q)
      cx += (p.at(0) + q.at(0)) * k
      cy += (p.at(1) + q.at(1)) * k
    }
    (cx / (6 * a), cy / (6 * a))
  }
}

#let regular-polygon(n, center: (0, 0), radius: 1, start-angle: 90deg) = g.regular-polygon-points(n, center: center, radius: radius, start-angle: start-angle)

#let affine-point(p, matrix: ((1, 0), (0, 1)), shift: (0, 0)) = (
  matrix.at(0).at(0) * p.at(0) + matrix.at(0).at(1) * p.at(1) + shift.at(0),
  matrix.at(1).at(0) * p.at(0) + matrix.at(1).at(1) * p.at(1) + shift.at(1),
)
