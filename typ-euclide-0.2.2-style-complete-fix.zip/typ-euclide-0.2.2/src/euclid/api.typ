// Public advanced Euclidean API.
#import "style.typ" as style
#import "model.typ" as model
#import "objects.typ" as objects
#import "analytic.typ" as analytic
#import "render.typ" as render
#import "figures.typ" as figures
#import "construct.typ" as construct
#import "templates.typ" as templates
#import "conics.typ" as conics
#import "theorems.typ" as theorems

// Most-used convenience exports.
#import "style.typ": euclid-theme, stroke-for, fill-for
#import "model.typ": empty-model, point-at, has-point, point-names, object-list, object-at, objects-with-tag, objects-of-kind, resolve, extend, with-point, with-points, alias-point, with-point-option, with-meta, with-style, merge-models, with-object, with-objects, without-object, map-objects, patch-object, patch-objects, patch-kind, patch-tag, hide-object, show-object, translate, rotate, scale, reflect, bounds, validate
#import "render.typ": draw-object, draw-model, render-model
#import "objects.typ": point, label, segment, line, ray, vector, polyline, polygon, circle, circle-through, arc, ellipse, angle, right-angle, ticks, parallel, grid, axes, function-curve, parametric-curve
#import "figures.typ": triangle, right-triangle, equilateral-triangle, isosceles-triangle, quadrilateral, rectangle, square, parallelogram, rhombus, trapezoid, kite, regular-polygon, coordinate-plane
#import "analytic.typ": midpoint, lerp, distance, direction, projection, reflection, divide-segment, line-intersection-points, segment-intersection, circle-line-intersections-points, circle-circle-intersections-points, tangent-points, triangle-data, polygon-area, polygon-centroid, invert-point, radical-axis, power-of-point
#import "construct.typ": define-point, division-point, point-on-segment, barycentric-point, centroid, incenter, circumcenter, orthocenter, angle-bisector-foot, line-intersection, circle-line-intersections, circle-circle-intersections, perpendicular-line, parallel-line, circumcircle, incircle, excenter, inversion
#let define-tangent-points = construct.tangent-points
