// Extensible analytic conic models built on the generic scene API.
#import "model.typ" as m
#import "objects.typ" as o
#import "analytic.typ" as g

#let parabola(
  vertex: (0, 0),
  p: 1,
  rotation: 0deg,
  domain: (-3.5, 3.5),
  features: ("vertex", "focus", "directrix", "axis"),
) = {
  let local = t => (t, t * t / (4 * p))
  let map = q => g.add(vertex, g.rotate-point(q, rotation))
  let F = map((0, p))
  let D0 = map((-1, -p))
  let D1 = map((1, -p))
  let A0 = map((0, -2))
  let A1 = map((0, 4))
  let points = (V: vertex, F: F, D_0: D0, D_1: D1, A_0: A0, A_1: A1)
  let objects = (
    o.parametric-curve(t => map(local(t)), domain: domain, id: "parabola", role: "strong", tags: ("conic", "parabola")),
  )
  if "directrix" in features or "all" in features { objects.push(o.line("D_0", "D_1", id: "directrix", role: "construction", extend: 5)) }
  if "axis" in features or "all" in features { objects.push(o.line("A_0", "A_1", id: "axis", role: "auxiliary", extend: 3)) }
  if "vertex" in features or "all" in features { objects.push(o.point("V", role: "accent")) }
  if "focus" in features or "all" in features { objects.push(o.point("F", role: "secondary")) }
  m.model(points: points, objects: objects, meta: (kind: "parabola", p: p, rotation: rotation))
}

#let ellipse(
  center: (0, 0),
  a: 3,
  b: 2,
  rotation: 0deg,
  features: ("center", "foci", "axes", "vertices"),
) = {
  let rx = calc.abs(a)
  let ry = calc.abs(b)
  let map = q => g.add(center, g.rotate-point(q, rotation))
  let major-is-x = rx >= ry
  let major = calc.max(rx, ry)
  let minor = calc.min(rx, ry)
  let c = calc.sqrt(calc.max(0, major * major - minor * minor))
  let focus-one = if major-is-x { map((-c, 0)) } else { map((0, -c)) }
  let focus-two = if major-is-x { map((c, 0)) } else { map((0, c)) }
  let major-one = if major-is-x { map((-rx, 0)) } else { map((0, -ry)) }
  let major-two = if major-is-x { map((rx, 0)) } else { map((0, ry)) }
  let minor-one = if major-is-x { map((0, -ry)) } else { map((-rx, 0)) }
  let minor-two = if major-is-x { map((0, ry)) } else { map((rx, 0)) }
  let points = (
    O: center,
    F_1: focus-one, F_2: focus-two,
    A_1: major-one, A_2: major-two,
    B_1: minor-one, B_2: minor-two,
  )
  let objects = (
    o.parametric-curve(t => map((rx * calc.cos(t), ry * calc.sin(t))), domain: (0deg, 360deg), samples: 240, id: "ellipse", role: "strong", close: true, tags: ("conic", "ellipse")),
  )
  if "axes" in features or "all" in features {
    objects.push(o.segment("A_1", "A_2", id: "major-axis", role: "auxiliary"))
    objects.push(o.segment("B_1", "B_2", id: "minor-axis", role: "auxiliary"))
  }
  if "center" in features or "all" in features { objects.push(o.point("O", role: "accent")) }
  if "foci" in features or "all" in features { objects.push(o.point("F_1", role: "secondary")); objects.push(o.point("F_2", role: "secondary")) }
  if "vertices" in features or "all" in features {
    for name in ("A_1", "A_2", "B_1", "B_2") { objects.push(o.point(name)) }
  }
  m.model(points: points, objects: objects, meta: (kind: "ellipse", a: rx, b: ry, c: c, major-axis: if major-is-x { "x" } else { "y" }, rotation: rotation))
}

#let hyperbola(
  center: (0, 0),
  a: 2,
  b: 1.4,
  rotation: 0deg,
  t-max: 2.0,
  features: ("center", "foci", "axes", "vertices", "asymptotes"),
) = {
  let map = q => g.add(center, g.rotate-point(q, rotation))
  let c = calc.sqrt(a * a + b * b)
  let points = (
    O: center,
    F_1: map((-c, 0)), F_2: map((c, 0)),
    A_1: map((-a, 0)), A_2: map((a, 0)),
    X_1: map((-a * calc.cosh(t-max), -b * calc.sinh(t-max))),
    X_2: map((a * calc.cosh(t-max), b * calc.sinh(t-max))),
  )
  let objects = (
    o.parametric-curve(t => map((a * calc.cosh(t), b * calc.sinh(t))), domain: (-t-max, t-max), samples: 160, id: "hyperbola-right", role: "strong", tags: ("conic", "hyperbola")),
    o.parametric-curve(t => map((-a * calc.cosh(t), b * calc.sinh(t))), domain: (-t-max, t-max), samples: 160, id: "hyperbola-left", role: "strong", tags: ("conic", "hyperbola")),
  )
  if "asymptotes" in features or "all" in features {
    objects.push(o.line(map((-a, -b)), map((a, b)), id: "asymptote-1", role: "construction", extend: 4))
    objects.push(o.line(map((-a, b)), map((a, -b)), id: "asymptote-2", role: "construction", extend: 4))
  }
  if "axes" in features or "all" in features { objects.push(o.line("A_1", "A_2", id: "transverse-axis", role: "auxiliary", extend: 2)) }
  if "center" in features or "all" in features { objects.push(o.point("O", role: "accent")) }
  if "foci" in features or "all" in features { objects.push(o.point("F_1", role: "secondary")); objects.push(o.point("F_2", role: "secondary")) }
  if "vertices" in features or "all" in features { objects.push(o.point("A_1")); objects.push(o.point("A_2")) }
  m.model(points: points, objects: objects, meta: (kind: "hyperbola", a: a, b: b, c: c, rotation: rotation))
}
