// Named construction helpers that extend an existing model.
#import "model.typ" as m
#import "objects.typ" as o
#import "analytic.typ" as g

#let _point-object(name, show, role, label, tags) = if show { (o.point(name, label: label, role: role, tags: tags),) } else { () }

#let define-point(model, name, at, show: true, role: "main", label: "auto", options: (:), tags: ("constructed",)) = {
  let result = m.with-point(model, name, at, options: options)
  m.with-objects(result, _point-object(name, show, role, label, tags))
}

#let midpoint(model, name, a, b, show: true, role: "secondary", draw-segment: false) = {
  let p = g.midpoint(m.resolve(model, a), m.resolve(model, b))
  let result = define-point(model, name, p, show: show, role: role, tags: ("midpoints", "constructed"))
  if draw-segment { m.with-object(result, o.segment(a, b, id: "support-" + name, role: "auxiliary")) } else { result }
}

#let division-point(model, name, a, b, ratio: 1, internal: true, show: true, role: "secondary") = define-point(
  model,
  name,
  g.divide-segment(m.resolve(model, a), m.resolve(model, b), ratio: ratio, internal: internal),
  show: show,
  role: role,
  tags: ("division-points", "constructed"),
)

#let projection(model, name, p, a, b, show: true, role: "tertiary", draw-perpendicular: true, mark-right: true) = {
  let foot = g.projection(m.resolve(model, p), m.resolve(model, a), m.resolve(model, b))
  let result = define-point(model, name, foot, show: show, role: role, tags: ("feet", "constructed"))
  let extras = ()
  if draw-perpendicular { extras.push(o.segment(p, name, id: "perpendicular-" + name, role: "auxiliary", tags: ("perpendiculars",))) }
  if mark-right { extras.push(o.right-angle(name, p, b, id: "right-" + name, role: "auxiliary", tags: ("marks",))) }
  m.with-objects(result, extras)
}

#let reflection(model, name, p, a, b, show: true, role: "accent", draw-helper: true) = {
  let image = g.reflect(m.resolve(model, p), m.resolve(model, a), m.resolve(model, b))
  let result = define-point(model, name, image, show: show, role: role, tags: ("images", "reflection"))
  if draw-helper { m.with-object(result, o.segment(p, name, id: "reflection-helper-" + name, role: "construction")) } else { result }
}

#let rotation(model, name, p, center, angle, show: true, role: "accent", draw-helper: true) = {
  let image = g.rotate(m.resolve(model, p), center: m.resolve(model, center), angle: angle)
  let result = define-point(model, name, image, show: show, role: role, tags: ("images", "rotation"))
  let extras = ()
  if draw-helper {
    extras.push(o.segment(center, p, id: "rotation-source-" + name, role: "construction"))
    extras.push(o.segment(center, name, id: "rotation-image-" + name, role: "construction"))
  }
  m.with-objects(result, extras)
}

#let translation(model, name, p, by: (0, 0), show: true, role: "accent", draw-vector: true) = {
  let image = g.translate(m.resolve(model, p), by: by)
  let result = define-point(model, name, image, show: show, role: role, tags: ("images", "translation"))
  if draw-vector { m.with-object(result, o.vector(p, name, id: "translation-" + name, role: "accent")) } else { result }
}

#let homothety(model, name, p, center, ratio, show: true, role: "accent", draw-helper: true) = {
  let image = g.scale-from(m.resolve(model, p), center: m.resolve(model, center), ratio: ratio)
  let result = define-point(model, name, image, show: show, role: role, tags: ("images", "homothety"))
  if draw-helper { m.with-object(result, o.line(center, name, id: "homothety-line-" + name, role: "construction", extend: 1)) } else { result }
}

#let line-intersection(model, name, a, b, c, d, show: true, role: "accent") = {
  let p = g.line-intersection-points(m.resolve(model, a), m.resolve(model, b), m.resolve(model, c), m.resolve(model, d))
  if p == none { model } else { define-point(model, name, p, show: show, role: role, tags: ("intersections", "constructed")) }
}

#let circle-line-intersections(model, names, center, radius, a, b, show: true, role: "accent") = {
  let pts = g.circle-line-intersections-points(m.resolve(model, center), radius, m.resolve(model, a), m.resolve(model, b))
  let result = model
  for (i, p) in pts.enumerate() {
    if i < names.len() { result = define-point(result, names.at(i), p, show: show, role: role, tags: ("intersections", "constructed")) }
  }
  result
}

#let circle-circle-intersections(model, names, c1, r1, c2, r2, show: true, role: "accent") = {
  let pts = g.circle-circle-intersections-points(m.resolve(model, c1), r1, m.resolve(model, c2), r2)
  let result = model
  for (i, p) in pts.enumerate() {
    if i < names.len() { result = define-point(result, names.at(i), p, show: show, role: role, tags: ("intersections", "constructed")) }
  }
  result
}

#let tangent-points(model, names, center, radius, p, show: true, role: "accent", draw-tangents: true) = {
  let pts = g.tangent-points(g.circle(m.resolve(model, center), radius), m.resolve(model, p))
  let result = model
  for (i, q) in pts.enumerate() {
    if i < names.len() {
      let name = names.at(i)
      result = define-point(result, name, q, show: show, role: role, tags: ("tangent-points", "constructed"))
      if draw-tangents { result = m.with-object(result, o.segment(p, name, id: "tangent-" + name, role: "accent")) }
    }
  }
  result
}

#let perpendicular-line(model, through, a, b, id: none, role: "construction", extend: 10) = {
  let p = m.resolve(model, through)
  let d = g.perp(g.sub(m.resolve(model, b), m.resolve(model, a)))
  m.with-object(model, o.line(p, g.add(p, d), id: id, role: role, extend: extend, tags: ("constructed-lines", "perpendiculars")))
}

#let parallel-line(model, through, a, b, id: none, role: "construction", extend: 10) = {
  let p = m.resolve(model, through)
  let d = g.sub(m.resolve(model, b), m.resolve(model, a))
  m.with-object(model, o.line(p, g.add(p, d), id: id, role: role, extend: extend, tags: ("constructed-lines", "parallels")))
}

// Higher-level named constructions.
#let point-on-segment(model, name, a, b, t: 0.5, show: true, role: "secondary") = define-point(
  model,
  name,
  g.lerp(m.resolve(model, a), m.resolve(model, b), t),
  show: show,
  role: role,
  tags: ("points-on-segment", "constructed"),
)

#let barycentric-point(model, name, a, b, c, weights, show: true, role: "accent") = define-point(
  model,
  name,
  g.barycentric(m.resolve(model, a), m.resolve(model, b), m.resolve(model, c), weights),
  show: show,
  role: role,
  tags: ("barycentric-points", "constructed"),
)

#let centroid(model, name, a, b, c, show: true, role: "accent") = barycentric-point(
  model, name, a, b, c, (1, 1, 1), show: show, role: role,
)

#let incenter(model, name, a, b, c, show: true, role: "accent") = define-point(
  model,
  name,
  g.triangle-data(m.resolve(model, a), m.resolve(model, b), m.resolve(model, c)).I,
  show: show,
  role: role,
  tags: ("triangle-centers", "incenters", "constructed"),
)

#let circumcenter(model, name, a, b, c, show: true, role: "accent") = {
  let center = g.triangle-data(m.resolve(model, a), m.resolve(model, b), m.resolve(model, c)).O
  if center == none { model }
  else { define-point(model, name, center, show: show, role: role, tags: ("triangle-centers", "circumcenters", "constructed")) }
}

#let orthocenter(model, name, a, b, c, show: true, role: "accent") = {
  let center = g.triangle-data(m.resolve(model, a), m.resolve(model, b), m.resolve(model, c)).H
  if center == none { model }
  else { define-point(model, name, center, show: show, role: role, tags: ("triangle-centers", "orthocenters", "constructed")) }
}

#let angle-bisector-foot(model, name, vertex, a, b, show: true, role: "secondary") = {
  let p = m.resolve(model, vertex)
  let q = m.resolve(model, a)
  let r = m.resolve(model, b)
  let l = g.angle-bisector-line(q, p, r)
  let foot = g.intersect-lines(l, g.line(q, r))
  if foot == none { model }
  else { define-point(model, name, foot, show: show, role: role, tags: ("bisector-feet", "constructed")) }
}

#let circumcircle(
  model,
  center-name,
  a,
  b,
  c,
  id: "constructed-circumcircle",
  show-center: true,
  role: "accent",
  center-role: "accent",
) = {
  let data = g.circle-through-three(m.resolve(model, a), m.resolve(model, b), m.resolve(model, c))
  if data == none { model }
  else {
    let result = define-point(model, center-name, data.center, show: show-center, role: center-role, tags: ("triangle-centers", "constructed"))
    m.with-object(result, o.circle(center-name, data.radius, id: id, role: role, tags: ("circles", "constructed")))
  }
}

#let incircle(
  model,
  center-name,
  a,
  b,
  c,
  id: "constructed-incircle",
  show-center: true,
  role: "secondary",
  center-role: "secondary",
) = {
  let data = g.triangle-data(m.resolve(model, a), m.resolve(model, b), m.resolve(model, c))
  let result = define-point(model, center-name, data.I, show: show-center, role: center-role, tags: ("triangle-centers", "constructed"))
  m.with-object(result, o.circle(center-name, data.incircle.radius, id: id, role: role, tags: ("circles", "constructed")))
}

#let excenter(model, name, a, b, c, which: "a", show: true, role: "construction") = {
  let data = g.triangle-data(m.resolve(model, a), m.resolve(model, b), m.resolve(model, c))
  let center = if which == "a" { data.I_a } else if which == "b" { data.I_b } else { data.I_c }
  define-point(model, name, center, show: show, role: role, tags: ("triangle-centers", "excenters", "constructed"))
}

#let inversion(model, name, p, center, radius, show: true, role: "accent", draw-helper: true) = {
  let image = g.invert-point(m.resolve(model, p), center: m.resolve(model, center), radius: radius)
  if image == none { model }
  else {
    let result = define-point(model, name, image, show: show, role: role, tags: ("images", "inversion"))
    if draw-helper { m.with-object(result, o.ray(center, p, id: "inversion-ray-" + name, role: "construction", extend: 1)) } else { result }
  }
}

#let radical-axis(
  model,
  center-one,
  radius-one,
  center-two,
  radius-two,
  id: "radical-axis",
  role: "tertiary",
  extend: 5,
) = {
  let c1 = g.circle(m.resolve(model, center-one), radius-one)
  let c2 = g.circle(m.resolve(model, center-two), radius-two)
  let equation = g.radical-axis(c1, c2)
  if calc.abs(equation.a) <= g.eps and calc.abs(equation.b) <= g.eps { model }
  else {
    let l = g.equation-to-line(equation)
    m.with-object(model, o.line(l.p, l.q, id: id, role: role, extend: extend, tags: ("radical-axes", "constructed-lines")))
  }
}
