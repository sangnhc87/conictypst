// Extensible figure builders. They return models instead of hard-coded canvas content.
#import "model.typ" as m
#import "objects.typ" as o
#import "analytic.typ" as g

#let _has(features, name) = name in features or "all" in features
#let _point-objects(names, role: "main", layer: 40) = names.map(name => o.point(name, role: role, layer: layer, tags: ("points",)))

#let triangle(
  A: (-2.2, -1.2),
  B: (2.3, -1.2),
  C: (0.4, 2.2),
  features: ("vertices",),
  fill-role: "none",
  point-options: (:),
  meta: (:),
) = {
  let d = g.triangle-data(A, B, C)
  let points = (
    A: A, B: B, C: C,
    M_a: d.M_a, M_b: d.M_b, M_c: d.M_c,
    H_a: d.H_a, H_b: d.H_b, H_c: d.H_c,
    T_a: d.T_a, T_b: d.T_b, T_c: d.T_c,
    G: d.G, O: d.O, I: d.I, H: d.H, N: d.N,
    I_a: d.I_a, I_b: d.I_b, I_c: d.I_c,
    K: d.K, Ge: d.Ge, Na: d.Na, S: d.S, Be: d.Be, L: d.L,
  )
  let objects = (
    o.polygon(("A", "B", "C"), id: "triangle", role: "strong", fill-role: fill-role, tags: ("sides", "triangle")),
  )

  if _has(features, "medians") {
    objects.push(o.segment("A", "M_a", id: "median-a", role: "auxiliary", tags: ("medians",)))
    objects.push(o.segment("B", "M_b", id: "median-b", role: "auxiliary", tags: ("medians",)))
    objects.push(o.segment("C", "M_c", id: "median-c", role: "auxiliary", tags: ("medians",)))
  }
  if _has(features, "altitudes") {
    objects.push(o.segment("A", "H_a", id: "altitude-a", role: "auxiliary", tags: ("altitudes",)))
    objects.push(o.segment("B", "H_b", id: "altitude-b", role: "auxiliary", tags: ("altitudes",)))
    objects.push(o.segment("C", "H_c", id: "altitude-c", role: "auxiliary", tags: ("altitudes",)))
    objects.push(o.right-angle("H_a", "A", "C", id: "right-ha", role: "auxiliary", tags: ("altitudes", "marks")))
    objects.push(o.right-angle("H_b", "B", "A", id: "right-hb", role: "auxiliary", tags: ("altitudes", "marks")))
    objects.push(o.right-angle("H_c", "C", "B", id: "right-hc", role: "auxiliary", tags: ("altitudes", "marks")))
  }
  if _has(features, "angle-bisectors") {
    objects.push(o.segment("A", "I", id: "bisector-a", role: "auxiliary", tags: ("bisectors",)))
    objects.push(o.segment("B", "I", id: "bisector-b", role: "auxiliary", tags: ("bisectors",)))
    objects.push(o.segment("C", "I", id: "bisector-c", role: "auxiliary", tags: ("bisectors",)))
  }
  if _has(features, "perpendicular-bisectors") {
    for item in (("A", "B", "M_c"), ("B", "C", "M_a"), ("C", "A", "M_b")) {
      let p = points.at(item.at(0))
      let q = points.at(item.at(1))
      let mid = points.at(item.at(2))
      let n = g.perp(g.direction(p, q))
      objects.push(o.line(g.sub(mid, n), g.add(mid, n), id: "perp-bisector-" + item.at(2), role: "construction", tags: ("perpendicular-bisectors",)))
    }
  }
  if _has(features, "midpoints") or _has(features, "medial-triangle") {
    objects += _point-objects(("M_a", "M_b", "M_c"), role: "secondary")
  }
  if _has(features, "feet") or _has(features, "orthic-triangle") {
    objects += _point-objects(("H_a", "H_b", "H_c"), role: "tertiary")
  }
  if _has(features, "contact-points") or _has(features, "contact-triangle") {
    objects += _point-objects(("T_a", "T_b", "T_c"), role: "secondary")
  }
  if _has(features, "medial-triangle") {
    objects.push(o.polygon(("M_a", "M_b", "M_c"), id: "medial-triangle", role: "secondary", fill-role: "none", tags: ("derived-triangles",)))
  }
  if _has(features, "orthic-triangle") {
    objects.push(o.polygon(("H_a", "H_b", "H_c"), id: "orthic-triangle", role: "tertiary", fill-role: "none", tags: ("derived-triangles",)))
  }
  if _has(features, "contact-triangle") {
    objects.push(o.polygon(("T_a", "T_b", "T_c"), id: "contact-triangle", role: "secondary", fill-role: "none", tags: ("derived-triangles",)))
  }
  if _has(features, "excentral-triangle") {
    objects.push(o.polygon(("I_a", "I_b", "I_c"), id: "excentral-triangle", role: "construction", fill-role: "none", tags: ("derived-triangles",)))
    objects += _point-objects(("I_a", "I_b", "I_c"), role: "construction")
  }
  if _has(features, "incircle") {
    objects.push(o.circle("I", d.incircle.radius, id: "incircle", role: "secondary", tags: ("circles",)))
  }
  if _has(features, "circumcircle") and d.circumcircle != none {
    objects.push(o.circle("O", d.circumcircle.radius, id: "circumcircle", role: "accent", tags: ("circles",)))
  }
  if _has(features, "nine-point-circle") and d.N != none and d.circumcircle != none {
    objects.push(o.circle("N", d.circumcircle.radius / 2, id: "nine-point-circle", role: "tertiary", tags: ("circles",)))
  }
  if _has(features, "advanced-centers") {
    objects += _point-objects(("K", "Ge", "Na", "S"), role: "accent")
    if d.Be != none { objects.push(o.point("Be", role: "secondary", tags: ("advanced-centers",))) }
    if d.L != none { objects.push(o.point("L", role: "tertiary", tags: ("advanced-centers",))) }
  }
  if _has(features, "gergonne-cevians") {
    objects.push(o.segment("A", "T_a", id: "gergonne-a", role: "auxiliary", tags: ("cevians",)))
    objects.push(o.segment("B", "T_b", id: "gergonne-b", role: "auxiliary", tags: ("cevians",)))
    objects.push(o.segment("C", "T_c", id: "gergonne-c", role: "auxiliary", tags: ("cevians",)))
    objects.push(o.point("Ge", role: "accent", tags: ("advanced-centers",)))
  }

  if _has(features, "excircles") {
    let ca = g.triangle-excircle(d, which: "a")
    let cb = g.triangle-excircle(d, which: "b")
    let cc = g.triangle-excircle(d, which: "c")
    objects.push(o.circle("I_a", ca.radius, id: "excircle-a", role: "construction", tags: ("circles", "excircles")))
    objects.push(o.circle("I_b", cb.radius, id: "excircle-b", role: "construction", tags: ("circles", "excircles")))
    objects.push(o.circle("I_c", cc.radius, id: "excircle-c", role: "construction", tags: ("circles", "excircles")))
  }
  if _has(features, "euler-line") and d.O != none and d.H != none {
    objects.push(o.line("O", "H", id: "euler-line", role: "tertiary", tags: ("notable-lines",)))
  }
  if _has(features, "centers") or _has(features, "medians") { objects.push(o.point("G", role: "accent", tags: ("centers",))) }
  if (_has(features, "centers") or _has(features, "circumcircle") or _has(features, "euler-line")) and d.O != none { objects.push(o.point("O", role: "accent", tags: ("centers",))) }
  if _has(features, "centers") or _has(features, "incircle") or _has(features, "angle-bisectors") { objects.push(o.point("I", role: "secondary", tags: ("centers",))) }
  if (_has(features, "centers") or _has(features, "altitudes") or _has(features, "euler-line")) and d.H != none { objects.push(o.point("H", role: "tertiary", tags: ("centers",))) }
  if (_has(features, "centers") or _has(features, "nine-point-circle")) and d.N != none { objects.push(o.point("N", role: "tertiary", tags: ("centers",))) }
  if _has(features, "vertices") { objects += _point-objects(("A", "B", "C"), role: "main") }

  m.model(
    points: points,
    objects: objects,
    point-options: point-options,
    meta: (kind: "triangle", data: d) + meta,
  )
}

#let right-triangle(
  A: (0, 0),
  B: (4, 0),
  C: (0, 3),
  features: ("vertices", "right-angle"),
  fill-role: "none",
  point-options: (:),
) = {
  let result = triangle(A: A, B: B, C: C, features: features, fill-role: fill-role, point-options: point-options)
  if _has(features, "right-angle") {
    m.with-object(result, o.right-angle("A", "B", "C", id: "right-angle-A", role: "main", tags: ("marks",)))
  } else { result }
}

#let equilateral-triangle(
  side: 4,
  center: (0, 0),
  rotation: 0deg,
  features: ("vertices", "equal-sides"),
  fill-role: "none",
) = {
  let h = side * calc.sqrt(3) / 2
  let A0 = (-side / 2, -h / 3)
  let B0 = (side / 2, -h / 3)
  let C0 = (0, 2 * h / 3)
  let move = p => g.add(center, g.rotate-point(p, rotation))
  let result = triangle(A: move(A0), B: move(B0), C: move(C0), features: features, fill-role: fill-role)
  if _has(features, "equal-sides") {
    m.with-objects(result, (
      o.ticks("A", "B", id: "tick-ab", count: 1),
      o.ticks("B", "C", id: "tick-bc", count: 1),
      o.ticks("C", "A", id: "tick-ca", count: 1),
    ))
  } else { result }
}

#let isosceles-triangle(
  base: 4,
  height: 3.5,
  center: (0, 0),
  features: ("vertices", "equal-sides"),
  fill-role: "none",
) = {
  let A = g.add(center, (-base / 2, -height / 3))
  let B = g.add(center, (base / 2, -height / 3))
  let C = g.add(center, (0, 2 * height / 3))
  let result = triangle(A: A, B: B, C: C, features: features, fill-role: fill-role)
  if _has(features, "equal-sides") {
    m.with-objects(result, (
      o.ticks("A", "C", id: "tick-ac", count: 1),
      o.ticks("B", "C", id: "tick-bc", count: 1),
    ))
  } else { result }
}

#let quadrilateral(
  A: (-2.4, -1.2),
  B: (2.2, -1.1),
  C: (1.5, 2.0),
  D: (-1.7, 1.7),
  features: ("vertices",),
  fill-role: "none",
  point-options: (:),
  meta: (:),
) = {
  let E = g.line-intersection-points(A, C, B, D)
  let points = (
    A: A, B: B, C: C, D: D,
    M_ab: g.midpoint(A, B), M_bc: g.midpoint(B, C), M_cd: g.midpoint(C, D), M_da: g.midpoint(D, A),
    E: E,
  )
  let objects = (o.polygon(("A", "B", "C", "D"), id: "quadrilateral", role: "strong", fill-role: fill-role, tags: ("sides", "quadrilateral")),)
  if _has(features, "diagonals") {
    objects.push(o.segment("A", "C", id: "diagonal-ac", role: "auxiliary", tags: ("diagonals",)))
    objects.push(o.segment("B", "D", id: "diagonal-bd", role: "auxiliary", tags: ("diagonals",)))
  }
  if _has(features, "midpoints") { objects += _point-objects(("M_ab", "M_bc", "M_cd", "M_da"), role: "secondary") }
  if _has(features, "diagonal-intersection") and E != none { objects.push(o.point("E", role: "accent", tags: ("intersections",))) }
  if _has(features, "vertices") { objects += _point-objects(("A", "B", "C", "D")) }
  m.model(points: points, objects: objects, point-options: point-options, meta: (kind: "quadrilateral",) + meta)
}

#let rectangle(width: 4, height: 2.5, center: (0, 0), features: ("vertices",), fill-role: "none") = quadrilateral(
  A: g.add(center, (-width / 2, -height / 2)),
  B: g.add(center, (width / 2, -height / 2)),
  C: g.add(center, (width / 2, height / 2)),
  D: g.add(center, (-width / 2, height / 2)),
  features: features,
  fill-role: fill-role,
  meta: (subkind: "rectangle", width: width, height: height),
)

#let square(side: 3, center: (0, 0), features: ("vertices", "diagonals"), fill-role: "none") = rectangle(width: side, height: side, center: center, features: features, fill-role: fill-role)

#let parallelogram(base: 4, side-vector: (1.2, 2.4), center: (0, 0), features: ("vertices",), fill-role: "none") = {
  let A = g.add(center, g.mul(-0.5, g.add((base, 0), side-vector)))
  let B = g.add(A, (base, 0))
  let D = g.add(A, side-vector)
  let C = g.add(B, side-vector)
  quadrilateral(A: A, B: B, C: C, D: D, features: features, fill-role: fill-role, meta: (subkind: "parallelogram",))
}

#let rhombus(diagonal-x: 4.5, diagonal-y: 3, center: (0, 0), features: ("vertices", "diagonals"), fill-role: "none") = quadrilateral(
  A: g.add(center, (-diagonal-x / 2, 0)),
  B: g.add(center, (0, -diagonal-y / 2)),
  C: g.add(center, (diagonal-x / 2, 0)),
  D: g.add(center, (0, diagonal-y / 2)),
  features: features,
  fill-role: fill-role,
  meta: (subkind: "rhombus",),
)

#let trapezoid(bottom: 5, top: 2.8, height: 2.5, offset: 0.8, center: (0, 0), features: ("vertices",), fill-role: "none") = quadrilateral(
  A: g.add(center, (-bottom / 2, -height / 2)),
  B: g.add(center, (bottom / 2, -height / 2)),
  C: g.add(center, (offset + top / 2, height / 2)),
  D: g.add(center, (offset - top / 2, height / 2)),
  features: features,
  fill-role: fill-role,
  meta: (subkind: "trapezoid",),
)

#let kite(width: 4, upper: 2.4, lower: 1.6, center: (0, 0), features: ("vertices", "diagonals"), fill-role: "none") = quadrilateral(
  A: g.add(center, (-width / 2, 0)),
  B: g.add(center, (0, -lower)),
  C: g.add(center, (width / 2, 0)),
  D: g.add(center, (0, upper)),
  features: features,
  fill-role: fill-role,
  meta: (subkind: "kite",),
)

#let regular-polygon(n: 5, center: (0, 0), radius: 2.5, start-angle: 90deg, features: ("vertices",), fill-role: "none") = {
  let raw = g.regular-polygon(n, center: center, radius: radius, start-angle: start-angle)
  let points = (:)
  let refs = ()
  for i in range(n) {
    let name = "P_" + str(i + 1)
    points.insert(name, raw.at(i))
    refs.push(name)
  }
  points.insert("O", center)
  let objects = (o.polygon(refs, id: "regular-polygon", role: "strong", fill-role: fill-role, tags: ("polygon",)),)
  if _has(features, "radii") {
    for name in refs { objects.push(o.segment("O", name, role: "auxiliary", tags: ("radii",))) }
  }
  if _has(features, "circumcircle") { objects.push(o.circle("O", radius, id: "circumcircle", role: "accent", tags: ("circles",))) }
  if _has(features, "center") { objects.push(o.point("O", role: "accent", tags: ("centers",))) }
  if _has(features, "vertices") { objects += _point-objects(refs) }
  m.model(points: points, objects: objects, meta: (kind: "regular-polygon", n: n, radius: radius))
}

#let circle(
  O: (0, 0),
  radius: 2.5,
  angles: (),
  features: ("center",),
  fill-role: "none",
  point-prefix: "P",
) = {
  let points = (O: O)
  let refs = ()
  for (i, angle) in angles.enumerate() {
    let name = point-prefix + "_" + str(i + 1)
    points.insert(name, (O.at(0) + radius * calc.cos(angle), O.at(1) + radius * calc.sin(angle)))
    refs.push(name)
  }
  let objects = (o.circle("O", radius, id: "circle", role: "strong", fill-role: fill-role, tags: ("circle",)),)
  if _has(features, "radii") { for name in refs { objects.push(o.segment("O", name, role: "auxiliary", tags: ("radii",))) } }
  if _has(features, "polygon") and refs.len() >= 3 { objects.push(o.polygon(refs, id: "inscribed-polygon", role: "secondary", tags: ("inscribed",))) }
  if _has(features, "center") { objects.push(o.point("O", role: "accent", tags: ("center",))) }
  if _has(features, "points") { objects += _point-objects(refs) }
  m.model(points: points, objects: objects, meta: (kind: "circle", radius: radius, point-names: refs))
}

#let coordinate-plane(x-range: (-5, 5), y-range: (-5, 5), grid-step: 1, axes: true, grid: true) = {
  let objects = ()
  if grid { objects.push(o.grid(x-range: x-range, y-range: y-range, step: grid-step)) }
  if axes { objects.push(o.axes(x-range: x-range, y-range: y-range, tick-step: grid-step)) }
  m.model(objects: objects, meta: (kind: "coordinate-plane", x-range: x-range, y-range: y-range))
}
