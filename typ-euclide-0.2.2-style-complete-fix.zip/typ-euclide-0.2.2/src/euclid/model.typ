// Reusable named-geometry model. A model contains named points and drawable objects.
#import "../core.typ" as geo

#let model(
  points: (:),
  objects: (),
  point-options: (:),
  meta: (:),
  styles: (:),
) = (
  points: points,
  objects: objects,
  point-options: point-options,
  meta: meta,
  styles: styles,
)

#let empty-model() = model()

#let point-at(m, name, default: none) = m.points.at(name, default: default)
#let has-point(m, name) = name in m.points
#let point-names(m) = m.points.keys()
#let point-pairs(m) = m.points.pairs()
#let object-list(m) = m.objects
#let object-at(m, id, default: none) = {
  let found = m.objects.find(o => o.at("id", default: none) == id)
  if found == none { default } else { found }
}
#let objects-with-tag(m, tag) = m.objects.filter(o => tag in o.at("tags", default: ()))
#let objects-of-kind(m, kind) = m.objects.filter(o => o.at("kind", default: none) == kind)
#let metadata(m, key, default: none) = m.meta.at(key, default: default)

#let resolve(m, value) = {
  if type(value) == str {
    point-at(m, value)
  } else {
    value
  }
}

#let resolve-many(m, values) = values.map(v => resolve(m, v))

#let extend(
  m,
  points: (:),
  objects: (),
  point-options: (:),
  meta: (:),
  styles: (:),
) = model(
  points: m.points + points,
  objects: m.objects + objects,
  point-options: m.point-options + point-options,
  meta: m.meta + meta,
  styles: m.styles + styles,
)

#let with-point(m, name, at, options: (:)) = {
  let pts = m.points
  pts.insert(name, at)
  let opts = m.point-options
  if options.len() > 0 { opts.insert(name, options) }
  model(points: pts, objects: m.objects, point-options: opts, meta: m.meta, styles: m.styles)
}

#let with-points(m, points, point-options: (:)) = extend(m, points: points, point-options: point-options)
#let alias-point(m, alias, source, options: (:)) = with-point(m, alias, resolve(m, source), options: options)
#let with-point-option(m, name, options) = {
  let all = m.point-options
  all.insert(name, all.at(name, default: (:)) + options)
  model(points: m.points, objects: m.objects, point-options: all, meta: m.meta, styles: m.styles)
}
#let with-meta(m, meta) = model(points: m.points, objects: m.objects, point-options: m.point-options, meta: m.meta + meta, styles: m.styles)
#let with-style(m, styles) = model(points: m.points, objects: m.objects, point-options: m.point-options, meta: m.meta, styles: m.styles + styles)
#let merge-models(left, right) = model(
  points: left.points + right.points,
  objects: left.objects + right.objects,
  point-options: left.point-options + right.point-options,
  meta: left.meta + right.meta,
  styles: left.styles + right.styles,
)
#let with-object(m, object) = extend(m, objects: (object,))
#let with-objects(m, objects) = extend(m, objects: objects)

#let without-object(m, id) = model(
  points: m.points,
  objects: m.objects.filter(o => o.at("id", default: none) != id),
  point-options: m.point-options,
  meta: m.meta,
  styles: m.styles,
)

#let map-objects(m, transform) = model(
  points: m.points,
  objects: m.objects.map(transform),
  point-options: m.point-options,
  meta: m.meta,
  styles: m.styles,
)

#let patch-object(m, id, patch) = model(
  points: m.points,
  objects: m.objects.map(o => if o.at("id", default: none) == id { o + patch } else { o }),
  point-options: m.point-options,
  meta: m.meta,
  styles: m.styles,
)

#let patch-objects(m, ids, patch) = map-objects(m, o => if o.at("id", default: none) in ids { o + patch } else { o })
#let patch-kind(m, kind, patch) = map-objects(m, o => if o.at("kind", default: none) == kind { o + patch } else { o })

#let patch-tag(m, tag, patch) = model(
  points: m.points,
  objects: m.objects.map(o => if tag in o.at("tags", default: ()) { o + patch } else { o }),
  point-options: m.point-options,
  meta: m.meta,
  styles: m.styles,
)

#let hide-object(m, id) = patch-object(m, id, (visible: false,))
#let show-object(m, id) = patch-object(m, id, (visible: true,))

#let map-points(m, transform) = {
  let points = (:)
  for pair in m.points.pairs() {
    points.insert(pair.at(0), if pair.at(1) == none { none } else { transform(pair.at(1)) })
  }
  model(
    points: points,
    objects: m.objects,
    point-options: m.point-options,
    meta: m.meta,
    styles: m.styles,
  )
}

#let translate(m, by: (0, 0)) = map-points(m, p => geo.translate-point(p, by: by))
#let rotate(m, angle, center: (0, 0)) = map-points(m, p => geo.rotate-point(p, angle, center: center))
#let scale(m, ratio, center: (0, 0)) = map-points(m, p => geo.homothety(p, center: center, ratio: ratio))
#let reflect(m, a, b) = map-points(m, p => geo.reflect-point-line(p, a, b))

#let bounds(m, padding: 0.5) = {
  let values = m.points.values().filter(p => p != none)
  if values.len() == 0 {
    (x: (-1, 1), y: (-1, 1))
  } else {
    let xs = values.map(p => p.at(0))
    let ys = values.map(p => p.at(1))
    (
      x: (calc.min(..xs) - padding, calc.max(..xs) + padding),
      y: (calc.min(..ys) - padding, calc.max(..ys) + padding),
    )
  }
}

#let validate(m) = {
  let errors = ()
  for o in m.objects {
    let kind = o.at("kind", default: none)
    if kind == none { errors.push("Object is missing kind") }
    for key in ("a", "b", "center", "vertex", "through") {
      let ref = o.at(key, default: none)
      if type(ref) == str and not (ref in m.points) {
        errors.push("Unknown point '" + ref + "' in object " + str(o.at("id", default: "<unnamed>")))
      }
    }
    let point-at-ref = o.at("at", default: none)
    if type(point-at-ref) == str and not (point-at-ref in m.points) {
      errors.push("Unknown point '" + point-at-ref + "' in object " + str(o.at("id", default: "<unnamed>")))
    }
    let refs = o.at("points", default: ())
    for ref in refs {
      if type(ref) == str and not (ref in m.points) {
        errors.push("Unknown point '" + ref + "' in object " + str(o.at("id", default: "<unnamed>")))
      }
    }
  }
  errors
}
