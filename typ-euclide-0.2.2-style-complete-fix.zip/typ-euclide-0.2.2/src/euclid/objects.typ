// Declarative drawable-object constructors.
#let _base(kind, id: none, role: "main", layer: 0, visible: true, tags: ()) = (
  kind: kind,
  id: id,
  role: role,
  layer: layer,
  visible: visible,
  tags: tags,
)

#let point(name, label: "auto", role: "main", layer: 40, offset: none, anchor: none, radius: none, fill: none, stroke: none, tags: ()) = _base("point", id: "point-" + name, role: role, layer: layer, tags: tags) + (
  at: name,
  name: name,
  label: label,
  offset: offset,
  anchor: anchor,
  radius: radius,
  fill: fill,
  stroke: stroke,
)

#let label(at, body, id: none, role: "main", layer: 50, offset: (0, 0), anchor: "center", angle: 0deg, padding: 0pt, tags: ()) = _base("label", id: id, role: role, layer: layer, tags: tags) + (
  at: at,
  body: body,
  offset: offset,
  anchor: anchor,
  angle: angle,
  padding: padding,
)

#let segment(a, b, id: none, role: "main", layer: 0, stroke: none, mark: none, tags: ()) = _base("segment", id: id, role: role, layer: layer, tags: tags) + (
  a: a, b: b, stroke: stroke, mark: mark,
)

#let line(a, b, id: none, role: "main", layer: 0, extend: 10, stroke: none, tags: ()) = _base("line", id: id, role: role, layer: layer, tags: tags) + (
  a: a, b: b, extend: extend, stroke: stroke,
)

#let ray(a, b, id: none, role: "main", layer: 0, extend: 10, stroke: none, mark: "stealth", tags: ()) = _base("ray", id: id, role: role, layer: layer, tags: tags) + (
  a: a, b: b, extend: extend, stroke: stroke, mark: mark,
)

#let vector(a, b, id: none, role: "strong", layer: 0, stroke: none, label: none, tags: ()) = _base("vector", id: id, role: role, layer: layer, tags: tags) + (
  a: a, b: b, stroke: stroke, label: label,
)

#let polyline(points, id: none, role: "main", layer: 0, close: false, stroke: none, fill: none, fill-role: "none", tags: ()) = _base("polyline", id: id, role: role, layer: layer, tags: tags) + (
  points: points,
  close: close,
  stroke: stroke,
  fill: fill,
  fill-role: fill-role,
)

#let polygon(points, id: none, role: "main", layer: -10, stroke: none, fill: none, fill-role: "none", tags: ()) = polyline(
  points,
  id: id,
  role: role,
  layer: layer,
  close: true,
  stroke: stroke,
  fill: fill,
  fill-role: fill-role,
  tags: tags,
) + (kind: "polygon",)

#let circle(center, radius, id: none, role: "main", layer: 0, stroke: none, fill: none, fill-role: "none", tags: ()) = _base("circle", id: id, role: role, layer: layer, tags: tags) + (
  center: center,
  radius: radius,
  stroke: stroke,
  fill: fill,
  fill-role: fill-role,
)

#let circle-through(center, through, id: none, role: "main", layer: 0, stroke: none, fill: none, fill-role: "none", tags: ()) = _base("circle-through", id: id, role: role, layer: layer, tags: tags) + (
  center: center,
  through: through,
  stroke: stroke,
  fill: fill,
  fill-role: fill-role,
)

#let arc(center, radius, start, stop, id: none, role: "main", layer: 0, stroke: none, fill: none, fill-role: "none", mode: "OPEN", tags: ()) = _base("arc", id: id, role: role, layer: layer, tags: tags) + (
  center: center,
  radius: radius,
  start: start,
  stop: stop,
  stroke: stroke,
  fill: fill,
  fill-role: fill-role,
  mode: mode,
)

#let ellipse(center, rx, ry, id: none, role: "main", layer: 0, stroke: none, fill: none, fill-role: "none", tags: ()) = _base("ellipse", id: id, role: role, layer: layer, tags: tags) + (
  center: center,
  rx: rx,
  ry: ry,
  stroke: stroke,
  fill: fill,
  fill-role: fill-role,
)

#let angle(vertex, a, b, id: none, role: "main", layer: 20, radius: none, label: none, stroke: none, fill: none, reflex: false, tags: ()) = _base("angle", id: id, role: role, layer: layer, tags: tags) + (
  vertex: vertex,
  a: a,
  b: b,
  radius: radius,
  label: label,
  stroke: stroke,
  fill: fill,
  reflex: reflex,
)

#let right-angle(vertex, a, b, id: none, role: "main", layer: 20, size: 0.28, stroke: none, fill: none, tags: ()) = _base("right-angle", id: id, role: role, layer: layer, tags: tags) + (
  vertex: vertex,
  a: a,
  b: b,
  size: size,
  stroke: stroke,
  fill: fill,
)

#let ticks(a, b, id: none, role: "main", layer: 20, count: 1, size: 0.12, gap: 0.10, stroke: none, tags: ()) = _base("ticks", id: id, role: role, layer: layer, tags: tags) + (
  a: a,
  b: b,
  count: count,
  size: size,
  gap: gap,
  stroke: stroke,
)

#let parallel(a, b, id: none, role: "main", layer: 20, count: 1, size: 0.14, gap: 0.11, stroke: none, tags: ()) = _base("parallel", id: id, role: role, layer: layer, tags: tags) + (
  a: a,
  b: b,
  count: count,
  size: size,
  gap: gap,
  stroke: stroke,
)

#let grid(x-range: (-5, 5), y-range: (-5, 5), step: 1, id: "grid", role: "construction", layer: -100, tags: ()) = _base("grid", id: id, role: role, layer: layer, tags: tags) + (
  x-range: x-range,
  y-range: y-range,
  step: step,
)

#let axes(x-range: (-5, 5), y-range: (-5, 5), id: "axes", role: "main", layer: -90, ticks: true, tick-step: 1, x-label: $x$, y-label: $y$, tags: ()) = _base("axes", id: id, role: role, layer: layer, tags: tags) + (
  x-range: x-range,
  y-range: y-range,
  ticks: ticks,
  tick-step: tick-step,
  x-label: x-label,
  y-label: y-label,
)

#let function-curve(f, domain: (-5, 5), samples: 180, id: none, role: "main", layer: 0, stroke: none, tags: ()) = _base("function-curve", id: id, role: role, layer: layer, tags: tags) + (
  f: f,
  domain: domain,
  samples: samples,
  stroke: stroke,
)

#let parametric-curve(f, domain: (0, 1), samples: 180, id: none, role: "main", layer: 0, stroke: none, close: false, fill: none, fill-role: "none", tags: ()) = _base("parametric-curve", id: id, role: role, layer: layer, tags: tags) + (
  f: f,
  domain: domain,
  samples: samples,
  stroke: stroke,
  close: close,
  fill: fill,
  fill-role: fill-role,
)
