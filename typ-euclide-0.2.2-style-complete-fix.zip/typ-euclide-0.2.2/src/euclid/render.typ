// Generic renderer for named Euclidean models.
#import "@preview/cetz:0.5.2": canvas, draw
#import "../core.typ" as geo
#import "../primitives.typ" as primitive
#import "../marks.typ" as marks
#import "style.typ" as estyle
#import "model.typ" as models

#let _label-content(value) = {
  if value == none { none }
  else if type(value) == str { eval("$" + value + "$") }
  else { value }
}

#let _point-options(m, name) = m.point-options.at(name, default: (:))

#let draw-object(m, object, style: estyle.euclid-theme()) = {
  if not object.at("visible", default: true) { return }

  let kind = object.at("kind")
  let role = object.at("role", default: "main")
  let stroke = estyle.stroke-for(style, role: role, override: object.at("stroke", default: none))
  let fill = estyle.fill-for(
    style,
    role: object.at("fill-role", default: "none"),
    override: object.at("fill", default: none),
  )

  if kind == "segment" {
    let a = models.resolve(m, object.a)
    let b = models.resolve(m, object.b)
    let mark = object.at("mark", default: none)
    if mark == none { draw.line(a, b, stroke: stroke) }
    else { draw.line(a, b, stroke: stroke, mark: mark) }
  } else if kind == "line" {
    let a = models.resolve(m, object.a)
    let b = models.resolve(m, object.b)
    let u = geo.direction(a, b)
    let e = object.at("extend", default: 10)
    draw.line(geo.sub(a, geo.mul(e, u)), geo.add(b, geo.mul(e, u)), stroke: stroke)
  } else if kind == "ray" {
    let a = models.resolve(m, object.a)
    let b = models.resolve(m, object.b)
    let u = geo.direction(a, b)
    let e = object.at("extend", default: 10)
    draw.line(a, geo.add(b, geo.mul(e, u)), stroke: stroke, mark: (end: object.at("mark", default: "stealth")))
  } else if kind == "vector" {
    let a = models.resolve(m, object.a)
    let b = models.resolve(m, object.b)
    draw.line(a, b, stroke: stroke, mark: (end: "stealth"))
    let body = object.at("label", default: none)
    if body != none {
      primitive.draw-label(geo.midpoint(a, b), body, offset: (0, 0.14), anchor: "south", style: style)
    }
  } else if kind == "polyline" or kind == "polygon" {
    let pts = models.resolve-many(m, object.points)
    draw.line(..pts, close: object.at("close", default: kind == "polygon"), stroke: stroke, fill: fill)
  } else if kind == "function-curve" {
    let domain = object.at("domain", default: (-5, 5))
    let samples = object.at("samples", default: 180)
    let f = object.at("f")
    let pts = range(samples + 1).map(i => {
      let t = i / samples
      let x = domain.at(0) + t * (domain.at(1) - domain.at(0))
      (x, f(x))
    })
    draw.line(..pts, stroke: stroke)
  } else if kind == "parametric-curve" {
    let domain = object.at("domain", default: (0, 1))
    let samples = object.at("samples", default: 180)
    let f = object.at("f")
    let pts = range(samples + 1).map(i => {
      let t = domain.at(0) + i / samples * (domain.at(1) - domain.at(0))
      f(t)
    })
    draw.line(..pts, close: object.at("close", default: false), stroke: stroke, fill: fill)
  } else if kind == "circle" {
    draw.circle(models.resolve(m, object.center), radius: object.radius, stroke: stroke, fill: fill)
  } else if kind == "circle-through" {
    let center = models.resolve(m, object.center)
    let through = models.resolve(m, object.through)
    draw.circle(center, radius: geo.distance(center, through), stroke: stroke, fill: fill)
  } else if kind == "ellipse" {
    draw.circle(models.resolve(m, object.center), radius: (object.rx, object.ry), stroke: stroke, fill: fill)
  } else if kind == "arc" {
    let center = models.resolve(m, object.center)
    draw.arc(
      geo.arc-start(center, object.radius, object.start),
      radius: object.radius,
      start: object.start,
      stop: object.stop,
      mode: object.at("mode", default: "OPEN"),
      stroke: stroke,
      fill: fill,
    )
  } else if kind == "angle" {
    marks.angle-mark(
      models.resolve(m, object.vertex),
      models.resolve(m, object.a),
      models.resolve(m, object.b),
      radius: object.at("radius", default: none),
      label: object.at("label", default: none),
      style: style,
      stroke: stroke,
      fill: fill,
      reflex: object.at("reflex", default: false),
    )
  } else if kind == "right-angle" {
    marks.right-angle(
      models.resolve(m, object.vertex),
      models.resolve(m, object.a),
      models.resolve(m, object.b),
      size: object.at("size", default: 0.28),
      style: style,
      stroke: stroke,
      fill: fill,
    )
  } else if kind == "ticks" {
    marks.segment-ticks(
      models.resolve(m, object.a),
      models.resolve(m, object.b),
      count: object.at("count", default: 1),
      size: object.at("size", default: 0.12),
      gap: object.at("gap", default: 0.10),
      style: style,
      stroke: stroke,
    )
  } else if kind == "parallel" {
    marks.parallel-marks(
      models.resolve(m, object.a),
      models.resolve(m, object.b),
      count: object.at("count", default: 1),
      size: object.at("size", default: 0.14),
      gap: object.at("gap", default: 0.11),
      style: style,
      stroke: stroke,
    )
  } else if kind == "grid" {
    primitive.draw-grid(
      x-range: object.at("x-range", default: (-5, 5)),
      y-range: object.at("y-range", default: (-5, 5)),
      step: object.at("step", default: 1),
      style: style,
    )
  } else if kind == "axes" {
    primitive.draw-axes(
      x-range: object.at("x-range", default: (-5, 5)),
      y-range: object.at("y-range", default: (-5, 5)),
      x-label: object.at("x-label", default: $x$),
      y-label: object.at("y-label", default: $y$),
      ticks: object.at("ticks", default: true),
      tick-step: object.at("tick-step", default: 1),
      style: style,
    )
  } else if kind == "point" {
    let name = object.at("name", default: object.at("at"))
    let p = models.resolve(m, object.at("at"))
    let options = _point-options(m, name)
    let point-base = estyle.point-style(style, options.at("point", default: (:)))
    let label-base = estyle.label-style(style, options.at("label", default: (:)))
    let label-value = object.at("label", default: options.at("label-content", default: "auto"))
    let body = if label-value == "auto" { _label-content(name) } else { _label-content(label-value) }
    let object-offset = object.at("offset", default: none)
    let object-anchor = object.at("anchor", default: none)
    let object-radius = object.at("radius", default: none)
    let object-fill = object.at("fill", default: none)
    let object-stroke = object.at("stroke", default: none)
    let role-stroke = estyle.stroke-for(style, role: role)
    let role-paint = if type(role-stroke) == dictionary { role-stroke.at("paint", default: none) } else { role-stroke }
    let resolved-fill = if object-fill != none { object-fill } else if role != "main" and role-paint != none { role-paint } else { point-base.at("fill", default: none) }
    let point-render-style = style + (
      label-size: label-base.at("size", default: style.at("label-size", default: 9pt)),
      label-fill: label-base.at("fill", default: style.at("label-fill", default: black)),
    )
    primitive.draw-point(
      p,
      label: body,
      label-offset: if object-offset == none { label-base.at("offset", default: (0.12, 0.12)) } else { object-offset },
      label-anchor: if object-anchor == none { label-base.at("anchor", default: "south-west") } else { object-anchor },
      style: point-render-style,
      radius: if object-radius == none { point-base.at("radius", default: none) } else { object-radius },
      fill: resolved-fill,
      stroke: if object-stroke == none { point-base.at("stroke", default: none) } else { object-stroke },
    )
  } else if kind == "label" {
    primitive.draw-label(
      models.resolve(m, object.at("at")),
      object.at("body"),
      offset: object.at("offset", default: (0, 0)),
      anchor: object.at("anchor", default: "center"),
      angle: object.at("angle", default: 0deg),
      style: style,
      padding: object.at("padding", default: 0pt),
    )
  }
}

#let draw-model(m, style: estyle.euclid-theme(), extra-objects: (), overlay: none) = {
  let effective-style = style + m.styles
  let all = m.objects + extra-objects
  let ordered = all.sorted(key: o => o.at("layer", default: 0))
  for object in ordered { draw-object(m, object, style: effective-style) }
  if overlay != none { overlay(m) }
}

#let render-model(
  m,
  style: estyle.euclid-theme(),
  length: 1cm,
  extra-objects: (),
  overlay: none,
) = canvas(length: length, {
  draw-model(m, style: style, extra-objects: extra-objects, overlay: overlay)
})
