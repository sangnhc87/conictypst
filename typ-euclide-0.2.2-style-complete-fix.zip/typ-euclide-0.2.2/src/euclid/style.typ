// Advanced, layered styles for reusable Euclidean models.
#import "../styles.typ" as base

// -----------------------------------------------------------------------------
// Internal normalization helpers
// -----------------------------------------------------------------------------

#let _as-dictionary(value, fallback: (:)) = {
  if type(value) == dictionary { value } else { fallback }
}

#let _theme-base(name) = {
  let selected = if name == none { "default" } else { name }

  if type(selected) == dictionary {
    selected
  } else if selected == "blue" {
    base.theme-blue
  } else if selected == "red" {
    base.theme-red
  } else if selected == "green" {
    base.theme-green
  } else if selected == "orange" {
    base.theme-orange
  } else if selected == "minimal" {
    base.theme-minimal
  } else {
    base.theme-default
  }
}

#let _soft-fill(value, amount) = {
  if value == none {
    none
  } else if type(value) == color {
    value.transparentize(amount)
  } else {
    // Gradients and tilings are already valid fills, but do not provide
    // `transparentize`. Keep them unchanged.
    value
  }
}

// -----------------------------------------------------------------------------
// Role tables
// -----------------------------------------------------------------------------

#let role-strokes(style) = {
  let style = _as-dictionary(style, fallback: base.theme-default)
  let defaults = base.theme-default

  let accent-color = style.at("accent", default: defaults.accent)
  let secondary-color = style.at("secondary", default: defaults.secondary)
  let tertiary-color = style.at("tertiary", default: defaults.tertiary)

  (
    main: style.at("stroke", default: defaults.stroke),
    strong: style.at("strong-stroke", default: defaults.strong-stroke),
    auxiliary: style.at("auxiliary-stroke", default: defaults.auxiliary-stroke),
    construction: style.at(
      "construction-stroke",
      default: defaults.construction-stroke,
    ),
    hidden: style.at("hidden-stroke", default: defaults.hidden-stroke),

    // These three can be overridden directly with `accent-stroke`,
    // `secondary-stroke`, and `tertiary-stroke`.
    accent: style.at(
      "accent-stroke",
      default: (
        paint: accent-color,
        thickness: 1pt,
        cap: "round",
        join: "round",
      ),
    ),
    secondary: style.at(
      "secondary-stroke",
      default: (
        paint: secondary-color,
        thickness: 0.9pt,
        cap: "round",
        join: "round",
      ),
    ),
    tertiary: style.at(
      "tertiary-stroke",
      default: (
        paint: tertiary-color,
        thickness: 0.85pt,
        cap: "round",
        join: "round",
      ),
    ),
  )
}

#let role-fills(style) = {
  let style = _as-dictionary(style, fallback: base.theme-default)
  let defaults = base.theme-default

  let accent-color = style.at("accent", default: defaults.accent)
  let secondary-color = style.at("secondary", default: defaults.secondary)
  let tertiary-color = style.at("tertiary", default: defaults.tertiary)

  (
    none: none,
    main: style.at("fill", default: none),
    accent: style.at(
      "accent-fill",
      default: _soft-fill(accent-color, 84%),
    ),
    secondary: style.at(
      "secondary-fill",
      default: _soft-fill(secondary-color, 86%),
    ),
    tertiary: style.at(
      "tertiary-fill",
      default: _soft-fill(tertiary-color, 86%),
    ),
    paper: style.at("paper", default: base.palette.paper),
  )
}

// -----------------------------------------------------------------------------
// Public theme constructor
// -----------------------------------------------------------------------------

#let euclid-theme(name: "default", overrides: (:)) = {
  let base-root = _theme-base(name)
  let overrides = _as-dictionary(overrides)
  let root = base-root + overrides

  // Nested dictionaries are normalized before merging. This prevents errors
  // when a caller accidentally provides `none` for one of these sections.
  let stroke-overrides = _as-dictionary(
    root.at("strokes", default: (:)),
  )
  let fill-overrides = _as-dictionary(
    root.at("fills", default: (:)),
  )
  let point-overrides = _as-dictionary(
    root.at("point", default: (:)),
  )
  let label-overrides = _as-dictionary(
    root.at("label", default: (:)),
  )
  let angle-overrides = _as-dictionary(
    root.at("angle", default: (:)),
  )
  let layer-overrides = _as-dictionary(
    root.at("layer-order", default: (:)),
  )

  let default-point = (
    radius: root.at("point-radius", default: 0.055),
    fill: root.at("point-fill", default: white),
    stroke: root.at(
      "point-stroke",
      default: (
        paint: black,
        thickness: 0.8pt,
      ),
    ),
  )

  let default-label = (
    size: root.at("label-size", default: 9pt),
    fill: root.at("label-fill", default: black),
    offset: root.at("label-offset", default: (0.12, 0.12)),
    anchor: root.at("label-anchor", default: "south-west"),
    padding: root.at("label-padding", default: 0pt),
  )

  let default-angle = (
    radius: root.at("angle-radius", default: 0.34),
    stroke: root.at(
      "angle-stroke",
      default: root.at(
        "stroke",
        default: (
          paint: black,
          thickness: 0.8pt,
        ),
      ),
    ),
    fill: root.at("angle-fill", default: none),
  )

  root + (
    strokes: role-strokes(root) + stroke-overrides,
    fills: role-fills(root) + fill-overrides,
    point: default-point + point-overrides,
    label: default-label + label-overrides,
    angle: default-angle + angle-overrides,
    layer-order: (
      background: -100,
      construction: -30,
      fill: -20,
      main: 0,
      marks: 20,
      points: 40,
      labels: 50,
    ) + layer-overrides,
  )
}

// -----------------------------------------------------------------------------
// Public access helpers
// -----------------------------------------------------------------------------

#let get(style, key, fallback: none) = {
  let style = _as-dictionary(style)
  style.at(key, default: fallback)
}

#let stroke-for(style, role: "main", override: none) = {
  if override != none {
    override
  } else {
    let style = if type(style) == dictionary {
      style
    } else {
      euclid-theme()
    }
    let role = if type(role) == str { role } else { "main" }
    let strokes = _as-dictionary(
      style.at("strokes", default: role-strokes(style)),
      fallback: role-strokes(style),
    )

    strokes.at(
      role,
      default: style.at("stroke", default: base.theme-default.stroke),
    )
  }
}

#let fill-for(style, role: "none", override: none) = {
  if override != none {
    override
  } else {
    let style = if type(style) == dictionary {
      style
    } else {
      euclid-theme()
    }
    let role = if type(role) == str { role } else { "none" }
    let fills = _as-dictionary(
      style.at("fills", default: role-fills(style)),
      fallback: role-fills(style),
    )

    fills.at(role, default: none)
  }
}

#let point-style(style, override: (:)) = {
  let style = if type(style) == dictionary { style } else { euclid-theme() }
  let base-point = _as-dictionary(style.at("point", default: (:)))
  base-point + _as-dictionary(override)
}

#let label-style(style, override: (:)) = {
  let style = if type(style) == dictionary { style } else { euclid-theme() }
  let base-label = _as-dictionary(style.at("label", default: (:)))
  base-label + _as-dictionary(override)
}

#let angle-style(style, override: (:)) = {
  let style = if type(style) == dictionary { style } else { euclid-theme() }
  let base-angle = _as-dictionary(style.at("angle", default: (:)))
  base-angle + _as-dictionary(override)
}
