// Ready-to-extend Euclidean theorem and construction models.
#import "model.typ" as m
#import "objects.typ" as o
#import "analytic.typ" as g
#import "figures.typ" as f
#import "construct.typ" as c

#let triangle-centers(A: (-2.4, -1.1), B: (2.5, -1.1), C: (0.5, 2.5)) = f.triangle(
  A: A, B: B, C: C,
  features: ("vertices", "medians", "altitudes", "angle-bisectors", "circumcircle", "incircle", "centers"),
)

#let euler-triangle(A: (-2.4, -1.1), B: (2.5, -1.1), C: (0.5, 2.5)) = f.triangle(
  A: A, B: B, C: C,
  features: ("vertices", "midpoints", "feet", "altitudes", "circumcircle", "euler-line", "nine-point-circle", "centers"),
)

#let derived-triangles(A: (-2.4, -1.1), B: (2.5, -1.1), C: (0.5, 2.5)) = f.triangle(
  A: A, B: B, C: C,
  features: ("vertices", "medial-triangle", "orthic-triangle", "contact-triangle", "incircle", "circumcircle", "centers"),
)

#let thales(
  A: (-2.6, -1.2),
  B: (2.6, -1.2),
  C: (-0.6, 2.5),
  t-ab: 0.42,
  t-ac: 0.42,
) = {
  let D = g.lerp(A, B, t-ab)
  let E = g.lerp(A, C, t-ac)
  m.model(
    points: (A: A, B: B, C: C, D: D, E: E),
    objects: (
      o.polygon(("A", "B", "C"), id: "triangle", role: "strong"),
      o.segment("D", "E", id: "parallel-section", role: "accent"),
      o.parallel("B", "C", id: "parallel-bc", count: 1),
      o.parallel("D", "E", id: "parallel-de", count: 1),
      o.point("A"), o.point("B"), o.point("C"), o.point("D", role: "accent"), o.point("E", role: "accent"),
    ),
    meta: (kind: "thales", ratios: (AD_AB: t-ab, AE_AC: t-ac)),
  )
}

#let ceva(
  A: (0, 2.8),
  B: (-2.8, -1.4),
  C: (2.8, -1.4),
  t-a: 0.45,
  t-b: 0.55,
) = {
  let D = g.lerp(B, C, t-a)
  let E = g.lerp(C, A, t-b)
  let P = g.line-intersection-points(A, D, B, E)
  let F = g.line-intersection-points(A, B, C, P)
  m.model(
    points: (A: A, B: B, C: C, D: D, E: E, F: F, P: P),
    objects: (
      o.polygon(("A", "B", "C"), id: "triangle", role: "strong"),
      o.segment("A", "D", id: "cevian-a", role: "auxiliary"),
      o.segment("B", "E", id: "cevian-b", role: "auxiliary"),
      o.segment("C", "F", id: "cevian-c", role: "accent"),
      o.point("A"), o.point("B"), o.point("C"),
      o.point("D", role: "secondary"), o.point("E", role: "secondary"), o.point("F", role: "secondary"),
      o.point("P", role: "accent"),
    ),
    meta: (kind: "ceva",),
  )
}

#let menelaus(
  A: (0, 2.8),
  B: (-2.8, -1.4),
  C: (2.8, -1.4),
  D: (-1.1, -1.4),
  E: (1.0, 1.15),
) = {
  let F = g.line-intersection-points(D, E, A, B)
  m.model(
    points: (A: A, B: B, C: C, D: D, E: E, F: F),
    objects: (
      o.polygon(("A", "B", "C"), id: "triangle", role: "strong"),
      o.line("D", "E", id: "transversal", role: "accent", extend: 1.2),
      o.point("A"), o.point("B"), o.point("C"),
      o.point("D", role: "secondary"), o.point("E", role: "secondary"), o.point("F", role: "secondary"),
    ),
    meta: (kind: "menelaus",),
  )
}

#let perpendicular-bisector(A: (-2.2, 0), B: (2.2, 0), arc-radius: 3) = {
  let M = g.midpoint(A, B)
  let pts = g.circle-circle-intersections-points(A, arc-radius, B, arc-radius)
  let P = pts.at(0)
  let Q = pts.at(1)
  m.model(
    points: (A: A, B: B, M: M, P: P, Q: Q),
    objects: (
      o.segment("A", "B", id: "segment-ab", role: "strong"),
      o.circle("A", arc-radius, id: "arc-a", role: "construction"),
      o.circle("B", arc-radius, id: "arc-b", role: "construction"),
      o.line("P", "Q", id: "perpendicular-bisector", role: "accent", extend: 1),
      o.ticks("A", "M", count: 1), o.ticks("M", "B", count: 1),
      o.point("A"), o.point("B"), o.point("M", role: "secondary"),
      o.point("P", role: "accent"), o.point("Q", role: "accent"),
    ),
    meta: (kind: "perpendicular-bisector",),
  )
}

#let angle-bisector(O: (0, 0), A: (4, 0), B: (1.5, 3.2), length: 4) = {
  let d = g.angle-bisector-direction(A, O, B)
  let D = g.add(O, g.mul(length, d))
  m.model(
    points: (O: O, A: A, B: B, D: D),
    objects: (
      o.ray("O", "A", id: "ray-oa", role: "strong", extend: 0.5),
      o.ray("O", "B", id: "ray-ob", role: "strong", extend: 0.5),
      o.ray("O", "D", id: "bisector", role: "accent", extend: 0.2),
      o.angle("O", "A", "D", id: "angle-1", role: "secondary", label: $alpha$),
      o.angle("O", "D", "B", id: "angle-2", role: "secondary", label: $alpha$),
      o.point("O"), o.point("A"), o.point("B"), o.point("D", role: "accent"),
    ),
    meta: (kind: "angle-bisector",),
  )
}

#let tangent-from-point(O: (0, 0), radius: 2, P: (4.5, 1.0)) = {
  let ts = g.tangent-points(g.circle(O, radius), P)
  let T_1 = ts.at(0)
  let T_2 = ts.at(1)
  m.model(
    points: (O: O, P: P, T_1: T_1, T_2: T_2),
    objects: (
      o.circle("O", radius, id: "circle", role: "strong"),
      o.segment("P", "T_1", id: "tangent-1", role: "accent"),
      o.segment("P", "T_2", id: "tangent-2", role: "accent"),
      o.segment("O", "T_1", id: "radius-1", role: "auxiliary"),
      o.segment("O", "T_2", id: "radius-2", role: "auxiliary"),
      o.right-angle("T_1", "O", "P", id: "right-1"),
      o.right-angle("T_2", "O", "P", id: "right-2"),
      o.ticks("P", "T_1", count: 1), o.ticks("P", "T_2", count: 1),
      o.point("O", role: "accent"), o.point("P"), o.point("T_1", role: "secondary"), o.point("T_2", role: "secondary"),
    ),
    meta: (kind: "tangent-from-point",),
  )
}

#let intersecting-chords(O: (0, 0), radius: 2.7, angles: (20deg, 155deg, 225deg, 325deg)) = {
  let p = angle => (O.at(0) + radius * calc.cos(angle), O.at(1) + radius * calc.sin(angle))
  let A = p(angles.at(0))
  let B = p(angles.at(1))
  let C = p(angles.at(2))
  let D = p(angles.at(3))
  let P = g.line-intersection-points(A, C, B, D)
  m.model(
    points: (O: O, A: A, B: B, C: C, D: D, P: P),
    objects: (
      o.circle("O", radius, id: "circle", role: "strong"),
      o.segment("A", "C", id: "chord-ac", role: "accent"),
      o.segment("B", "D", id: "chord-bd", role: "secondary"),
      o.point("A"), o.point("B"), o.point("C"), o.point("D"), o.point("P", role: "accent"),
    ),
    meta: (kind: "intersecting-chords",),
  )
}

#let cyclic-quadrilateral(O: (0, 0), radius: 2.7, angles: (210deg, 325deg, 45deg, 130deg)) = {
  let p = angle => (O.at(0) + radius * calc.cos(angle), O.at(1) + radius * calc.sin(angle))
  let A = p(angles.at(0))
  let B = p(angles.at(1))
  let C = p(angles.at(2))
  let D = p(angles.at(3))
  let base = f.quadrilateral(A: A, B: B, C: C, D: D, features: ("vertices", "diagonals", "diagonal-intersection"))
  let base = m.with-point(base, "O", O)
  m.with-objects(base, (
    o.circle("O", radius, id: "circumcircle", role: "accent", layer: -20),
    o.point("O", role: "accent"),
  ))
}

#let reflection(A: (-2.5, -0.7), B: (2.8, 0.7), P: (0.3, 2.5)) = {
  let base = m.model(
    points: (A: A, B: B, P: P),
    objects: (o.line("A", "B", id: "mirror", role: "strong", extend: 1), o.point("A"), o.point("B"), o.point("P")),
  )
  c.reflection(base, "P_1", "P", "A", "B", role: "accent")
}

#let homothety(center: (0, 0), ratio: 1.7) = {
  let base = m.model(
    points: (O: center, A: (1, 0.4), B: (2.4, 0.4), C: (1.4, 1.8)),
    objects: (
      o.polygon(("A", "B", "C"), id: "source", role: "strong", fill-role: "main"),
      o.point("O", role: "accent"), o.point("A"), o.point("B"), o.point("C"),
    ),
  )
  let result = c.homothety(base, "A_1", "A", "O", ratio, role: "accent")
  result = c.homothety(result, "B_1", "B", "O", ratio, role: "accent")
  result = c.homothety(result, "C_1", "C", "O", ratio, role: "accent")
  m.with-object(result, o.polygon(("A_1", "B_1", "C_1"), id: "image", role: "accent", fill-role: "none"))
}
