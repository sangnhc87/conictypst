// Additional Euclidean theorem models. All functions return extensible models.
#import "model.typ" as m
#import "objects.typ" as o
#import "analytic.typ" as g
#import "figures.typ" as f

#let pedal-triangle(
  A: (-2.4, -1.1),
  B: (2.5, -1.1),
  C: (0.4, 2.5),
  P: (0.3, 0.8),
) = {
  let D = g.projection(P, B, C)
  let E = g.projection(P, C, A)
  let F = g.projection(P, A, B)
  m.model(
    points: (A: A, B: B, C: C, P: P, D: D, E: E, F: F),
    objects: (
      o.polygon(("A", "B", "C"), id: "triangle", role: "strong"),
      o.polygon(("D", "E", "F"), id: "pedal-triangle", role: "accent", fill-role: "accent"),
      o.segment("P", "D", id: "pd", role: "auxiliary"),
      o.segment("P", "E", id: "pe", role: "auxiliary"),
      o.segment("P", "F", id: "pf", role: "auxiliary"),
      o.right-angle("D", "P", "C", id: "right-d", role: "auxiliary"),
      o.right-angle("E", "P", "A", id: "right-e", role: "auxiliary"),
      o.right-angle("F", "P", "B", id: "right-f", role: "auxiliary"),
      o.point("A"), o.point("B"), o.point("C"), o.point("P", role: "secondary"),
      o.point("D", role: "accent"), o.point("E", role: "accent"), o.point("F", role: "accent"),
    ),
    meta: (kind: "pedal-triangle",),
  )
}

#let simson-line(
  A: (-2.4, -1.1),
  B: (2.5, -1.1),
  C: (0.4, 2.5),
  point-angle: 205deg,
) = {
  let d = g.triangle-data(A, B, C)
  let P = (
    d.O.at(0) + d.circumcircle.radius * calc.cos(point-angle),
    d.O.at(1) + d.circumcircle.radius * calc.sin(point-angle),
  )
  let D = g.projection(P, B, C)
  let E = g.projection(P, C, A)
  let F = g.projection(P, A, B)
  m.model(
    points: (A: A, B: B, C: C, O: d.O, P: P, D: D, E: E, F: F),
    objects: (
      o.polygon(("A", "B", "C"), id: "triangle", role: "strong"),
      o.circle("O", d.circumcircle.radius, id: "circumcircle", role: "construction"),
      o.segment("P", "D", id: "pd", role: "auxiliary"),
      o.segment("P", "E", id: "pe", role: "auxiliary"),
      o.segment("P", "F", id: "pf", role: "auxiliary"),
      o.line("D", "F", id: "simson-line", role: "accent", extend: 1.2),
      o.point("A"), o.point("B"), o.point("C"), o.point("P", role: "secondary"),
      o.point("D", role: "accent"), o.point("E", role: "accent"), o.point("F", role: "accent"),
    ),
    meta: (kind: "simson-line",),
  )
}

#let gergonne(
  A: (-2.4, -1.1),
  B: (2.5, -1.1),
  C: (0.4, 2.5),
) = f.triangle(
  A: A, B: B, C: C,
  features: ("vertices", "incircle", "contact-points", "contact-triangle", "gergonne-cevians"),
  meta: (kind: "gergonne",),
)

#let nagel(
  A: (-2.4, -1.1),
  B: (2.5, -1.1),
  C: (0.4, 2.5),
) = {
  let d = g.triangle-data(A, B, C)
  let D = g.line-intersection-points(A, d.Na, B, C)
  let E = g.line-intersection-points(B, d.Na, C, A)
  let F = g.line-intersection-points(C, d.Na, A, B)
  m.model(
    points: (A: A, B: B, C: C, D: D, E: E, F: F, Na: d.Na),
    objects: (
      o.polygon(("A", "B", "C"), id: "triangle", role: "strong"),
      o.segment("A", "D", id: "nagel-a", role: "auxiliary"),
      o.segment("B", "E", id: "nagel-b", role: "auxiliary"),
      o.segment("C", "F", id: "nagel-c", role: "auxiliary"),
      o.point("A"), o.point("B"), o.point("C"),
      o.point("D", role: "secondary"), o.point("E", role: "secondary"), o.point("F", role: "secondary"),
      o.point("Na", role: "accent"),
    ),
    meta: (kind: "nagel",),
  )
}

#let symmedians(
  A: (-2.4, -1.1),
  B: (2.5, -1.1),
  C: (0.4, 2.5),
) = {
  let d = g.triangle-data(A, B, C)
  let D = g.line-intersection-points(A, d.K, B, C)
  let E = g.line-intersection-points(B, d.K, C, A)
  let F = g.line-intersection-points(C, d.K, A, B)
  m.model(
    points: (A: A, B: B, C: C, D: D, E: E, F: F, K: d.K),
    objects: (
      o.polygon(("A", "B", "C"), id: "triangle", role: "strong"),
      o.segment("A", "D", id: "symmedian-a", role: "auxiliary"),
      o.segment("B", "E", id: "symmedian-b", role: "auxiliary"),
      o.segment("C", "F", id: "symmedian-c", role: "auxiliary"),
      o.point("A"), o.point("B"), o.point("C"),
      o.point("D", role: "secondary"), o.point("E", role: "secondary"), o.point("F", role: "secondary"),
      o.point("K", role: "accent"),
    ),
    meta: (kind: "symmedians",),
  )
}

#let radical-axis(
  O_1: (-1.5, 0),
  r_1: 2.4,
  O_2: (1.5, 0.4),
  r_2: 2.0,
) = {
  let c1 = g.circle(O_1, r_1)
  let c2 = g.circle(O_2, r_2)
  let line = g.equation-to-line(g.radical-axis(c1, c2))
  let intersections = g.intersect-circles(c1, c2)
  let points = (O_1: O_1, O_2: O_2, R_0: line.p, R_1: line.q)
  let objects = (
    o.circle("O_1", r_1, id: "circle-1", role: "accent"),
    o.circle("O_2", r_2, id: "circle-2", role: "secondary"),
    o.line("R_0", "R_1", id: "radical-axis", role: "tertiary", extend: 5),
    o.segment("O_1", "O_2", id: "line-centers", role: "construction"),
    o.point("O_1", role: "accent"), o.point("O_2", role: "secondary"),
  )
  for (i, p) in intersections.enumerate() {
    let name = "X_" + str(i + 1)
    points.insert(name, p)
    objects.push(o.point(name, role: "tertiary"))
  }
  m.model(points: points, objects: objects, meta: (kind: "radical-axis",))
}

#let power-of-point(
  O: (0, 0),
  radius: 2.2,
  P: (4.5, 0.6),
  secant-angles: (165deg, 205deg),
) = {
  let c = g.circle(O, radius)
  let make-line = angle => g.line(P, g.add(P, (calc.cos(angle), calc.sin(angle))))
  let s1 = g.intersect-line-circle(make-line(secant-angles.at(0)), c)
  let s2 = g.intersect-line-circle(make-line(secant-angles.at(1)), c)
  let A = s1.at(0)
  let B = s1.at(1)
  let C = s2.at(0)
  let D = s2.at(1)
  m.model(
    points: (O: O, P: P, A: A, B: B, C: C, D: D),
    objects: (
      o.circle("O", radius, id: "circle", role: "strong"),
      o.segment("P", "B", id: "secant-1", role: "accent"),
      o.segment("P", "D", id: "secant-2", role: "secondary"),
      o.point("O", role: "accent"), o.point("P"),
      o.point("A"), o.point("B"), o.point("C"), o.point("D"),
    ),
    meta: (kind: "power-of-point", power: g.power-of-point(P, c)),
  )
}

#let inversion(
  O: (0, 0),
  radius: 2,
  points: ((A: (3.5, 0.7)), (B: (-1.2, 3.0)), (C: (-3.0, -1.4))),
) = {
  let named = (O: O)
  let objects = (o.circle("O", radius, id: "inversion-circle", role: "strong"), o.point("O", role: "accent"))
  for item in points {
    let name = item.keys().at(0)
    let p = item.at(name)
    let image-name = name + "_1"
    let image = g.invert-point(p, center: O, radius: radius)
    named.insert(name, p)
    named.insert(image-name, image)
    objects.push(o.ray("O", name, id: "ray-" + name, role: "construction", extend: 1))
    objects.push(o.segment(name, image-name, id: "pair-" + name, role: "auxiliary"))
    objects.push(o.point(name))
    objects.push(o.point(image-name, role: "accent"))
  }
  m.model(points: named, objects: objects, meta: (kind: "inversion", radius: radius))
}

#let ptolemy(
  O: (0, 0),
  radius: 2.6,
  angles: (210deg, 315deg, 35deg, 125deg),
) = {
  let p = angle => (O.at(0) + radius * calc.cos(angle), O.at(1) + radius * calc.sin(angle))
  let A = p(angles.at(0))
  let B = p(angles.at(1))
  let C = p(angles.at(2))
  let D = p(angles.at(3))
  m.model(
    points: (O: O, A: A, B: B, C: C, D: D),
    objects: (
      o.circle("O", radius, id: "circumcircle", role: "construction"),
      o.polygon(("A", "B", "C", "D"), id: "cyclic-quadrilateral", role: "strong"),
      o.segment("A", "C", id: "diagonal-ac", role: "accent"),
      o.segment("B", "D", id: "diagonal-bd", role: "secondary"),
      o.point("A"), o.point("B"), o.point("C"), o.point("D"), o.point("O", role: "construction"),
    ),
    meta: (
      kind: "ptolemy",
      lhs: g.distance(A, C) * g.distance(B, D),
      rhs: g.distance(A, B) * g.distance(C, D) + g.distance(B, C) * g.distance(D, A),
    ),
  )
}

#let inscribed-angle(
  O: (0, 0),
  radius: 2.6,
  angles: (205deg, 330deg, 85deg),
) = {
  let p = angle => (O.at(0) + radius * calc.cos(angle), O.at(1) + radius * calc.sin(angle))
  let A = p(angles.at(0))
  let B = p(angles.at(1))
  let C = p(angles.at(2))
  m.model(
    points: (O: O, A: A, B: B, C: C),
    objects: (
      o.circle("O", radius, id: "circle", role: "strong"),
      o.segment("C", "A", id: "chord-ca", role: "accent"),
      o.segment("C", "B", id: "chord-cb", role: "accent"),
      o.segment("O", "A", id: "radius-oa", role: "auxiliary"),
      o.segment("O", "B", id: "radius-ob", role: "auxiliary"),
      o.angle("C", "A", "B", id: "inscribed-angle", role: "secondary", label: $alpha$),
      o.angle("O", "A", "B", id: "central-angle", role: "tertiary", label: $2 alpha$),
      o.point("O", role: "accent"), o.point("A"), o.point("B"), o.point("C"),
    ),
    meta: (kind: "inscribed-angle",),
  )
}
