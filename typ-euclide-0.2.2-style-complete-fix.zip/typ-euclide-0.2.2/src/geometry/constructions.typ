#import "@preview/cetz:0.5.2": canvas, draw
#import "../core.typ" as geo
#import "../styles.typ" as styles
#import "../primitives.typ" as primitive
#import "../marks.typ" as mark

#let perpendicular-bisector(
  a: (-2, 0),
  b: (2, 0),
  arc-radius: 2.7,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let m = geo.midpoint(a, b)
  let intersections = geo.circle-circle-intersections(a, arc-radius, b, arc-radius)
  draw.line(a, b, stroke: styles.get(style, "strong-stroke"))
  draw.circle(a, radius: arc-radius, stroke: styles.get(style, "construction-stroke"))
  draw.circle(b, radius: arc-radius, stroke: styles.get(style, "construction-stroke"))
  if intersections.len() == 2 {
    draw.line(intersections.at(0), intersections.at(1), stroke: (paint: styles.get(style, "accent"), thickness: 1pt))
    primitive.draw-points(intersections, labels: ($P$, $Q$), style: style)
  }
  primitive.draw-points((a, b, m), labels: ($A$, $B$, $M$), style: style)
  mark.segment-ticks(a, m, style: style)
  mark.segment-ticks(m, b, style: style)
})

#let angle-bisector(
  vertex: (0, 0),
  a: (3.5, 0),
  b: (1.4, 3.0),
  ray-length: 4,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let u = geo.direction(vertex, a)
  let v = geo.direction(vertex, b)
  let direction = geo.unit(geo.add(u, v))
  let c = geo.add(vertex, geo.mul(ray-length, direction))
  draw.line(vertex, a, stroke: styles.get(style, "stroke"))
  draw.line(vertex, b, stroke: styles.get(style, "stroke"))
  draw.line(vertex, c, stroke: (paint: styles.get(style, "accent"), thickness: 1pt))
  mark.angle-mark(vertex, a, c, label: $alpha$, style: style)
  mark.angle-mark(vertex, c, b, label: $alpha$, style: style)
  primitive.draw-points((vertex, a, b, c), labels: ($O$, $A$, $B$, $D$), style: style)
})

#let reflection-across-line(
  p: (1.5, 2.3),
  a: (-3, -0.5),
  b: (3, 1.0),
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let h = geo.project-point-line(p, a, b)
  let q = geo.reflect-point-line(p, a, b)
  primitive.draw-line(a, b, style: style)
  draw.line(p, q, stroke: styles.get(style, "auxiliary-stroke"))
  mark.right-angle(h, p, b, style: style)
  mark.segment-ticks(p, h, style: style)
  mark.segment-ticks(h, q, style: style)
  primitive.draw-points((p, h, q), labels: ($P$, $H$, $P'$), style: style)
})

#let homothety-figure(
  center: (0, 0),
  points: ((1, 0.5), (2.4, 0.5), (1.4, 1.8)),
  ratio: 1.7,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let image = points.map(p => geo.homothety(p, center: center, ratio: ratio))
  primitive.draw-polygon(points, style: style, fill: styles.get(style, "fill"))
  primitive.draw-polygon(image, style: style, stroke: (paint: styles.get(style, "accent"), thickness: 1pt), fill: none)
  for i in range(points.len()) {
    draw.line(center, image.at(i), stroke: styles.get(style, "construction-stroke"))
  }
  primitive.draw-points(points, labels: ($A$, $B$, $C$), style: style)
  primitive.draw-points(image, labels: ($A'$, $B'$, $C'$), style: style)
  primitive.draw-point(center, label: $O$, style: style, fill: styles.get(style, "accent"))
})

#let circle-through-three-points(
  a: (-2, -0.6),
  b: (2.2, -0.2),
  c: (0.5, 2.2),
  show-bisectors: true,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let o = geo.triangle-circumcenter(a, b, c)
  primitive.draw-polygon((a, b, c), style: style)
  if o != none {
    draw.circle(o, radius: geo.distance(o, a), stroke: (paint: styles.get(style, "accent"), thickness: 1pt))
    if show-bisectors {
      for (p, q) in ((a, b), (b, c)) {
        let m = geo.midpoint(p, q)
        let n = geo.perp(geo.direction(p, q))
        draw.line(geo.sub(m, geo.mul(4, n)), geo.add(m, geo.mul(4, n)), stroke: styles.get(style, "construction-stroke"))
      }
    }
    primitive.draw-point(o, label: $O$, style: style, fill: styles.get(style, "accent"))
  }
  primitive.draw-points((a, b, c), labels: ($A$, $B$, $C$), style: style)
})
