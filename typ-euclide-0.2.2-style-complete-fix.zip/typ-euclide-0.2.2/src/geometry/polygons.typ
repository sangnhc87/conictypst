#import "@preview/cetz:0.5.2": canvas, draw
#import "../core.typ" as geo
#import "../styles.typ" as styles
#import "../primitives.typ" as primitive
#import "../marks.typ" as mark

#let regular-polygon(
  n: 5,
  radius: 2.5,
  start-angle: 90deg,
  labels: (),
  diagonals: "none",
  step: 2,
  center: (0, 0),
  style: styles.theme(),
  fill: none,
  length: 1cm,
) = canvas(length: length, {
  let pts = geo.regular-polygon-points(n, center: center, radius: radius, start-angle: start-angle)
  primitive.draw-polygon(pts, style: style, fill: fill)
  if diagonals == "all" {
    for i in range(n) {
      for j in range(i + 2, n) {
        if not (i == 0 and j == n - 1) {
          draw.line(pts.at(i), pts.at(j), stroke: styles.get(style, "auxiliary-stroke"))
        }
      }
    }
  } else if diagonals == "from-first" {
    for j in range(2, n - 1) { draw.line(pts.at(0), pts.at(j), stroke: styles.get(style, "auxiliary-stroke")) }
  } else if diagonals == "star" {
    let order = ()
    let current = 0
    for _ in range(n) {
      order += (pts.at(current),)
      current = calc.rem(current + step, n)
    }
    draw.line(..order, close: true, stroke: (paint: styles.get(style, "accent"), thickness: 1pt))
  }
  for i in range(n) { mark.segment-ticks(pts.at(i), pts.at(calc.rem(i + 1, n)), style: style) }
  primitive.draw-points(pts, labels: labels, style: style)
  primitive.draw-point(center, label: $O$, style: style, fill: styles.get(style, "accent"))
})

#let star-polygon(n: 5, step: 2, radius: 2.5, style: styles.theme(), fill: none, length: 1cm) = regular-polygon(
  n: n,
  step: step,
  radius: radius,
  diagonals: "star",
  style: style,
  fill: fill,
  length: length,
)

#let polygon-angle-sum(n: 6, radius: 2.5, selected: 0, style: styles.theme(), length: 1cm) = canvas(length: length, {
  let pts = geo.regular-polygon-points(n, radius: radius, start-angle: 90deg)
  primitive.draw-polygon(pts, style: style, fill: styles.get(style, "fill"))
  let c = (0, 0)
  for p in pts { draw.line(c, p, stroke: styles.get(style, "construction-stroke")) }
  let prev = pts.at(calc.rem(selected - 1 + n, n))
  let v = pts.at(selected)
  let next = pts.at(calc.rem(selected + 1, n))
  mark.angle-mark(v, prev, next, label: $alpha$, style: style, stroke: (paint: styles.get(style, "accent"), thickness: 1pt))
  primitive.draw-points(pts, style: style)
  primitive.draw-point(c, label: $O$, style: style)
})
