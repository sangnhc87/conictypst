#import "@preview/cetz:0.5.2": canvas, draw
#import "../core.typ" as geo
#import "../styles.typ" as styles
#import "../primitives.typ" as primitive
#import "../marks.typ" as mark

#let thales-parallel(
  a: (0.4, 3.2),
  b: (-2.8, -1.2),
  c: (3.2, -1.2),
  ratio: 0.55,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let d = geo.lerp(a, b, ratio)
  let e = geo.lerp(a, c, ratio)
  primitive.draw-polygon((a, b, c), style: style, fill: styles.get(style, "fill"))
  draw.line(d, e, stroke: (paint: styles.get(style, "accent"), thickness: 1.1pt))
  mark.parallel-marks(d, e, count: 1, style: style)
  mark.parallel-marks(b, c, count: 1, style: style)
  primitive.draw-points((a, b, c, d, e), labels: ($A$, $B$, $C$, $D$, $E$), style: style)
})

#let square-on-segment(a, b, sign: 1) = {
  let v = geo.sub(b, a)
  let n = geo.mul(sign, geo.perp(v))
  (a, b, geo.add(b, n), geo.add(a, n))
}

#let pythagorean-squares(
  adjacent: 4,
  opposite: 3,
  show-area-labels: true,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let a = (0, 0)
  let b = (adjacent, 0)
  let c = (adjacent, opposite)
  let qab = square-on-segment(a, b, sign: -1)
  let qbc = square-on-segment(b, c, sign: -1)
  let qca = square-on-segment(c, a, sign: -1)
  primitive.draw-polygon(qab, style: style, fill: styles.get(style, "accent").transparentize(86%))
  primitive.draw-polygon(qbc, style: style, fill: styles.get(style, "secondary").transparentize(86%))
  primitive.draw-polygon(qca, style: style, fill: styles.get(style, "tertiary").transparentize(86%))
  primitive.draw-polygon((a, b, c), style: style, fill: white)
  mark.right-angle(b, a, c, style: style)
  primitive.draw-points((a, b, c), labels: ($A$, $B$, $C$), style: style)
  if show-area-labels {
    primitive.draw-label(geo.polygon-centroid(qab), $a^2$, style: style)
    primitive.draw-label(geo.polygon-centroid(qbc), $b^2$, style: style)
    primitive.draw-label(geo.polygon-centroid(qca), $c^2$, style: style)
  }
})

#let ceva-configuration(
  a: (0, 3.4),
  b: (-3, -1.2),
  c: (3.2, -1.2),
  p: (0.35, 0.45),
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let d = geo.line-intersection(a, p, b, c)
  let e = geo.line-intersection(b, p, c, a)
  let f = geo.line-intersection(c, p, a, b)
  primitive.draw-polygon((a, b, c), style: style, fill: styles.get(style, "fill"))
  if d != none { draw.line(a, d, stroke: styles.get(style, "auxiliary-stroke")) }
  if e != none { draw.line(b, e, stroke: styles.get(style, "auxiliary-stroke")) }
  if f != none { draw.line(c, f, stroke: styles.get(style, "auxiliary-stroke")) }
  primitive.draw-points((a, b, c), labels: ($A$, $B$, $C$), style: style)
  if d != none { primitive.draw-point(d, label: $D$, style: style) }
  if e != none { primitive.draw-point(e, label: $E$, style: style) }
  if f != none { primitive.draw-point(f, label: $F$, style: style) }
  primitive.draw-point(p, label: $P$, style: style, fill: styles.get(style, "accent"))
})

#let menelaus-configuration(
  a: (0, 3.2),
  b: (-3, -1.2),
  c: (3.2, -1.2),
  line-a: (-3.8, 1.4),
  line-b: (4.0, -0.15),
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let d = geo.line-intersection(line-a, line-b, b, c)
  let e = geo.line-intersection(line-a, line-b, c, a)
  let f = geo.line-intersection(line-a, line-b, a, b)
  primitive.draw-polygon((a, b, c), style: style, fill: styles.get(style, "fill"))
  primitive.draw-line(line-a, line-b, extend: 0.2, style: style, stroke: (paint: styles.get(style, "accent"), thickness: 1pt))
  primitive.draw-points((a, b, c), labels: ($A$, $B$, $C$), style: style)
  if d != none { primitive.draw-point(d, label: $D$, style: style, fill: styles.get(style, "accent")) }
  if e != none { primitive.draw-point(e, label: $E$, style: style, fill: styles.get(style, "accent")) }
  if f != none { primitive.draw-point(f, label: $F$, style: style, fill: styles.get(style, "accent")) }
})

#let power-of-point(
  center: (0, 0),
  radius: 2.2,
  p: (4.6, 0.6),
  direction-1: (-1, 0.18),
  direction-2: (-1, -0.42),
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  draw.circle(center, radius: radius, stroke: styles.get(style, "strong-stroke"), fill: styles.get(style, "fill"))
  let q1 = geo.add(p, geo.mul(10, geo.unit(direction-1)))
  let q2 = geo.add(p, geo.mul(10, geo.unit(direction-2)))
  let ints1 = geo.circle-line-intersections(center, radius, p, q1)
  let ints2 = geo.circle-line-intersections(center, radius, p, q2)
  draw.line(p, q1, stroke: styles.get(style, "auxiliary-stroke"))
  draw.line(p, q2, stroke: styles.get(style, "auxiliary-stroke"))
  primitive.draw-point(p, label: $P$, style: style, fill: styles.get(style, "accent"))
  if ints1.len() == 2 { primitive.draw-points(ints1, labels: ($A$, $B$), style: style) }
  if ints2.len() == 2 { primitive.draw-points(ints2, labels: ($C$, $D$), style: style) }
  primitive.draw-point(center, label: $O$, style: style)
})

#let tangent-secant-theorem(
  center: (0, 0),
  radius: 2,
  p: (4.5, 0.8),
  secant-direction: (-1, -0.35),
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  draw.circle(center, radius: radius, stroke: styles.get(style, "strong-stroke"), fill: styles.get(style, "fill"))
  let d = geo.distance(center, p)
  let base-angle = geo.angle-of(geo.sub(p, center))
  let offset = calc.acos(radius / d)
  let t = geo.add(center, (radius * calc.cos(base-angle + offset), radius * calc.sin(base-angle + offset)))
  let q = geo.add(p, geo.mul(10, geo.unit(secant-direction)))
  let intersections = geo.circle-line-intersections(center, radius, p, q)
  draw.line(p, t, stroke: (paint: styles.get(style, "accent"), thickness: 1.1pt))
  draw.line(p, q, stroke: styles.get(style, "auxiliary-stroke"))
  draw.line(center, t, stroke: styles.get(style, "construction-stroke"))
  mark.right-angle(t, center, p, style: style)
  primitive.draw-point(center, label: $O$, style: style)
  primitive.draw-point(p, label: $P$, style: style, fill: styles.get(style, "accent"))
  primitive.draw-point(t, label: $T$, style: style, fill: styles.get(style, "secondary"))
  if intersections.len() == 2 { primitive.draw-points(intersections, labels: ($A$, $B$), style: style) }
})
