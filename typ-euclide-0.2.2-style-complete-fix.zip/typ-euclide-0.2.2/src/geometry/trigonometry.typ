#import "@preview/cetz:0.5.2": canvas, draw
#import "../core.typ" as geo
#import "../styles.typ" as styles
#import "../primitives.typ" as primitive
#import "../marks.typ" as mark

#let unit-circle(
  angle: 40deg,
  radius: 2.4,
  show-tangent: true,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let p = (radius * calc.cos(angle), radius * calc.sin(angle))
  primitive.draw-grid(x-range: (-3, 3), y-range: (-3, 3), style: style)
  primitive.draw-axes(x-range: (-3, 3), y-range: (-3, 3), style: style)
  draw.circle((0, 0), radius: radius, stroke: styles.get(style, "strong-stroke"))
  draw.line((0, 0), p, stroke: (paint: styles.get(style, "accent"), thickness: 1.2pt))
  draw.line(p, (p.at(0), 0), stroke: styles.get(style, "auxiliary-stroke"))
  draw.line(p, (0, p.at(1)), stroke: styles.get(style, "auxiliary-stroke"))
  mark.angle-mark((0, 0), (radius, 0), p, label: $theta$, style: style)
  if show-tangent and calc.abs(calc.cos(angle)) > geo.eps {
    let t = (radius / calc.cos(angle), 0)
    draw.line((radius, -2.5), (radius, 2.5), stroke: styles.get(style, "construction-stroke"))
    draw.line((0, 0), t, stroke: (paint: styles.get(style, "secondary"), thickness: 0.9pt))
  }
  primitive.draw-point(p, label: $(cos theta, sin theta)$, style: style, fill: styles.get(style, "accent"))
})

#let right-triangle-trig(
  adjacent: 4,
  opposite: 3,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let a = (0, 0)
  let b = (adjacent, 0)
  let c = (adjacent, opposite)
  primitive.draw-polygon((a, b, c), style: style, fill: styles.get(style, "fill"))
  mark.right-angle(b, a, c, style: style)
  mark.angle-mark(a, b, c, label: $theta$, style: style)
  primitive.draw-label(geo.midpoint(a, b), [adjacent], offset: (0, -0.22), anchor: "north", style: style)
  primitive.draw-label(geo.midpoint(b, c), [opposite], offset: (0.18, 0), anchor: "west", style: style)
  primitive.draw-label(geo.midpoint(a, c), [hypotenuse], offset: (-0.12, 0.12), anchor: "south", angle: geo.angle-of(geo.sub(c, a)), style: style)
  primitive.draw-points((a, b, c), labels: ($A$, $B$, $C$), style: style)
})

#let sine-rule-triangle(
  a: (-2.2, -1),
  b: (2.4, -1),
  c: (0.6, 2.1),
  circumcircle: true,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  primitive.draw-polygon((a, b, c), style: style, fill: styles.get(style, "fill"))
  let o = geo.triangle-circumcenter(a, b, c)
  if circumcircle and o != none {
    draw.circle(o, radius: geo.distance(o, a), stroke: styles.get(style, "construction-stroke"))
    primitive.draw-point(o, label: $O$, style: style)
  }
  mark.angle-mark(a, b, c, label: $A$, style: style)
  mark.angle-mark(b, c, a, label: $B$, style: style)
  mark.angle-mark(c, a, b, label: $C$, style: style)
  primitive.draw-label(geo.midpoint(b, c), $a$, offset: (0.1, 0.1), style: style)
  primitive.draw-label(geo.midpoint(c, a), $b$, offset: (-0.1, 0.1), style: style)
  primitive.draw-label(geo.midpoint(a, b), $c$, offset: (0, -0.15), anchor: "north", style: style)
})

#let vector-components(
  vector: (3.5, 2.2),
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  primitive.draw-grid(x-range: (-1, 5), y-range: (-1, 4), style: style)
  primitive.draw-axes(x-range: (-1, 5), y-range: (-1, 4), style: style)
  let o = (0, 0)
  let p = vector
  primitive.draw-vector(o, p, label: $bold(v)$, style: style, stroke: (paint: styles.get(style, "accent"), thickness: 1.2pt))
  primitive.draw-vector(o, (p.at(0), 0), label: $v_x$, style: style, stroke: (paint: styles.get(style, "secondary"), thickness: 1pt))
  primitive.draw-vector((p.at(0), 0), p, label: $v_y$, style: style, stroke: (paint: styles.get(style, "tertiary"), thickness: 1pt))
  mark.angle-mark(o, (1, 0), p, label: $theta$, style: style)
})
