#import "@preview/cetz:0.5.2": canvas, draw
#import "core.typ" as geo
#import "styles.typ": theme, get
#import "primitives.typ" as primitive
#import "conics.typ": draw-curve

#let function-plot(
  f,
  domain: (-5, 5),
  y-range: (-5, 5),
  samples: 200,
  grid: true,
  axes: true,
  label: none,
  style: theme(),
  stroke: none,
  length: 1cm,
) = canvas(length: length, {
  if grid { primitive.draw-grid(x-range: domain, y-range: y-range, style: style) }
  if axes { primitive.draw-axes(x-range: domain, y-range: y-range, style: style) }
  draw-curve(f, domain: domain, samples: samples, style: style, stroke: stroke, name: "graph")
  if label != none {
    draw.content(("graph.start", 80%, "graph.end"), label, anchor: "south", padding: 2pt)
  }
})

#let integral-region(
  f,
  g: x => 0,
  interval: (-2, 2),
  domain: (-3, 3),
  y-range: (-4, 6),
  samples: 160,
  fill: none,
  style: theme(),
  length: 1cm,
) = canvas(length: length, {
  primitive.draw-grid(x-range: domain, y-range: y-range, style: style)
  primitive.draw-axes(x-range: domain, y-range: y-range, style: style)
  let xs = range(samples + 1).map(i => interval.at(0) + i / samples * (interval.at(1) - interval.at(0)))
  let upper = xs.map(xx => (xx, f(xx)))
  let lower = xs.rev().map(xx => (xx, g(xx)))
  let area-fill = if fill == none { get(style, "fill") } else { fill }
  draw.line(..(upper + lower), close: true, fill: area-fill, stroke: none)
  draw-curve(f, domain: domain, samples: samples, style: style, stroke: (paint: get(style, "accent"), thickness: 1pt))
  draw-curve(g, domain: domain, samples: samples, style: style, stroke: (paint: get(style, "secondary"), thickness: 1pt))
})

#let linear-programming-region(
  vertices,
  x-range: (0, 8),
  y-range: (0, 8),
  constraints: (),
  style: theme(),
  fill: none,
  length: 1cm,
) = canvas(length: length, {
  primitive.draw-grid(x-range: x-range, y-range: y-range, style: style)
  primitive.draw-axes(x-range: x-range, y-range: y-range, style: style)
  for c in constraints {
    let a = c.at("a")
    let b = c.at("b")
    let d = c.at("c")
    let s = c.at("stroke", default: get(style, "auxiliary-stroke"))
    if calc.abs(b) > geo.eps {
      draw.line((x-range.at(0), (d - a * x-range.at(0)) / b), (x-range.at(1), (d - a * x-range.at(1)) / b), stroke: s)
    } else if calc.abs(a) > geo.eps {
      let xx = d / a
      draw.line((xx, y-range.at(0)), (xx, y-range.at(1)), stroke: s)
    }
  }
  let area-fill = if fill == none { get(style, "fill") } else { fill }
  primitive.draw-polygon(vertices, style: style, fill: area-fill, stroke: get(style, "strong-stroke"))
  for (i, p) in vertices.enumerate() { primitive.draw-point(p, label: text(size: 8pt)[#p], style: style) }
})
