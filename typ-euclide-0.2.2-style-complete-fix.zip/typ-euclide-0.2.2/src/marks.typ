#import "@preview/cetz:0.5.2": draw
#import "core.typ" as geo
#import "styles.typ": theme, get

#let right-angle(vertex, a, b, size: 0.28, style: theme(), stroke: none, fill: none) = {
  let u = geo.direction(vertex, a)
  let v = geo.direction(vertex, b)
  let p = geo.add(vertex, geo.mul(size, u))
  let q = geo.add(p, geo.mul(size, v))
  let r = geo.add(vertex, geo.mul(size, v))
  let s = if stroke == none { get(style, "stroke") } else { stroke }
  if fill == none {
    draw.line(p, q, r, stroke: s)
  } else {
    draw.line(vertex, p, q, r, close: true, stroke: s, fill: fill)
  }
}

#let angle-mark(vertex, a, b, radius: none, label: none, style: theme(), stroke: none, fill: none, reflex: false) = {
  let r = if radius == none { get(style, "angle-radius") } else { radius }
  let aa = geo.angle-of(geo.sub(a, vertex))
  let bb = geo.angle-of(geo.sub(b, vertex))
  let raw = bb - aa
  let minor = if raw > 180deg { raw - 360deg } else if raw < -180deg { raw + 360deg } else { raw }
  let delta = if reflex {
    if minor >= 0deg { minor - 360deg } else { minor + 360deg }
  } else {
    minor
  }
  let stop = aa + delta
  let s = if stroke == none { get(style, "stroke") } else { stroke }
  draw.arc(geo.arc-start(vertex, r, aa), radius: r, start: aa, stop: stop, stroke: s, fill: fill, name: "angle-mark")
  if label != none {
    let mid = aa + delta / 2
    let pos = geo.add(vertex, (1.35 * r * calc.cos(mid), 1.35 * r * calc.sin(mid)))
    draw.content(pos, label, anchor: "center")
  }
}

#let segment-ticks(a, b, count: 1, size: 0.12, gap: 0.10, style: theme(), stroke: none) = {
  let u = geo.direction(a, b)
  let n = geo.perp(u)
  let m = geo.midpoint(a, b)
  let s = if stroke == none { get(style, "stroke") } else { stroke }
  for i in range(count) {
    let offset = (i - (count - 1) / 2) * gap
    let c = geo.add(m, geo.mul(offset, u))
    draw.line(geo.sub(c, geo.mul(size, n)), geo.add(c, geo.mul(size, n)), stroke: s)
  }
}

#let parallel-marks(a, b, count: 1, size: 0.14, gap: 0.11, style: theme(), stroke: none) = {
  let u = geo.direction(a, b)
  let n = geo.perp(u)
  let m = geo.midpoint(a, b)
  let s = if stroke == none { get(style, "stroke") } else { stroke }
  for i in range(count) {
    let offset = (i - (count - 1) / 2) * gap
    let c = geo.add(m, geo.mul(offset, u))
    let p1 = geo.add(geo.sub(c, geo.mul(size, u)), geo.mul(size, n))
    let p2 = c
    let p3 = geo.add(geo.add(c, geo.mul(size, u)), geo.mul(size, n))
    draw.line(p1, p2, p3, stroke: s)
  }
}

#let perpendicular-foot(p, a, b, label: none, size: 0.24, style: theme()) = {
  let h = geo.project-point-line(p, a, b)
  draw.line(p, h, stroke: get(style, "auxiliary-stroke"))
  right-angle(h, p, b, size: size, style: style)
  if label != none { draw.content(geo.add(h, (0.1, -0.1)), label, anchor: "north-west") }
  h
}
