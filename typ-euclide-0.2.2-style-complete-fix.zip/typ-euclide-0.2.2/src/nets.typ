#import "@preview/cetz:0.5.2": canvas, draw
#import "core.typ" as geo
#import "styles.typ": theme, get
#import "primitives.typ" as primitive

#let cube-net(side: 1.5, layout: "cross", style: theme(), length: 1cm) = canvas(length: length, {
  let cells = if layout == "t" {
    ((0, 0), (1, 0), (2, 0), (3, 0), (1, 1), (1, -1))
  } else {
    ((0, 0), (1, 0), (2, 0), (3, 0), (1, 1), (1, -1))
  }
  for c in cells {
    let x = c.at(0) * side
    let y = c.at(1) * side
    draw.rect((x, y), (x + side, y + side), stroke: get(style, "stroke"), fill: get(style, "fill"))
  }
})

#let prism-net(n: 3, side: 1.5, height: 2.2, style: theme(), length: 1cm) = canvas(length: length, {
  for i in range(n) {
    draw.rect((i * side, 0), ((i + 1) * side, height), stroke: get(style, "stroke"), fill: get(style, "fill"))
  }
  let radius = side / (2 * calc.sin(180deg / n))
  let top-center = (side / 2, height + radius + 0.2)
  let bottom-center = ((n - 0.5) * side, -radius - 0.2)
  primitive.draw-regular-polygon(n, center: top-center, radius: radius, start-angle: -90deg, style: style, fill: get(style, "fill"))
  primitive.draw-regular-polygon(n, center: bottom-center, radius: radius, start-angle: 90deg, style: style, fill: get(style, "fill"))
})

#let cylinder-net(radius: 1, height: 3, style: theme(), length: 1cm) = canvas(length: length, {
  let width = 2 * calc.pi * radius
  draw.rect((0, 0), (width, height), stroke: get(style, "stroke"), fill: get(style, "fill"))
  draw.circle((radius, height + radius + 0.25), radius: radius, stroke: get(style, "stroke"), fill: get(style, "fill"))
  draw.circle((width - radius, -radius - 0.25), radius: radius, stroke: get(style, "stroke"), fill: get(style, "fill"))
})

#let cone-net(radius: 1.2, slant: 3.2, style: theme(), length: 1cm) = canvas(length: length, {
  let angle = 360deg * radius / slant
  draw.arc(geo.arc-start((0, 0), slant, 0deg), radius: slant, start: 0deg, stop: angle, mode: "PIE", stroke: get(style, "stroke"), fill: get(style, "fill"))
  draw.circle((slant + radius + 0.5, 0), radius: radius, stroke: get(style, "stroke"), fill: get(style, "fill"))
})
