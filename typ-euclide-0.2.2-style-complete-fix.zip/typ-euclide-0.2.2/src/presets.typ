#import "styles.typ": theme
#import "triangles.typ" as triangles
#import "quadrilaterals.typ" as quads
#import "circles.typ" as circles
#import "solids.typ" as solids
#import "nets.typ" as nets
#import "graphs.typ" as graphs
#import "geometry/trigonometry.typ" as trig
#import "geometry/theorems.typ" as theorems
#import "geometry/constructions.typ" as constructions
#import "space/unfold.typ" as unfold
#import "analysis/regions.typ" as regions

// Ready-to-use figures common in Vietnamese secondary and high-school mathematics.
#let _preset-style(style, fallback) = if style == none { theme(fallback) } else { style }

#let triangle-centers(style: none, length: 1cm) = triangles.triangle(features: ("all",), style: _preset-style(style, "blue"), length: length)
#let triangle-euler(style: none, length: 1cm) = triangles.triangle(features: ("medians", "altitudes", "circumcircle", "euler-line", "nine-point-circle"), style: _preset-style(style, "green"), length: length)
#let right-triangle-basic(style: none, length: 1cm) = triangles.right-triangle(legs: (4, 3), style: _preset-style(style, "blue"), length: length)
#let right-triangle-trig(style: none, length: 1cm) = trig.right-triangle-trig(adjacent: 4, opposite: 3, style: _preset-style(style, "blue"), length: length)
#let square-diagonals(style: none, length: 1cm) = quads.square(diagonals: true, style: _preset-style(style, "red"), length: length)
#let circle-tangents(style: none, length: 1cm) = circles.tangent-from-point(style: _preset-style(style, "orange"), length: length)
#let circle-inscribed-angle(style: none, length: 1cm) = circles.inscribed-angle(style: _preset-style(style, "green"), length: length)
#let cube-space-diagonal(style: none, length: 1cm) = solids.cube(diagonals: ((0, 6),), style: _preset-style(style, "blue"), length: length)
#let pyramid-regular(style: none, length: 1cm) = solids.pyramid(n: 4, style: _preset-style(style, "orange"), length: length)
#let cone-and-net(style: none, length: 1cm) = {
  let style = _preset-style(style, "blue")
  grid(columns: (1fr, 1fr), gutter: 1cm, solids.cone(style: style, length: length), nets.cone-net(style: style, length: length))
}
#let area-between-curves(style: none, length: 1cm) = graphs.integral-region(x => x * x - 2, g: x => x, interval: (-1, 2), domain: (-2.5, 3), y-range: (-3, 7), style: _preset-style(style, "green"), length: length)
#let auto-area-between-curves(style: none, length: 1cm) = regions.integral-regions(x => x * x - 2, g: x => x, domain: (-2.5, 3), y-range: (-3, 7), style: _preset-style(style, "green"), length: length)
#let pythagoras(style: none, length: 1cm) = theorems.pythagorean-squares(style: _preset-style(style, "blue"), length: length)
#let thales(style: none, length: 1cm) = theorems.thales-parallel(style: _preset-style(style, "green"), length: length)
#let circumcircle-construction(style: none, length: 1cm) = constructions.circle-through-three-points(style: _preset-style(style, "orange"), length: length)
#let cylinder-shortest-path(style: none, length: 0.55cm) = unfold.wrapped-cylinder(r: 1, h: 4, wrap: 2, style: _preset-style(style, "red"), scale: length)
