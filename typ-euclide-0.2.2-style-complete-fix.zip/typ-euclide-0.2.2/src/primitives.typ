#import "@preview/cetz:0.5.2": draw
#import "core.typ" as geo
#import "styles.typ": theme, get

#let draw-point(
  p,
  label: none,
  label-offset: (0.12, 0.12),
  label-anchor: "south-west",
  style: theme(),
  radius: none,
  fill: none,
  stroke: none,
) = {
  let r = if radius == none { get(style, "point-radius") } else { radius }
  let f = if fill == none { get(style, "point-fill") } else { fill }
  let s = if stroke == none { get(style, "point-stroke") } else { stroke }
  draw.circle(p, radius: r, fill: f, stroke: s)
  if label != none {
    draw.content(
      geo.add(p, label-offset),
      text(size: get(style, "label-size"), fill: get(style, "label-fill"))[#label],
      anchor: label-anchor,
    )
  }
}

#let draw-points(points, labels: (), style: theme(), offsets: ()) = {
  for (i, p) in points.enumerate() {
    let label = if i < labels.len() { labels.at(i) } else { none }
    let offset = if i < offsets.len() { offsets.at(i) } else { (0.12, 0.12) }
    draw-point(p, label: label, label-offset: offset, style: style)
  }
}

#let draw-segment(a, b, style: theme(), stroke: none, name: none, mark: none) = {
  let s = if stroke == none { get(style, "stroke") } else { stroke }
  if mark == none {
    draw.line(a, b, stroke: s, name: name)
  } else {
    draw.line(a, b, stroke: s, mark: mark, name: name)
  }
}

#let draw-polyline(points, style: theme(), stroke: none, close: false, fill: none, name: none) = {
  let s = if stroke == none { get(style, "stroke") } else { stroke }
  let args = points
  draw.line(..args, close: close, stroke: s, fill: fill, name: name)
}

#let draw-line(a, b, extend: 10, style: theme(), stroke: none, name: none) = {
  let u = geo.direction(a, b)
  draw-segment(geo.sub(a, geo.mul(extend, u)), geo.add(b, geo.mul(extend, u)), style: style, stroke: stroke, name: name)
}

#let draw-ray(a, b, extend: 10, style: theme(), stroke: none, name: none) = {
  let u = geo.direction(a, b)
  let s = if stroke == none { get(style, "stroke") } else { stroke }
  draw.line(a, geo.add(b, geo.mul(extend, u)), stroke: s, mark: (end: "stealth"), name: name)
}

#let draw-vector(a, b, label: none, style: theme(), stroke: none) = {
  let s = if stroke == none { get(style, "strong-stroke") } else { stroke }
  draw.line(a, b, stroke: s, mark: (end: "stealth"), name: "vector")
  if label != none {
    draw.content(("vector.start", 50%, "vector.end"), label, anchor: "south", padding: 2pt)
  }
}

#let draw-circle(center, radius, style: theme(), stroke: none, fill: none, name: none) = {
  let s = if stroke == none { get(style, "stroke") } else { stroke }
  draw.circle(center, radius: radius, stroke: s, fill: fill, name: name)
}

#let draw-ellipse(center, rx, ry, style: theme(), stroke: none, fill: none, name: none) = {
  let s = if stroke == none { get(style, "stroke") } else { stroke }
  draw.circle(center, radius: (rx, ry), stroke: s, fill: fill, name: name)
}

#let draw-arc(center, radius, start, stop, style: theme(), stroke: none, fill: none, mode: "OPEN", name: none) = {
  let s = if stroke == none { get(style, "stroke") } else { stroke }
  draw.arc(
    geo.arc-start(center, radius, start),
    radius: radius,
    start: start,
    stop: stop,
    mode: mode,
    stroke: s,
    fill: fill,
    name: name,
  )
}

#let draw-polygon(points, style: theme(), stroke: none, fill: none, name: none) = {
  draw-polyline(points, style: style, stroke: stroke, fill: fill, close: true, name: name)
}

#let draw-regular-polygon(n, center: (0, 0), radius: 1, start-angle: 90deg, style: theme(), stroke: none, fill: none) = {
  draw-polygon(geo.regular-polygon-points(n, center: center, radius: radius, start-angle: start-angle), style: style, stroke: stroke, fill: fill)
}

#let draw-label(p, body, offset: (0, 0), anchor: "center", angle: 0deg, style: theme(), padding: 0pt) = {
  draw.content(
    geo.add(p, offset),
    text(size: get(style, "label-size"), fill: get(style, "label-fill"))[#body],
    anchor: anchor,
    angle: angle,
    padding: padding,
  )
}

#let draw-grid(x-range: (-5, 5), y-range: (-5, 5), step: 1, style: theme()) = {
  let sx = if type(step) == array { step.at(0) } else { step }
  let sy = if type(step) == array { step.at(1) } else { step }
  let stroke = get(style, "grid-stroke")
  let xmin = calc.ceil(x-range.at(0) / sx)
  let xmax = calc.floor(x-range.at(1) / sx)
  let ymin = calc.ceil(y-range.at(0) / sy)
  let ymax = calc.floor(y-range.at(1) / sy)
  for i in range(xmin, xmax + 1) {
    let xx = i * sx
    draw.line((xx, y-range.at(0)), (xx, y-range.at(1)), stroke: stroke)
  }
  for i in range(ymin, ymax + 1) {
    let yy = i * sy
    draw.line((x-range.at(0), yy), (x-range.at(1), yy), stroke: stroke)
  }
}

#let draw-axes(
  x-range: (-5, 5),
  y-range: (-5, 5),
  x-label: $x$,
  y-label: $y$,
  ticks: true,
  tick-step: 1,
  x-tick-step: none,
  y-tick-step: none,
  style: theme(),
) = {
  let axis = get(style, "axis-stroke")
  let xstep = if x-tick-step == none { tick-step } else { x-tick-step }
  let ystep = if y-tick-step == none { tick-step } else { y-tick-step }
  draw.line((x-range.at(0), 0), (x-range.at(1), 0), stroke: axis, mark: (end: "stealth"))
  draw.line((0, y-range.at(0)), (0, y-range.at(1)), stroke: axis, mark: (end: "stealth"))
  draw.content((x-range.at(1), 0), x-label, anchor: "west", padding: 2pt)
  draw.content((0, y-range.at(1)), y-label, anchor: "south", padding: 2pt)
  if ticks {
    let xmin = calc.ceil(x-range.at(0) / xstep)
    let xmax = calc.floor(x-range.at(1) / xstep)
    for i in range(xmin, xmax + 1) {
      let xx = i * xstep
      if calc.abs(xx) > geo.eps {
        draw.line((xx, -0.06), (xx, 0.06), stroke: axis)
        draw.content((xx, -0.12), text(size: 7pt)[#xx], anchor: "north")
      }
    }
    let ymin = calc.ceil(y-range.at(0) / ystep)
    let ymax = calc.floor(y-range.at(1) / ystep)
    for i in range(ymin, ymax + 1) {
      let yy = i * ystep
      if calc.abs(yy) > geo.eps {
        draw.line((-0.06, yy), (0.06, yy), stroke: axis)
        draw.content((-0.12, yy), text(size: 7pt)[#yy], anchor: "east")
      }
    }
  }
}
