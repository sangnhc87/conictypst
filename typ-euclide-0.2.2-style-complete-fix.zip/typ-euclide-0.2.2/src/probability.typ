#import "@preview/cetz:0.5.2": canvas, draw
#import "styles.typ" as styles
#import "core.typ" as geo

#let as-content(value) = [#value]

// Accepts either a dictionary tree or the compact legacy tuple format used in demo.typ.
// Dictionary node: (label: [...], edge: $p$, style: (:), children: (...))
// Legacy node: ([Label], "edge label", (style: ...), (child...), ...)
#let normalize-node(node, path: "0") = {
  if type(node) == dictionary {
    let children = node.at("children", default: ())
    node + (
      id: node.at("id", default: path),
      label: node.at("label", default: path),
      edge: node.at("edge", default: none),
      style: node.at("style", default: (:)),
      children: children.enumerate().map(pair => normalize-node(pair.at(1), path: path + "." + str(pair.at(0)))),
    )
  } else {
    let label = node.at(0)
    let edge = none
    let local-style = (:)
    let start = 1
    if node.len() > 1 and type(node.at(1)) != array and type(node.at(1)) != dictionary {
      edge = node.at(1)
      start = 2
    }
    if node.len() > start and type(node.at(start)) == dictionary {
      local-style = node.at(start)
      start += 1
    }
    let children = ()
    for i in range(start, node.len()) {
      if type(node.at(i)) == array {
        children += (normalize-node(node.at(i), path: path + "." + str(i - start)),)
      }
    }
    (id: path, label: label, edge: edge, style: local-style, children: children)
  }
}

#let probability-tree(
  data,
  dir: "right",
  level-step: 3.2,
  node-step: 1.25,
  path-type: "straight",
  angled-labels: false,
  style: styles.theme(),
  length: 1cm,
) = {
  let root = normalize-node(data)
  let cursor = 0.0

  let layout(node, depth: 0) = {
    let laid-children = ()
    let cross = 0.0
    if node.children.len() == 0 {
      cross = -cursor * node-step
      cursor += 1
    } else {
      for child in node.children {
        laid-children += (layout(child, depth: depth + 1),)
      }
      let sum-cross = 0.0
      for child in laid-children { sum-cross += child.cross }
      cross = sum-cross / laid-children.len()
    }
    let pos = if dir == "down" { (cross, -depth * level-step) } else { (depth * level-step, cross) }
    node + (pos: pos, cross: cross, children: laid-children)
  }

  let tree = layout(root)

  canvas(length: length, {
    let render(node, parent: none) = {
      let p = node.pos
      if parent != none {
        let pp = parent.pos
        let edge-style = node.style.at("edge-stroke", default: styles.get(style, "edge-stroke", fallback: styles.get(style, "stroke")))
        let label-pos = none
        if path-type == "orthogonal" {
          let bend = if dir == "down" { (pp.at(0), p.at(1)) } else { (p.at(0), pp.at(1)) }
          draw.line(pp, bend, p, stroke: edge-style, mark: (end: "stealth"))
          label-pos = if dir == "down" { ((pp.at(0) + bend.at(0)) / 2, (pp.at(1) + bend.at(1)) / 2) } else { ((bend.at(0) + p.at(0)) / 2, (bend.at(1) + p.at(1)) / 2) }
        } else {
          draw.line(pp, p, stroke: edge-style, mark: (end: "stealth"))
          label-pos = ((pp.at(0) + p.at(0)) / 2, (pp.at(1) + p.at(1)) / 2)
        }
        if node.edge != none and node.edge != "" {
          if angled-labels and path-type != "orthogonal" {
            draw.content(label-pos, as-content(node.edge), angle: geo.angle-of(geo.sub(p, pp)), anchor: "south", padding: 2pt, fill: white)
          } else {
            draw.content(label-pos, as-content(node.edge), anchor: "south", padding: 2pt, fill: white)
          }
        }
      }

      let frame = node.style.at("shape", default: styles.get(style, "node-shape", fallback: "rect"))
      let padding = if "padding" in node.style {
        node.style.at("padding")
      } else if "radius" in node.style {
        node.style.at("radius") * length
      } else {
        styles.get(style, "node-padding", fallback: 3pt)
      }
      let node-fill = node.style.at("fill", default: styles.get(style, "node-fill", fallback: white))
      let node-stroke = node.style.at("stroke", default: styles.get(style, "node-stroke", fallback: styles.get(style, "point-stroke")))
      draw.content(p, as-content(node.label), frame: if frame == "none" { none } else { frame }, padding: padding, fill: node-fill, stroke: node-stroke)

      for child in node.children { render(child, parent: node) }
    }
    render(tree)
  })
}

#let prob-tree(
  data,
  dir: "right",
  theme: "default",
  scale: 1cm,
  level-step: 3.2,
  node-step: 1.25,
  path-type: "straight",
  angled-labels: false,
) = probability-tree(
  data,
  dir: dir,
  level-step: level-step,
  node-step: node-step,
  path-type: path-type,
  angled-labels: angled-labels,
  style: if type(theme) == dictionary { theme } else { styles.theme(theme) },
  length: scale,
)

#let venn(n: 2, labels: ($A$, $B$, $C$, $D$), values: (:), style: styles.theme(), length: 1cm, universe: none) = canvas(length: length, {
  if universe != none {
    draw.rect((-3.1, -2.35), (3.1, 2.35), stroke: styles.get(style, "stroke"), fill: none)
    draw.content((-2.9, 2.15), as-content(universe), anchor: "north-west")
  }
  if n == 2 {
    draw.circle((-0.8, 0), radius: 1.6, stroke: (paint: styles.get(style, "accent"), thickness: 1pt), fill: styles.get(style, "accent").transparentize(86%))
    draw.circle((0.8, 0), radius: 1.6, stroke: (paint: styles.get(style, "secondary"), thickness: 1pt), fill: styles.get(style, "secondary").transparentize(86%))
    draw.content((-1.5, 1.4), as-content(labels.at(0)))
    draw.content((1.5, 1.4), as-content(labels.at(1)))
    if "A" in values { draw.content((-1.35, 0), as-content(values.at("A"))) }
    if "B" in values { draw.content((1.35, 0), as-content(values.at("B"))) }
    if "AB" in values { draw.content((0, 0), as-content(values.at("AB"))) }
  } else if n == 3 {
    let centers = ((-0.9, 0.45), (0.9, 0.45), (0, -0.8))
    let colors = (styles.get(style, "accent"), styles.get(style, "secondary"), styles.get(style, "tertiary"))
    for i in range(3) {
      draw.circle(centers.at(i), radius: 1.55, stroke: (paint: colors.at(i), thickness: 1pt), fill: colors.at(i).transparentize(88%))
      draw.content((centers.at(i).at(0), centers.at(i).at(1) + 1.55), as-content(labels.at(i)), anchor: "south")
    }
    let positions = (
      A: (-1.35, 0.65), B: (1.35, 0.65), C: (0, -1.25),
      AB: (0, 0.85), AC: (-0.55, -0.25), BC: (0.55, -0.25), ABC: (0, 0.05),
    )
    for key in positions.keys() { if key in values { draw.content(positions.at(key), as-content(values.at(key))) } }
  } else {
    // Four rotated ellipses: a symmetric 4-set Venn layout with 16 regions.
    let centers = ((-0.42, 0), (0.42, 0), (-0.42, 0), (0.42, 0))
    let angles = (42deg, -42deg, -42deg, 42deg)
    let colors = (styles.get(style, "accent"), styles.get(style, "secondary"), styles.get(style, "tertiary"), rgb("6A1B9A"))
    let ellipse-points(center, rx, ry, angle) = range(145).map(i => {
      let t = i / 144 * 360deg
      let local = (rx * calc.cos(t), ry * calc.sin(t))
      geo.add(center, geo.rotate-vector(local, angle))
    })
    for i in range(4) {
      let pts = ellipse-points(centers.at(i), 1.05, 2.15, angles.at(i))
      draw.line(..pts, close: true, stroke: (paint: colors.at(i), thickness: 0.9pt), fill: colors.at(i).transparentize(91%))
      draw.content(((-2.0, 1.65), (2.0, 1.65), (-2.0, -1.65), (2.0, -1.65)).at(i), as-content(labels.at(i)))
    }
    if "ABCD" in values { draw.content((0, 0), as-content(values.at("ABCD"))) }
    if "A" in values { draw.content((-1.55, 0.95), as-content(values.at("A"))) }
    if "B" in values { draw.content((1.55, 0.95), as-content(values.at("B"))) }
    if "C" in values { draw.content((-1.55, -0.95), as-content(values.at("C"))) }
    if "D" in values { draw.content((1.55, -0.95), as-content(values.at("D"))) }
    if "AB" in values { draw.content((0, 1.25), as-content(values.at("AB"))) }
    if "CD" in values { draw.content((0, -1.25), as-content(values.at("CD"))) }
  }
})

#let venn-diagram(n: 2, labels: ("A", "B", "C", "D"), values: (:), theme: "default", size-scale: 1.0, universe: none) = venn(
  n: n,
  labels: labels,
  values: values,
  style: if type(theme) == dictionary { theme } else { styles.theme(theme) },
  length: size-scale * 1cm,
  universe: universe,
)
