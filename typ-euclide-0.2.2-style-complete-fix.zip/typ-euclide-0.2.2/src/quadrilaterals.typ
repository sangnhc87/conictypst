#import "@preview/cetz:0.5.2": canvas, draw
#import "core.typ" as geo
#import "styles.typ": theme, get
#import "primitives.typ" as primitive
#import "marks.typ" as mark

#let draw-quadrilateral(points, labels: ($A$, $B$, $C$, $D$), diagonals: false, style: theme(), fill: none) = {
  primitive.draw-polygon(points, style: style, fill: fill)
  if diagonals {
    draw.line(points.at(0), points.at(2), stroke: get(style, "auxiliary-stroke"))
    draw.line(points.at(1), points.at(3), stroke: get(style, "auxiliary-stroke"))
  }
  primitive.draw-points(points, labels: labels, offsets: ((-0.12, -0.12), (0.12, -0.12), (0.12, 0.12), (-0.12, 0.12)), style: style)
}

#let rectangle(width: 4, height: 2.5, labels: ($A$, $B$, $C$, $D$), diagonals: false, style: theme(), fill: none, length: 1cm) = canvas(length: length, {
  let pts = ((0, 0), (width, 0), (width, height), (0, height))
  draw-quadrilateral(pts, labels: labels, diagonals: diagonals, style: style, fill: fill)
  mark.right-angle(pts.at(0), pts.at(1), pts.at(3), style: style)
})

#let square(side: 3, labels: ($A$, $B$, $C$, $D$), diagonals: true, style: theme(), fill: none, length: 1cm) = rectangle(width: side, height: side, labels: labels, diagonals: diagonals, style: style, fill: fill, length: length)

#let parallelogram(base: 4, side-vector: (1.2, 2.4), labels: ($A$, $B$, $C$, $D$), diagonals: false, style: theme(), fill: none, length: 1cm) = canvas(length: length, {
  let a = (0, 0)
  let b = (base, 0)
  let d = side-vector
  let c = geo.add(b, side-vector)
  draw-quadrilateral((a, b, c, d), labels: labels, diagonals: diagonals, style: style, fill: fill)
  mark.parallel-marks(a, b, count: 1, style: style)
  mark.parallel-marks(d, c, count: 1, style: style)
  mark.parallel-marks(a, d, count: 2, style: style)
  mark.parallel-marks(b, c, count: 2, style: style)
})

#let rhombus(diagonal-x: 4.5, diagonal-y: 3, labels: ($A$, $B$, $C$, $D$), diagonals: true, style: theme(), fill: none, length: 1cm) = canvas(length: length, {
  let pts = ((-diagonal-x / 2, 0), (0, -diagonal-y / 2), (diagonal-x / 2, 0), (0, diagonal-y / 2))
  draw-quadrilateral(pts, labels: labels, diagonals: diagonals, style: style, fill: fill)
  for i in range(4) { mark.segment-ticks(pts.at(i), pts.at(calc.rem(i + 1, 4)), count: 1, style: style) }
})

#let trapezoid(bottom: 5, top: 2.8, height: 2.5, offset: 0.8, labels: ($A$, $B$, $C$, $D$), diagonals: false, style: theme(), fill: none, length: 1cm) = canvas(length: length, {
  let pts = ((0, 0), (bottom, 0), (offset + top, height), (offset, height))
  draw-quadrilateral(pts, labels: labels, diagonals: diagonals, style: style, fill: fill)
  mark.parallel-marks(pts.at(0), pts.at(1), count: 1, style: style)
  mark.parallel-marks(pts.at(3), pts.at(2), count: 1, style: style)
})

#let cyclic-quadrilateral(radius: 2.5, angles: (210deg, 325deg, 45deg, 130deg), labels: ($A$, $B$, $C$, $D$), diagonals: true, style: theme(), length: 1cm) = canvas(length: length, {
  let pts = angles.map(a => (radius * calc.cos(a), radius * calc.sin(a)))
  draw.circle((0, 0), radius: radius, stroke: get(style, "stroke"))
  draw-quadrilateral(pts, labels: labels, diagonals: diagonals, style: style)
})
