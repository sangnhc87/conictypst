#import "@preview/cetz:0.5.2": canvas, draw
#import "core.typ" as geo
#import "styles.typ": theme, get
#import "primitives.typ" as primitive

#let project3(p, yaw: -28deg, pitch: 22deg) = {
  let x = p.at(0)
  let y = p.at(1)
  let z = p.at(2)
  (
    x * calc.cos(yaw) - y * calc.sin(yaw),
    x * calc.sin(yaw) * calc.sin(pitch) + y * calc.cos(yaw) * calc.sin(pitch) + z * calc.cos(pitch),
  )
}

#let draw-edge(a, b, hidden: false, style: theme()) = draw.line(a, b, stroke: if hidden { get(style, "hidden-stroke") } else { get(style, "stroke") })

#let base-labels = ($A$, $B$, $C$, $D$, $E$, $F$, $G$, $H$, $I$, $J$, $K$, $L$)
#let top-labels = ($A'$, $B'$, $C'$, $D'$, $E'$, $F'$, $G'$, $H'$, $I'$, $J'$, $K'$, $L'$)
#let choose-label(labels, i, top: false) = {
  let source = if type(labels) == array { labels } else if top { top-labels } else { base-labels }
  if i < source.len() { source.at(i) } else { none }
}

#let cube(side: 3, yaw: -28deg, pitch: 22deg, labels: true, diagonals: (), style: theme(), length: 1cm) = canvas(length: length, {
  let pts3 = (
    (0, 0, 0), (side, 0, 0), (side, side, 0), (0, side, 0),
    (0, 0, side), (side, 0, side), (side, side, side), (0, side, side),
  )
  let p = pts3.map(q => project3(q, yaw: yaw, pitch: pitch))
  for (i, j, hidden) in (
    (0, 1, false), (1, 2, false), (2, 3, true), (3, 0, true),
    (4, 5, false), (5, 6, false), (6, 7, false), (7, 4, false),
    (0, 4, false), (1, 5, false), (2, 6, false), (3, 7, true),
  ) { draw-edge(p.at(i), p.at(j), hidden: hidden, style: style) }
  for d in diagonals {
    draw.line(p.at(d.at(0)), p.at(d.at(1)), stroke: get(style, "auxiliary-stroke"))
  }
  if labels != false {
    let labs = if type(labels) == array { labels } else { ($A$, $B$, $C$, $D$, $A'$, $B'$, $C'$, $D'$) }
    primitive.draw-points(p, labels: labs, style: style)
  }
})

#let prism(n: 3, radius: 2, height: 3, yaw: -28deg, pitch: 20deg, labels: true, style: theme(), length: 1cm) = canvas(length: length, {
  let base = geo.regular-polygon-points(n, radius: radius, start-angle: 90deg)
  let bottom3 = base.map(q => (q.at(0), q.at(1), 0))
  let top3 = base.map(q => (q.at(0), q.at(1), height))
  let bottom = bottom3.map(q => project3(q, yaw: yaw, pitch: pitch))
  let top = top3.map(q => project3(q, yaw: yaw, pitch: pitch))
  draw.line(..bottom, close: true, stroke: get(style, "stroke"))
  draw.line(..top, close: true, stroke: get(style, "stroke"))
  for i in range(n) { draw.line(bottom.at(i), top.at(i), stroke: get(style, "stroke")) }
  if labels != false {
    for i in range(n) {
      primitive.draw-point(bottom.at(i), label: choose-label(labels, i), style: style)
      primitive.draw-point(top.at(i), label: choose-label(labels, i, top: true), style: style)
    }
  }
})

#let pyramid(n: 4, radius: 2.2, height: 3.5, yaw: -28deg, pitch: 20deg, labels: true, style: theme(), length: 1cm) = canvas(length: length, {
  let base = geo.regular-polygon-points(n, radius: radius, start-angle: 45deg)
  let bp = base.map(q => project3((q.at(0), q.at(1), 0), yaw: yaw, pitch: pitch))
  let apex = project3((0, 0, height), yaw: yaw, pitch: pitch)
  draw.line(..bp, close: true, stroke: get(style, "stroke"))
  for q in bp { draw.line(apex, q, stroke: get(style, "stroke")) }
  if labels != false {
    primitive.draw-point(apex, label: $S$, style: style)
    for (i, q) in bp.enumerate() { primitive.draw-point(q, label: choose-label(labels, i), style: style) }
  }
})

#let cylinder(radius: 2, height: 3.5, squash: 0.38, style: theme(), length: 1cm) = canvas(length: length, {
  let bottom = (0, 0)
  let top = (0, height)
  draw.circle(bottom, radius: (radius, radius * squash), stroke: get(style, "stroke"))
  draw.circle(top, radius: (radius, radius * squash), stroke: get(style, "stroke"))
  draw.line((-radius, 0), (-radius, height), stroke: get(style, "stroke"))
  draw.line((radius, 0), (radius, height), stroke: get(style, "stroke"))
  primitive.draw-points((bottom, top), labels: ($O$, $O'$), style: style)
})

#let cone(radius: 2, height: 3.8, squash: 0.38, style: theme(), length: 1cm) = canvas(length: length, {
  let o = (0, 0)
  let s = (0, height)
  draw.circle(o, radius: (radius, radius * squash), stroke: get(style, "stroke"))
  draw.line((-radius, 0), s, stroke: get(style, "stroke"))
  draw.line((radius, 0), s, stroke: get(style, "stroke"))
  draw.line(o, s, stroke: get(style, "auxiliary-stroke"))
  primitive.draw-points((o, s), labels: ($O$, $S$), style: style)
})

#let frustum(radius-bottom: 2.2, radius-top: 1.1, height: 3.2, squash: 0.38, style: theme(), length: 1cm) = canvas(length: length, {
  draw.circle((0, 0), radius: (radius-bottom, radius-bottom * squash), stroke: get(style, "stroke"))
  draw.circle((0, height), radius: (radius-top, radius-top * squash), stroke: get(style, "stroke"))
  draw.line((-radius-bottom, 0), (-radius-top, height), stroke: get(style, "stroke"))
  draw.line((radius-bottom, 0), (radius-top, height), stroke: get(style, "stroke"))
})

#let sphere(radius: 2.3, style: theme(), length: 1cm) = canvas(length: length, {
  draw.circle((0, 0), radius: radius, stroke: get(style, "stroke"))
  draw.arc(geo.arc-start((0, 0), (radius, radius * 0.28), 0deg), radius: (radius, radius * 0.28), start: 0deg, stop: 180deg, stroke: get(style, "hidden-stroke"))
  draw.arc(geo.arc-start((0, 0), (radius, radius * 0.28), 180deg), radius: (radius, radius * 0.28), start: 180deg, stop: 360deg, stroke: get(style, "stroke"))
  draw.line((0, 0), (radius, 0), stroke: get(style, "auxiliary-stroke"))
  primitive.draw-point((0, 0), label: $O$, style: style)
})
