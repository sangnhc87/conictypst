#import "@preview/cetz:0.5.2": canvas, draw
#import "../core.typ" as geo
#import "../styles.typ" as styles

#let section-radius(value, kind, value-type: "radius") = {
  if value-type == "side" and kind != "circle" and kind != "semi-circle" {
    value / 2
  } else {
    value
  }
}

#let polygon-section-points(kind, center, value, axis: "y", depth: 0.36, rotation: 0deg, value-type: "radius", anchor: "center") = {
  let n = if kind == "triangle" { 3 } else if kind == "square" { 4 } else if kind == "pentagon" { 5 } else { 6 }
  let r = section-radius(value, kind, value-type: value-type)
  let start = if kind == "square" { 45deg + rotation } else { 90deg + rotation }
  let raw = geo.regular-polygon-points(n, radius: r, start-angle: start)
  let transformed = raw.map(p => {
    if axis == "x" {
      (center.at(0) + p.at(0) * depth, center.at(1) + p.at(1))
    } else {
      (center.at(0) + p.at(0), center.at(1) + p.at(1) * depth)
    }
  })
  if anchor == "bottom" {
    let min-cross = 1e9
    for p in transformed {
      let value = if axis == "x" { p.at(1) } else { p.at(0) }
      if value < min-cross { min-cross = value }
    }
    transformed.map(p => if axis == "x" {
      (p.at(0), p.at(1) - min-cross)
    } else {
      (p.at(0) - min-cross, p.at(1))
    })
  } else {
    transformed
  }
}

#let draw-section-shape(
  kind,
  center,
  value,
  axis: "y",
  depth: 0.36,
  rotation: 0deg,
  value-type: "radius",
  anchor: "center",
  stroke: black,
  fill: none,
) = {
  let r = section-radius(value, kind, value-type: value-type)
  if kind == "circle" {
    if axis == "x" {
      draw.circle(center, radius: (r * depth, r), stroke: stroke, fill: fill)
    } else {
      draw.circle(center, radius: (r, r * depth), stroke: stroke, fill: fill)
    }
  } else if kind == "semi-circle" {
    if axis == "x" {
      draw.arc(geo.arc-start(center, (r * depth, r), -90deg), radius: (r * depth, r), start: -90deg, stop: 90deg, mode: "CLOSE", stroke: stroke, fill: fill)
    } else {
      draw.arc(geo.arc-start(center, (r, r * depth), 0deg), radius: (r, r * depth), start: 0deg, stop: 180deg, mode: "CLOSE", stroke: stroke, fill: fill)
    }
  } else {
    let pts = polygon-section-points(kind, center, value, axis: axis, depth: depth, rotation: rotation, value-type: value-type, anchor: anchor)
    draw.line(..pts, close: true, stroke: stroke, fill: fill)
  }
}

#let solid-section(
  kind: "circle",
  axis: "y",
  f,
  f2: none,
  domain: (0, 4),
  slices: (),
  value-type: "radius",
  anchor: "center",
  rotation: 0deg,
  depth: 0.36,
  samples: 100,
  caps: true,
  style: styles.theme(),
  length: 1cm,
) = canvas(length: length, {
  let lo = domain.at(0)
  let hi = domain.at(1)
  let ts = range(samples + 1).map(i => lo + i / samples * (hi - lo))
  let left = ts.map(t => {
    let r = calc.abs(f(t))
    if axis == "x" { (t, -r) } else { (-r, t) }
  })
  let right = ts.map(t => {
    let r = calc.abs(f(t))
    if axis == "x" { (t, r) } else { (r, t) }
  })

  let surface-fill = styles.get(style, "fill")
  draw.line(..(left + right.rev()), close: true, stroke: none, fill: surface-fill)
  draw.line(..left, stroke: styles.get(style, "stroke"))
  draw.line(..right, stroke: styles.get(style, "stroke"))

  if f2 != none {
    let inner-left = ts.map(t => {
      let r = calc.abs(f2(t))
      if axis == "x" { (t, -r) } else { (-r, t) }
    })
    let inner-right = ts.map(t => {
      let r = calc.abs(f2(t))
      if axis == "x" { (t, r) } else { (r, t) }
    })
    draw.line(..inner-left, stroke: styles.get(style, "hidden-stroke"))
    draw.line(..inner-right, stroke: styles.get(style, "hidden-stroke"))
  }

  for t in slices {
    let center = if axis == "x" { (t, 0) } else { (0, t) }
    draw-section-shape(
      kind,
      center,
      calc.abs(f(t)),
      axis: axis,
      depth: depth,
      rotation: rotation,
      value-type: value-type,
      anchor: anchor,
      stroke: styles.get(style, "auxiliary-stroke"),
      fill: styles.get(style, "accent").transparentize(92%),
    )
    if f2 != none {
      draw-section-shape(
        kind,
        center,
        calc.abs(f2(t)),
        axis: axis,
        depth: depth,
        rotation: rotation,
        value-type: value-type,
        anchor: anchor,
        stroke: styles.get(style, "hidden-stroke"),
        fill: white,
      )
    }
  }

  if caps {
    for t in (lo, hi) {
      let center = if axis == "x" { (t, 0) } else { (0, t) }
      draw-section-shape(
        kind,
        center,
        calc.abs(f(t)),
        axis: axis,
        depth: depth,
        rotation: rotation,
        value-type: value-type,
        anchor: anchor,
        stroke: styles.get(style, "strong-stroke"),
        fill: styles.get(style, "accent").transparentize(88%),
      )
      if f2 != none {
        draw-section-shape(
          kind,
          center,
          calc.abs(f2(t)),
          axis: axis,
          depth: depth,
          rotation: rotation,
          value-type: value-type,
          anchor: anchor,
          stroke: styles.get(style, "hidden-stroke"),
          fill: white,
        )
      }
    }
  }
})

// Compatibility wrapper matching the original demo API.
#let draw-solid-section(
  type: "circle",
  axis: "y",
  f,
  f2: none,
  domain: (0, 4),
  slices: (),
  value-type: "radius",
  anchor: "center",
  rotation: 0deg,
  theme: "default",
  size-scale: 1.0,
  caps: true,
  depth: 0.36,
) = solid-section(
  kind: type,
  axis: axis,
  f: f,
  f2: f2,
  domain: domain,
  slices: slices,
  value-type: value-type,
  anchor: anchor,
  rotation: rotation,
  depth: depth,
  caps: caps,
  style: styles.theme(theme),
  length: size-scale * 1cm,
)
