#import "@preview/cetz:0.5.2": canvas, draw
#import "../core.typ" as geo
#import "../styles.typ" as styles
#import "../primitives.typ" as primitive

// Surface-unfolding helpers for shortest-path and wrapped-path exercises.
// The 3D views are pedagogical projections; the 2D views use the true
// surface dimensions supplied by the caller.

#let path-stroke(style) = (paint: styles.get(style, "secondary"), thickness: 1.35pt, cap: "round")
#let edge-stroke(style) = styles.get(style, "stroke")
#let hidden-stroke(style) = styles.get(style, "hidden-stroke")
#let fill-style(style) = styles.get(style, "fill")

#let show-pair(view3d, view2d, display: "both", gap: 1.2cm) = {
  if display == "3d" { view3d }
  else if display == "2d" { view2d }
  else { grid(columns: (auto, auto), gutter: gap, align: center, view3d, view2d) }
}

#let helix-points(radius-fn, height, turns: 1, samples: 160, squash: 0.34, phase: 180deg) = range(samples + 1).map(i => {
  let t = i / samples
  let angle = phase + turns * 360deg * t
  let r = radius-fn(t)
  (r * calc.cos(angle), height * t + squash * r * calc.sin(angle))
})

#let cylinder-3d(radius, height, turns, squash, style, length) = canvas(length: length, {
  draw.circle((0, 0), radius: (radius, radius * squash), stroke: edge-stroke(style), fill: fill-style(style))
  draw.circle((0, height), radius: (radius, radius * squash), stroke: edge-stroke(style), fill: none)
  draw.line((-radius, 0), (-radius, height), stroke: edge-stroke(style))
  draw.line((radius, 0), (radius, height), stroke: edge-stroke(style))
  let path = helix-points(_ => radius, height, turns: turns, squash: squash)
  draw.line(..path, stroke: path-stroke(style))
  primitive.draw-point(path.first(), label: $A$, style: style, fill: styles.get(style, "secondary"))
  primitive.draw-point(path.last(), label: $B$, style: style, fill: styles.get(style, "secondary"))
})

#let cylinder-net-view(radius, height, turns, style, length) = canvas(length: length, {
  let width = 2 * calc.pi * radius * turns
  draw.rect((0, 0), (width, height), stroke: edge-stroke(style), fill: fill-style(style))
  for i in range(calc.floor(turns) + 1) {
    let xx = i * 2 * calc.pi * radius
    if xx > 0 and xx < width { draw.line((xx, 0), (xx, height), stroke: hidden-stroke(style)) }
  }
  draw.line((0, 0), (width, height), stroke: path-stroke(style))
  primitive.draw-point((0, 0), label: $A$, style: style, fill: styles.get(style, "secondary"))
  primitive.draw-point((width, height), label: $B$, style: style, fill: styles.get(style, "secondary"))
})

#let wrapped-cylinder(
  r: 1,
  h: 4,
  vis-r: none,
  vis-h: none,
  wrap: 1,
  display: "both",
  scale: 0.75cm,
  gap: 1.2cm,
  squash: 0.34,
  style: styles.theme(),
) = {
  let vr = if vis-r == none { r } else { vis-r }
  let vh = if vis-h == none { h } else { vis-h }
  show-pair(
    cylinder-3d(vr, vh, wrap, squash, style, scale),
    cylinder-net-view(r, h, wrap, style, scale),
    display: display,
    gap: gap,
  )
}

#let cone-3d(radius, height, turns, to, squash, style, length) = canvas(length: length, {
  let apex = (0, height)
  draw.circle((0, 0), radius: (radius, radius * squash), stroke: edge-stroke(style), fill: fill-style(style))
  draw.line((-radius, 0), apex, stroke: edge-stroke(style))
  draw.line((radius, 0), apex, stroke: edge-stroke(style))
  let end-frac = geo.clamp(to, 0, 1)
  let path = range(181).map(i => {
    let t = i / 180 * end-frac
    let rr = radius * (1 - t)
    let angle = 180deg + turns * 360deg * t / calc.max(end-frac, geo.eps)
    (rr * calc.cos(angle), height * t + squash * rr * calc.sin(angle))
  })
  draw.line(..path, stroke: path-stroke(style))
  primitive.draw-point(path.first(), label: $A$, style: style, fill: styles.get(style, "secondary"))
  primitive.draw-point(path.last(), label: $B$, style: style, fill: styles.get(style, "secondary"))
})

#let cone-net-view(radius, slant, turns, to-distance, style, length) = canvas(length: length, {
  let angle = 360deg * radius / slant * turns
  draw.arc(geo.arc-start((0, 0), slant, 0deg), radius: slant, start: 0deg, stop: angle, mode: "PIE", stroke: edge-stroke(style), fill: fill-style(style))
  let end-radius = geo.clamp(to-distance, 0, slant)
  let a = (slant, 0)
  let b = (end-radius * calc.cos(angle), end-radius * calc.sin(angle))
  draw.line(a, b, stroke: path-stroke(style))
  primitive.draw-point((0, 0), label: $S$, style: style)
  primitive.draw-point(a, label: $A$, style: style, fill: styles.get(style, "secondary"))
  primitive.draw-point(b, label: $B$, style: style, fill: styles.get(style, "secondary"))
})

#let wrapped-cone(
  r: 1,
  l: 4,
  to: none,
  vis-r: none,
  vis-h: none,
  wrap: 1,
  display: "both",
  scale: 0.65cm,
  gap: 1.2cm,
  squash: 0.34,
  style: styles.theme(),
) = {
  let vr = if vis-r == none { r } else { vis-r }
  let vh = if vis-h == none { calc.sqrt(calc.max(l * l - r * r, geo.eps)) } else { vis-h }
  let end-distance = if to == none { 0 } else { to }
  let end-frac = if to == none { 1 } else { geo.clamp((l - to) / l, 0, 1) }
  show-pair(
    cone-3d(vr, vh, wrap, end-frac, squash, style, scale),
    cone-net-view(r, l, wrap, end-distance, style, scale),
    display: display,
    gap: gap,
  )
}

#let frustum-radii(r1, r2, slant) = {
  let delta = calc.abs(r1 - r2)
  if delta < geo.eps {
    (inner: 0, outer: slant, angle: 360deg * r1 / slant)
  } else {
    let outer = slant * calc.max(r1, r2) / delta
    let inner = outer - slant
    (inner: inner, outer: outer, angle: 360deg * delta / slant)
  }
}

#let frustum-3d(r1, r2, height, turns, squash, style, length) = canvas(length: length, {
  draw.circle((0, 0), radius: (r1, r1 * squash), stroke: edge-stroke(style), fill: fill-style(style))
  draw.circle((0, height), radius: (r2, r2 * squash), stroke: edge-stroke(style), fill: none)
  draw.line((-r1, 0), (-r2, height), stroke: edge-stroke(style))
  draw.line((r1, 0), (r2, height), stroke: edge-stroke(style))
  let path = helix-points(t => r1 + (r2 - r1) * t, height, turns: turns, squash: squash)
  draw.line(..path, stroke: path-stroke(style))
  primitive.draw-point(path.first(), label: $A$, style: style, fill: styles.get(style, "secondary"))
  primitive.draw-point(path.last(), label: $B$, style: style, fill: styles.get(style, "secondary"))
})

#let frustum-net-view(r1, r2, slant, turns, style, length) = canvas(length: length, {
  let data = frustum-radii(r1, r2, slant)
  let angle = data.angle * turns
  draw.arc(geo.arc-start((0, 0), data.outer, 0deg), radius: data.outer, start: 0deg, stop: angle, mode: "PIE", stroke: edge-stroke(style), fill: fill-style(style))
  if data.inner > geo.eps {
    draw.arc(geo.arc-start((0, 0), data.inner, 0deg), radius: data.inner, start: 0deg, stop: angle, mode: "PIE", stroke: edge-stroke(style), fill: white)
  }
  let a = (data.outer, 0)
  let b = (data.inner * calc.cos(angle), data.inner * calc.sin(angle))
  draw.line(a, b, stroke: path-stroke(style))
  primitive.draw-point(a, label: $A$, style: style, fill: styles.get(style, "secondary"))
  primitive.draw-point(b, label: $B$, style: style, fill: styles.get(style, "secondary"))
})

#let wrapped-frustum(
  r1: 2,
  r2: 1,
  l: 4,
  vis-r1: none,
  vis-r2: none,
  vis-h: none,
  wrap: 1,
  path-style: "straight",
  display: "both",
  scale: 0.6cm,
  gap: 1.2cm,
  squash: 0.34,
  style: styles.theme(),
) = {
  let vr1 = if vis-r1 == none { r1 } else { vis-r1 }
  let vr2 = if vis-r2 == none { r2 } else { vis-r2 }
  let vh = if vis-h == none { calc.sqrt(calc.max(l * l - (r1 - r2) * (r1 - r2), geo.eps)) } else { vis-h }
  show-pair(
    frustum-3d(vr1, vr2, vh, wrap, squash, style, scale),
    frustum-net-view(r1, r2, l, wrap, style, scale),
    display: display,
    gap: gap,
  )
}

#let prism-3d(faces, side, height, turns, z-start, z-end, style, length) = canvas(length: length, {
  let radius = side / (2 * calc.sin(180deg / faces))
  let bottom = geo.regular-polygon-points(faces, radius: radius, start-angle: 90deg)
  let offset = (0.8, height)
  let top = bottom.map(p => geo.add(p, offset))
  draw.line(..bottom, close: true, stroke: edge-stroke(style), fill: fill-style(style))
  draw.line(..top, close: true, stroke: edge-stroke(style), fill: none)
  for i in range(faces) { draw.line(bottom.at(i), top.at(i), stroke: edge-stroke(style)) }
  let total = calc.max(1, calc.ceil(turns * faces))
  let path = range(total + 1).map(i => {
    let t = i / total
    let k = calc.rem(i, faces)
    let base = geo.lerp(bottom.at(k), top.at(k), z-start + (z-end - z-start) * t)
    geo.add(base, (0.06 * i, 0))
  })
  draw.line(..path, stroke: path-stroke(style))
  primitive.draw-point(path.first(), label: $M$, style: style, fill: styles.get(style, "secondary"))
  primitive.draw-point(path.last(), label: $N$, style: style, fill: styles.get(style, "secondary"))
})

#let prism-net-view(faces, side, height, turns, z-start, z-end, style, length) = canvas(length: length, {
  let count = calc.max(1, calc.ceil(turns * faces))
  for i in range(count) {
    draw.rect((i * side, 0), ((i + 1) * side, height), stroke: edge-stroke(style), fill: fill-style(style))
  }
  let a = (0, z-start * height)
  let b = (count * side, z-end * height)
  draw.line(a, b, stroke: path-stroke(style))
  primitive.draw-point(a, label: $M$, style: style, fill: styles.get(style, "secondary"))
  primitive.draw-point(b, label: $N$, style: style, fill: styles.get(style, "secondary"))
})

#let wrapped-prism(
  faces: 3,
  a: 2,
  h: 4,
  wrap: 1,
  z-start: 0,
  z-end: 1,
  display: "both",
  scale: 0.55cm,
  gap: 1.2cm,
  style: styles.theme(),
) = show-pair(
  prism-3d(faces, a, h, wrap, z-start, z-end, style, scale),
  prism-net-view(faces, a, h, wrap, z-start, z-end, style, scale),
  display: display,
  gap: gap,
)

#let wrapped-cube(
  a: 2,
  wrap: 4,
  z-start: 0,
  z-end: 1,
  m-at-bottom: false,
  path-type: "auto",
  display: "both",
  scale: 0.55cm,
  gap: 1.2cm,
  style: styles.theme(),
) = wrapped-prism(
  faces: 4,
  a: a,
  h: a,
  wrap: wrap / 4,
  z-start: if m-at-bottom { 0 } else { z-start },
  z-end: z-end,
  display: display,
  scale: scale,
  gap: gap,
  style: style,
)

#let pyramid-3d(n, side, edge, turns, start-distance, end-distance, style, length) = canvas(length: length, {
  let radius = side / (2 * calc.sin(180deg / n))
  let base = geo.regular-polygon-points(n, radius: radius, start-angle: -90deg)
  let apex = (0, calc.sqrt(calc.max(edge * edge - radius * radius, geo.eps)))
  draw.line(..base, close: true, stroke: edge-stroke(style), fill: fill-style(style))
  for p in base { draw.line(apex, p, stroke: edge-stroke(style)) }
  let start = geo.lerp(apex, base.first(), geo.clamp(start-distance / edge, 0, 1))
  let end-index = calc.rem(calc.round(turns * n), n)
  let end = geo.lerp(apex, base.at(end-index), geo.clamp(end-distance / edge, 0, 1))
  draw.line(start, end, stroke: path-stroke(style))
  primitive.draw-point(apex, label: $S$, style: style)
  primitive.draw-point(start, label: $M$, style: style, fill: styles.get(style, "secondary"))
  primitive.draw-point(end, label: $N$, style: style, fill: styles.get(style, "secondary"))
})

#let pyramid-net-view(n, side, edge, turns, start-distance, end-distance, style, length) = canvas(length: length, {
  let apex = (0, 0)
  let beta = 2 * calc.asin(side / (2 * edge))
  let count = calc.max(1, calc.ceil(turns * n))
  for i in range(count) {
    let a1 = i * beta
    let a2 = (i + 1) * beta
    draw.line(apex, (edge * calc.cos(a1), edge * calc.sin(a1)), (edge * calc.cos(a2), edge * calc.sin(a2)), close: true, stroke: edge-stroke(style), fill: fill-style(style))
  }
  let p = (start-distance, 0)
  let angle = count * beta
  let q = (end-distance * calc.cos(angle), end-distance * calc.sin(angle))
  draw.line(p, q, stroke: path-stroke(style))
  primitive.draw-point(apex, label: $S$, style: style)
  primitive.draw-point(p, label: $M$, style: style, fill: styles.get(style, "secondary"))
  primitive.draw-point(q, label: $N$, style: style, fill: styles.get(style, "secondary"))
})

#let wrapped-pyramid(
  n: 4,
  a: 2,
  e: 3,
  wrap: 1,
  sm: none,
  sm2: none,
  display: "both",
  scale: 0.6cm,
  gap: 1.2cm,
  style: styles.theme(),
) = {
  let start-distance = if sm == none { e } else { sm }
  let end-distance = if sm2 == none { e } else { sm2 }
  show-pair(
    pyramid-3d(n, a, e, wrap, start-distance, end-distance, style, scale),
    pyramid-net-view(n, a, e, wrap, start-distance, end-distance, style, scale),
    display: display,
    gap: gap,
  )
}
