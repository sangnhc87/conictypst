// Centralized themes and style helpers.

#let palette = (
  ink: rgb("20252B"),
  muted: rgb("667085"),
  blue: rgb("1565C0"),
  red: rgb("C62828"),
  green: rgb("2E7D32"),
  orange: rgb("EF6C00"),
  violet: rgb("6A1B9A"),
  cyan: rgb("00838F"),
  yellow: rgb("F9A825"),
  paper: rgb("FFFFFF"),
  grid: rgb("D0D5DD"),
)

#let theme-default = (
  stroke: (paint: palette.ink, thickness: 0.8pt, cap: "round", join: "round"),
  strong-stroke: (paint: palette.ink, thickness: 1.25pt, cap: "round", join: "round"),
  auxiliary-stroke: (paint: palette.muted, thickness: 0.65pt, dash: "dashed"),
  hidden-stroke: (paint: palette.muted, thickness: 0.55pt, dash: "dashed"),
  construction-stroke: (paint: palette.blue.transparentize(25%), thickness: 0.6pt, dash: "dotted"),
  point-radius: 0.055,
  point-fill: palette.paper,
  point-stroke: (paint: palette.ink, thickness: 0.8pt),
  label-fill: palette.ink,
  label-size: 9pt,
  angle-radius: 0.34,
  mark-size: 0.18,
  fill: palette.blue.transparentize(86%),
  accent: palette.blue,
  secondary: palette.red,
  tertiary: palette.green,
  axis-stroke: (paint: palette.ink, thickness: 0.75pt),
  grid-stroke: (paint: palette.grid, thickness: 0.35pt),
  edge-stroke: (paint: palette.muted, thickness: 0.7pt),
  node-shape: "rect",
  node-fill: palette.paper,
  node-stroke: (paint: palette.ink, thickness: 0.7pt),
  node-padding: 3pt,
)

#let theme-blue = theme-default + (
  accent: palette.blue,
  secondary: palette.red,
  tertiary: palette.green,
  fill: palette.blue.transparentize(86%),
)

#let theme-red = theme-default + (
  accent: palette.red,
  secondary: palette.blue,
  tertiary: palette.orange,
  fill: palette.red.transparentize(87%),
)

#let theme-green = theme-default + (
  accent: palette.green,
  secondary: palette.orange,
  tertiary: palette.violet,
  fill: palette.green.transparentize(87%),
)

#let theme-orange = theme-default + (
  accent: palette.orange,
  secondary: palette.blue,
  tertiary: palette.green,
  fill: palette.orange.transparentize(86%),
)

#let theme-minimal = theme-default + (
  stroke: (paint: palette.ink, thickness: 0.65pt, cap: "round", join: "round"),
  strong-stroke: (paint: palette.ink, thickness: 0.9pt, cap: "round", join: "round"),
  point-radius: 0.045,
  label-size: 8.5pt,
  fill: none,
  node-shape: "none",
  node-stroke: none,
  node-fill: none,
)

#let theme(name: none, overrides: (:)) = {
  let selected = if name == none { "default" } else { name }
  let base = if type(selected) == dictionary {
    selected
  } else if selected == "blue" {
    theme-blue
  } else if selected == "red" {
    theme-red
  } else if selected == "green" {
    theme-green
  } else if selected == "orange" {
    theme-orange
  } else if selected == "minimal" {
    theme-minimal
  } else {
    theme-default
  }
  base + overrides
}

#let get(style, key, fallback: none) = style.at(key, default: fallback)
#let stroke-with(style, paint: none, thickness: none, dash: none) = {
  let result = style
  if paint != none { result.paint = paint }
  if thickness != none { result.thickness = thickness }
  if dash != none { result.dash = dash }
  result
}
