#import "@preview/cetz:0.5.2": canvas, draw
#import "core.typ" as geo
#import "styles.typ": theme, get
#import "primitives.typ" as primitive
#import "marks.typ" as mark

#let draw-triangle(
  a, b, c,
  labels: ($A$, $B$, $C$),
  label-offsets: ((-0.12, 0.14), (-0.12, -0.16), (0.12, -0.16)),
  features: (),
  style: theme(),
  fill: none,
  show-points: true,
  show-centers: true,
) = {
  primitive.draw-polygon((a, b, c), style: style, fill: fill)

  let ma = geo.midpoint(b, c)
  let mb = geo.midpoint(c, a)
  let mc = geo.midpoint(a, b)
  let g = geo.triangle-centroid(a, b, c)
  let o = geo.triangle-circumcenter(a, b, c)
  let i = geo.triangle-incenter(a, b, c)
  let h = geo.triangle-orthocenter(a, b, c)

  if "medians" in features or "all" in features {
    draw.line(a, ma, stroke: get(style, "auxiliary-stroke"))
    draw.line(b, mb, stroke: get(style, "auxiliary-stroke"))
    draw.line(c, mc, stroke: get(style, "auxiliary-stroke"))
  }
  if "altitudes" in features or "all" in features {
    let ha = geo.project-point-line(a, b, c)
    let hb = geo.project-point-line(b, c, a)
    let hc = geo.project-point-line(c, a, b)
    draw.line(a, ha, stroke: get(style, "auxiliary-stroke"))
    draw.line(b, hb, stroke: get(style, "auxiliary-stroke"))
    draw.line(c, hc, stroke: get(style, "auxiliary-stroke"))
    mark.right-angle(ha, a, c, size: 0.18, style: style)
    mark.right-angle(hb, b, a, size: 0.18, style: style)
    mark.right-angle(hc, c, b, size: 0.18, style: style)
  }
  if "perpendicular-bisectors" in features or "all" in features {
    for (p, q) in ((a, b), (b, c), (c, a)) {
      let m = geo.midpoint(p, q)
      let n = geo.perp(geo.direction(p, q))
      draw.line(geo.sub(m, geo.mul(5, n)), geo.add(m, geo.mul(5, n)), stroke: get(style, "construction-stroke"))
    }
  }
  if "angle-bisectors" in features or "all" in features {
    draw.line(a, i, stroke: get(style, "auxiliary-stroke"))
    draw.line(b, i, stroke: get(style, "auxiliary-stroke"))
    draw.line(c, i, stroke: get(style, "auxiliary-stroke"))
  }
  if "incircle" in features or "all" in features {
    let inc = geo.triangle-incircle(a, b, c)
    draw.circle(inc.center, radius: inc.radius, stroke: (paint: get(style, "secondary"), thickness: 0.8pt))
  }
  if "circumcircle" in features or "all" in features {
    let circum = geo.triangle-circumcircle(a, b, c)
    if circum != none {
      draw.circle(circum.center, radius: circum.radius, stroke: (paint: get(style, "accent"), thickness: 0.8pt))
    }
  }
  if "euler-line" in features or "all" in features {
    if o != none and h != none {
      let u = geo.direction(o, h)
      draw.line(geo.sub(o, geo.mul(2, u)), geo.add(h, geo.mul(2, u)), stroke: (paint: get(style, "tertiary"), thickness: 0.8pt, dash: "dashed"))
    }
  }
  if "nine-point-circle" in features or "all" in features {
    if o != none and h != none {
      let n = geo.midpoint(o, h)
      draw.circle(n, radius: geo.distance(o, a) / 2, stroke: (paint: get(style, "tertiary"), thickness: 0.75pt, dash: "dashed"))
      if show-centers { primitive.draw-point(n, label: $N$, style: style, fill: get(style, "tertiary")) }
    }
  }

  if show-centers {
    if ("medians" in features or "all" in features) { primitive.draw-point(g, label: $G$, style: style, fill: get(style, "accent")) }
    if ("circumcircle" in features or "euler-line" in features or "all" in features) and o != none { primitive.draw-point(o, label: $O$, style: style, fill: get(style, "accent")) }
    if ("incircle" in features or "angle-bisectors" in features or "all" in features) { primitive.draw-point(i, label: $I$, style: style, fill: get(style, "secondary")) }
    if ("altitudes" in features or "euler-line" in features or "all" in features) and h != none { primitive.draw-point(h, label: $H$, style: style, fill: get(style, "tertiary")) }
  }

  if show-points {
    primitive.draw-points((a, b, c), labels: labels, offsets: label-offsets, style: style)
  }
}

#let triangle(
  a: (-2.2, -1.2),
  b: (2.3, -1.2),
  c: (0.4, 2.2),
  labels: ($A$, $B$, $C$),
  features: (),
  style: theme(),
  fill: none,
  length: 1cm,
) = canvas(length: length, {
  draw-triangle(a, b, c, labels: labels, features: features, style: style, fill: fill)
})

#let right-triangle(
  legs: (4, 3),
  labels: ($A$, $B$, $C$),
  show-right-angle: true,
  features: (),
  style: theme(),
  length: 1cm,
) = canvas(length: length, {
  let a = (0, 0)
  let b = (legs.at(0), 0)
  let c = (0, legs.at(1))
  draw-triangle(a, b, c, labels: labels, features: features, style: style)
  if show-right-angle { mark.right-angle(a, b, c, style: style) }
})

#let equilateral-triangle(
  side: 4,
  labels: ($A$, $B$, $C$),
  features: (),
  style: theme(),
  length: 1cm,
) = canvas(length: length, {
  let a = (-side / 2, 0)
  let b = (side / 2, 0)
  let c = (0, side * calc.sqrt(3) / 2)
  draw-triangle(a, b, c, labels: labels, features: features, style: style)
  mark.segment-ticks(a, b, count: 1, style: style)
  mark.segment-ticks(b, c, count: 1, style: style)
  mark.segment-ticks(c, a, count: 1, style: style)
})

#let isosceles-triangle(
  base: 4,
  height: 3.5,
  labels: ($A$, $B$, $C$),
  features: (),
  style: theme(),
  length: 1cm,
) = canvas(length: length, {
  let a = (-base / 2, 0)
  let b = (base / 2, 0)
  let c = (0, height)
  draw-triangle(a, b, c, labels: labels, features: features, style: style)
  mark.segment-ticks(a, c, count: 1, style: style)
  mark.segment-ticks(b, c, count: 1, style: style)
})
