#import "../unfold.typ": cone, cylinder, draw-lp-region, draw-integral-region
#import "../tree.typ": prob-tree
#import "../venn.typ": venn-diagram
#import "../solid-section.typ": draw-solid-section
#import "../conic-tangent.typ": draw-tangent-parabola
#import "@preview/cetz:0.5.2"

#cone(r: 1, l: 4, display: "2d", scale: 0.25cm)
#venn-diagram(n: 2, values: ("A": 3, "B": 4, "AB": 1), size-scale: 0.35)

#cetz.canvas(length: 0.45cm, {
  import cetz.draw: *
  draw-lp-region(((a: 1, b: 1, c: 4), (a: -1, b: 0, c: 0), (a: 0, b: -1, c: 0)))
})

#cetz.canvas(length: 0.45cm, {
  import cetz.draw: *
  draw-integral-region(x => x * x, x => x, domain: (-1, 2))
})

#cetz.canvas(length: 0.45cm, {
  import cetz.draw: *
  draw-tangent-parabola(a: 1, circles: ((R: 1, y: "auto"),), axes-range: ((-2, 2), (-1, 4)))
})
