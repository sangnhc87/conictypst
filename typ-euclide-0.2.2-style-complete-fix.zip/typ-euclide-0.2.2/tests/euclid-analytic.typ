#import "../lib.typ": euclid

#let close(a, b, tolerance: 1e-6) = calc.abs(a - b) <= tolerance

// Vector and angle conventions.
#assert(close(euclid.distance((0, 0), (3, 4)), 5))
#assert(close(euclid.analytic.signed-angle((1, 0), (0, 0), (0, 1)).deg(), 90))

// Triangle centers.
#let d = euclid.triangle-data((0, 0), (4, 0), (0, 3))
#assert(close(d.G.at(0), 4 / 3))
#assert(close(d.G.at(1), 1))
#assert(close(d.O.at(0), 2))
#assert(close(d.O.at(1), 1.5))
#assert(close(d.H.at(0), 0))
#assert(close(d.H.at(1), 0))

// Tangent points have radius OT and right angle OTP.
#let circle = euclid.analytic.circle((0, 0), 2)
#let tangents = euclid.tangent-points(circle, (4, 0))
#assert(tangents.len() == 2)
#for t in tangents {
  assert(close(euclid.distance((0, 0), t), 2))
  assert(close(euclid.analytic.dot(t, euclid.analytic.sub((4, 0), t)), 0))
}

// Open named model and query/customization helpers.
#let fig = euclid.triangle(features: ("vertices", "centers"))
#assert(euclid.object-at(fig, "triangle") != none)
#assert(euclid.objects-with-tag(fig, "centers").len() >= 4)
#let fig = euclid.alias-point(fig, "X", "G")
#let fig = euclid.with-point-option(fig, "X", (point: (fill: red),))
#let fig = euclid.with-object(fig, euclid.point("X", role: "accent"))
#assert(euclid.has-point(fig, "X"))
#assert(euclid.validate(fig).len() == 0)

// Vertical-major ellipse is supported.
#let vertical = euclid.conics.ellipse(a: 1.5, b: 3)
#assert(close(euclid.point-at(vertical, "F_1").at(0), 0))
#assert(euclid.point-at(vertical, "F_1").at(1) < 0)
