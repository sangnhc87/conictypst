#import "../lib.typ": euclid

#let tri = euclid.triangle(
  A: (-2, 0),
  B: (3, 0),
  C: (0.5, 3),
  features: ("vertices", "all"),
)

#assert(euclid.has-point(tri, "A"))
#assert(euclid.has-point(tri, "G"))
#assert(euclid.has-point(tri, "K"))
#assert(euclid.validate(tri).len() == 0)

#let tri = euclid.construct.midpoint(tri, "D", "B", "C")
#let tri = euclid.with-object(tri, euclid.segment("A", "D", id: "extra-ad", role: "accent"))
#assert(euclid.has-point(tri, "D"))
#assert(euclid.validate(tri).len() == 0)

#let q = euclid.trapezoid(features: ("vertices", "diagonals", "midpoints", "diagonal-intersection"))
#assert(euclid.validate(q).len() == 0)

#let conic = euclid.conics.ellipse(a: 3, b: 2, rotation: 10deg)
#assert(euclid.has-point(conic, "F_1"))
#assert(euclid.validate(conic).len() == 0)

#grid(columns: (1fr, 1fr),
  euclid.render-model(tri, style: euclid.euclid-theme("blue"), length: 0.65cm),
  euclid.render-model(q, style: euclid.euclid-theme("green"), length: 0.65cm),
  euclid.render-model(conic, style: euclid.euclid-theme("red"), length: 0.65cm),
)
