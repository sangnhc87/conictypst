#import "../lib.typ": *
#import "@preview/cetz:0.5.2" as cetz

#set page(width: auto, height: auto, margin: 5pt)

#grid(columns: (1fr, 1fr, 1fr), gutter: 5pt,
  right-triangle(length: 0.35cm),
  square(length: 0.35cm),
  tangent-from-point(length: 0.35cm),
  regular-polygon(n: 5, length: 0.35cm),
  thales-parallel(length: 0.35cm),
  pythagorean-squares(length: 0.28cm),
  unit-circle(length: 0.28cm),
  perpendicular-bisector(length: 0.3cm),
  parabola(length: 0.3cm),
  tangent-parabola(circles: ((R: 1, y: "auto"),), length: 0.3cm),
  cube(length: 0.35cm),
  cone-net(length: 0.35cm),
  wrapped-cylinder(display: "2d", scale: 0.25cm),
  solid-section(kind: "circle", f: y => 1 + y / 4, domain: (0, 3), length: 0.3cm),
  venn-diagram(n: 3, size-scale: 0.45),
)

#integral-regions(x => x * x - 2, g: x => x, domain: (-2.5, 3), y-range: (-3, 7), length: 0.3cm)

#cetz.canvas({
  import cetz.draw: *
  draw-lp-region((
    (a: 1, b: 2, c: 10),
    (a: 2, b: 1, c: 8),
    (a: -1, b: 0, c: 0),
    (a: 0, b: -1, c: 0),
  ))
})
