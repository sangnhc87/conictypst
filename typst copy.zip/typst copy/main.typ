// main.typ — Chỉ include đề, mọi cấu hình trong file đề 
#include "exams/de-01.typ"
