// ═══════════════════════════════════════════════════════════
// STEXGV BOOK MODULE
// Phân hệ biên soạn Sách, Chuyên đề và Đề cương học tập
// ═══════════════════════════════════════════════════════════

#import "exam.typ": palette, classic, draw-lines, _sol as _exam-sol
#import "exam.typ": lythuyet as _lythuyet, luuy as _luuy, note as _note, dn as _dn, dl as _dl, tc as _tc, bode as _bode

#let _chap-cnt = counter("stx-chap")
#let _topic-cnt = counter("stx-topic")
#let _vd-cnt = counter("stx-vd")
#let _bt-cnt = counter("stx-bt")

#let _advance(counter) = context {
  let value = counter.get().first() + 1
  let _ = counter.update(value)
  value
}

#let _resolve-loigiai(loigiai, args) = {
  if loigiai != none { loigiai } else { args.named().at("solution", default: none) }
}

#let setcounter(env, start) = {
  let current = if start > 0 { start - 1 } else { 0 }
  let name = if type(env) == str { lower(env) } else { env }
  if ("chapter", "chuong").contains(name) {
    let _ = _chap-cnt.update(current)
  }
  if ("topic", "dang").contains(name) {
    let _ = _topic-cnt.update(current)
  }
  if ("vd", "vidu").contains(name) {
    let _ = _vd-cnt.update(current)
  }
  if ("bt", "baitap").contains(name) {
    let _ = _bt-cnt.update(current)
  }
}

#let _banner(
  number,
  title,
  prefix: "Chương",
  accent: classic.blue,
  fill: auto,
  stroke: auto,
  inset: 18pt,
  radius: 10pt,
) = {
  let body-fill = if fill == auto { accent.lighten(92%) } else { fill }
  let body-stroke = if stroke == auto { 0.8pt + accent.lighten(45%) } else { stroke }
  block(width: 100%, fill: body-fill, inset: inset, radius: radius, stroke: body-stroke)[
    #grid(columns: (auto, 1fr), column-gutter: 16pt, align: (left + horizon, left + horizon),
      box(fill: accent, inset: (x: 16pt, y: 12pt), radius: 8pt)[
        #text(size: 9pt, weight: "bold", fill: white)[#upper(prefix)]
        #v(0.15em)
        #text(size: 30pt, weight: "bold", fill: white)[#number]
      ],
      [
        #text(size: 10pt, weight: "bold", fill: accent)[Nội dung trọng tâm]
        #v(0.35em)
        #text(size: 22pt, weight: "bold", fill: accent.darken(10%))[#title]
      ],
    )
    #v(0.85em)
    #line(length: 100%, stroke: 1pt + accent.lighten(55%))
  ]
}

#let _numbered-card(
  body,
  counter,
  prefix,
  loigiai: none,
  lines: 0,
  theme-color: classic.blue,
  boxed: true,
  fill: white,
  stroke: auto,
  inset: (x: 10pt, y: 10pt),
  radius: 4pt,
  header-fill: auto,
  title-fill: auto,
) = context {
  let num = _advance(counter)
  let border = if stroke == auto { 0.5pt + theme-color } else { stroke }
  let banner-fill = if header-fill == auto { theme-color.lighten(85%) } else { header-fill }
  let heading-fill = if title-fill == auto { theme-color.darken(20%) } else { title-fill }

  v(1em)
  if boxed {
    block(width: 100%, stroke: border, radius: radius, inset: 0pt, fill: fill, clip: true)[
      #block(width: 100%, fill: banner-fill, inset: (x: 10pt, y: 8pt), stroke: (bottom: 0.5pt + theme-color))[
        #text(weight: "bold", fill: heading-fill)[#prefix #num.]
      ]
      #block(width: 100%, inset: inset)[
        #body
        #if lines > 0 { draw-lines(lines) }
        #if loigiai != none {
          v(0.8em)
          _exam-sol(loigiai, theme-color)
        }
      ]
    ]
  } else {
    [
      #text(weight: "bold", fill: heading-fill)[#prefix #num.]
      #v(0.5em)
      #body
      #if lines > 0 { draw-lines(lines) }
      #if loigiai != none {
        v(0.8em)
        _exam-sol(loigiai, theme-color)
      }
    ]
  }
  v(0.5em)
}

#let stexgv-book(
  title: "TÀI LIỆU TOÁN HỌC",
  author: "Nguyễn Văn Sang",
  theme-color: classic.blue,
  doc-type: "book",
  show-cover: true,
  show-outline: true,
  body,
) = {
  set document(title: title, author: author)
  set page(
    paper: "a4",
    margin: (top: 2.5cm, bottom: 2.5cm, inside: 2.5cm, outside: 2cm),
    header: context {
      let page-num = counter(page).get().first()
      if page-num == 1 and show-cover { return none }

      set text(size: 10pt, fill: theme-color)
      grid(
        columns: (1fr, auto),
        align: (left, right),
        text(weight: "bold")[#title],
        text(weight: "bold")[#author],
      )
      v(-4pt)
      line(length: 100%, stroke: 0.8pt + theme-color)
    },
    footer: context {
      let page-num = counter(page).get().first()
      if page-num == 1 and show-cover { return none }

      set text(size: 10pt, fill: palette.muted)
      line(length: 100%, stroke: 0.4pt + palette.border)
      v(2pt)
      align(center)[Trang #page-num]
    },
  )

  set text(font: "Libertinus Serif", size: 12pt, lang: "vi")
  set par(justify: true, leading: 0.75em)
  show math.equation.where(block: false): math.display
  set enum(numbering: "1.")

  if show-cover {
    align(center + horizon)[
      #text(size: 30pt, weight: "bold", fill: theme-color)[#title]
      #v(1em)
      #text(size: 18pt, style: "italic")[Biên soạn: #author]
      #v(3em)
    ]
    pagebreak()
  }

  if show-outline {
    outline(title: text(fill: theme-color)[MỤC LỤC], depth: 3, indent: auto)
    pagebreak()
  }

  body
}

#let chapter(
  title,
  prefix: "Chương",
  theme-color: classic.blue,
  pagebreak-before: true,
  boxed: true,
  fill: auto,
  stroke: auto,
) = {
  let num = _advance(_chap-cnt)
  let _ = _topic-cnt.update(0)
  let _ = _vd-cnt.update(0)
  let _ = _bt-cnt.update(0)

  if pagebreak-before { pagebreak(weak: true) }
  v(2em)
  if boxed {
    _banner(
      num,
      title,
      prefix: prefix,
      accent: theme-color,
      fill: fill,
      stroke: stroke,
    )
  } else {
    [
      #text(size: 16pt, weight: "bold", fill: theme-color)[#upper(prefix) #num:]
      #v(0.5em)
      #text(size: 22pt, weight: "bold", fill: theme-color.darken(10%))[#title]
    ]
  }
  v(2em)
}

#let topic(
  title,
  prefix: "Dạng",
  theme-color: classic.blue,
  boxed: true,
  fill: auto,
  stroke: auto,
  radius: 4pt,
) = {
  let num = _advance(_topic-cnt)
  let _ = _vd-cnt.update(0)
  let _ = _bt-cnt.update(0)

  v(1.5em)
  if boxed {
    block(
      width: 100%,
      fill: if fill == auto { theme-color.lighten(95%) } else { fill },
      inset: (x: 12pt, y: 10pt),
      radius: radius,
      stroke: if stroke == auto { (left: 4pt + theme-color) } else { stroke },
    )[
      #text(size: 14pt, weight: "bold", fill: theme-color)[#prefix #num. #title]
    ]
  } else {
    text(size: 14pt, weight: "bold", fill: theme-color)[#prefix #num. #title]
  }
  v(1em)
}

#let dang = topic

#let vd(
  stem,
  loigiai: none,
  lines: 0,
  theme-color: classic.blue,
  prefix: "Ví dụ",
  boxed: true,
  fill: white,
  stroke: auto,
  inset: (x: 10pt, y: 10pt),
  radius: 4pt,
  header-fill: auto,
  title-fill: auto,
  ..args,
) = context {
  let loigiai = _resolve-loigiai(loigiai, args)
  _numbered-card(
    stem,
    _vd-cnt,
    prefix,
    loigiai: loigiai,
    lines: lines,
    theme-color: theme-color,
    boxed: boxed,
    fill: fill,
    stroke: stroke,
    inset: inset,
    radius: radius,
    header-fill: header-fill,
    title-fill: title-fill,
  )
}

#let bt(
  stem,
  loigiai: none,
  lines: 0,
  theme-color: classic.emerald,
  prefix: "Bài tập",
  boxed: true,
  fill: white,
  stroke: auto,
  inset: (x: 10pt, y: 10pt),
  radius: 4pt,
  header-fill: auto,
  title-fill: auto,
  ..args,
) = context {
  let loigiai = _resolve-loigiai(loigiai, args)
  _numbered-card(
    stem,
    _bt-cnt,
    prefix,
    loigiai: loigiai,
    lines: lines,
    theme-color: theme-color,
    boxed: boxed,
    fill: fill,
    stroke: stroke,
    inset: inset,
    radius: radius,
    header-fill: header-fill,
    title-fill: title-fill,
  )
}

#let vidu = vd
#let baitap = bt

#let nhanxet(body, title: [Nhận xét], ..args) = _note(
  body,
  title: title,
  accent: rgb("#b45309"),
  fill: rgb("#fff7ed"),
  title-fill: rgb("#9a3412"),
  ..args,
)

#let ghinho(body, title: [Ghi nhớ], ..args) = _note(
  body,
  title: title,
  accent: rgb("#0369a1"),
  fill: rgb("#eff6ff"),
  title-fill: rgb("#075985"),
  ..args,
)

#let phuongphap(body, title: [Phương pháp], ..args) = _lythuyet(
  body,
  title: title,
  accent: classic.emerald,
  fill: rgb("#ecfdf5"),
  title-fill: classic.emerald,
  ..args,
)

#let lythuyet(body, ..args) = _lythuyet(body, ..args)
#let luuy(body, ..args) = _luuy(body, ..args)
#let note(body, ..args) = _note(body, ..args)
#let dn(body, ..args) = _dn(body, ..args)
#let dl(body, ..args) = _dl(body, ..args)
#let tc(body, ..args) = _tc(body, ..args)
#let bode(body, ..args) = _bode(body, ..args)

#let definition(body, ..args) = dn(body, ..args)