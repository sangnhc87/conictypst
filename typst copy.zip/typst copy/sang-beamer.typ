// =========================================================
// SANG-BEAMER.TYP v3.0 — Slide trình chiếu Premium
// =========================================================

#import "@preview/touying:0.7.3": *
#import themes.metropolis: *

#import "sang-exam.typ": palette, classic, True, vect, ppgiai, luuy, meo, lythuyet, note, dn, dl, tc, bode, draw-lines

// ── Màu sắc sống động ──────────────────────────────────
#let bm-colors = (
  bg:       rgb("#0f172a"),    // Nền slide xanh đậm
  fg:       white,
  accent:   rgb("#3b82f6"),    // Xanh dương sáng
  correct:  rgb("#22c55e"),    // Xanh lá tươi
  wrong:    rgb("#ef4444"),    // Đỏ
  card:     rgb("#1e293b"),    // Card tối
  card-hi:  rgb("#172554"),    // Card hover
  muted:    rgb("#94a3b8"),
  gold:     rgb("#f59e0b"),    // Vàng accent
)

// ── Label tracker cho hyperlink ─────────────────────────
// Mỗi câu tạo label <bm-q-N> để footer nhảy tới

#let _resolve-loigiai(loigiai, args) = {
  if loigiai != none { loigiai } else { args.named().at("solution", default: none) }
}

#let _label-num(num, label-num: auto, offset: 0) = {
  if label-num == auto { offset + num } else { label-num }
}

// ── Beamer Theme ────────────────────────────────────────
#let sang-beamer-theme(body,
  title:       "ĐỀ THI THPT QUỐC GIA",
  subtitle:    "TOÁN - LỚP 12",
  author:      "GV Nguyễn Văn Sang",
  institution: "Sở GD&ĐT",
  date:        datetime.today(),
  accent:      bm-colors.accent,
  aspect-ratio: "16-9",
  code:        "",
  total-q:     22,
) = {
  show: metropolis-theme.with(
    aspect-ratio: aspect-ratio,
    config-info(
      title: [#title],
      subtitle: [#subtitle #if code != "" [— Mã đề: #code]],
      author: [#author],
      date: date,
      institution: [#institution],
    ),
    config-common(slide-fn: slide),
    config-colors(
      primary: accent,
      primary-light: accent.lighten(50%),
      secondary: bm-colors.gold,
      neutral-lightest: bm-colors.bg,
      neutral-darkest: white,
    ),
    config-page(
      footer: context {
        set text(size: 7pt, fill: bm-colors.muted)
        v(2pt)
        grid(columns: (auto, 1fr, auto),
          align: (left + horizon, center + horizon, right + horizon),
          pad(left: 8pt)[#author — #institution],
          // ── Nút nhảy câu tròn ──
          {
            let dots = ()
            for i in range(1, total-q + 1) {
              let lbl = label("bm-q-" + str(i))
              let has = query(lbl).len() > 0
              if has {
                dots.push(
                  link(lbl, box(
                    width: 13pt, height: 13pt, radius: 50%,
                    fill: accent.lighten(70%),
                    stroke: 0.5pt + accent,
                    align(center + horizon)[
                      #text(size: 5.5pt, weight: "bold", fill: accent)[#i]
                    ]
                  ))
                )
              } else {
                dots.push(
                  box(width: 10pt, height: 10pt, radius: 50%,
                    fill: bm-colors.bg.lighten(20%),
                    stroke: 0.4pt + bm-colors.muted.lighten(40%),
                  )
                )
              }
            }
            stack(dir: ltr, spacing: 3pt, ..dots)
          },
          pad(right: 8pt)[#counter(page).display() / #counter(page).final().first()],
        )
      },
    ),
  )

  set text(font: "Libertinus Serif", size: 18pt, fill: white, lang: "vi")
  show math.equation.where(block: false): math.display
  show math.equation: set text(fill: bm-colors.gold)

  title-slide()
  body
}

// ── exam-part ────────────────────────────────────────────
#let exam-part(title, count: auto, reset-counter: true) = {
  [= #title]
}

// ── MCQ ──────────────────────────────────────────────────
#let mcq(stem, options,
  correct: (), loigiai: none, mode: "loigiai", accent: bm-colors.accent,
  fig: none, fig-pos: "right", fig-width: 40%, cols: 0, lines: 0,
  num: 0, prefix: "Câu", label-num: auto,
  card-fill: bm-colors.card, card-stroke: auto,
  ..args,
) = {
  let loigiai = _resolve-loigiai(loigiai, args)
  let card-stroke = if card-stroke == auto { 1.2pt + accent.lighten(30%) } else { card-stroke }
  let labels = ("A", "B", "C", "D", "E", "F")
  let ai = -1
  let idx = 0
  for opt in options {
    let ok = if type(opt) == dictionary { opt.at("correct", default: false) }
             else { correct.contains(idx + 1) }
    if ok { ai = idx }
    idx += 1
  }
  let opt-texts = options.map(o => if type(o) == dictionary { o.body } else { o })
  let opt-oks = options.enumerate().map(((i, o)) =>
    if type(o) == dictionary { o.at("correct", default: false) }
    else { correct.contains(i + 1) })

  // SLIDE 1: Câu hỏi
  slide(title: none)[
    #[#metadata("q") #label("bm-q-" + str(_label-num(num, label-num: label-num)))]
    #v(-0.5em)
    #grid(columns: (auto, 1fr), column-gutter: 10pt, align: (left + top, left + top),
      box(fill: accent, inset: (x: 10pt, y: 6pt), radius: 4pt)[
        #text(weight: "bold", fill: white, size: 16pt)[#prefix #num]
      ],
      text(size: 17pt, fill: white)[#stem],
    )

    #if fig != none {
      v(0.3em)
      align(center, block(width: fig-width)[#fig])
    }

    #v(0.5em)
    #grid(columns: (1fr, 1fr), row-gutter: 10pt, column-gutter: 12pt,
      ..opt-texts.enumerate().map(((i, t)) => {
        box(width: 100%, inset: (x: 14pt, y: 10pt),
          radius: 8pt,
          fill: card-fill,
          stroke: card-stroke,
        )[
          #text(weight: "bold", fill: accent, size: 17pt)[#labels.at(i).]
          #h(8pt) #text(size: 16pt, fill: white)[#t]
        ]
      })
    )
  ]

  // SLIDE 2: Đáp án
  if mode == "loigiai" and (ai >= 0 or loigiai != none) {
    slide(title: none)[
      #v(-0.5em)
      #grid(columns: (auto, 1fr), column-gutter: 10pt, align: (left + horizon, left + horizon),
        box(fill: bm-colors.correct, inset: (x: 10pt, y: 6pt), radius: 4pt)[
          #text(weight: "bold", fill: white, size: 16pt)[#prefix #num — ĐÁP ÁN]
        ],
        [],
      )

      #v(0.4em)
      #grid(columns: (1fr, 1fr), row-gutter: 10pt, column-gutter: 12pt,
        ..opt-texts.enumerate().map(((i, t)) => {
          let ok = opt-oks.at(i)
          let bg = if ok { bm-colors.correct.darken(60%) } else { card-fill }
          let brd = if ok { 2pt + bm-colors.correct } else { 0.8pt + rgb("#334155") }
          let mark = if ok { [ ✓] } else { [] }
          let txt-col = if ok { white } else { bm-colors.muted }
          box(width: 100%, inset: (x: 14pt, y: 10pt),
            radius: 8pt, fill: bg, stroke: brd,
          )[
            #text(weight: "bold", fill: if ok { bm-colors.correct } else { bm-colors.muted }, size: 17pt)[#labels.at(i).#mark]
            #h(8pt) #text(size: 16pt, fill: txt-col)[#t]
          ]
        })
      )

      #if loigiai != none {
        v(0.5em)
        block(width: 100%, fill: rgb("#0c1a3a"),
          stroke: (left: 3pt + bm-colors.gold),
          inset: (x: 14pt, y: 10pt), radius: (right: 6pt),
        )[
          #text(weight: "bold", fill: bm-colors.gold, size: 14pt)[📝 Lời giải]
          #v(0.3em)
          #set text(size: 13pt, fill: rgb("#cbd5e1"))
          #loigiai
        ]
      }
    ]
  }
}

// ── TF ───────────────────────────────────────────────────
#let tf(stem, statements,
  loigiai: none, mode: "loigiai", accent: bm-colors.accent,
  fig: none, fig-pos: "right", fig-width: 30%, lines: 0,
  num: 0, prefix: "Câu", label-num: auto,
  ..args,
) = {
  let loigiai = _resolve-loigiai(loigiai, args)
  let alpha = ("a", "b", "c", "d", "e", "f")

  slide(title: none)[
    #[#metadata("q") #label("bm-q-" + str(_label-num(num, label-num: label-num, offset: 12)))]
    #v(-0.5em)
    #box(fill: accent, inset: (x: 10pt, y: 6pt), radius: 4pt)[
      #text(weight: "bold", fill: white, size: 16pt)[#prefix #num — Đúng/Sai]
    ]
    #v(0.3em)
    #text(size: 15pt, fill: white)[#stem]
    #if fig != none { v(0.3em); align(center, fig) }

    #v(0.3em)
    #table(
      columns: (1fr, auto, auto),
      stroke: 0.6pt + rgb("#334155"),
      align: (left + horizon, center + horizon, center + horizon),
      table.cell(fill: accent,
        pad(x: 8pt, y: 5pt)[#text(fill: white, weight: "bold", size: 13pt)[Phát biểu]]),
      table.cell(fill: accent,
        pad(x: 8pt, y: 5pt)[#text(fill: white, weight: "bold", size: 13pt)[Đ]]),
      table.cell(fill: accent,
        pad(x: 8pt, y: 5pt)[#text(fill: white, weight: "bold", size: 13pt)[S]]),
      ..statements.enumerate().map(((i, s)) => {
        let txt = if type(s) == dictionary { s.body } else { s }
        (
          table.cell(fill: bm-colors.card,
            pad(x: 8pt, y: 5pt)[#text(weight: "bold", fill: accent, size: 12pt)[#alpha.at(i))] #h(4pt) #text(size: 12pt, fill: white)[#txt]]),
          table.cell(fill: bm-colors.card,
            align(center)[#box(width: 1.6em, height: 1.6em, stroke: 0.6pt + bm-colors.muted, radius: 3pt)]),
          table.cell(fill: bm-colors.card,
            align(center)[#box(width: 1.6em, height: 1.6em, stroke: 0.6pt + bm-colors.muted, radius: 3pt)]),
        )
      }).flatten()
    )
  ]

  if mode == "loigiai" {
    slide(title: none)[
      #v(-0.5em)
      #box(fill: bm-colors.correct, inset: (x: 10pt, y: 6pt), radius: 4pt)[
        #text(weight: "bold", fill: white, size: 16pt)[#prefix #num — ĐÁP ÁN]
      ]
      #v(0.3em)
      #table(
        columns: (1fr, auto, auto),
        stroke: 0.6pt + rgb("#334155"),
        align: (left + horizon, center + horizon, center + horizon),
        table.cell(fill: accent,
          pad(x: 8pt, y: 5pt)[#text(fill: white, weight: "bold", size: 13pt)[Phát biểu]]),
        table.cell(fill: accent,
          pad(x: 8pt, y: 5pt)[#text(fill: white, weight: "bold", size: 13pt)[Đ]]),
        table.cell(fill: accent,
          pad(x: 8pt, y: 5pt)[#text(fill: white, weight: "bold", size: 13pt)[S]]),
        ..statements.enumerate().map(((i, s)) => {
          let ok = if type(s) == dictionary { s.at("correct", default: false) } else { false }
          let txt = if type(s) == dictionary { s.body } else { s }
          let fd = if ok { bm-colors.correct.darken(60%) } else { bm-colors.card }
          let fs = if not ok { bm-colors.wrong.darken(60%) } else { bm-colors.card }
          let md = if ok { text(fill: bm-colors.correct, weight: "bold", size: 13pt)[✓] } else { none }
          let ms = if not ok { text(fill: bm-colors.wrong, weight: "bold", size: 13pt)[✓] } else { none }
          (
            table.cell(fill: bm-colors.card,
              pad(x: 8pt, y: 5pt)[#text(weight: "bold", fill: accent, size: 12pt)[#alpha.at(i))] #h(4pt) #text(size: 12pt, fill: white)[#txt]]),
            table.cell(fill: fd,
              align(center)[#box(width: 1.6em, height: 1.6em, stroke: 0.6pt + bm-colors.muted, radius: 3pt, fill: fd,
                align(center + horizon)[#md])]),
            table.cell(fill: fs,
              align(center)[#box(width: 1.6em, height: 1.6em, stroke: 0.6pt + bm-colors.muted, radius: 3pt, fill: fs,
                align(center + horizon)[#ms])]),
          )
        }).flatten()
      )

      #if loigiai != none {
        v(0.3em)
        block(width: 100%, fill: rgb("#0c1a3a"),
          stroke: (left: 3pt + bm-colors.gold),
          inset: (x: 14pt, y: 8pt), radius: (right: 6pt),
        )[
          #text(weight: "bold", fill: bm-colors.gold, size: 13pt)[📝 Lời giải] #v(0.2em)
          #set text(size: 12pt, fill: rgb("#cbd5e1"))
          #loigiai
        ]
      }
    ]
  }
}

// ── SHORT ────────────────────────────────────────────────
#let short(stem, answer,
  loigiai: none, mode: "loigiai", accent: bm-colors.accent,
  fig: none, fig-pos: "right", fig-width: 30%, show-boxes: true, lines: 0,
  num: 0, prefix: "Câu", label-num: auto, box-count: 4,
  ..args,
) = {
  let loigiai = _resolve-loigiai(loigiai, args)
  slide(title: none)[
    #[#metadata("q") #label("bm-q-" + str(_label-num(num, label-num: label-num, offset: 16)))]
    #v(-0.5em)
    #box(fill: accent, inset: (x: 10pt, y: 6pt), radius: 4pt)[
      #text(weight: "bold", fill: white, size: 16pt)[#prefix #num — Trả lời ngắn]
    ]
    #v(0.4em)
    #text(size: 17pt, fill: white)[#stem]
    #if fig != none { v(0.3em); align(center, fig) }

    #if show-boxes {
      v(0.8em)
      align(center)[
        #text(weight: "bold", fill: white, size: 17pt)[Đáp số: ]
        #h(8pt)
        #stack(dir: ltr, spacing: 4pt,
          ..range(box-count).map(_ => box(width: 2em, height: 2em, stroke: 1.2pt + bm-colors.gold, radius: 4pt, fill: bm-colors.card)))
      ]
    }
  ]

  if mode == "loigiai" {
    slide(title: none)[
      #v(-0.5em)
      #box(fill: bm-colors.correct, inset: (x: 10pt, y: 6pt), radius: 4pt)[
        #text(weight: "bold", fill: white, size: 16pt)[#prefix #num — ĐÁP ÁN]
      ]
      #v(0.6em)
      #align(center)[
        #box(fill: bm-colors.correct.darken(40%), stroke: 2pt + bm-colors.correct,
          inset: (x: 24pt, y: 14pt), radius: 10pt)[
          #text(weight: "bold", size: 24pt, fill: bm-colors.correct)[Đáp số: #answer]
        ]
      ]

      #if loigiai != none {
        v(0.6em)
        block(width: 100%, fill: rgb("#0c1a3a"),
          stroke: (left: 3pt + bm-colors.gold),
          inset: (x: 14pt, y: 10pt), radius: (right: 6pt),
        )[
          #text(weight: "bold", fill: bm-colors.gold, size: 14pt)[📝 Lời giải] #v(0.2em)
          #set text(size: 13pt, fill: rgb("#cbd5e1"))
          #loigiai
        ]
      }
    ]
  }
}

#let tl(stem,
  loigiai: none, mode: "loigiai", accent: bm-colors.accent,
  fig: none, fig-pos: "right", fig-width: 30%, show-boxes: true,
  num: 0, prefix: "Câu", label-num: auto,
  ..args,
) = {
  let loigiai = _resolve-loigiai(loigiai, args)

  slide(title: none)[
    #[#metadata("q") #label("bm-q-" + str(_label-num(num, label-num: label-num)))]
    #v(-0.5em)
    #box(fill: accent, inset: (x: 10pt, y: 6pt), radius: 4pt)[
      #text(weight: "bold", fill: white, size: 16pt)[#prefix #num — Tự luận]
    ]
    #v(0.4em)
    #text(size: 17pt, fill: white)[#stem]
    #if fig != none { v(0.3em); align(center, fig) }

    #if show-boxes {
      v(0.7em)
      block(width: 100%, fill: bm-colors.card, stroke: 1pt + accent.lighten(30%), inset: (x: 14pt, y: 12pt), radius: 8pt)[
        #text(size: 14pt, fill: bm-colors.muted)[Trình bày lời giải vào vở hoặc tài liệu phát tay.]
      ]
    }
  ]

  if mode == "loigiai" and loigiai != none {
    slide(title: none)[
      #v(-0.5em)
      #box(fill: bm-colors.correct, inset: (x: 10pt, y: 6pt), radius: 4pt)[
        #text(weight: "bold", fill: white, size: 16pt)[#prefix #num — LỜI GIẢI]
      ]
      #v(0.6em)
      #block(width: 100%, fill: rgb("#0c1a3a"),
        stroke: (left: 3pt + bm-colors.gold),
        inset: (x: 14pt, y: 10pt), radius: (right: 6pt),
      )[
        #text(weight: "bold", fill: bm-colors.gold, size: 14pt)[📝 Lời giải]
        #v(0.2em)
        #set text(size: 13pt, fill: rgb("#cbd5e1"))
        #loigiai
      ]
    ]
  }
}

#let tn = mcq
#let ds = tf
#let tln = short

// ── exam-mode ────────────────────────────────────────────
#let exam-mode(mode: "loigiai", accent: bm-colors.accent) = (
  tn:    tn.with(mode: mode, accent: accent),
  ds:    ds.with(mode: mode, accent: accent),
  tln:   tln.with(mode: mode, accent: accent),
  tl:    tl.with(mode: mode, accent: accent),
  mcq:   mcq.with(mode: mode, accent: accent),
  tf:    tf.with(mode: mode, accent: accent),
  short: short.with(mode: mode, accent: accent),
)

// ── het ──────────────────────────────────────────────────
#let het = slide(title: none)[
  #align(center + horizon)[
    #text(weight: "bold", size: 40pt, fill: bm-colors.gold)[— HẾT —]
    #v(0.6em)
    #text(size: 18pt, fill: bm-colors.muted)[
      Cảm ơn các em đã theo dõi bài giảng! \
      Chúc các em ôn thi tốt! 🎓
    ]
  ]
]

// ── No-ops ───────────────────────────────────────────────
#let print-answer-key() = {}
#let thpt-school-exam(body, ..args) = body
