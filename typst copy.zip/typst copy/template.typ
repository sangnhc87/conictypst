// ═══════════════════════════════════════════════════════════
// STEXGV TEMPLATE ECOSYSTEM
// Hệ sinh thái Typst chuẩn mực cho Toán học
// ═══════════════════════════════════════════════════════════

// Export các công cụ dùng chung
#import "modules/exam.typ": palette, classic, tn, ds, tln, tl, mcq, tf, short, exam-part, het, print-answer-key, exam-mode, ppgiai, luuy, meo, giainhanh, lythuyet, note, dn, dl, tc, bode, setcounter, resetcounter, setcau, resetcau, setphan, resetphan
#import "modules/book.typ": stexgv-book, chapter, topic, dang, vd, vidu, bt, baitap, nhanxet, ghinho, phuongphap, definition
#import "modules/research.typ": stexgv-research

// ─────────────────────────────────────────────────────────
// HÀM ĐIỀU PHỐI CHÍNH (ROUTER)
// ─────────────────────────────────────────────────────────
#let stexgv-doc(
  doc-type: "book", // "exam" | "book" | "outline" | "research"
  title: "TÀI LIỆU STEXGV",
  author: "Tác Giả",
  theme-color: classic.blue,
  
  // Tham số cho đề thi
  department: "BỘ GIÁO DỤC VÀ ĐÀO TẠO",
  school: "SỞ GIÁO DỤC VÀ ĐÀO TẠO",
  duration: "90 phút",
  structure: "12 câu trắc nghiệm, 4 đúng/sai, 1 điền đáp án",
  code: "",
  footer-left: none,
  
  // Tham số cho NCKH
  abstract: none,
  keywords: (),
  two-columns: true,

  body
) = {
  if doc-type == "exam" {
    import "modules/exam.typ": thpt-school-exam
    show: thpt-school-exam.with(
      department: department,
      school: school,
      exam-title: title,
      subject: "MÔN TOÁN",
      duration: duration,
      structure: structure,
      code: code,
      footer-left: footer-left,
      accent: theme-color
    )
    body
  } else if doc-type == "book" or doc-type == "outline" {
    show: stexgv-book.with(
      title: title,
      author: author,
      theme-color: theme-color,
      doc-type: doc-type
    )
    body
  } else if doc-type == "research" {
    show: stexgv-research.with(
      title: title,
      authors: (author,),
      abstract: abstract,
      keywords: keywords,
      two-columns: two-columns,
      theme-color: theme-color
    )
    body
  } else {
    // Fallback mặc định
    body
  }
}
